"""Read-only deterministic actor inference; no PPO, optimizer or simulator imports."""
import argparse,hashlib,json,pathlib,sys
import torch
from torch import nn
ROOT=pathlib.Path(__file__).resolve().parent
class Policy(nn.Module):
 def __init__(self,saved,device='cpu'):
  super().__init__();self.metadata=saved['metadata'];o=self.metadata['obs_dim'];a=self.metadata['action_dim']
  with torch.random.fork_rng(devices=[]):self.actor=nn.Sequential(nn.Linear(o,64),nn.Tanh(),nn.Linear(64,64),nn.Tanh(),nn.Linear(64,a))
  self.actor.load_state_dict(saved['actor_state'],strict=True)
  self.register_buffer('mean',saved['obs_stats']['mean']);self.register_buffer('var',saved['obs_stats']['var'])
  self.to(device);self.eval();self.requires_grad_(False)
 @torch.no_grad()
 def forward(self,raw,clip_actions=False):
  x=torch.as_tensor(raw,dtype=torch.float32,device=self.mean.device)
  if x.ndim not in (1,2) or x.shape[-1]!=self.mean.numel() or not x.numel() or not bool(torch.isfinite(x).all()):raise ValueError('Invalid observation shape or nonfinite values')
  y=self.actor(((x-self.mean)/(self.var+1e-8).sqrt()).clamp(-10,10))
  if not bool(torch.isfinite(y).all()):raise ValueError('Nonfinite action')
  return y.clamp(-1,1) if clip_actions else y

def load_policy(environment,seed=None,method='Full',device='cpu'):
 manifest=json.loads((ROOT/'POLICY_MANIFEST.json').read_text())
 if seed is None:
  if method!='Full':raise ValueError('Specify seed for a comparison method')
  seed=manifest['best_full_by_final'][environment]
 row=next(x for x in manifest['models'] if x['environment']==environment and x['method']==method and x['seed']==seed)
 p=ROOT/row['path']
 if hashlib.sha256(p.read_bytes()).hexdigest()!=row['policy_sha256']:raise ValueError('Model checksum mismatch')
 saved=torch.load(p,map_location='cpu',weights_only=True)
 if saved['metadata']['source_checkpoint_sha256']!=row['source_checkpoint_sha256']:raise ValueError('Source checkpoint mismatch')
 return Policy(saved,device)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--environment',required=True);p.add_argument('--seed',type=int);p.add_argument('--method',default='Full');p.add_argument('--input',type=pathlib.Path);p.add_argument('--device',default='cpu');a=p.parse_args()
 raw=json.loads(a.input.read_text() if a.input else sys.stdin.read());policy=load_policy(a.environment,a.seed,a.method,a.device)
 print(json.dumps({'metadata':policy.metadata,'raw_action_mean':policy(raw).cpu().tolist(),'clipped_control':policy(raw,True).cpu().tolist()},ensure_ascii=False))
