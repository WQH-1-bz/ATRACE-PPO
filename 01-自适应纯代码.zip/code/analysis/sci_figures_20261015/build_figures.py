from pathlib import Path
import json,csv,statistics,math,zipfile,html,xml.etree.ElementTree as ET
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator,FuncFormatter
import argparse
parser=argparse.ArgumentParser(description='Reproduce four-environment Fig.2–7 from the separately supplied weights/data package.')
parser.add_argument('--weights-root',type=Path,required=True)
parser.add_argument('--out',type=Path,default=Path('figure_outputs'))
args=parser.parse_args();A=args.weights_root.resolve();O=args.out.resolve();O.mkdir(parents=True,exist_ok=True)
ENVS=['HalfCheetah','Swimmer','PointMaze','CartpoleSwingup'];TITLES=['HalfCheetah','Swimmer','PointMaze','Cartpole Swingup'];SEEDS=list(range(21,29))
METHODS=['fixed90','fixed95','fixed99','linear','critic_aware','gradient_ppo','reward_profiling','pae','Full']
LABEL={'fixed90':'Fixed λ=0.90','fixed95':'Base (λ=0.95)','fixed99':'Fixed λ=0.99','linear':'Linear schedule','critic_aware':'Critic-aware GAE','gradient_ppo':'Gradient PPO','reward_profiling':'Reward Profiling','pae':'PAE','Full':'Full','innovation1':'Feedback only','innovation2':'Tail only'}
COL={'fixed90':'#C58A49','fixed95':'#55585B','fixed99':'#8D79A9','linear':'#4C948A','critic_aware':'#7BA2B8','gradient_ppo':'#BA7580','reward_profiling':'#B39B55','pae':'#7F9274','Full':'#153E65','innovation1':'#C58A49','innovation2':'#4C948A'}
STYLE={'fixed90':(0,(5,2)),'fixed95':'-','fixed99':(0,(2,1.8)),'linear':(0,(6,1.8,1.2,1.8)),'critic_aware':(0,(4,2)),'gradient_ppo':(0,(2,2)),'reward_profiling':(0,(6,2,1,2)),'pae':(0,(5,1.5,1,1.5,1,1.5)),'Full':'-'}
mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':7,'axes.labelsize':7,'axes.titlesize':8,'axes.titleweight':'normal','xtick.labelsize':6.5,'ytick.labelsize':6.5,'legend.fontsize':7,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,'legend.frameon':False,'savefig.facecolor':'white'})
D=json.loads((A/'report_source/data.json').read_text());DATA={};CURVES={};raw=[];finalraw=[];CURVEROW=[];LAM={};lambda_raw=[];lambda_summary=[];targets=[]
for e in ENVS:
 for m in METHODS+['innovation1','innovation2']:
  ys=[];grids=[]
  for seed in SEEDS:
   p=A/'models'/e/m/f'seed{seed}';ev=[json.loads(s) for s in (p/'evaluations.jsonl').read_text().splitlines()];ini=json.loads((p/'initial_evaluation.json').read_text());hist=[(0,ini['mean'])]+[(v['steps'],v['mean']) for v in ev]
   xx=np.array([x[0] for x in hist]);yy=np.array([x[1] for x in hist]);assert np.all(np.diff(xx)>0) and xx[-1]==10027008
   auc=float(np.sum(np.diff(xx)*(yy[:-1]+yy[1:])/2)/xx[-1]);idx=SEEDS.index(seed);mm=D['environments'][e]['methods'][m]
   assert abs(auc-mm['auc'][idx])<1e-6 and abs(yy[-1]-mm['final'][idx])<1e-6
   finalraw.append([e,LABEL[m],seed,float(yy[-1]),auc]);ys.append(yy);grids.append(xx)
   if m in METHODS:
    for step,y in hist:raw.append([e,LABEL[m],seed,int(step),step/1e6,y])
  assert all(np.array_equal(x,grids[0]) for x in grids)
  y=np.array(ys);DATA[e,m]={'final':y[:,-1],'auc':np.array(D['environments'][e]['methods'][m]['auc'])};CURVES[e,m]=(grids[0]/1e6,y.mean(0),y.std(0,ddof=1))
  if m in METHODS:
   for x,mean,sd in zip(*CURVES[e,m]):CURVEROW.append([e,LABEL[m],int(round(x*1e6)),x,mean,sd,8])
 for seed in SEEDS:
  p=A/'models'/e/'Full'/f'seed{seed}';c=json.loads((p/'config.json').read_text());pr=list(csv.DictReader((p/'progress.csv').open()));xx=np.array([0]+[int(x['steps']) for x in pr])/1e6;yy=np.array([float(pr[0]['gae_lambda_used'])]+[float(x['gae_lambda_used']) for x in pr]);assert np.all(np.diff(xx)>0)
  LAM[e,seed]=(xx,yy,c['stage_switch_steps']/1e6)
  for x,y in zip(xx,yy):lambda_raw.append([e,seed,int(round(x*1e6)),x,y,c['stage_switch_steps']])
  if (p/'lambda_decisions.jsonl').exists():
   for line in (p/'lambda_decisions.jsonl').read_text().splitlines():
    row=json.loads(line)
    if 'target' in row:targets.append([e,seed,row['update'],row['steps'],row.get('realized_kl',''),row.get('ema',''),row.get('reference',''),row['target'],row['used']])
 for i,x in enumerate(LAM[e,21][0]):
  vals=[LAM[e,s][1][i] for s in SEEDS];lambda_summary.append([e,int(round(x*1e6)),x,float(np.mean(vals)),float(np.std(vals,ddof=1)),min(vals),max(vals),8])
(O/'FIGURE_CONTRACT.md').write_text('''# Figure contract
Backend: saved Python preference, matplotlib only. Quantitative grids, editable PDF/SVG and600dpiPNG/TIFF.
User-requested environment subset: HalfCheetah,Swimmer,PointMaze,Cartpole Swingup; Walker2d omitted only from display, never silently from the original statistical correction family.
Fig2 internal learning; Fig3 external learning: each method's native actual evaluation steps, eight-seed arithmetic mean±sampleSD; no smoothing, no interpolation, no resampling. Different methods can have different native evaluation times.
Fig4 nine-method Final/AUC summaries plus allseed observations. Fig5 paired Full−Base means with95%two-sidedtCI df7; existingHolm10comparisonfamily retained; only requested significantAUCpanels annotated. Fig6 actual task-specific fourarm configurations, notstrict matchedfactorial. Fig7 actualactorlambda staircase traces; sharedrange within each row; stageboundary4.980736million.
All eight seeds21–28 retained. n denotes independent training seeds, not episodes. No modelselection/subsetselection of seeds. Colours: darknavyFull, darkgreyBase, muted distinctbaseline colours plus dash patterns. Lower fontfloor6.5pt, width183mm.
''')
def save(fig,name):
 fig.savefig(O/f'{name}.pdf');fig.savefig(O/f'{name}.svg');fig.savefig(O/f'{name}.png',dpi=600);fig.savefig(O/f'{name}.tiff',dpi=600);plt.close(fig)
def panel(ax,letter,title):
 ax.set_title(title,pad=7);ax.text(-.04,1.07,letter,transform=ax.transAxes,fontweight='bold',fontsize=9,va='bottom');ax.grid(axis='y',color='#E5E9ED',linewidth=.45,zorder=0)
def legend_handles(ms):return [Line2D([0],[0],color=COL[m],lw=2.2 if m=='Full' else 1.4,ls=STYLE.get(m,'-'),label=LABEL[m]) for m in ms]
def learning(ms,name):
 fig,axes=plt.subplots(2,2,figsize=(7.2047244094,5.4));fig.subplots_adjust(left=.105,right=.985,bottom=.17,top=.93,hspace=.48,wspace=.29)
 for ax,e,title,l in zip(axes.flat,ENVS,TITLES,'abcd'):
  panel(ax,l,title)
  for m in ms:
   x,mu,sd=CURVES[e,m];ax.fill_between(x,mu-sd,mu+sd,color=COL[m],alpha=.12 if m=='Full' else .085,lw=0,zorder=1)
   ax.plot(x,mu,color=COL[m],ls=STYLE[m],lw=2.0 if m=='Full' else 1.25,zorder=5 if m=='Full' else 3)
  ax.set_xlim(0,10.027008);ax.set_xticks([0,2,4,6,8,10]);ax.yaxis.set_major_locator(MaxNLocator(5));ax.set_xlabel('Fresh transitions (million)');ax.set_ylabel('Evaluation return')
 fig.legend(handles=legend_handles(ms),loc='lower center',bbox_to_anchor=(.52,.005),ncol=3,handlelength=2.6,columnspacing=1.8,labelspacing=.7)
 save(fig,name)
INTERNAL=['fixed90','fixed95','fixed99','linear','Full'];EXTERNAL=['fixed95','critic_aware','gradient_ppo','reward_profiling','pae','Full']
learning(INTERNAL,'Fig2_internal_learning');learning(EXTERNAL,'Fig3_external_learning')
# Point-interval summaries; raw paired seed positions deterministic, never randomized.
SUM=[]
for e in ENVS:
 for metric in ['final','auc']:
  for m in METHODS:
   vals=DATA[e,m][metric];SUM.append([e,'Final return' if metric=='final' else 'Normalized AUC',LABEL[m],float(vals.mean()),float(vals.std(ddof=1)),8])
fig,axes=plt.subplots(2,4,figsize=(7.2047244094,5.6),sharey='row');fig.subplots_adjust(left=.19,right=.99,bottom=.12,top=.92,wspace=.32,hspace=.4)
for r,metric in enumerate(['final','auc']):
 for j,(e,title) in enumerate(zip(ENVS,TITLES)):
  ax=axes[r,j];ax.set_title(title if r==0 else '',pad=8);ax.text(-.04,1.04,'abcdefgh'[r*4+j],transform=ax.transAxes,fontweight='bold',fontsize=8)
  for k,m in enumerate(METHODS):
   vals=DATA[e,m][metric];offs=np.linspace(-.16,.16,8);ax.scatter(vals,k+offs,color=COL[m],alpha=.25,s=6,edgecolors='none',zorder=2)
   ax.errorbar(vals.mean(),k,xerr=vals.std(ddof=1),fmt='o',color=COL[m],ms=4.3 if m=='Full' else 3.7,lw=1.1,capsize=2,zorder=4)
  ax.set_yticks(range(9));ax.set_yticklabels([LABEL[m] for m in METHODS]);ax.set_ylim(8.55,-.6);ax.xaxis.set_major_locator(MaxNLocator(3));ax.tick_params(axis='y',length=0);ax.grid(axis='x',color='#E7EAED',lw=.45)
  ax.xaxis.set_major_formatter(FuncFormatter(lambda x,pos:f'{x/1000:g}k' if abs(x)>=1000 else f'{x:g}'));ax.set_xlabel('Final return' if r==0 else 'Normalized AUC')
save(fig,'Fig4_all_methods_final_auc')
# Paired CI from preserved five-environment, two-metric main correction family.
ST=list(csv.DictReader((A/'statistics/paired_statistics.csv').open(encoding='utf-8-sig')));PAIR=[];PAIRRAW=[]
fig,axes=plt.subplots(2,4,figsize=(7.2047244094,4.2));fig.subplots_adjust(left=.095,right=.99,bottom=.16,top=.91,wspace=.35,hspace=.56)
for row,metric in enumerate(['final','auc']):
 for j,(e,title) in enumerate(zip(ENVS,TITLES)):
  ax=axes[row,j];s=next(v for v in ST if v['环境']==e and v['指标']==metric and v['对比方法']=='Base：固定λ=0.95');diff=DATA[e,'Full'][metric]-DATA[e,'fixed95'][metric];mean=float(diff.mean());lo=float(s['95%CI下界']);hi=float(s['95%CI上界']);p=float(s['Holm校正p']);assert abs(mean-float(s['Full−对比均值']))<1e-9
  PAIR.append([e,metric,mean,lo,hi,float(s['双侧p']),p,8,7,'Original five environments × two metrics; 10 comparisons'])
  for seed,val in zip(SEEDS,diff):PAIRRAW.append([e,metric,seed,float(val)])
  ax.axvline(0,color='#9A9FA4',ls=(0,(3,2)),lw=.8,zorder=1);ax.scatter(diff,np.linspace(-.22,.22,8),color=COL['Full'],alpha=.3,s=13,edgecolors='none',zorder=3)
  ax.errorbar(mean,0,xerr=np.array([[mean-lo],[hi-mean]]),fmt='o',color=COL['Full'],ms=5,lw=1.6,capsize=3,zorder=4)
  ax.set_ylim(-.5,.6);ax.set_yticks([]);ax.spines['left'].set_visible(False);ax.xaxis.set_major_locator(MaxNLocator(3));ax.set_title(title if row==0 else '',pad=10);ax.text(-.04,1.07,'abcdefgh'[row*4+j],transform=ax.transAxes,fontweight='bold',fontsize=8)
  ax.set_xlabel('Δ Final return' if row==0 else 'Δ Normalized AUC')
  if metric=='auc' and e in ['PointMaze','CartpoleSwingup']:
   shown='0.0025' if e=='PointMaze' else '0.0049';assert abs(p-float(shown))<.00006;ax.text(.5,.88,r'$p_{\mathrm{adj}} = '+shown+'$',ha='center',transform=ax.transAxes,color=COL['Full'],fontsize=8)
save(fig,'Fig5_full_base_paired_difference')
# Four actual component arms, same seed lines.
ARMS=['fixed95','innovation1','innovation2','Full'];COMP=[];COMPRAW=[]
fig,axes=plt.subplots(2,4,figsize=(7.2047244094,5.6));fig.subplots_adjust(left=.09,right=.99,bottom=.18,top=.92,wspace=.45,hspace=.64)
for row,metric in enumerate(['final','auc']):
 for j,(e,title) in enumerate(zip(ENVS,TITLES)):
  ax=axes[row,j];panel(ax,'abcdefgh'[row*4+j],title if row==0 else '')
  vals=np.array([DATA[e,m][metric] for m in ARMS]).T
  for line in vals:ax.plot(range(4),line,color='#B7C0C8',alpha=.5,lw=.65,marker='o',ms=1.6,zorder=1)
  for k,m in enumerate(ARMS):
   y=vals[:,k];ax.errorbar(k,y.mean(),yerr=y.std(ddof=1),fmt='o',color=COL[m],ms=4.5,lw=1.4,capsize=2.5,zorder=4);COMP.append([e,metric,LABEL[m],float(y.mean()),float(y.std(ddof=1)),8])
   for seed,v in zip(SEEDS,y):COMPRAW.append([e,metric,LABEL[m],seed,float(v)])
  ax.set_xticks(range(4));ax.set_xticklabels(['Base','Feedback only','Tail only','Full'],fontsize=6.5,rotation=40,ha='right',rotation_mode='anchor');ax.set_xlim(-.4,3.4);ax.yaxis.set_major_locator(MaxNLocator(4));ax.set_ylabel(('Final return' if metric=='final' else 'Normalized AUC') if j==0 else '')
save(fig,'Fig6_component_comparison')
# Actual trajectories as staircase intervals; no smoothing.
fig,axes=plt.subplots(2,2,figsize=(7.2047244094,4.7),sharey='row');fig.subplots_adjust(left=.11,right=.98,bottom=.19,top=.92,wspace=.24,hspace=.48)
for j,(ax,e,title) in enumerate(zip(axes.flat,ENVS,TITLES)):
 panel(ax,'abcd'[j],title);xx=LAM[e,21][0];mat=np.array([LAM[e,s][1] for s in SEEDS]);assert all(np.array_equal(LAM[e,s][0],xx) for s in SEEDS)
 for line in mat:ax.step(xx,line,where='pre',color='#7F9DB5',alpha=.38,lw=.7,zorder=2)
 ax.step(xx,mat.mean(0),where='pre',color=COL['Full'],lw=2.1,zorder=4);ax.axvline(LAM[e,21][2],color='#8A8F94',lw=.85,ls=(0,(4,3)),zorder=1)
 ax.set_ylim((.93,.955) if j<2 else (.982,.991));ax.set_xlim(0,10.027008);ax.set_xticks([0,2,4,6,8,10]);ax.set_xlabel('Fresh transitions (million)');ax.set_ylabel('Actor trace parameter λ')
fig.legend(handles=[Line2D([0],[0],color='#7F9DB5',alpha=.65,lw=.8,label='Individual seeds'),Line2D([0],[0],color=COL['Full'],lw=2.1,label='Eight-seed mean'),Line2D([0],[0],color='#8A8F94',lw=.85,ls=(0,(4,3)),label='Stage boundary')],loc='lower center',bbox_to_anchor=(.53,.025),ncol=3)
save(fig,'Fig7_actor_lambda_trajectories')
# Save clean source tables and editable multi-sheet workbook.
SHEETS=[]
def add(n,headers,rows):SHEETS.append((n,[headers]+rows))
for metric,tabname in [('final','Table1_Final_Return'),('auc','Table2_Normalized_AUC')]:
 add(tabname,['Method']+TITLES,[[LABEL[m]]+[f"{DATA[e,m][metric].mean():.3f} ± {DATA[e,m][metric].std(ddof=1):.3f}" for e in ENVS] for m in METHODS])
for metric,tabname in [('final','Table3_Components_Final'),('auc','Table4_Components_AUC')]:
 add(tabname,['Method']+TITLES,[[LABEL[m]]+[f"{DATA[e,m][metric].mean():.3f} ± {DATA[e,m][metric].std(ddof=1):.3f}" for e in ENVS] for m in ARMS])
hc=['Environment','Method','Fresh transitions','Fresh transitions (million)','Mean evaluation return','Sample SD','Training seeds']
add('Fig2_curve_mean_SD',hc,[v for v in CURVEROW if v[1] in [LABEL[m] for m in INTERNAL]])
add('Fig3_curve_mean_SD',hc,[v for v in CURVEROW if v[1] in [LABEL[m] for m in EXTERNAL]])
add('Learning_curve_raw',['Environment','Method','Seed','Fresh transitions','Fresh transitions (million)','Evaluation return'],raw)
add('Fig4_final_AUC_mean_SD',['Environment','Metric','Method','Mean','Sample SD','Training seeds'],SUM)
add('Fig4_final_AUC_raw',['Environment','Method','Seed','Final return','Normalized AUC'],[v for v in finalraw if v[1] in [LABEL[m] for m in METHODS]])
add('Fig5_paired_CI',['Environment','Metric','Mean paired difference','95% CI lower','95% CI upper','Two-sided paired t p','Holm adjusted p','Training seeds','df','Correction family'],PAIR)
add('Fig5_paired_raw',['Environment','Metric','Seed','Full minus Base'],PAIRRAW)
add('Fig6_component_mean_SD',['Environment','Metric','Method','Mean','Sample SD','Training seeds'],COMP)
add('Fig6_component_raw',['Environment','Metric','Method','Seed','Value'],COMPRAW)
add('Fig7_lambda_mean_SD',['Environment','Fresh transitions','Fresh transitions (million)','Mean actor lambda','Sample SD','Minimum','Maximum','Training seeds'],lambda_summary)
add('Fig7_lambda_raw',['Environment','Seed','Fresh transitions','Fresh transitions (million)','Actor lambda used','Stage boundary transitions'],lambda_raw)
add('Supp_target_lambda',['Environment','Seed','Update','Fresh transitions','Realized KL if logged','Fast statistic','Slow reference','Target lambda','Actual actor lambda'],targets)
CAPTIONS={
'Fig2':'Fig. 2 | Learning curves against internal λ baselines. Panels (a–d) show HalfCheetah, Swimmer, PointMaze and Cartpole Swingup. Lines show the arithmetic mean over eight training seeds (21–28); shaded regions show one sample standard deviation (ddof=1). Each method is plotted at its actual evaluation steps. No smoothing, interpolation or resampling is applied. The horizontal axis counts fresh training transitions.',
'Fig3':'Fig. 3 | Learning curves against external PPO methods. The four environments and eight training seeds are the same as in Fig. 2. Lines indicate means and shaded regions indicate sample standard deviations. Curves use native evaluation steps without smoothing or interpolation. Reward Profiling uses additional profiling interactions that are not included in the primary fresh-transition axis. These additional interactions are reported separately in the source-data workbook.',
'Fig4':'Fig. 4 | Final return and normalized return AUC for all nine methods. The first row shows final-checkpoint return and the second row shows normalized AUC; columns correspond to the four environments. Large points and horizontal intervals indicate eight-seed means and sample standard deviations. Faint points show all individual training seeds, with fixed vertical offsets for visibility. Every panel has its own horizontal scale. Normalized AUC is the trapezoidal integral of the native evaluation trajectory, including the initial evaluation, divided by 10,027,008 fresh transitions.',
'Fig5':'Fig. 5 | Paired Full–Base differences. The upper row shows final-return differences and the lower row shows normalized-AUC differences. Faint points represent all eight matched training seeds; dark points represent mean paired differences. Horizontal intervals are two-sided 95% t confidence intervals (df=7), not sample standard deviations. The vertical dashed line marks zero. Displayed Holm-adjusted p values retain the original family of ten Full–Base comparisons (five environments × two metrics), although Walker2d is omitted from this figure. Only PointMaze AUC (p_adj=0.0025) and Cartpole AUC (p_adj=0.0049) are annotated. Analyses are retrospective on development seeds; the confidence intervals are not multiplicity-adjusted.',
'Fig6':'Fig. 6 | Component comparisons in four environments. The first row shows final return and the second row shows normalized AUC. Within each panel, faint lines connect the same training seed across Base, Feedback only, Tail only and Full. Large points and intervals denote eight-seed means and sample standard deviations. The four arms represent the actual task-specific configurations rather than a strictly matched factorial ablation.',
'Fig7':'Fig. 7 | Actual actor trace-parameter trajectories. Faint step lines show all eight seeds and the dark line shows their arithmetic mean. No smoothing is applied. The dashed vertical line marks the predetermined stage boundary at 4,980,736 fresh transitions. The upper row shares a λ range of 0.930–0.955; the lower row shares 0.982–0.991. Swimmer remains at λ=0.95 and is shown without adding artificial variation. Target λ values, where preserved, are supplied separately in the source-data workbook.'}
# Extra budget table explicitly accompanies profiling caveat.
BUD=[]
for e in ENVS:
 for seed in SEEDS:
  s=json.loads((A/'models'/e/'reward_profiling'/f'seed{seed}'/'summary.json').read_text());BUD.append([e,seed,s['training_transitions'],s['profiling_extra_transitions'],s['total_algorithm_transitions']])
add('RewardProfiling_budget',['Environment','Seed','Primary fresh training transitions','Additional profiling interactions','Total algorithm interactions'],BUD)
add('Readme',[ 'Item','Definition'],[['Environments','Four requested environments; Walker2d excluded from all displayed figures'],['Seeds','All training seeds21–28; no performance-based exclusions'],['No smoothing','Native evaluation grids; no interpolation; each method has matching seed grids'],['Spread','Sample SD ddof=1 except Fig5 two-sided95% tCI df7'],['Statistics','Holm10-comparison original family retained; no four-environment recalculation'],['Components','Actual task-specific configurations; not strictly matched factorial ablation'],['Lambda','Actual used actor lambda from progress.csv; step intervals end at logged fresh-transition count'],['Target logs','Only preserved target fields; Walker2d excluded; Swimmer target fields not archived'],['Evaluation','32 deterministic episodes per evaluation, raw return; training seed is independent unit'],['AUC','Trapezoidal integration on each actual evaluation grid, divided by10027008']])
for n,data in SHEETS:
 with (O/(n+'.csv')).open('w',newline='',encoding='utf-8-sig') as f:csv.writer(f).writerows(data)
# Standalone XML workbook: numeric cells retain numeric precision.
xns='http://schemas.openxmlformats.org/spreadsheetml/2006/main';rns='http://schemas.openxmlformats.org/officeDocument/2006/relationships';pns='http://schemas.openxmlformats.org/package/2006/relationships'
def col(n):
 s=''
 while n:n,j=divmod(n-1,26);s=chr(65+j)+s
 return s
def sheet(data):
 rows=[]
 for i,row in enumerate(data,1):
  cells=[]
  for j,v in enumerate(row,1):
   addr=f'{col(j)}{i}';style=1 if i==1 else 0
   if isinstance(v,(int,float,np.floating)) and math.isfinite(v):cells.append(f'<c r="{addr}" s="{style}"><v>{v}</v></c>')
   else:cells.append(f'<c r="{addr}" s="{style}" t="inlineStr"><is><t>{html.escape(str(v))}</t></is></c>')
  rows.append(f'<row r="{i}">'+''.join(cells)+'</row>')
 return f'<worksheet xmlns="{xns}"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" state="frozen"/></sheetView></sheetViews><cols>'+''.join(f'<col min="{i}" max="{i}" width="{28 if i<4 else 25}" customWidth="1"/>' for i in range(1,len(data[0])+1))+'</cols><sheetData>'+''.join(rows)+f'</sheetData><autoFilter ref="A1:{col(len(data[0]))}{len(data)}"/></worksheet>'
styles=f'<styleSheet xmlns="{xns}"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF153E65"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'
with zipfile.ZipFile(O/'Fig2-7_SourceData.xlsx','w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'+''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1,len(SHEETS)+1))+'</Types>')
 z.writestr('_rels/.rels',f'<Relationships xmlns="{pns}"><Relationship Id="rId1" Type="{rns}/officeDocument" Target="xl/workbook.xml"/></Relationships>')
 z.writestr('xl/workbook.xml',f'<workbook xmlns="{xns}" xmlns:r="{rns}"><sheets>'+''.join(f'<sheet name="{n}" sheetId="{i}" r:id="rId{i}"/>' for i,(n,_) in enumerate(SHEETS,1))+'</sheets></workbook>')
 z.writestr('xl/_rels/workbook.xml.rels',f'<Relationships xmlns="{pns}">'+''.join(f'<Relationship Id="rId{i}" Type="{rns}/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1,len(SHEETS)+1))+f'<Relationship Id="rId{len(SHEETS)+1}" Type="{rns}/styles" Target="styles.xml"/></Relationships>')
 z.writestr('xl/styles.xml',styles)
 for i,(_,data) in enumerate(SHEETS,1):z.writestr(f'xl/worksheets/sheet{i}.xml',sheet(data))
with zipfile.ZipFile(O/'Fig2-7_SourceData.xlsx') as z:
 assert z.testzip() is None
 for n in z.namelist():ET.fromstring(z.read(n))
(O/'Figure_captions.txt').write_text('\n\n'.join(CAPTIONS.values()))
md='# Four-environment results: Figures 2–7\n\n'
for i,base in [(2,'Fig2_internal_learning'),(3,'Fig3_external_learning'),(4,'Fig4_all_methods_final_auc'),(5,'Fig5_full_base_paired_difference'),(6,'Fig6_component_comparison'),(7,'Fig7_actor_lambda_trajectories')]:
 md+=f'## Fig. {i}\n\n![]({base}.png){{width=17cm}}\n\n'+CAPTIONS[f'Fig{i}']+'\n\n'
(O/'Figures_and_captions.md').write_text(md)
(O/'DATA_QA.json').write_text(json.dumps({'state':'passed','display_environments':ENVS,'omitted_environment':'Walker2d per user instruction','all_eight_seeds_retained':True,'methods_learning_grids_identical_across_seeds':True,'no_smoothing_interpolation_or_resampling':True,'final_auc_independently_recomputed':True,'original_Holm_family':10,'fig5_statistics':PAIR,'lambda_ranges':{e:[float(min(LAM[e,s][1].min() for s in SEEDS)),float(max(LAM[e,s][1].max() for s in SEEDS))] for e in ENVS},'workbook_sheets':len(SHEETS),'source_rows':{n:len(d)-1 for n,d in SHEETS}},indent=2))
print('Created six figure sets, CSV tables and',len(SHEETS),'sheet workbook.')
