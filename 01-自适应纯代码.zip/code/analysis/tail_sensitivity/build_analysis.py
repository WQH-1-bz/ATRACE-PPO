from pathlib import Path
import json,csv,statistics,math
ROOT=Path('/home/mumu08/ssd_2/wch/dpo');OUT=Path(__file__).resolve().parent
source=ROOT/'archive/cleanup_20261011/parent_receipts/pointmaze_tail_sensitivity_terminal16_collect_20261012/stdout.txt'
x=json.loads(source.read_text());assert x['state']=='passed'
assert all(r['verified']['consumed_target_replay']['split_trace_target_replay']=='passed' and r['verified']['consumed_target_replay']['split_trace_audit_count']==3 for r in x['runs'] if r['tail']!=16)
(OUT/'verified_results.json').write_text(json.dumps(x,indent=2,ensure_ascii=False))
(OUT/'per_seed_results.csv').write_text(x['results_csv'],encoding='utf-8-sig')
rows=x['analysis']['rows'];summary=x['analysis']['summary']
base=summary['16'];diff=[]
for L in [8,16,24]:
 d={'tail':L}
 for m in ['final_return','auc']:
  d[m+'_mean']=summary[str(L)][m]['mean'];d[m+'_sd']=summary[str(L)][m]['sd'];d[m+'_diff16']=d[m+'_mean']-base[m]['mean'];d[m+'_pct16']=100*d[m+'_diff16']/base[m]['mean']
 diff.append(d)
with (OUT/'summary.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(diff[0]));w.writeheader();w.writerows(diff)
contract='''# Figure contract
Conclusion: Tail length16 has the highest observed eight-seed mean Final and normalized AUC; observed differences across8/16/24 are small in this task.
Archetype: quantitative grid, two complementary panels (Final and AUC).
Backend: saved Python/matplotlib preference.
All24observations retained; grey lines pair the same seeds21–28; coloured summary points show mean ± sample SD, not CI.
No hypothesis test or significance/equivalence claim. L16 uses archived results after exact short admission, L8/L24 new training.
183×78mm, fonts>=7pt, SVG/PDF editable, PNG600dpi. Source data per_seed_results.csv, summary.csv and verified_results.json.
'''
(OUT/'FIGURE_CONTRACT.md').write_text(contract)
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':8,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.7})
fig,axes=plt.subplots(1,2,figsize=(7.2047244094,3.0708661417));fig.subplots_adjust(left=.09,right=.99,bottom=.23,top=.86,wspace=.33)
for ax,m,label,letter in zip(axes,['final_return','auc'],['Final return','Normalized return AUC'],['a','b']):
 vals=np.array([[next(r[m] for r in rows if r['seed']==s and r['tail']==L) for L in [8,16,24]] for s in range(21,29)])
 assert vals.shape==(8,3) and np.isfinite(vals).all()
 for y in vals:ax.plot([8,16,24],y,'o-',color='#B3BCC4',lw=.65,ms=2.4,alpha=.7,zorder=1)
 ax.errorbar([8,16,24],vals.mean(0),yerr=vals.std(0,ddof=1),fmt='o-',color='#1F627E',lw=1.7,ms=5,capsize=3,zorder=3)
 ax.set_xticks([8,16,24]);ax.set_xlabel('Retained tail length (steps)');ax.set_ylabel(label);ax.set_xlim(5,27);ax.text(-.16,1.06,letter,transform=ax.transAxes,fontweight='bold',fontsize=9)
 ax.grid(axis='y',color='#E7EBEF',lw=.5,zorder=0)
fig.text(.5,.035,'All eight seeds (21–28); paired seed traces; mean ± sample SD',ha='center',fontsize=7)
fig.savefig(OUT/'tail_sensitivity.svg')
fig.savefig(OUT/'tail_sensitivity.pdf')
fig.savefig(OUT/'tail_sensitivity.png',dpi=600)
fig.savefig(OUT/'tail_sensitivity.tiff',dpi=600)
plt.close(fig)
def tab(headers,rr):return '| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+''.join('| '+' | '.join(map(str,r))+' |\n' for r in rr)+'\n'
md='''# PointMaze 尾段长度参数敏感性分析

## 实验设计

在 PointMaze_UMazeDense-v3 上保持 Full 的两项机制均启用，仅改变创新点2的尾段保留长度，比较8、16和24步。每个取值均使用21—28全部八个种子。8步和24步各新增八次训练，16步复用已有八次结果；复用前已核对配置，并通过原实现与修改实现的16步短训练精确一致性验证。

每次训练采集10,027,008条新转移；1024个并行环境、64步基础窗口、batch为1024、每批10轮优化。阶段切换点为4,980,736条转移，actor优势初始λ为0.99，critic λ为0.95；KL反馈控制器、网络、优化器、奖励和评估规则保持一致。每次评估32个回合，评估间隔为262,144条新转移。AUC按实际评估步数作梯形积分，再除以总新采样预算，数值越高越好。

## 八种子结果

'''
md+=tab(['尾段长度','最终回报（均值 ± SD）','AUC（均值 ± SD）'],[[L,f"{summary[str(L)]['final_return']['mean']:.3f} ± {summary[str(L)]['final_return']['sd']:.3f}",f"{summary[str(L)]['auc']['mean']:.3f} ± {summary[str(L)]['auc']['sd']:.3f}"] for L in [8,16,24]])
md+='''![图1 尾段长度敏感性。灰色点及连线表示相同种子的配对成绩，蓝色点及误差线表示八种子均值与样本标准差。](tail_sensitivity.png){width=17cm}

16步的两项均值均最高。相对16步，8步最终回报低0.310（约0.119%），AUC低0.934（约0.371%）；24步最终回报低0.156（约0.060%），AUC低0.079（约0.031%）。这些数值支持在当前任务与参数范围内，平均成绩变化较小，保留16步作为当前默认设置。本实验未检验统计等价或跨任务稳健性，不能把均值接近解释为已证明等价。

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```

## 完整逐种子结果

下表保留全部八种子，单元格依次为最终回报／AUC。没有挑选种子或舍弃不利参数点。

'''
md+=tab(['种子','8步：回报／AUC','16步：回报／AUC','24步：回报／AUC'],[[s]+[f"{next(r['final_return'] for r in rows if r['seed']==s and r['tail']==L):.3f}／{next(r['auc'] for r in rows if r['seed']==s and r['tail']==L):.3f}" for L in [8,16,24]] for s in range(21,29)])
md+='''## 实现核验与预算

16个新训练全部正常完成。已从初始评估和39次训练评估独立复算最终回报及AUC，且与汇总文件一致。每次训练的actor和critic各执行97,920次优化，新转移与直接训练样本总数均为10,027,008。不同尾段长度会改变窗口数量：8步、16步和24步分别为164、178和198个窗口，控制器也随窗口更新；优化总量保持不变。该实验反映实际尾段长度配置的整体敏感性，不把差异全部归因为上下文长度。

全部新训练均通过控制器逐窗回放、样本账本核对及3个保存窗口的实际actor／critic标签CUDA回放，共48个窗口。8步与24步均通过跨GPU短训练精确一致性验证，各种子的初始评估也与原16步结果一致。

本次新训练在两张RTX 5090上每卡并发8个，使用确定性Torch和Warp计算。8步与24步分布于不同GPU；短训练核验支持执行一致性，但没有另做全预算跨卡重复实验。历史16步与本次运行时间的硬件负载和并发条件不同，不据此作算法速度排名。

本结果补齐了一个代表环境、一个关键新增参数、三个取值、全部八种子的参数敏感性实验。它不替代严格匹配的四组组件消融，也不改变其他补充项目的审核状态。
'''
(OUT/'report.md').write_text(md)
(OUT/'ANALYSIS_QA.json').write_text(json.dumps({'state':'passed','new_training_runs':16,'archived_reference_runs':8,'all_rows_retained':24,'independent_auc_recomputation':'passed','native_target_audits':48,'all16_receipts_rc0_wait_reaped':True,'no_significance_or_equivalence_claim':True,'summary':diff},indent=2))
print(json.dumps(diff,indent=2))
