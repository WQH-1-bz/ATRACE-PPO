from pathlib import Path
import json,csv,statistics,math,itertools,hashlib,zipfile,html,xml.etree.ElementTree as ET
from scipy import stats
import numpy as np
R=Path('/home/mumu08/ssd_2/wch/dpo');A=R/'archive/current';O=Path(__file__).resolve().parent
D=json.loads((A/'report_source/data.json').read_text());envs=D['environment_order'];methods=D['method_order'];seeds=D['seeds']
names={'fixed90':'固定λ=0.90','fixed95':'Base：固定λ=0.95','fixed99':'固定λ=0.99','linear':'线性λ调度','critic_aware':'Critic-aware自适应GAE','gradient_ppo':'Gradient PPO','reward_profiling':'PPO+Lookback Reward Profiling','pae':'PAE','innovation1':'仅创新点1','innovation2':'仅创新点2','Full':'Full'}
def read(p):return json.loads(p.read_text())
def lines(p):return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]
def f(v):return f'{v:.3f}'
def pair(a,b):
 ds=np.asarray(a)-np.asarray(b);mean=float(ds.mean());sd=float(ds.std(ddof=1));se=sd/math.sqrt(8);t=mean/se if se else 0;p=float(stats.t.sf(abs(t),7)*2) if se else (0. if mean else 1.)
 exact=sum(abs(float(np.mean(ds*np.array(sig))))>=abs(mean)-1e-12 for sig in itertools.product([-1,1],repeat=8))/256
 return {'diff':mean,'lo':mean-stats.t.ppf(.975,7)*se,'hi':mean+stats.t.ppf(.975,7)*se,'t':t,'p':p,'exact_p':exact,'positive_seeds':sum(ds>0),'ds':ds.tolist()}
SAVED=read(O/'saved_optimizer_counts.json')
ST=[]
for e in envs:
 for metric in ['final','auc']:
  for m in methods[:8]:
   ST.append({'env':e,'metric':metric,'control':m,'family':'主比较10项：Full对固定0.95，五环境×两指标' if m=='fixed95' else '次比较70项：Full对其他七基线，五环境×两指标',**pair(D['environments'][e]['methods']['Full'][metric],D['environments'][e]['methods'][m][metric])})
for fam in set(x['family'] for x in ST):
 group=sorted([x for x in ST if x['family']==fam],key=lambda x:x['p']);running=0
 for i,x in enumerate(group):running=max(running,min(1,(len(group)-i)*x['p']));x['holm']=running
sheets=[]
def add(name,headers,rows,widths=None):sheets.append((name,[headers]+rows,widths or [22]*len(headers)))
# Full numerical main tables; all11methods,allfive tasks.
for metric,title in [('final','最终回报主表'),('auc','AUC主表')]:
 rr=[]
 for m in methods:
  rr.append([names[m]]+[f"{D['environments'][e]['methods'][m]['mean_'+metric]:.3f} ± {D['environments'][e]['methods'][m]['sd_'+metric]:.3f}" for e in envs])
 add(title,['方法']+envs,rr,[35]+[27]*5)
add('完整440组成绩',['环境','方法','种子','最终回报','AUC'],[[e,names[m],s,D['environments'][e]['methods'][m]['final'][i],D['environments'][e]['methods'][m]['auc'][i]] for e in envs for m in methods for i,s in enumerate(seeds)],[22,35,10,24,24])
add('配对差与统计',['环境','指标','对比方法','n','Full−对比均值','95%CI下界','95%CI上界','配对t','df','双侧p','Holm校正p','精确符号翻转p','正差种子数','比较族'],[[x['env'],x['metric'],names[x['control']],8,x['diff'],x['lo'],x['hi'],x['t'],7,x['p'],x['holm'],x['exact_p'],int(x['positive_seeds']),x['family']] for x in ST],[20,12,35,8,23,23,23,18,8,22,22,22,16,62])
# Swimmer robust summaries and raw paired leave-one-out values.
SW=[]
for m in methods:
 mm=D['environments']['Swimmer']['methods'][m]
 for metric in ['final','auc']:
  v=np.asarray(mm[metric]);q=np.quantile(v,[.25,.75]);SW.append([names[m],metric,float(v.mean()),float(v.std(ddof=1)),float(np.median(v)),float(q[0]),float(q[1]),float(q[1]-q[0])])
add('Swimmer稳健统计',['方法','指标','均值','SD','中位数','Q1','Q3','IQR'],SW,[35,12]+[23]*6)
add('Swimmer逐种子稳健',['对比方法','指标','种子','Full','对比成绩','配对差','留出该种子后7种子平均差'],[[names[m],metric,s,D['environments']['Swimmer']['methods']['Full'][metric][i],D['environments']['Swimmer']['methods'][m][metric][i],x['ds'][i],statistics.mean(x['ds'][:i]+x['ds'][i+1:])] for m in methods[:8] for metric in ['final','auc'] for x in ST if x['env']=='Swimmer' and x['control']==m and x['metric']==metric for i,s in enumerate(seeds)],[35,12,10,24,24,24,34])
# Component results and actual independent configuration differences.
AR=[];CF=[];ME=[];CO=[];RE=[];BRAW=[]
for e in envs:
 for m in ['fixed95','innovation1','innovation2','Full']:
  mm=D['environments'][e]['methods'][m];p=A/'models'/e/m/'seed21';c=read(p/'config.json')
  AR.append([e,names[m],int(m in ['innovation1','Full']),int(m in ['innovation2','Full']),mm['mean_final'],mm['sd_final'],mm['mean_auc'],mm['sd_auc']])
  CF.append([e,names[m],c.get('initial_lambda',c.get('gae_lambda')),c.get('retained_tail_steps',0),c.get('stage_switch_steps','无'),c.get('fixed_critic_lambda',c.get('full_composition',{}).get('critic_lambda',.95)),c.get('num_envs'),c.get('rollout'),c.get('batch_size'),c.get('epochs'),c.get('actor_lr',c.get('learning_rate','见原配置')),json.dumps(c.get('actor_controller_design',c.get('lambda_design',c.get('adaptive_lambda_design',{}))),ensure_ascii=False)])
 for m in methods:
  vals=[]
  for seed in seeds:
   p=A/'models'/e/m/f'seed{seed}';c=read(p/'config.json');s=read(p/'summary.json');evals=lines(p/'evaluations.jsonl');ini=read(p/'initial_evaluation.json')
   hist=[(0,ini['mean'])]+[(v['steps'],v['mean']) for v in evals]
   assert hist[-1][0]==10027008 and all(a[0]<b[0] for a,b in zip(hist,hist[1:])),p
   auc=sum((b[0]-a[0])*(a[1]+b[1])/2 for a,b in zip(hist,hist[1:]))/10027008
   i=seeds.index(seed);assert abs(auc-D['environments'][e]['methods'][m]['auc'][i])<1e-6,p
   assert abs(evals[-1]['mean']-D['environments'][e]['methods'][m]['final'][i])<1e-6,p
   train=s.get('training_transitions',s['steps']);total=s.get('total_algorithm_transitions',train);extra=s.get('profiling_extra_transitions',0);op=s.get('optimizer_steps') or SAVED.get(f'{e}/{m}/seed{seed}',{});evsteps=sum(sum(v.get('lengths',[])) for v in [ini]+evals)
   cost=[e,names[m],seed,train,extra,total,evsteps,op.get('actor','未记录'),op.get('critic','未记录'),op.get('h','未记录'),s.get('elapsed_seconds'),s.get('steps_per_second'),c.get('device'),json.dumps(c.get('determinism'),ensure_ascii=False)]
   BRAW.append(cost);vals.append(cost)
   RE.append([e,names[m],seed,str((p/'config.json').relative_to(R)),hashlib.sha256((p/'config.json').read_bytes()).hexdigest(),json.dumps(c.get('source_sha256',{}),ensure_ascii=False),c.get('xml_sha256','未记录'),str((p/'policy.pt').relative_to(R)),len(evals),len(ini.get('returns',[])),c.get('eval_every'),c.get('task_adapter',{}).get('benchmark_id',e),json.dumps(c.get('task_adapter',{}),ensure_ascii=False)])
  med=lambda index:statistics.median(v[index] for v in vals) if all(isinstance(v[index],(int,float)) for v in vals) else '未记录'
  CO.append([e,names[m],8,med(3),min(v[4] for v in vals),max(v[4] for v in vals),min(v[5] for v in vals),max(v[5] for v in vals),med(6),med(7),med(8),med(9),med(10)/60,med(11),'历史硬件／负载／并发不同；耗时不作方法速度排名'])
 # actual lambda range and controller fields.
 for seed in seeds:
  p=A/'models'/e/'Full'/f'seed{seed}';c=read(p/'config.json');prog=list(csv.DictReader((p/'progress.csv').open()));dec=lines(p/'lambda_decisions.jsonl') if (p/'lambda_decisions.jsonl').exists() else []
  lam=[float(v['gae_lambda_used']) for v in prog];targets=[v['target'] for v in dec if isinstance(v.get('target'),(int,float))]
  ctrl=c.get('actor_controller_design',c.get('full_composition',c.get('adaptive_lambda_design',{})))
  ME.append([e,seed,len(prog),min(lam),max(lam),lam[-1],min(targets) if targets else '归档progress不含目标列',max(targets) if targets else '归档progress不含目标列',len(dec),c.get('retained_tail_steps'),c.get('stage_switch_steps'),json.dumps(ctrl,ensure_ascii=False),json.dumps(c.get('retained_tail_trace_design',{}),ensure_ascii=False)])
add('四组组件成绩',['环境','组别','I1开关','I2开关','回报均值','回报SD','AUC均值','AUC SD'],AR,[22,30,12,12]+[23]*4)
add('四组实际配置',['环境','组别','初始λ','尾段长度','阶段边界','critic λ','并行环境','基础窗口','batch','epochs','actor lr','控制器实际配置'],CF,[22,30,14,14,22,28,16,16,14,12,25,100])
add('机制参数与轨迹',['环境','种子','窗口数','实际λ最小','实际λ最大','实际λ末值','目标λ最小','目标λ最大','控制日志行数','尾段长度','阶段边界','反馈与控制器','密度比及尾段递推'],ME,[22,10,14,22,22,22,30,30,18,14,22,100,120])
add('成本预算汇总',['环境','方法','种子数','每种子训练交互中位数','辅助交互最小','辅助交互最大','算法总交互最小','算法总交互最大','评估交互中位数','actor优化中位数','critic优化中位数','h优化中位数','耗时中位数分钟','吞吐中位数steps每秒','说明'],CO,[20,35,12]+[24]*11+[70])
add('成本预算逐种子',['环境','方法','种子','训练交互','辅助profiling交互','算法总交互','评估交互','actor优化次数','critic优化次数','h优化次数','耗时秒','吞吐steps每秒','device','确定性配置'],BRAW,[20,35,10]+[24]*10+[70])
add('实现复现索引',['环境','方法','种子','配置路径','配置SHA256','源代码SHA256','环境XML SHA256','推理权重路径','训练评估次数','每次评估回合','评估间隔','环境标识','环境适配实际配置'],RE,[22,35,10,90,80,120,80,90,18,18,18,40,130])
S=read(R/'reports/pointmaze_tail_sensitivity_20261012/verified_results.json')['analysis']
add('参数敏感性',['尾段长度','种子','最终回报','AUC','数据来源'],[[x['tail'],x['seed'],x['final_return'],x['auc'],'原16步结果；短训练与初始评估一致性核验' if x['tail']==16 else '本次完整10027008新转移训练；CUDA／控制器回放通过'] for x in S['rows']],[18,10,25,25,95])
add('方法实际超参数',['环境','方法','代表种子','并行环境','基础窗口','batch','epochs','初始λ','评估环境数','评估间隔','完整实际配置'],[[e,names[m],21]+[read(A/'models'/e/m/'seed21/config.json').get(k,'见完整配置') for k in ['num_envs','rollout','batch_size','epochs','initial_lambda','eval_envs','eval_every']]+[json.dumps(read(A/'models'/e/m/'seed21/config.json'),ensure_ascii=False)] for e in envs for m in methods],[22,35,12,16,16,16,16,16,18,22,160])
F=read(R/'research/baselines_2025_2026/frozen_baseline_manifest.json');P=read(R/'research/baselines_2025_2026/implementation_audit_v2.json')
EXT=[]
notes={
 'critic_aware':('最后minibatch价值损失趋势控制λ；策略每两epoch更新，价值每epoch更新；clipped value loss','λ初值.95，范围.70—.99；步长.090−.085×训练比例；10epochs；actor/critic lr3e-4，按轮退火','GPU共享骨干；区分真实终止与时间截断；作者年份2025、期刊年次来源存在差异，按归档信息标注'),
 'gradient_ppo':('TDRC(λ)、辅助h网络；保留δλ梯度和独立actor/critic/h优化器','λ=.95，β=1，4epochs；actor lr3e-4，critic/h lr3e-3；同world连续32步序列','作者JAX实现移植PyTorch／GPU共享骨干；终止与截断统一后端处理'),
 'reward_profiling':('单一PPO+Lookback变体；策略更新后独立profiling轨迹作接受／回退','profile_chunks=10；PPO共享lr3e-4；辅助实际交互见成本逐种子表','GPU共享骨干；profiling轨迹与报告评估隔离，额外交互明确计入算法预算'),
 'pae':('保留partial GAE与窗口前缀训练／尾段延后使用','λ=.95，基础窗口64；前缀48／尾段16，10epochs；实际各任务配置见复现索引','2025卷期、2024在线、2023预印本；作者实现两个仓库commit记录；共享GPU移植结果不等于原论文分数复现')}
for x in F['methods']:
 m=x['id'];core,hyp,adapt=notes[m];repo=x.get('repo_url','https://github.com/decatt/drl-jyz ; https://github.com/decatt/phd_thesis');commit=x.get('commit',json.dumps(P['pae_sources']))
 EXT.append([names[m],x['title'],x.get('year',x.get('year_note')),x.get('venue','按论文／作者仓库信息'),x['primary_url'],repo,commit,core,hyp,adapt])
add('四外部方法适配',['方法','原论文','年份说明','刊物','论文来源','作者代码','代码commit','保留的方法步骤','实际参数摘要','移植与版本说明'],EXT,[32,75,90,70,85,85,90,100,110,120])
fulltext='；'.join(f"{e}：{D['environments'][e]['methods']['Full']['mean_final']:.3f}±{D['environments'][e]['methods']['Full']['sd_final']:.3f}／{D['environments'][e]['methods']['Full']['mean_auc']:.3f}±{D['environments'][e]['methods']['Full']['sd_auc']:.3f}" for e in envs)
stattext='；'.join(f"{x['env']} {x['metric']}：差{x['diff']:.3f}，95%CI[{x['lo']:.3f},{x['hi']:.3f}]，Holm p={x['holm']:.4g}" for x in ST if x['control']=='fixed95')
swfull=[x for x in SW if x[0]=='Full'];swtext='；'.join(f"{x[1]}中位数{x[4]:.3f}，IQR{x[7]:.3f}" for x in swfull)
main=[
 ['1','五环境完整八种子主结果', '五环境×11方法×8种子，共440次结果。种子21—28全部保留。Full最终回报／AUC：'+fulltext+'。其他方法完整均值±SD列入两张主表。环境及参数经历结果驱动开发，主表不使用事后筛选种子。','最终回报主表；AUC主表；完整440组成绩'],
 ['2','配对统计与Swimmer稳健性','Full对Base完整8种子配对统计：'+stattext+'。双侧配对t、df=7；95% t区间；补充256种符号翻转检验。Holm分主比较10项及次比较70项，属于本次回顾性整理，非原实验预注册。Swimmer Full：'+swtext+'；保留全部逐种子配对差和逐一留一结果。','配对差与统计；Swimmer稳健统计；Swimmer逐种子稳健'],
 ['3','四组组件实验','完整列出五环境Base、仅I1、仅I2、Full各8种子的均值±SD及实际配置。HalfCheetah四组共同初始λ=.95，I2／Full尾段8；Full按新转移4980736切换，控制器按实际窗口更新。PointMaze Full初始λ=.99、尾段16，而单独I1初始.95、单独I2尾段8；Cartpole Full另有critic早期.99、后期.95。因此表中列的是各实际配置组件比较，不改称仅两个开关变化的统一实现实验。','四组组件成绩；四组实际配置；完整440组成绩'],
 ['4','机制与诊断','创新1：训练反馈→周期目标λ→受限小步实际λ，跟踪率.1、最大步长.001、每4有效窗口更新目标。HalfCheetah／PointMaze用KL快慢统计；Walker2d／Swimmer用NCS优势跨度信号；Cartpole用sqrt(clip(1−EV,0,1))价值残差反馈。创新2：早期保留尾段并补充后续上下文，阶段边界4980736，之后64步普通窗口。ρ=exp(当前冻结策略log密度−原行为log密度)，TD用未截断ρ，连续递推用min(1,ρ)，新段ρ=1。实际8种子λ范围、目标字段和窗口数逐行填写。本次PointMaze长度实验16次控制器回放、48个保存窗口CUDA标签回放均通过。','机制参数与轨迹；参数敏感性；单次模型配置与评估索引'],
 ['5','关键参数敏感性','PointMaze Full尾段8／16／24，全8种子；两项均值±SD依次为259.680±4.183／250.703±1.664、259.990±2.987／251.638±1.758、259.833±3.089／251.559±1.638。16步复用原结果；8／24新增16次完整训练。各次10027008新转移、actor／critic各97920次优化；窗口数164／178／198。保留所有取值和种子。','参数敏感性；独立Word参数敏感性报告'],
 ['6','外部方法适配','四方法为Critic-aware、Gradient PPO、PPO+Lookback Reward Profiling、PAE。表中逐项填写论文题目、年份说明、论文地址、作者代码、commit、保留算法步骤、实际参数及GPU移植改动。共同使用64×64骨干及GPU环境适配；表内结果为共享骨干移植比较，非原论文分数复现。PAE版本及critic-aware刊年信息按实际来源注明。','四外部方法适配；实现复现索引'],
 ['7','成本与预算','五环境11方法全部440次的训练交互、辅助profiling交互、算法总交互、报告评估交互、actor／critic／h优化、耗时、吞吐均逐行填写，并汇总方法中位数和范围。主训练预算10027008；Reward Profiling额外交互单列，不作为免费数据。Full历史耗时中位数：HalfCheetah100.67分钟，Walker2d245.97分钟，Swimmer263.07分钟，PointMaze36.26分钟，Cartpole50.92分钟。历史硬件与并发不同，不按耗时作算法速度结论。','成本预算汇总；成本预算逐种子'],
 ['8','实现与复现','440次当前主结果逐一关联配置路径、配置SHA256、源代码哈希、环境XML哈希、policy.pt推理权重、评估次数／回合数／间隔和实际环境适配配置。观测／折扣回报归一化、真实终止取消自举、时间截断保留终态自举并切断跨回合递推。Torch确定性、Warp run_to_run/max_records8、CUBLAS :4096:8；本次PointMaze运行时Python3.11.13、Torch2.8.0+cu128、MuJoCo3.12.0、mujoco-warp3.12.0、Warp1.17.0。推理入口archive/current/inference.py；依赖记录及历史核验材料共同列入来源。','实现复现索引；archive/current/FILE_MANIFEST.json；POLICY_MANIFEST.json']]
sheets.insert(0,('客户需求填写总表',[['序号','客户项目','具体填写内容','对应明细表']]+main,[8,32,150,65]))
add('报告与开发说明',['项目','填写内容'],[
 ['统计单位','独立训练种子为n=8，评估回合不作为独立训练重复'],['种子／排除','21—28全部使用；无因低分排除种子；不以三／五种子筛选结果作为主结论'],['统计分析时间','2026-10-12对既有开发结果作回顾性整理；比较族在本次计算脚本中固定，非原实验预注册'],['比较族','主比较：Full对固定.95，五环境×Final/AUC共10项；次比较：Full对其他七内部／外部基线，共70项，分别Holm校正'],['指标','最终保存checkpoint的确定性原始回报；AUC从初始到最终按实际新采样步数梯形积分／总预算'],['Swimmer分位数','numpy.quantile线性插值；逐一留一为每次去掉一个种子后的剩余7个配对差均值'],['组件解释','单独机制／Full历史配置不同，实际配置并列列出；不把它们直接说成严格两开关2×2'],['环境变化','研究经历噪声实验、常规任务开发与任务替换；当前五环境为开发后选择，不能称独立确认性任务集'],['代码与成本','所有表格由build_filled_tables.py读取归档配置、summary和评估记录计算；不启动训练或改变权重'],['依赖','统计使用Python及SciPy；依赖具体版本列见本目录DATA_AUDIT.json；PointMaze本次训练依赖由RUNTIME_VERIFIED复核']],[35,150])
# Minimal editable workbook with numeric cells and frozen headers.
xns='http://schemas.openxmlformats.org/spreadsheetml/2006/main';rns='http://schemas.openxmlformats.org/officeDocument/2006/relationships';pns='http://schemas.openxmlformats.org/package/2006/relationships'
def col(n):
 out=''
 while n:n,j=divmod(n-1,26);out=chr(65+j)+out
 return out
def sheet(data,widths):
 rr=[]
 for i,row in enumerate(data,1):
  cc=[]
  for j,v in enumerate(row,1):
   if v is None:v='未记录'
   if isinstance(v,(int,float)) and math.isfinite(v):t=f'<c r="{col(j)}{i}" s="{1 if i==1 else 2}"><v>{v}</v></c>'
   else:t=f'<c r="{col(j)}{i}" s="{1 if i==1 else 2}" t="inlineStr"><is><t xml:space="preserve">{html.escape(str(v))}</t></is></c>'
   cc.append(t)
  rr.append(f'<row r="{i}" ht="{30 if i==1 else (180 if len(data)==9 and len(widths)==4 else 45)}" customHeight="1">'+''.join(cc)+'</row>')
 return f'<worksheet xmlns="{xns}"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" state="frozen"/></sheetView></sheetViews><cols>'+''.join(f'<col min="{i}" max="{i}" width="{w}" customWidth="1"/>' for i,w in enumerate(widths,1))+'</cols><sheetData>'+''.join(rr)+f'</sheetData><autoFilter ref="A1:{col(len(widths))}{len(data)}"/><pageMargins left="0.3" right="0.3" top="0.4" bottom="0.4" header="0.2" footer="0.2"/><pageSetup orientation="landscape" paperSize="9" fitToWidth="1" fitToHeight="0"/></worksheet>'
styles=f'<styleSheet xmlns="{xns}"><fonts count="2"><font><sz val="11"/><name val="Microsoft YaHei"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Microsoft YaHei"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF234E70"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'
with zipfile.ZipFile(O/'客户需求_完整填写表.xlsx','w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'+''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1,len(sheets)+1))+'</Types>')
 z.writestr('_rels/.rels',f'<Relationships xmlns="{pns}"><Relationship Id="rId1" Type="{rns}/officeDocument" Target="xl/workbook.xml"/></Relationships>')
 z.writestr('xl/workbook.xml',f'<workbook xmlns="{xns}" xmlns:r="{rns}"><sheets>'+''.join(f'<sheet name="{n}" sheetId="{i}" r:id="rId{i}"/>' for i,(n,*_) in enumerate(sheets,1))+'</sheets></workbook>')
 z.writestr('xl/_rels/workbook.xml.rels',f'<Relationships xmlns="{pns}">'+''.join(f'<Relationship Id="rId{i}" Type="{rns}/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1,len(sheets)+1))+f'<Relationship Id="rId{len(sheets)+1}" Type="{rns}/styles" Target="styles.xml"/></Relationships>')
 z.writestr('xl/styles.xml',styles)
 for i,(n,data,widths) in enumerate(sheets,1):z.writestr(f'xl/worksheets/sheet{i}.xml',sheet(data,widths))
for n,data,widths in sheets:
 with (O/(n+'.csv')).open('w',encoding='utf-8-sig',newline='') as f:csv.writer(f).writerows(data)
# Filled table in Word, numbered sections prevent over-wide tables.
md='# 客户需求完整填写表\n\n'
for row in main:
 md+='## '+row[0]+' '+row[1]+'\n\n| 填写项 | 具体内容 |\n| --- | --- |\n| 实验与分析内容 | '+row[2].replace('|','／')+' |\n| 对应数据表 | '+row[3]+' |\n\n'
(O/'filled_table.md').write_text(md)
import scipy
with zipfile.ZipFile(O/'客户需求_完整填写表.xlsx') as z:
 assert z.testzip() is None
 for n in z.namelist():ET.fromstring(z.read(n))
assert len(RE)==len(BRAW)==440 and len(ST)==80 and len(S['rows'])==24 and len(ME)==40
(O/'DATA_AUDIT.json').write_text(json.dumps({'state':'verified','sheets':len(sheets),'main_result_runs':440,'paired_comparisons':80,'seeds':seeds,'swimmer_summaries':len(SW),'mechanism_seed_rows':40,'sensitivity_rows':24,'no_new_training':True,'source_results_sha256':hashlib.sha256((A/'report_source/data.json').read_bytes()).hexdigest(),'statistics_scipy':scipy.__version__,'numpy':np.__version__,'xlsx_zip_xml':'passed','all_eight_seeds_retained':True,'all440_final_and_auc_independently_recomputed':True,'184_missing_summary_optimizer_counts_read_from_saved_Adam_state':True},ensure_ascii=False,indent=2))
print(json.dumps({'workbook':str(O/'客户需求_完整填写表.xlsx'),'sheets':len(sheets),'rows440':len(RE),'paired80':len(ST)},ensure_ascii=False))
