from pathlib import Path
import json,torch
R=Path('/home/mumu08/ssd_2/wch/dpo');out={}
for p in (R/'archive/current/models').glob('*/*/seed*/summary.json'):
 if p.parent.parent.parent.name not in ['HalfCheetah','Walker2d','Swimmer','PointMaze','CartpoleSwingup']:continue
 s=json.loads(p.read_text())
 if isinstance(s.get('optimizer_steps'),dict):continue
 cp=torch.load(p.parent/'latest.pt',map_location='cpu',weights_only=False);op=cp.get('optimizer');assert op is not None,p
 counts={float(v['step']) for v in op['state'].values() if 'step' in v};assert len(counts)==1,(p,counts)
 n=int(counts.pop());out[str(p.parent.relative_to(R/'archive/current/models'))]={'actor':n,'critic':n,'h':0,'source':'saved joint Adam state; all parameter counters equal'}
(R/'reports/customer_filled_tables_20261012/saved_optimizer_counts.json').write_text(json.dumps(out,indent=2));print('Read exact saved Adam counts:',len(out))
