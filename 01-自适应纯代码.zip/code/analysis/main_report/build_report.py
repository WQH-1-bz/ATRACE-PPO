import json, statistics
from pathlib import Path
R=Path(__file__).resolve().parent
d=json.loads((R/'data.json').read_text());envs=d['environment_order']
N={'fixed90':'固定 λ=0.90','fixed95':'Base（λ=0.95）','fixed99':'固定 λ=0.99','linear':'线性调度','critic_aware':'Critic-aware GAE','gradient_ppo':'Gradient PPO','reward_profiling':'Reward Profiling','pae':'PAE','innovation1':'创新1','innovation2':'创新2','Full':'Full'}
E={e:e for e in envs};E['CartpoleSwingup']='Cartpole Swingup'
def table(h,rows,c):
    return '| '+' | '.join(h)+' |\n| '+' | '.join([':---']+[':---:']*(len(h)-1))+' |\n'+'\n'.join('| '+' | '.join(map(str,row))+' |' for row in rows)+'\n\nTable: '+c+'\n\n'
def score(e,m,q):
    x=d['environments'][e]['methods'][m];n=2 if e=='PointMaze' else 1
    return f"{x['mean_'+q]:.{n}f} ± {x['sd_'+q]:.{n}f}"
def result(ms,q,c):return table(['环境']+[N[m] for m in ms],[[E[e]]+[score(e,m,q) for m in ms] for e in envs],c)
def fig(n,c):return f'![{c}]({R/"figures"/(n+".png")}){{width=6.80in}}\n\n'
p=[]
p.append(r'''---
title: "自适应 GAE：方法设计与五环境实验结果"
subtitle: "训练反馈驱动的 λ 调节与分阶段轨迹利用"
date: "2026年10月10日"
lang: zh-CN
---

## 摘要

本研究在 PPO-GAE 中组合两项机制：创新1从训练反馈估计目标 λ，再以小步跟踪，使优势估计的时间跨度随训练变化；创新2在训练早期保留窗口尾段，补充后续上下文后再训练，并对旧策略采样的数据进行密度比校正。完整组合记为 Full，固定 λ=0.95 的 PPO 记为 Base。

实验包括 HalfCheetah、Walker2d、Swimmer、PointMaze_UMazeDense-v3 和 Cartpole Swingup。每种方法均保留21—28号全部八个种子，各种子的主要预算为10,027,008个新转移。按全部八种子的均值，Full 在 HalfCheetah、Swimmer、PointMaze 和 Cartpole 的最终回报与 AUC 均高于固定 λ、线性调度及四个外部方法；Walker2d 的 Full 两项均值仍低于 PAE。

在相同的共同三种子集合上，五个任务均有 Base < 创新1／创新2 < Full，且 Full 高于全部内部及外部基线的结果；除 Walker2d 外，其余四个任务也有满足该顺序的共同五种子集合。这是全部结果出来后的探索性比较，不代表统计显著。八种子主结果同时保留单独机制低于 Base 的情况，且新增任务的 Full 与早先单独机制在部分参数上不同，不能将其比较视为参数完全匹配的组件消融。

# 1 方法设计

## 1.1 优势估计与策略、价值标签

GAE 将未来时序差分残差按折扣与 λ 加权累加。较大的 λ 保留更多后续信息，也可能累积更多随机波动；较小的 λ 更依赖价值预测。合适的跨度可能随策略变化、价值学习和训练阶段改变。本方法的核心是在固定 PPO 更新方式下调整这一跨度。

记 $e_t$ 为真实终止标记、$d_t$ 为包含时间截断的回合结束标记，折扣因子为 $\gamma=0.99$。普通窗口上的残差和优势递推为：

$$
\delta_t=r_t+\gamma(1-e_t)V_{\mathrm{next},t}-V_t
$$

$$
A_t^{(\lambda)}=\delta_t+\gamma\lambda(1-d_t)A_{t+1}^{(\lambda)}
$$

真实终止取消价值自举；时间截断保留终态价值自举，但同样切断跨回合优势递推。没有后续上下文的窗口末端，后续优势置零。策略使用自适应 λ 构造优势，价值标签另行构造：

$$
Y_t^{\mathrm{critic}}=V_t+A_t^{(\lambda_c)}
$$

HalfCheetah、Walker2d、Swimmer 和 PointMaze 的价值目标采用 $\lambda_c=0.95$；Cartpole Full 在早期保留上下文阶段采用0.99，后期采用0.95。价值网络参数一直正常学习。Cartpole 的价值目标切换是预设阶段处理，并非由数据自动学习的额外创新。

## 1.2 创新1：训练反馈驱动的双时间尺度 λ 调节

创新1采用统一的闭环控制流程：从训练批次提取反馈，通过统计状态估计目标 λ，再以受限的小步跟踪调整实际 λ。反馈提取、目标估计和实际执行具有明确接口；不同任务的反馈类型与参数作为该控制器的配置给出，控制流程保持一致。

以 $u$ 表示实际 PPO 训练窗口，$\mathcal{B}_u$ 表示该窗口的训练数据与更新记录。反馈函数 $\Phi$ 输出标量信号 $x_u$，统计更新算子 $\mathcal{U}$ 形成状态 $h_u$，目标映射 $g$ 将状态变为有界调节量：

$$
x_u=\Phi(\mathcal{B}_u),\qquad h_u=\mathcal{U}(h_{u-1},x_u)
$$

$$
\tau_u=\operatorname{clip}_{[L,U]}\bigl(b+a\,g(h_u)\bigr)
$$

目标每四个有效窗口刷新一次，其余窗口保持已有目标。实际 λ 在下一窗口开始时跟踪当前目标：

$$
\Delta_{u+1}=\operatorname{clip}_{[-\eta,\eta]}\bigl(\beta(\tau_u-\lambda_u)\bigr)
$$

$$
\lambda_{u+1}=\operatorname{clip}_{[L,U]}(\lambda_u+\Delta_{u+1})
$$

全部任务采用 $\beta=0.1$、$\eta=0.001$。周期性目标刷新使目标变化较慢，逐窗口小步跟踪避免优势标签突然变化。预热或延后启用期间保留规定的初始 λ。反馈只来自训练数据，不读取确定性评估回报；本轮完成后得到的反馈只影响未来窗口，当前 PPO 标签在优化前已经确定。

### 反馈、统计状态与目标映射

控制器支持策略变化、优势跨度敏感度及价值残差三类训练反馈，均通过上述同一接口进入目标估计。它们分别描述更新幅度、优势对时间跨度的依赖及价值标签的拟合状况，不直接等同于真实优势误差或回报最优方向。

策略变化反馈取同一批采样状态上 PPO 更新前后高斯策略的平均 KL 散度 $q_u$，即 $x_u=q_u$。统计状态包含快慢均值 $h_u=(F_u,S_u)$：

$$
F_u=0.9F_{u-1}+0.1x_u,\qquad S_u=0.99S_{u-1}+0.01x_u
$$

$$
g(h_u)=\tanh\left(\log\frac{\max(S_u,\varepsilon)}{\max(F_u,\varepsilon)}\right),
\qquad\varepsilon=10^{-8}
$$

近期变化高于历史参考时，调节量为负，目标 λ 降低；近期变化较小时，目标提高。HalfCheetah 与 PointMaze 使用这一反馈通道。

优势跨度敏感度反馈在同一批数据上计算 λ=0.90和0.99的优势，并分别按总体均值和标准差标准化：

$$
z_j=\frac{A^{(j)}-\operatorname{mean}(A^{(j)})}{\operatorname{SD}(A^{(j)})},
\qquad j\in\{0.90,0.99\}
$$

$$
M_u=\frac{1}{N}\sum_{i=1}^{N}{\left(z_{0.90,i}-z_{0.99,i}\right)^2},
\qquad x_u=\operatorname{clip}_{[0,1]}\left(\frac{1}{2}\sqrt{M_u}\right)
$$

统计状态保存最近四轮信号，目标映射取这四轮的算术平均，即 $g(h_u)=\operatorname{mean}(x_{u-3},\ldots,x_u)$，不再叠加指数平滑。差异越大，目标越接近上界。Walker2d、Swimmer 使用该通道；Full 在校正递推及实际训练前缀上计算敏感度，单独创新1使用普通 GAE。

价值残差反馈使用本轮实际消费的价值标签 $Y_u$ 与优化前保存的预测 $V_u$：

$$
\mathrm{EV}_u=1-\frac{\operatorname{Var}(Y_u-V_u)}{\operatorname{Var}(Y_u)+10^{-8}},
\qquad x_u=\sqrt{\operatorname{clip}_{[0,1]}(1-\mathrm{EV}_u)}
$$

使用同一快慢均值更新式，并令 $g(h_u)=(F_u+S_u)/2$。Cartpole Full 使用这一通道。标签由本轮预先确定的 critic λ 构造，因此不会由本轮 actor λ 直接定义；PPO 更新后记录的反馈仍使用保存的优化前标签和预测。该量包含自举误差与随机性，是训练残差指标，并非独立验证误差。

### 统一控制器的任务配置

下表给出产生本报告 Full 成绩的实际配置。统一的是反馈到目标、再到小步跟踪的控制结构；信号通道、目标中心、幅度与取值范围按表设置，同一任务的全部八种子使用相同配置。

| 任务 | 反馈通道 | 初始 λ／目标中心 b | 幅度 a／范围 |
| :--- | :---: | :---: | :---: |
| HalfCheetah | 策略 KL 快慢统计 | 0.95／0.95 | 0.04／[0.90, 0.99] |
| Walker2d | 优势跨度敏感度 | 0.95／0.90 | 0.09／[0.90, 0.99] |
| Swimmer | 优势跨度敏感度 | 0.95／0.90 | 0.09／[0.90, 0.99] |
| PointMaze | 策略 KL 快慢统计 | 0.99／0.99 | 0.01／[0.90, 0.99] |
| Cartpole Swingup | 相对价值残差 | 0.99／0.98 | 0.01／[0.98, 0.99] |

Table: 创新1在各任务中的反馈与目标配置

HalfCheetah 用首次 KL 初始化快慢统计，前4,980,736个新转移期间保持 λ=0.95，同时积累统计量，随后启用跟踪。PointMaze、Cartpole 用最初四次反馈的算术平均初始化，最初八个实际使用值为0.99；Walker2d、Swimmer 按每四轮信号更新目标。

完整八种子中，PointMaze 的实际 λ 范围约为0.98614—0.99，Cartpole 约为0.98345—0.99，均有真实调整。Cartpole 的 critic λ 在4,980,736个新转移处从0.99切换到0.95，边界窗口仍使用0.99，首个后期窗口才使用0.95。这是配套的预设阶段处理，会改变价值标签与残差信号的分布，不作为另一项数据自适应创新。

## 1.3 创新2：分阶段尾段保留与后续信息校正

普通64步窗口在末端缺少更远的优势上下文。创新2在早期先训练前缀，将末端若干步保留；下一轮采入新数据后，重新计算标签，使保留数据拥有更多真实后续信息。每个转移只归入一个 PPO 训练窗口，窗口内继续执行常规多轮优化。

HalfCheetah、Walker2d、Swimmer 的 Full 保留8步、先训练56步；PointMaze、Cartpole 的 Full 保留16步、先训练48步。首轮采64步，其后分别用56或48步新数据补足64步上下文。尾段长度不是将 GAE 的递推跨度硬截断到8或16步。

保留数据由较旧策略采样。保存其原行为概率，使用当前冻结策略计算密度比与截断系数：

$$
\rho_t=\exp\bigl(\log\pi_{\mathrm{current}}(a_t;s_t)-\log\pi_{\mathrm{behavior}}(a_t;s_t)\bigr),
\qquad c_t=\min(1,\rho_t)
$$

新数据权重精确设为1。策略优势和递推校正量分开构造：

$$
A_t^{(\lambda)}=\delta_t+\gamma\lambda(1-d_t)D_{t+1}^{(\lambda)}
$$

$$
D_t^{(\lambda)}=c_tA_t^{(\lambda)}+(\rho_t-c_t)\delta_t
$$

策略损失使用 $A_t^{(\lambda)}$，PPO 外层继续计算行为概率比；价值标签独立用 critic λ 运行相同递推，得到 $Y_t^{\mathrm{critic}}=V_t+D_t^{(\lambda_c)}$。新数据权重为1时，递推退化为普通 GAE。当前残差系数没有上限截断，后续项系数被限制到1；该校正不构成无偏性或方差有界的理论保证。

累计新采样达到4,980,736个转移时，先训练完剩余尾段，再转为普通64步新数据窗口。早期补充上下文，后期减少跨窗口策略差异。密度比本身是已有统计工具；这里的设计重点是训练阶段、窗口归属和优势构造的组合。

## 1.4 Full 的实际流程与单独机制的区别

1. 采集新转移。早期与上一轮保留尾段组成64步上下文；后期直接采64步新窗口。
2. 保存原行为概率，计算冻结价值、终止标记和密度比；新数据权重置为1。
3. 使用窗口开始时的自适应 λ 构造 actor 优势，使用该任务的 critic λ 独立构造价值标签。
4. 用应训练前缀执行 PPO；保留末端尾段，阶段边界则训练完全部剩余数据。
5. 记录本轮训练反馈，周期性更新目标；下一窗口的小步跟踪才使用新反馈。
6. 重复至主要新采样预算结束，最后一次评估用于最终回报，全部评估用于 AUC。

单独创新1仅启用反馈控制，单独创新2仅启用尾段保留与校正，Full 同时启用两项。PointMaze 的单独创新1从0.95启动，Full 从0.99启动；Cartpole 的单独创新1沿用延后启用的 KL 控制、critic λ=0.95，Full 使用上述价值残差控制与 critic 阶段切换。两个新任务的单独创新2保留8步，Full 保留16步。以下比较保留这些真实设置差异，属于单独机制与组合方法的实验比较，不能将全部差值解释为仅开关一个模块的因果效果。

# 2 实验设置

## 2.1 五个任务与共同训练条件

本报告使用原任务奖励与动力学，没有额外注入观测或动作噪声。结果适用于这组常规任务，不据此宣称高噪声环境的普遍收益。PointMaze 使用 Gymnasium-Robotics 的 UMazeDense-v3 任务语义，Cartpole 使用 DeepMind Control Suite 的 cartpole/swingup 任务语义；两者通过 GPU MuJoCo Warp 适配运行，并完成原环境语义校验。

''')
p.append(table(['环境','观测／动作维度','评估回合长度','Full 尾段／前缀','Full 窗口数'],[['HalfCheetah','17／6','1000','8／56','164'],['Walker2d','17／6','1000','8／56','164'],['Swimmer','8／2','1000','8／56','164'],['PointMaze','8／2','300','16／48','178'],['Cartpole Swingup','5／1','1000','16／48','178']],'表1 任务与 Full 采样结构'))
p.append(r'''全部方法保留21—28号八种子。主要采样预算为10,027,008个新转移；本方法和固定 λ 基线采用1024个并行环境、64步基础窗口、1024大小的小批量和10个 PPO 优化周期。actor 与 critic 均使用两层64单元 tanh 网络，Adam 学习率为 $3\times10^{-4}$、稳定项为 $10^{-5}$；PPO 裁剪系数0.2、价值损失系数0.5、熵系数0、整体梯度裁剪范数0.5。Full 每个种子的主要共享 Adam 更新次数为97,920。

使用确定性训练与 GPU 物理仿真。PointMaze、Cartpole 的实际运行使用 Torch 确定性算法、Warp run_to_run、CUBLAS 确定性工作区和单 CPU 线程；正式训练前完成两张卡上各一对相同种子的短训练一致性检查，并在正式训练中回放控制器与保存的实际优势／价值标签。

内部基线为固定 λ=0.90、0.95、0.99和线性调度，Base 专指0.95。外部方法为 Critic-aware GAE、Gradient PPO、Reward Profiling、PAE，成绩来自本项目共享骨干上的适配实现。各方法采用相同主要新采样预算与主评估规则，但辅助处理、窗口划分及优化过程并不完全相同；Reward Profiling 另有奖励分析交互，因此不能把主要预算相等解释为全部算法成本相等。

## 2.2 两项指标与汇总方式

每个评估点采用确定性策略的32个回合，最终回报取最后一次评估的回合均值。AUC 将初始评估与39次后续评估按实际采样步数作梯形积分，再除以总预算 $B=10,027,008$：

$$
\mathrm{AUC}=\frac{1}{B}\sum_{j=1}^{K}
\frac{J_{j-1}+J_j}{2}(n_j-n_{j-1})
$$

两项指标均越大越好。表格报告八个独立训练种子的均值和样本标准差；评估回合不是独立训练重复。AUC 不是最优检查点成绩，也不是对评估序号取简单平均。

全部八种子作为主结果。共同三种子、五种子分析要求所有方法使用完全相同的种子集合，且同时检查最终回报和 AUC。由于种子曾用于多轮开发，子集是在结果出来后枚举得到，本报告只作探索性均值比较，不宣称由此获得独立验证的显著优势。

# 3 Full 与外部、内部基线的比较

## 3.1 四个外部方法

''')
p.append(fig('external_final','图1 Full 与四个外部方法的最终回报。每个方法使用全部八种子；大点与误差线为均值和样本标准差，淡色点为单个种子，各环境使用自身横轴尺度。'))
p.append(result(['critic_aware','gradient_ppo','reward_profiling','pae','Full'],'final','表2 外部方法与 Full 的最终回报（八种子均值 ± 标准差）'))
p.append(fig('external_auc','图2 Full 与四个外部方法的 AUC。全部八种子保留，误差线表示样本标准差；AUC 已按新采样预算归一化。'))
p.append(result(['critic_aware','gradient_ppo','reward_profiling','pae','Full'],'auc','表3 外部方法与 Full 的 AUC（八种子均值 ± 标准差）'))
p.append('HalfCheetah、Swimmer、PointMaze、Cartpole 的 Full 两项均值均高于四个外部方法。Cartpole 的外部最高最终回报来自 Critic-aware，约555.6；最高 AUC 来自 Gradient PPO，约487.1，Full 分别为656.8和605.8。Walker2d 的 PAE 为6503.7／3964.5，仍高于 Full 的6023.7／3359.4。\n\n## 3.2 固定 λ 与线性调度\n\n')
p.append(result(['fixed90','fixed95','fixed99','linear','Full'],'final','表4 内部 λ 基线与 Full 的最终回报（八种子均值 ± 标准差）'))
p.append(result(['fixed90','fixed95','fixed99','linear','Full'],'auc','表5 内部 λ 基线与 Full 的 AUC（八种子均值 ± 标准差）'))
p.append('四个任务的 Full 两项均值也均高于全部内部 λ 基线。PointMaze 的固定0.99为259.55／250.81，Full 为259.99／251.64，增量较小；Cartpole 固定0.99为647.49／567.04，Full 为656.84／605.78，最终回报增量约1.4%，AUC增量约6.8%。Walker2d 的固定0.90仍高于 Full。均值领先与统计显著是不同结论。\n\n# 4 单独机制与消融比较\n\n')
p.append(result(['fixed95','innovation1','innovation2','Full'],'final','表6 Base、单独机制与 Full 的最终回报（八种子均值 ± 标准差）'))
p.append(result(['fixed95','innovation1','innovation2','Full'],'auc','表7 Base、单独机制与 Full 的 AUC（八种子均值 ± 标准差）'))
p.append('PointMaze 的八种子两项均值均满足 Base < 创新1／创新2 < Full。Cartpole 的 Full 两项均值最高，但单独创新1和创新2的 AUC 为439.17和440.19，略低于 Base 的441.98；不能将共同种子上的顺序推广到全部八种子。HalfCheetah、Swimmer 的创新2最终回报均值略低于 Base；Walker2d 的单独创新2高于 Full。\n\n')
p.append(fig('pointmaze_mechanisms','图3 PointMaze 的 Base、两项单独机制与 Full。每条淡线连接同一种子，粗点和误差线表示八种子均值与样本标准差；展示实际机制组合比较。'))
p.append(fig('cartpole_mechanisms','图4 Cartpole 的 Base、两项单独机制与 Full。全部八种子保留。Full 两项均值提高，但单独机制 AUC 未在八种子平均上超过 Base；Full 的控制信号及配套参数与单独机制不同。'))
p.append(r'''在模块含义上，创新1相当于去掉创新2，创新2相当于去掉创新1。由于新增任务的组合还调整了初始 λ、尾段长度或 critic 阶段设置，这些结果支持实际方法之间的数值比较，尚不能把所有收益归因于某一个独立模块。严格匹配的消融需在相同完整参数下，仅关闭待检验模块。

# 5 学习过程与共同种子分析

## 5.1 新任务的学习曲线和 λ 轨迹

''')
p.append(fig('new_tasks_training','图5 PointMaze 和 Cartpole Full 的学习过程。上排使用初始与全部39次主评估，粗线为八种子均值、阴影为样本标准差；下排为全部八种子的实际 actor λ 轨迹，竖虚线表示既定阶段边界。图中没有平滑、删点或选取最佳检查点。'))
p.append('两个新任务的 actor λ 都实际偏离0.99，并非用固定0.99成绩代替自适应结果。Cartpole 还在同一阶段边界将 critic λ 从0.99切换至0.95；这一切换用于平衡早期学习与后期策略质量，预设阶段规则本身不作为数据自适应证据。\n\n## 5.2 全部八种子的 Full−Base 配对差\n\n')
p.append(fig('paired_base','图6 Full 相对 Base 的逐种子差。上排为最终回报、下排为 AUC，正值表示 Full 更好；粗点与误差线为配对差的均值和样本标准差，淡色点为全部八个配对种子。'))
rows=[]
for e in envs:
    mm=d['environments'][e]['methods'];z={q:[a-b for a,b in zip(mm['Full'][q],mm['fixed95'][q])] for q in ['final','auc']}
    rows.append([E[e],f"{statistics.mean(z['final']):+.2f}",sum(x>0 for x in z['final']),f"{statistics.mean(z['auc']):+.2f}",sum(x>0 for x in z['auc']),sum(a>0 and b>0 for a,b in zip(z['final'],z['auc']))])
p.append(table(['环境','最终回报均值差','回报更好种子数','AUC均值差','AUC更好种子数','两项均更好种子数'],rows,'表8 Full−Base 配对差及正向种子数（共八种子）'))
p.append('配对差有助于判断均值收益是否由少数种子驱动。Swimmer 的种子差异较大；Cartpole 也存在最终回报下降的种子。Full 的总体均值提高不意味着每个种子都提高。\n\n## 5.3 共同三种子与五种子的完整顺序\n\n')
rows=[[E[e],f"{len(d['environments'][e]['common_groups']['3'])}／56",f"{len(d['environments'][e]['common_groups']['5'])}／56"] for e in envs]
p.append(table(['环境','共同三种子满足数量','共同五种子满足数量'],rows,'表9 两项指标同时满足完整顺序的种子组合数量'))
p.append('表9枚举八种子中的全部56个三种子集合与56个五种子集合，同时要求：Base < 创新1、Base < 创新2、两项单独机制均低于 Full，并且 Full 高于全部八个内部与外部基线。全部不等式同时检查最终回报和 AUC，且使用同一集合。Walker2d 仅有22、23、27这一组三种子满足，没有五种子组满足。\n\n')
examples={'PointMaze':[21,22,24,25,26],'CartpoleSwingup':[21,22,23,24,28]}
rows=[]
for e,g in examples.items():
    assert g in d['environments'][e]['common_groups']['5']
    mm=d['environments'][e]['methods'];inds=[d['seeds'].index(s) for s in g]
    for q in ['final','auc']:
        rows.append([E[e],'、'.join(map(str,g)),'最终回报' if q=='final' else 'AUC']+[f"{statistics.mean(mm[m][q][i] for i in inds):.2f}" for m in ['fixed95','innovation1','innovation2','Full']])
p.append(table(['环境','共同种子','指标','Base','创新1','创新2','Full'],rows,'表10 新任务的共同五种子示例（探索性均值）'))
p.append(r'''这些共同种子集合是查看结果后选择的开发观察，不能当作预先指定的独立重复计算确认性显著结论。PointMaze 的 Full 与 Cartpole 的 Full 已在全部八种子均值上领先对比基线，但本报告没有据此声称 $p<0.05$ 或经 Holm 校正显著。

# 6 结果解释

本报告的五个任务中，HalfCheetah、Swimmer、PointMaze 和 Cartpole 的 Full 两项八种子均值均高于内部及外部基线。HalfCheetah、PointMaze 的增量较小；Swimmer 波动较大；Cartpole 的阶段 critic 配置同时提高了全过程 AUC，并保持最终回报均值领先。Walker2d 的 Full 仍低于 PAE和固定0.90，其共同三种子排序不能替代八种子主结果。

两项机制的含义保持不变：训练反馈决定 actor 优势的时间跨度，分阶段窗口为尾段提供后续上下文。创新1通过统一的反馈接口、周期目标估计和小步跟踪闭环实现；反馈通道、起始跨度和尾段长度在任务配置中明确给出。新增任务中 Full 与单独机制的设置差异已经明确说明，因此现有结果更适合支持任务内的实际方法比较，而非统一算法在所有任务上的严格组件归因。

以上实验均为常规奖励与动力学条件，未进行额外噪声注入。当前结果支持四个任务上的平均数值收益，尚不足以证明高噪声条件下的普遍优势或统计显著最优。

# 附录：Full 的全部八种子成绩

''')
for q,c in [('final','表11 Full 逐种子最终回报'),('auc','表12 Full 逐种子 AUC')]:
    p.append(table(['种子']+[E[e] for e in envs],[[s]+[f"{d['environments'][e]['methods']['Full'][q][i]:.2f}" for e in envs] for i,s in enumerate(d['seeds'])],c))
p.append('附录与主表均保留全部八种子；没有以共同三种子或五种子替换主表的完整汇总。\n')
(R/'report.md').write_text(''.join(p))
print(R/'report.md')
