import json, statistics, itertools, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
old=json.loads((ROOT.parent/'current_results_20261008/data.json').read_text())
envs=['HalfCheetah','Walker2d','Swimmer','PointMaze','CartpoleSwingup']
methods=old['method_order']; seeds=list(range(21,29))
d={'environment_order':envs,'method_order':methods,'seeds':seeds,'environments':{},'native':{}}
sources=[]
for e in envs[:3]:
    d['environments'][e]={'methods':old['environments'][e]['methods']}
for e,n in [('PointMaze','pointmaze_full_prior99_r4'),('CartpoleSwingup','cartpole_full_stagecritic_residual_r6')]:
    p=Path('runs')/(n+'_8seed_20261010')/'PARENT_TERMINAL_VERIFIED.json'
    x=json.loads(p.read_text());assert x['source_exact'] and x['suite']['verified_count']==8
    sources.append({'source':str(p.resolve()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    rows=x['refs']+x['standalone']+x['results']['all_seeds']
    assert len(rows)==88
    by={(('Full' if r['method']=='full' else r['method']),r['seed']):r for r in rows}
    assert set(by)==set(itertools.product(methods,seeds))
    mm={}
    for m in methods:
        z={'seeds':seeds}
        for out,key in [('final','final_return'),('auc','auc')]:
            v=[by[m,s][key] for s in seeds]
            z[out]=v;z['mean_'+out]=statistics.mean(v);z['sd_'+out]=statistics.stdev(v)
        mm[m]=z
    d['environments'][e]={'methods':mm}
    d['native'][e]={'seeds':x['seeds']}
for e in envs:
    mm=d['environments'][e]['methods']
    gates={}
    for k in (3,5):
        good=[]
        for g in itertools.combinations(range(8),k):
            mean=lambda m,q:statistics.mean(mm[m][q][i] for i in g)
            if all(mean(m,q)>mean('fixed95',q) for m in ['innovation1','innovation2'] for q in ['final','auc']) and all(mean('Full',q)>mean(m,q) for m in methods if m!='Full' for q in ['final','auc']):
                good.append([seeds[i] for i in g])
        gates[str(k)]=good
    d['environments'][e]['common_groups']=gates
    if e in envs[:3]:
        for k in ('3','5'):assert len(gates[k])==old['environments'][e]['joint_gate']['subsets'][k]['stricter_count']
    else:
        n='pointmaze_full_prior99_r4' if e=='PointMaze' else 'cartpole_full_stagecritic_residual_r6'
        a=json.loads((Path('runs')/(n+'_8seed_20261010')/'PARENT_COMPLETE_ANALYSIS.json').read_text())
        assert gates==a['common_groups']
(ROOT/'data.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
(ROOT/'DATA_AUDIT.json').write_text(json.dumps({'retained_environments':envs[:3],'replaced_environments':['Hopper','Reacher'],'new_environments':envs[3:],'source_rows':440,'all_eight_seeds':seeds,'sources':sources,'old_document_source_sha256':hashlib.sha256((ROOT.parent/'current_results_20261008/data.json').read_bytes()).hexdigest(),'no_training_or_score_changes':True},indent=2)+'\n')
print('Verified 440 method-seed rows; original three environment scores retained.')
