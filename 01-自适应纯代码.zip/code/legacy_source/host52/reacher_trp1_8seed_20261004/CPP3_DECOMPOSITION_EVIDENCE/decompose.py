"""CPU-only exploratory decomposition of every frozen CPP3 target audit."""
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
NAMES = ('reward', 'current_value', 'internal_value', 'value_continuity',
         'time_limit_bootstrap', 'rollout_end_bootstrap')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def variance(x):
    x = x.ravel()
    return float(np.mean((x - x.mean()) ** 2))


def rms(x):
    return float(np.sqrt(np.mean(x ** 2)))


def describe(x):
    return {'mean': float(x.mean()), 'rms': rms(x), 'sd': math.sqrt(variance(x)),
            'max_abs': float(np.max(np.abs(x)))}


def covariance(a, b):
    return float(np.mean((a - a.mean()) * (b - b.mean())))


def validate(r, v, nv, term, done, gamma, lam):
    assert r.ndim == 2 and r.shape == v.shape == nv.shape == term.shape == done.shape
    assert term.dtype == done.dtype == np.bool_
    assert not np.any(term & ~done)
    assert 0 <= gamma <= 1 and 0 <= lam <= 1
    assert all(np.isfinite(x).all() for x in (r, v, nv))


def operator(x, done, gamma, lam):
    result = np.empty_like(x)
    carry = np.zeros_like(x[0])
    for t in range(len(x) - 1, -1, -1):
        carry = x[t] + gamma * lam * (~done[t]) * carry
        result[t] = carry
    return result


def decompose(r, v, nv, term, done, gamma, lam):
    validate(r, v, nv, term, done, gamma, lam)
    continuation = ~done.copy()
    continuation[-1] = False
    future_v = np.zeros_like(v)
    future_v[:-1] = v[1:]
    end = np.zeros_like(done)
    end[-1] = ~done[-1] & ~term[-1]
    result = {
        'reward': operator(r, done, gamma, lam),
        'current_value': -v,
        'internal_value': operator(gamma * (1 - lam) * continuation * future_v, done, gamma, lam),
        'value_continuity': operator(gamma * continuation * (nv - future_v), done, gamma, lam),
        'time_limit_bootstrap': operator(gamma * done * (~term) * nv, done, gamma, lam),
        'rollout_end_bootstrap': operator(gamma * end * nv, done, gamma, lam),
    }
    direct = operator(r + gamma * (~term) * nv - v, done, gamma, lam)
    summed = sum(result.values())
    bound = 1e-10 + 1e-10 * float(np.max(np.abs(direct)))
    error = float(np.max(np.abs(direct - summed)))
    assert error <= bound, (error, bound)
    return result, direct, {'max_abs_difference': error, 'bound': bound, 'passed': True}


def closed_sum(r, v, nv, term, done, gamma, lam):
    """Separate explicit boundary-aware telescoping formula for fixtures."""
    out = np.zeros_like(r)
    for world in range(r.shape[1]):
        for t in range(r.shape[0]):
            b = t
            while b < len(r) - 1 and not done[b, world]:
                b += 1
            value = -v[t, world]
            for i in range(t, b + 1):
                weight = (gamma * lam) ** (i - t)
                value += weight * r[i, world]
                if i < b:
                    value += gamma * weight * ((1 - lam) * v[i + 1, world]
                                                + nv[i, world] - v[i + 1, world])
            value += gamma * (gamma * lam) ** (b - t) * (not term[b, world]) * nv[b, world]
            out[t, world] = value
    return out


def fixtures():
    r = np.array([[1., 2.], [3., 4.], [5., 6.], [7., 8.]])
    v = r * .3
    nv = np.vstack((v[1:], np.array([[9., 10.]])))
    done = np.zeros_like(r, dtype=bool)
    term = done.copy()
    cases = []
    for mode in ('continuous', 'discontinuous', 'terminal', 'timeout'):
        n = nv.copy()
        d, t = done.copy(), term.copy()
        if mode == 'discontinuous':
            n[0, 0] += .7
        if mode in ('terminal', 'timeout'):
            d[1, 0] = True
            t[1, 0] = mode == 'terminal'
            r_fixture = r.copy()
            r_fixture[2:, 0] += 1000
        else:
            r_fixture = r.copy()
        before = tuple(x.tobytes() for x in (r_fixture, v, n, t, d))
        for lam in (.94, .95):
            cs, direct, proof = decompose(r_fixture, v, n, t, d, .99, lam)
            assert np.max(np.abs(direct - closed_sum(r_fixture, v, n, t, d, .99, lam))) < 1e-10
            if mode == 'continuous':
                assert not np.any(cs['value_continuity'])
                assert cs['rollout_end_bootstrap'][-1, 1] == .99 * n[-1, 1]
            if mode == 'discontinuous':
                assert cs['value_continuity'][0, 0] == .99 * (n[0, 0] - v[1, 0])
            if mode in ('terminal', 'timeout'):
                expected = r[0, 0] + .99 * n[0, 0] - v[0, 0]
                expected += .99 * lam * (r[1, 0] + .99 * (mode == 'timeout') * n[1, 0] - v[1, 0])
                assert abs(direct[0, 0] - expected) < 1e-10
                assert cs['rollout_end_bootstrap'][0, 0] == 0
                assert (cs['time_limit_bootstrap'][0, 0] != 0) == (mode == 'timeout')
        assert before == tuple(x.tobytes() for x in (r_fixture, v, n, t, d))
        cases.append(mode)
    bad = r.copy()
    bad[0, 0] = np.nan
    try:
        decompose(bad, v, nv, term, done, .99, .95)
    except AssertionError:
        cases.append('nonfinite_rejected')
    else:
        raise AssertionError('Nonfinite fixture accepted')
    target = np.array([0., 1., 3., 8.])
    residual = np.array([1., -1., .5, -.5])
    assert abs(variance(residual) - variance(residual + 8.)) < 1e-12
    assert np.mean(residual ** 2) != np.mean((residual + 8.) ** 2)
    assert 1 - variance(np.full_like(target, 7.)) / (variance(target) + 1e-8) == 1.
    cases.append('proxy_residual_offset_blindness')
    return {'state': 'passed', 'cases': cases,
            'independent_closed_sum_checked': True, 'inputs_unchanged': True}


def main():
    torch.set_num_threads(1)
    assert not torch.cuda.is_initialized()
    rng_before = torch.random.get_rng_state().clone()
    manifest_sha = sha(ROOT / 'INPUT_MANIFEST.json')
    manifest = read(ROOT / 'INPUT_MANIFEST.json')
    assert manifest['state'] == 'frozen' and len(manifest['batches']) == 24
    for path, digest in manifest['input_hashes'].items():
        assert sha(path) == digest, ('Input changed', path)
    checks = fixtures()
    proof = read(manifest['native_proof'])
    assert proof['state'] == 'passed' and proof['all8_runs_verified'] and proof['analysis_recomputed_exact']
    rows = []
    for item in manifest['batches']:
        record = torch.load(item['path'], map_location='cpu', weights_only=False)
        assert record['update'] == item['update'] and record['critic_lambda'] == .95
        assert record['actor_lambda'] == item['recorded_actor_lambda']
        assert record['gamma'] == .99 and record['used_per_world'] == 64
        assert record['target_device'] == 'cuda:1'
        original = {key: tensor.numpy().copy() for key, tensor in record.items() if isinstance(tensor, torch.Tensor)}
        assert all(x.shape == (64, 1024) for x in original.values())
        xs = [original[k].astype(np.float64) for k in ('normalized_reward', 'values', 'next_values')]
        r, v, nv = xs
        term, done = original['terminated'], original['done']
        branches = {}
        tensors = {}
        for name, lam in (('actual_actor', record['actor_lambda']), ('matched95', .95)):
            parts, direct, identity = decompose(r, v, nv, term, done, .99, lam)
            tensors[name] = (parts, direct)
            captured = original['actor_advantage'].astype(np.float64) if name == 'actual_actor' else original['consumed_critic_return'].astype(np.float64) - v
            branches[name] = {'lambda': lam, 'decomposition_identity': identity,
                              'direct_advantage': describe(direct),
                              'float64_vs_captured_float32': describe(direct - captured),
                              'components': {k: describe(x) for k, x in parts.items()},
                              'component_covariance': [[covariance(parts[a], parts[b]) for b in NAMES] for a in NAMES]}
        ret = original['consumed_critic_return'].astype(np.float64)
        residual = ret - v
        native_float32_residual = (original['consumed_critic_return'] - original['values']).astype(np.float64)
        vr, vv, ve, cov = variance(ret), variance(v), variance(residual), covariance(v, residual)
        denominator = vr + 1e-8
        q64 = float(np.clip(1 - ve / denominator, 0, 1))
        identity_error = abs(vr - (vv + ve + 2 * cov))
        assert identity_error <= 1e-10 + 1e-10 * vr
        a = tensors['actual_actor'][1]
        b = tensors['matched95'][1]
        denominator_corr = math.sqrt(variance(a) * variance(b))
        edge = ~done[:-1]
        continuity = (nv[:-1] - v[1:])[edge]
        differences = {k: tensors['actual_actor'][0][k] - tensors['matched95'][0][k] for k in NAMES}
        difference_identity = float(np.max(np.abs(sum(differences.values()) - (a - b))))
        assert difference_identity <= 2e-10 + 2e-10 * float(np.max(np.abs(a)) + np.max(np.abs(b)))
        row = {'seed': item['seed'], 'update': item['update'], 'artifact_sha256': sha(item['path']),
               'recorded_actor_lambda': record['actor_lambda'], 'branches': branches,
               'proxy': {'recorded_q': item['recorded_q'], 'q_float64': q64,
                         'q_float64_from_native_float32_residual': float(np.clip(1 - variance(native_float32_residual) / denominator, 0, 1)),
                         'native_float32_residual_subtraction_roundoff': describe(native_float32_residual - residual),
                         'target_variance': vr, 'value_variance': vv, 'residual_variance': ve,
                         'residual_mean': float(residual.mean()), 'residual_mse': float(np.mean(residual ** 2)),
                         'twice_value_residual_covariance': 2 * cov,
                         'signed_ratios': {'value': vv / denominator, 'residual': ve / denominator,
                                           'twice_covariance': 2 * cov / denominator},
                         'variance_identity_max_abs_difference': identity_error},
               'boundaries': {'true_termination_count': int(term.sum()),
                              'time_limit_count': int((done & ~term).sum()),
                              'live_rollout_end_worlds': int((~done[-1]).sum()),
                              'continuing_value_difference': describe(continuity)},
               'actual_vs95': {'raw_label_difference': describe(a - b),
                              'raw_label_correlation': covariance(a, b) / denominator_corr if denominator_corr else None,
                              'raw_sign_difference_fraction': float(np.mean(np.sign(a) != np.sign(b))),
                              'component_difference_rms': {k: rms(differences[k]) for k in NAMES},
                              'component_difference_covariance': [[covariance(differences[x], differences[y]) for y in NAMES] for x in NAMES],
                              'component_difference_reconstruction_max_abs': difference_identity}}
        assert all(np.array_equal(original[k], record[k].numpy()) for k in original)
        rows.append(row)
    assert {(r['seed'], r['update']) for r in rows} == {(s, u) for s in range(21, 29) for u in (4, 5, 153)}
    for path, digest in manifest['input_hashes'].items():
        assert sha(path) == digest, ('Input changed after diagnostic', path)
    assert sha(ROOT / 'INPUT_MANIFEST.json') == manifest_sha
    assert torch.equal(rng_before, torch.random.get_rng_state())
    assert not torch.cuda.is_initialized()
    output = {'state': 'completed', 'fixtures': checks, 'component_order': NAMES, 'rows': rows,
              'input_manifest_sha256': manifest_sha,
              'geometry_scope': 'Float64 same-input estimator geometry; captured float32 discrepancies reported separately. No actual PPO minibatch geometry.',
              'input_hashes_unchanged': True, 'cpu_rng_unchanged': True, 'cuda_initialized': False,
              'environment_samples': 0, 'optimizer_calls': 0, 'new_evaluation_episodes': 0,
              'training_runs_launched': 0, 'reference_is_ground_truth': False,
              'new_lambda_or_training_admitted': False}
    (ROOT / 'ANALYSIS.json').write_text(json.dumps(output, indent=2, allow_nan=False) + '\n')
    print('Completed all24 CPU-only paired estimator decompositions; inputs/RNG unchanged; no training admitted.')


if __name__ == '__main__':
    main()
