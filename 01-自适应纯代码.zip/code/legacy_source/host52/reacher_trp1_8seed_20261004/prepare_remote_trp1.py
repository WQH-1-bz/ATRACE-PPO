"""Verify inherited controls and pin the completed CPP3 before a fresh queue."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil


def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--origin',type=Path,required=True);ap.add_argument('--root',type=Path,required=True);args=ap.parse_args()
    root=args.root.resolve();origin=args.origin.resolve()
    assert root.is_dir() and not(root/'PROTECTED_INVENTORY.json').exists()
    assert root.parent==origin.parent and root.name=='reacher_trp1_8seed_20261004'
    prior=read(origin/'suite_status.json')
    assert prior['state']=='completed' and prior['completed_count']==8 and not prior['active']
    assert prior['failure'] is None and prior['engineering_gate']['state']=='passed'
    parent=read(origin/'PARENT_VERIFIED_terminal8.json')
    assert parent['state']=='passed' and parent['all8_runs_verified'] and parent['analysis_recomputed_exact']
    analysis=read(origin/'ANALYSIS.json')
    assert analysis['round']=='CPP3' and len(analysis['rows'])==8
    inherited=read(origin/'PROTECTED_INVENTORY.json')
    files=dict(inherited['files'])
    for p,digest in files.items():assert sha(p)==digest,('protected changed',p)
    def pin(p,digest=None):
        digest=digest or sha(p)
        assert sha(p)==digest
        files[str(p)]=digest
    launch=read(origin/'LAUNCH_MANIFEST.json')
    assert launch['state']=='frozen' and len(launch['source_hashes'])==19
    assert len(inherited['files'])==789 and parent['protected_file_count']==789
    for name,digest in launch['source_hashes'].items():pin(origin/'source_i1'/name,digest)
    for name,digest in launch['program_hashes'].items():pin(origin/name,digest)
    for name in ['LAUNCH_MANIFEST.json','PROTECTED_INVENTORY.json','INTERNAL5_REFERENCE.json',
                 'suite_status.json','ANALYSIS.json','PARENT_VERIFIED_terminal8.json','REMOTE_PREPARED.json','SMOKE_VERIFIED.json']:
        pin(origin/name)
    assert len(prior['jobs'])==8 and len(prior['smoke_jobs'])==2
    for job in prior['jobs']+prior['smoke_jobs']:
        assert job['state']=='completed' and job['metrics']['controller_replay']=='passed'
        for name,digest in job['metrics']['artifact_hashes'].items():pin(Path(job['path'])/name,digest)
    provenance=read(root/'CPP3_DECOMPOSITION_PROVENANCE.json')
    assert provenance['state']=='local_provenance_copied' and len(provenance['files'])==8
    for name,entry in provenance['files'].items():
        relative=Path(entry['bundle_relative_path'])
        assert relative.parent==Path('CPP3_DECOMPOSITION_EVIDENCE') and relative.name==name
        # Do not dereference recorded local-machine absolute input/provenance paths remotely.
        pin(root/relative,entry['sha256'])
    pin(root/'CPP3_DECOMPOSITION_PROVENANCE.json')
    rows=read(root/'INTERNAL5_REFERENCE.json')['rows']
    assert rows==read(origin/'INTERNAL5_REFERENCE.json')['rows'] and len(rows)==40
    assert {(r['method'],r['seed']) for r in rows}=={(m,s) for m in ('fixed90','fixed95','fixed99','linear','critic_aware') for s in range(21,29)}
    agents=[]
    for ancestor in [root,*root.parents]:
        p=ancestor/'AGENTS.md'
        if p.is_file():agents.append({'path':str(p),'text':p.read_text()})
    prefix=root.parent/'reacher_innovation12_r4_replayfix1_8seed_20261003/runs/smoke__innovation1__a'
    for name in ['config.json','evaluations.jsonl','fixed_critic_audit_004.pt']:
        pin(prefix/name)
    prefix_config=read(prefix/'config.json')
    assert prefix_config['seed']==91081 and prefix_config['fixed_critic_lambda']==.95
    assert prefix_config['effective_steps']==524288
    assert not(root/'LAUNCH_MANIFEST.json').exists() and not(root/'suite_status.json').exists()
    for folder in ['runs','tmp']:
        p=root/folder
        if p.exists():assert p.is_dir() and not any(p.iterdir())
        else:p.mkdir()
    for name in ['.venv','analysis_dependencies']:
        if not(origin/name).exists():continue
        p=root/name
        if p.exists():assert p.is_symlink() and p.resolve()==(origin/name).resolve()
        else:p.symlink_to(origin/name,target_is_directory=True)
    if not(root/'cache').exists():
        if (origin/'cache').is_dir():shutil.copytree(origin/'cache',root/'cache')
        else:(root/'cache').mkdir()
    else:assert (root/'cache').is_dir() and not (root/'cache').is_symlink()
    inventory={**inherited,'state':'verified','files':files,'held_prefix_short_path':str(prefix),'preserved_cpp3_formal_runs':8,
               'preserved_cpp3_short_runs':2,'cpp3_root':str(origin),
               'preserved_cpp3_native_terminal_proof_sha256':sha(origin/'PARENT_VERIFIED_terminal8.json'),
               'cpp3_inherited_protected_count':len(inherited['files']),
               'cpp3_decomposition_evidence_files':8,
               'cpp3_decomposition_local_absolute_paths_scope':'provenance only; copied bytes verified on remote52'}
    write(root/'PROTECTED_INVENTORY.json',inventory)
    report={'state':'prepared','root':str(root),'origin':str(origin),'protected_count':len(files),
            'protected_inventory_sha256':sha(root/'PROTECTED_INVENTORY.json'),
            'internal_reference_sha256':sha(root/'INTERNAL5_REFERENCE.json'),
            'venv':str((root/'.venv').resolve()),'disk_free_bytes':shutil.disk_usage(root).free,
            'applicable_agents':agents,'training_launched':False,
            'preserved_cpp3_formal_runs':8,'preserved_cpp3_short_runs':2,
            'copied_decomposition_provenance_verified':True,
            'analysis_dependencies':str((root/'analysis_dependencies').resolve()) if (root/'analysis_dependencies').exists() else None}
    write(root/'REMOTE_PREPARED.json',report);print(json.dumps(report))


if __name__=='__main__':main()
