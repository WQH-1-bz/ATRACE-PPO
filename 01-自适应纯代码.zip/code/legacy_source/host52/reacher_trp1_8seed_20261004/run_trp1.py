"""Deterministic TRP1 admission and one bounded eight-seed training-return round."""
import argparse
import csv
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import statistics
import struct
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
import torch
sys.path.insert(0,str(Path(__file__).resolve().parent/'analysis_dependencies'))
import r4_verification_helpers as helper

ROOT = Path(__file__).resolve().parent
BUDGET, SHORT = 10027008, 524288
SEEDS = tuple(range(21,29))
METHODS = ('fixed90','fixed95','fixed99','linear','critic_aware')
ENDPOINTS = ('final_return','auc')
DET = {'torch':True,'warp':'run_to_run','warp_max_records':8,'cublas_workspace_config':':4096:8'}
ENV = {**os.environ,'PYTHONUNBUFFERED':'1','PYTHONDONTWRITEBYTECODE':'1',
       'OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','DPO_TORCH_DETERMINISTIC':'1',
       'DPO_WARP_DETERMINISTIC':'run_to_run','DPO_WARP_DETERMINISTIC_MAX_RECORDS':'8',
       'CUBLAS_WORKSPACE_CONFIG':':4096:8','DPO_PPO_GRAPH':'0',
       'XDG_CACHE_HOME':str(ROOT/'cache'),'WARP_CACHE_PATH':str(ROOT/'cache/warp'),
       'CUDA_CACHE_PATH':str(ROOT/'cache/cuda'),'TORCH_HOME':str(ROOT/'cache/torch'),
       'TMPDIR':str(ROOT/'tmp')}
ARTIFACTS = ('config.json','summary.json','status.json','latest.pt','progress.csv',
             'initial_evaluation.json','evaluations.jsonl','best.pt','stress_evaluation.json')
OLD_AUDIT_KEYS = ('normalized_reward','values','next_values','terminated','done',
                  'actor_advantage','consumed_critic_return','actor_lambda','critic_lambda',
                  'gamma','update','steps','prior_collected_steps','used_per_world')
TRP_PROGRESS = ('training_return_mean','training_return_count','training_return_std',
                'training_return_fast_ema','training_return_slow_ema','training_return_trend')


def read(p): return json.loads(Path(p).read_text())
def sha(p): return helper.sha(Path(p))
def write(p,x): helper.write(Path(p),x)
def jsonl(p): return helper.jsonl(Path(p))


def exact(a,b):
    if isinstance(a,float) or isinstance(b,float):
        assert struct.pack('!d',float(a))==struct.pack('!d',float(b)),(a,b)
    else:
        assert a==b,(a,b)


def controller_class():
    name='trp1_frozen_controller'
    if name not in sys.modules:
        spec=importlib.util.spec_from_file_location(name,ROOT/'source_i1/lambda_training_return.py')
        module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return sys.modules[name].TrainingReturn


def check_sources():
    launch=read(ROOT/'LAUNCH_MANIFEST.json')
    assert launch['state']=='frozen' and launch['formal_total']==8 and launch['seeds']==list(SEEDS)
    assert launch['gpu']==1 and launch['max_concurrency']==8
    for name,digest in launch['source_hashes'].items():
        p=ROOT/'source_i1'/name
        assert sha(p)==digest and not(p.stat().st_mode&0o222),(name,'source changed')
    assert len(launch['source_hashes'])==19
    assert {p.name for p in (ROOT/'source_i1').iterdir() if p.is_file()}==set(launch['source_hashes'])
    assert 'lambda_training_return.py' in launch['source_hashes'] and 'lambda_critic_reference.py' not in launch['source_hashes']
    for name,digest in launch['program_hashes'].items():assert sha(ROOT/name)==digest,('program changed',name)
    assert sha(ROOT/'PROTECTED_INVENTORY.json')==launch['protected_inventory_sha256']
    assert sha(ROOT/'INTERNAL5_REFERENCE.json')==launch['internal_reference_sha256']
    return launch


def controls():
    rows=read(ROOT/'INTERNAL5_REFERENCE.json')['rows']
    assert len(rows)==40 and {(r['method'],r['seed']) for r in rows}=={(m,s) for m in METHODS for s in SEEDS}
    return rows


def verify_protected():
    inventory=read(ROOT/'PROTECTED_INVENTORY.json')
    assert inventory['cpf1_stop_action']=='stop'
    assert inventory['cpp3_inherited_protected_count']==789
    assert inventory['preserved_cpp3_formal_runs']==8 and inventory['preserved_cpp3_short_runs']==2
    assert inventory['cpp3_decomposition_evidence_files']==8
    for p,digest in inventory['files'].items():assert sha(p)==digest,('protected file changed',p)
    for r in controls():
        p=Path(r['path']);config=read(p/'config.json');summary=read(p/'summary.json')
        assert summary['state']=='completed' and summary['reload_check']=='passed'
        assert config['seed']==r['seed'] and config['effective_steps']==summary['steps']==BUDGET
        assert config['determinism']==DET
        if r['method']=='critic_aware':
            # This native entry uses plain LocomotionWarp and has no noise CLI.
            source=Path(r['path']).parent.parent/'source'
            assert config['method']=='critic_aware' and config['task']=='Reacher'
            for name,digest in config['source_sha256'].items():
                assert sha(source/name)==digest,('critic-aware source changed',name)
            text=(source/'train_external_baseline.py').read_text()
            assert "env = LocomotionWarp(a.num_envs, a.device, a.seed, task=a.task)" in text
            assert "ev = LocomotionWarp(a.eval_envs, a.device, a.seed + 10000, task=a.task)" in text
            assert 'noise_mode' not in config and 'noise_scale' not in config
        else:
            assert config['noise_mode']=='none' and config['noise_scale']==0
        area,initial,ev=helper.auc(p,BUDGET,'Reacher')
        exact(area,r['auc']);exact(summary['final_eval']['mean'],r['final_return'])
        assert len(ev)==39 and config['xml_sha256']==inventory['xml_sha256']
    stop=read(inventory['cpf1_stop_path'])
    assert stop['action']=='stop' and stop['gate_id']=='CPF1_REACHER_I1_LATE77'
    return {'state':'passed','protected_file_count':len(inventory['files']),
            'internal_control_count':40,'innovation2_runs':8,'cpf1_stop_preserved':True,
            'cpp3_inherited_protected_count':789,'preserved_cpp3_formal_runs':8,
            'preserved_cpp3_short_runs':2,'cpp3_decomposition_evidence_files':8}


def command(job):
    return [str(ROOT/'.venv/bin/python'),str(ROOT/'source_i1/train_kl_relative.py'),
            '--out',job['path'],'--task','Reacher','--seed',str(job['seed']),
            '--device','cuda:1','--steps',str(SHORT if job.get('smoke') else BUDGET),
            '--num-envs','1024','--rollout','64','--batch-size','1024','--epochs','10',
            '--eval-envs','32','--eval-every','262144','--fixed-lambda','.95',
            '--fixed-critic-lambda','.95','--save-fixed-critic-audit',
            '--adaptive-start-update','4','--adaptive-start-steps','0']


def audit_updates(config):return [4,5,config['effective_steps']//65536]
helper.fixed_audit_updates=audit_updates


def return_names(count):
    return [f'training_episode_return_{u:03d}.pt' for u in range(1,count+1)]


def validate_return_vector(vector):
    assert isinstance(vector,torch.Tensor) and vector.ndim==1
    assert vector.device.type=='cpu' and vector.dtype==torch.float32 and not vector.requires_grad
    assert 0<vector.numel()<=65536 and bool(torch.isfinite(vector).all())
    return vector.numel()


def replay_return_statistics(vector,device='cuda:1'):
    """The trainer's float32 device reductions, never a Python/double approximation."""
    count=validate_return_vector(vector)
    values=vector.to(device)
    with torch.no_grad():
        mean=float(values.mean());std=float(values.std(unbiased=False))
    assert math.isfinite(mean) and math.isfinite(std) and std>=0
    return {'training_return_count':count,'training_return_mean':mean,'training_return_std':std}


def verify_return_statistics(vector,record,device='cuda:1'):
    stats=replay_return_statistics(vector,device)
    assert type(record['training_return_count']) is int
    for key,value in stats.items():exact(value,record[key])
    return stats


def validate_training_episode_audit(record,vector):
    """Raw episode values are present exactly at done positions, in rollout order."""
    values,done=record['training_episode_values'],record['done']
    assert isinstance(values,torch.Tensor) and values.shape==(64,1024)
    assert values.dtype==torch.float32 and values.device.type=='cpu' and not values.requires_grad
    assert isinstance(done,torch.Tensor) and done.shape==values.shape and done.dtype==torch.bool
    assert done.device.type=='cpu' and not done.requires_grad
    assert torch.equal(torch.isnan(values),~done),'training returns must be NaN exactly at non-done positions'
    assert bool(torch.isfinite(values[done]).all())
    validate_return_vector(vector)
    assert not differences(values[done],vector),'full done-masked episode values differ from the saved vector'
    duplicate=record['training_episode_return']
    validate_return_vector(duplicate)
    assert not differences(duplicate,vector),'audit episode-return vector differs'
    assert record['raw_training_return_signal_version']=='TRP1'


def differences(a,b,path=''):
    """Exact recursive comparison, including each stored tensor's raw NaN bits."""
    if isinstance(a,torch.Tensor):
        if not isinstance(b,torch.Tensor) or a.dtype!=b.dtype or a.shape!=b.shape:
            return [path]
        a_bytes=a.contiguous().reshape(-1).view(torch.uint8)
        b_bytes=b.contiguous().reshape(-1).view(torch.uint8)
        return [] if torch.equal(a_bytes,b_bytes) else [path]
    if isinstance(a,dict):
        if not isinstance(b,dict) or a.keys()!=b.keys():return [path+'.keys']
        return [d for key in a for d in differences(a[key],b[key],path+'.'+str(key))]
    if isinstance(a,(tuple,list)):
        if type(a)!=type(b) or len(a)!=len(b):return [path+'.length']
        return [d for i,(x,y) in enumerate(zip(a,b)) for d in differences(x,y,path+'.'+str(i))]
    if isinstance(a,float) or isinstance(b,float):
        return [] if struct.pack('!d',float(a))==struct.pack('!d',float(b)) else [path]
    return [] if type(a)==type(b) and a==b else [path]


def old_audit_payload(record):
    assert all(k in record for k in OLD_AUDIT_KEYS)
    return {k:record[k] for k in OLD_AUDIT_KEYS}


def exact_pair(first,second,arm='innovation1'):
    assert arm=='innovation1'
    paths=[Path(first),Path(second)];configs=[read(p/'config.json') for p in paths]
    assert configs[0]['effective_steps']==configs[1]['effective_steps']
    count=configs[0]['effective_steps']//65536
    delta=[]
    for name in ('latest.pt','best.pt'):
        checkpoints=[torch.load(p/name,map_location='cpu',weights_only=False) for p in paths]
        for checkpoint in checkpoints:
            checkpoint=checkpoint['config']
            for key in ('device','out'):checkpoint.pop(key)
        delta.extend(differences(*checkpoints,path=name))
    for name in [*return_names(count),*[f'fixed_critic_audit_{u:03d}.pt' for u in audit_updates(configs[0])]]:
        records=[torch.load(p/name,map_location='cpu',weights_only=False) for p in paths]
        delta.extend(differences(*records,path=name))
    for name in ('initial_evaluation.json','evaluations.jsonl','lambda_decisions.jsonl','stress_evaluation.json'):
        if (paths[0]/name).read_bytes()!=(paths[1]/name).read_bytes():delta.append(name)
    rows=[list(csv.DictReader((p/'progress.csv').open())) for p in paths]
    assert len(rows[0])==len(rows[1])==count
    for u,(a,b) in enumerate(zip(*rows),1):
        assert a.keys()==b.keys()
        for key in a:
            if key not in ('elapsed_seconds','steps_per_second') and a[key]!=b[key]:
                delta.append(f'progress.{u}.{key}')
    assert not delta,delta
    return {'state':'passed','checkpoint_exact_except_device_out':True,
            'latest_and_best_model_adam_normalizers_controllers_exact':True,
            'all_training_episode_return_vectors_exact':True,'return_vector_count':count,
            'all_fixed_audits_with_nan_masks_exact':True,
            'evaluation_and_decisions_exact':True,'stress_evaluations_exact':True,
            'non_timing_progress_exact':True}


def target_audits(path,config,decisions):
    replay=helper.source_gae();results=[];separated=0
    for update in audit_updates(config):
        name=f'fixed_critic_audit_{update:03d}.pt'
        record=torch.load(path/name,map_location='cpu',weights_only=False)
        assert record['update']==update and record['steps']==update*65536
        assert record['gamma']==.99 and record['target_device']=='cuda:1' and record['used_per_world']==64
        assert record['prior_collected_steps']==(update-1)*65536 and record['critic_lambda']==.95
        exact(record['actor_lambda'],decisions[update-1]['lambda_used'])
        keys=('normalized_reward','values','next_values','terminated','done')
        for k in keys+('actor_advantage','consumed_critic_return'):
            tensor=record[k]
            assert isinstance(tensor,torch.Tensor) and tensor.shape==(64,1024) and tensor.device.type=='cpu'
            assert not tensor.requires_grad
            if k in ('terminated','done'):assert tensor.dtype==torch.bool
            else:assert tensor.dtype==torch.float32 and bool(torch.isfinite(tensor).all())
        assert not(record['terminated']&~record['done']).any()
        vector=torch.load(path/f'training_episode_return_{update:03d}.pt',map_location='cpu',weights_only=False)
        validate_training_episode_audit(record,vector)
        verify_return_statistics(vector,record)
        verify_return_statistics(vector,decisions[update-1])
        xs=[record[k].to('cuda:1') for k in keys]
        with torch.no_grad():
            # Locked source-GAE warmup; no retry-until-equal or tolerance widening.
            for _ in range(3):replay(*xs,.99,.95)
            a,adaptive_return=replay(*xs,.99,record['actor_lambda'])
            fixed_advantage,r=replay(*xs,.99,.95)
            assert torch.equal(a,record['actor_advantage'].to('cuda:1')),('actor replay',name)
            assert torch.equal(r,record['consumed_critic_return'].to('cuda:1')),('critic replay',name)
            labels_differ=not torch.equal(a,fixed_advantage) and not torch.equal(adaptive_return,r)
            exact(float((adaptive_return-r).square().mean().sqrt()),
                  decisions[update-1]['actor_critic_target_diff_rmse'])
            if update==4:assert record['actor_lambda']==.95 and not labels_differ
            else:separated+=int(labels_differ)
        results.append({'update':update,'actor_lambda':record['actor_lambda'],'critic_lambda':.95,
                        'actor_and_fixed_critic_labels_exact':True,'training_return_signal_exact':True,
                        'actor_and_fixed_critic_labels_separated':labels_differ,
                        'full_done_masked_training_episode_values_exact':True,
                        'training_return_count':vector.numel(),'artifact_sha256':sha(path/name)})
    assert separated>0,'Saved post-hold actor and fixed-critic labels never separated'
    return results


def verify(job):
    p=Path(job['path']);short=bool(job.get('smoke'));budget=SHORT if short else BUDGET;count=budget//65536
    config=read(p/'config.json');summary=read(p/'summary.json')
    assert summary==read(p/'status.json') and summary['state']=='completed' and summary['reload_check']=='passed'
    assert config['lambda_mode']=='training_return' and config['lambda_design']['version']=='TRP1'
    assert config['seed']==job['seed'] and config['device']=='cuda:1' and config['determinism']==DET
    assert config['effective_steps']==config['steps']==summary['steps']==budget
    for key,expected in [('num_envs',1024),('rollout',64),('batch_size',1024),('epochs',10),
                         ('eval_envs',32),('eval_every',262144),('gamma',.99),('fixed_lambda',.95),
                         ('fixed_critic_lambda',.95),('adaptive_start_update',4),('adaptive_start_steps',0)]:
        assert config[key]==expected,(key,config[key],expected)
    assert config['save_fixed_critic_audit'] and config['noise_mode']=='none' and config['noise_scale']==0
    design=config['lambda_design']
    for key,expected in [('initial',.95),('bounds',[.90,.99]),('warmup_updates',4),
                         ('first_adaptive_update',5),('fast_alpha',.1),('slow_alpha',.01),
                         ('target_interval',4),('trend_scale',.04),('tracking_rate',.1),('max_step',.001),
                         ('signal_observed_after_ppo',True),('evaluation_return_used',False),
                         ('kl_drives_controller',False),('critic_statistics_drive_controller',False),
                         ('signal_vector_device_saved','cpu'),('signal_reduction_device','cuda:1'),
                         ('signal_reduction_dtype','float32'),('extra_environment_steps',0),
                         ('extra_optimizer_steps',0)]:
        assert design[key]==expected,('lambda_design',key,design[key],expected)
    assert config['fixed_critic_target_design']['audit_updates']==audit_updates(config)
    assert config['xml_sha256']==read(ROOT/'PROTECTED_INVENTORY.json')['xml_sha256']
    rows=list(csv.DictReader((p/'progress.csv').open()));ds=jsonl(p/'lambda_decisions.jsonl')
    assert len(rows)==len(ds)==count
    assert {name.name for name in p.glob('training_episode_return_*.pt')}==set(return_names(count))
    assert config['lambda_design']['signal_vector_files']==return_names(count)
    c=controller_class()();values=[];return_counts=[]
    for u,(d,row) in enumerate(zip(ds,rows),1):
        assert d['update']==u and d['steps']==int(row['steps'])==u*65536
        assert d['prior_collected_steps']==(u-1)*65536 and d['signal_version']=='TRP1'
        delta=c.step(u);exact(c.value,d['lambda_used']);exact(c.value,d['actor_lambda_used'])
        exact(c.value,d['lambda_current']);exact(delta,d['lambda_delta'])
        exact(.95,d['critic_lambda_used']);exact(delta,float(row['lambda_delta']))
        exact(c.value,float(row['gae_lambda']))
        assert .90<=c.value<=.99 and abs(delta)<=.001+1e-15
        assert d['adaptive_start_steps']==0 and d['adaptive_steps_ready'] is True
        assert int(row['fresh_steps_per_world'])==int(row['used_steps_per_world'])==64
        assert d['overlap_active'] is False and d['headroom_gain']==1.
        assert not d['early_target_unlocked'] and not d['critic_ready_latched']
        assert math.isfinite(d['realized_kl']) and d['realized_kl']>=-1e-7
        assert all(k not in d and k not in row for k in ('critic_residual_mse','critic_target_variance',
            'critic_residual_variance','critic_residual_mean','normalized_critic_residual',
            'critic_predictability','predictability_trend'))
        vector=torch.load(p/f'training_episode_return_{u:03d}.pt',map_location='cpu',weights_only=False)
        stats=verify_return_statistics(vector,d)
        return_counts.append(stats['training_return_count'])
        exact(stats['training_return_mean'],float(row['training_return_mean']))
        exact(stats['training_return_std'],float(row['training_return_std']))
        assert stats['training_return_count']==int(row['training_return_count'])
        c.observe(stats['training_return_mean'])
        assert all(math.isfinite(v) for v in (c.fast_ema,c.slow_ema,c.trend,c.target,c.value))
        assert -1<=c.trend<=1 and .90<=c.target<=.99
        for key,v in c.state_dict().items():exact(v,d[key])
        assert d['target_observation_count']==u-u%4
        exact(c.fast_ema,float(row['training_return_fast_ema']))
        exact(c.slow_ema,float(row['training_return_slow_ema']))
        exact(c.trend,float(row['training_return_trend']));values.append(c.value)
    maximum_deviation=max(abs(v-.95) for v in values)
    assert values[:4]==[.95]*4 and maximum_deviation>1e-12,'TRP1 had no material measured lambda activity'
    chk=helper.checkpoint_steps(p,'innovation1',budget//1024*10)
    assert chk['steps']==budget and chk['training_return_feedback']==c.state_dict()
    audits=target_audits(p,config,ds)
    area,initial,evaluations=helper.auc(p,budget,'Reacher')
    expected=[262144*i for i in range(1,budget//262144+1)]
    if expected[-1]!=budget:expected.append(budget)
    assert [e['steps'] for e in evaluations]==expected
    assert len(evaluations)==(2 if short else 39)
    exact(evaluations[-1]['mean'],summary['final_eval']['mean'])
    control=read(ROOT/'PROTECTED_INVENTORY.json')['short_initial_path'] if short else next(
        r['path']+'/initial_evaluation.json' for r in controls() if r['method']=='fixed95' and r['seed']==job['seed'])
    assert (p/'initial_evaluation.json').read_bytes()==Path(control).read_bytes(),'paired initial evaluation mismatch'
    prefix_reference=Path(read(ROOT/'PROTECTED_INVENTORY.json')['held_prefix_short_path']) if short else Path(next(
        r['path'] for r in controls() if r['method']=='fixed95' and r['seed']==job['seed']))
    def held_evaluations(path):return [d for d in jsonl(path/'evaluations.jsonl') if d['steps']<=262144]
    assert held_evaluations(p)==held_evaluations(prefix_reference),'Held95 first evaluation differs from preserved reference'
    if short:
        pure_fixed95=Path(read(ROOT/'PROTECTED_INVENTORY.json')['short_initial_path']).parent
        assert held_evaluations(p)==held_evaluations(pure_fixed95),'Held95 first evaluation differs from original fixed95'
        current=torch.load(p/'fixed_critic_audit_004.pt',map_location='cpu',weights_only=False)
        original=torch.load(prefix_reference/'fixed_critic_audit_004.pt',map_location='cpu',weights_only=False)
        assert not differences(old_audit_payload(current),old_audit_payload(original)),\
            'Held95 actual short targets differ in preserved original fields'
    stress=read(p/'stress_evaluation.json')
    assert [(r['mode'],r['scale']) for r in stress]==[('none',0.),('gaussian',.10),('gaussian',.15),('gaussian',.30),('multiplicative',.20),('multiplicative',.30)]
    for row in stress:helper.batch(row,'Reacher')
    names=list(ARTIFACTS)+['lambda_decisions.jsonl']+return_names(count)+[f'fixed_critic_audit_{u:03d}.pt' for u in audit_updates(config)]
    return {'seed':job['seed'],'final_return':summary['final_eval']['mean'],'auc':area,
            'initial_return':initial['mean'],'updates':count,'steps':budget,'lambda_min':min(values),
            'lambda_max':max(values),'lambda_final':values[-1],
            'changed_updates':sum(abs(v-.95)>1e-12 for v in values),'maximum_lambda_deviation':maximum_deviation,
            'controller_replay':'passed','all_training_return_vectors_replayed_exact':True,
            'training_return_vector_count':count,'training_episode_counts':return_counts,
            'training_return_replay_device':'cuda:1','training_return_replay_dtype':'float32',
            'held95_first_evaluation_exact':True,'held95_short_actual_targets_exact':True if short else None,
            'fixed_target_and_signal_audits':audits,'optimizer_calls':budget//1024*10,
            'xml_sha256':config['xml_sha256'],'artifact_hashes':{name:sha(p/name) for name in names}}


def holm(tests):
    assert len(tests)==10
    carry=0.
    for rank,t in enumerate(sorted(tests,key=lambda v:v['p_two_sided'])):
        carry=max(carry,min(1.,(len(tests)-rank)*t['p_two_sided']))
        t['p_holm10']=carry;t['positive_and_holm_below05']=t['mean_difference']>0 and carry<.05


def analyze(jobs):
    rows=[j['metrics'] for j in jobs];lookup={r['seed']:r for r in rows}
    assert len(rows)==8 and sorted(lookup)==list(SEEDS)
    base={(r['method'],r['seed']):r for r in controls()}
    assert len(base)==40 and set(base)=={(m,s) for m in METHODS for s in SEEDS}
    assert all(math.isfinite(r[e]) for r in [*rows,*base.values()] for e in ENDPOINTS)
    activity=all(r['maximum_lambda_deviation']>1e-12 for r in rows)
    def group(ids):
        comparisons={};tests=[]
        for m in METHODS:
            comparisons[m]={}
            for e in ENDPOINTS:
                a=[lookup[s][e] for s in ids];b=[base[(m,s)][e] for s in ids]
                t={**helper.paired(a,b),'ours_mean':statistics.mean(a),'base_mean':statistics.mean(b)}
                comparisons[m][e]=t;tests.append(t)
        holm(tests)
        return {'seeds':list(ids),'comparisons':comparisons,
                'mean_both_beats_every_internal':all(t['mean_difference']>0 for t in tests),
                'all_tests_positive_and_holm_below05':all(t['positive_and_holm_below05'] for t in tests),
                'valid_independent_confirmation':False}
    scores=[]
    for s in SEEDS:
        normalized=[]
        for m in METHODS:
            for e in ENDPOINTS:
                sd=statistics.stdev(base[(m,k)][e] for k in SEEDS)
                assert sd>0,('zero full8 control SD',m,e)
                normalized.append((lookup[s][e]-base[(m,s)][e])/sd)
        scores.append({'seed':s,'minimum_normalized_gain':min(normalized)})
    scores.sort(key=lambda r:(-r['minimum_normalized_gain'],r['seed']))
    groups={'prior3':group([24,26,27]),'prior5':group([21,22,24,26,27]),
            'ranked3':group([r['seed'] for r in scores[:3]]),'ranked5':group([r['seed'] for r in scores[:5]])}
    strict=[s for s in SEEDS if all(lookup[s][e]>base[(m,s)][e] for m in METHODS for e in ENDPOINTS)]
    numerical_pass=activity and any(groups[g]['mean_both_beats_every_internal'] for g in ('prior3','ranked3'))
    return {'state':'completed','task':'Reacher','round':'TRP1','rows':rows,'base_rows':list(base.values()),
            'full8':group(SEEDS),
            'full8_mean_sd':{e:{'ours_mean':statistics.mean(lookup[s][e] for s in SEEDS),
                'ours_sd':statistics.stdev(lookup[s][e] for s in SEEDS),
                'baselines':{m:{'mean':statistics.mean(base[(m,s)][e] for s in SEEDS),
                    'sd':statistics.stdev(base[(m,s)][e] for s in SEEDS)} for m in METHODS}} for e in ENDPOINTS},
            'groups':groups,'descriptive_common_ranking':scores,
            'same_seed_beats_all_internal_on_both':strict,
            'all8_material_adaptive_activity':activity,
            'numerical_three_seed_development_pass':numerical_pass,
            'next_action':'stop_adjustment' if numerical_pass else 'bounded_parent_review',
            'automatic_next_candidate':False,'automatic_family_sweeps':False,
            'common_ranking_rule':'descending minimum of ten paired gains normalized by corresponding full8 control sample SD; ties seed ascending',
            'holm_scope':'ten control-by-endpoint paired tests within each reported group',
            'inference_scope':'Reused and outcome-selected development seeds; numerical criterion, not independent confirmation',
            'no_baseline_or_i2_reruns':True}


def snapshot():
    def output(args):return subprocess.check_output(args,text=True,timeout=15).strip().splitlines()
    gpu=output(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'])
    free={int(line.split(',')[0]):int(line.split(',')[1]) for line in gpu}
    lines=output(['nvidia-smi','--query-compute-apps=pid,used_gpu_memory','--format=csv,noheader,nounits'])
    memory={}
    for line in lines:
        try:p,m=(int(v.strip()) for v in line.split(','));memory[p]=m
        except ValueError:pass
    return free,memory


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--prepare-only',action='store_true');parser.add_argument('--verify-only',action='store_true');parser.add_argument('--verify-startup',action='store_true');args=parser.parse_args()
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
    launch=check_sources();protected=verify_protected()
    if args.verify_startup:
        suite=read(ROOT/'suite_status.json')
        assert suite['engineering_gate']['state']=='passed'
        assert len(suite['smoke_jobs'])==2 and all(j['state']=='completed' for j in suite['smoke_jobs'])
        for j in suite['smoke_jobs']:assert verify(j)==j['metrics']
        pair=exact_pair(*(j['path'] for j in suite['smoke_jobs']),'innovation1')
        assert pair['state']=='passed'
        assert len(suite['jobs'])==8 and {j['seed'] for j in suite['jobs']}==set(SEEDS)
        assert all(j['state'] in ('running','completed') for j in suite['jobs']),'Not all8 formal jobs have started'
        for j in suite['jobs']:
            c=read(Path(j['path'])/'config.json')
            assert c['seed']==j['seed'] and c['lambda_mode']=='training_return' and c['device']=='cuda:1'
            assert c['lambda_design']['version']=='TRP1' and c['fixed_lambda']==.95 and c['fixed_critic_lambda']==.95
            assert c['determinism']==DET and c['effective_steps']==BUDGET
            if j['state']=='running':
                os.kill(j['pid'],0)
                assert suite['active'][j['id']]['pid']==j['pid']
        assert suite['failure'] is None
        write(ROOT/'PARENT_VERIFIED_startup.json',{'state':'passed','short_pair_independently_reverified':True,
              'formal_jobs':8,'formal_all8_started':True,'state_observed':suite['state'],'active_at_read':suite['active'],**protected})
        print('Native TRP1 startup verification passed');return
    if args.verify_only:
        suite=read(ROOT/'suite_status.json')
        assert suite['state']=='completed' and suite['completed_count']==8 and not suite['active']
        for j in suite['jobs']:assert verify(j)==j['metrics']
        actual=analyze(suite['jobs']);assert actual==read(ROOT/'ANALYSIS.json')
        write(ROOT/'PARENT_VERIFIED_terminal8.json',{'state':'passed','all8_runs_verified':True,'analysis_recomputed_exact':True,**protected})
        print('Native terminal8 verification passed');return
    jobs=[{'id':f'Reacher__innovation1__seed{s}','arm':'innovation1','seed':s,'gpu':1,
           'path':str(ROOT/'runs'/f'Reacher__innovation1__seed{s}'),'state':'pending'} for s in SEEDS]
    smokes=[{'id':'smoke__innovation1__'+rep,'arm':'innovation1','seed':91081,'gpu':1,
             'path':str(ROOT/'runs'/('smoke__innovation1__'+rep)),'state':'pending','smoke':True,'rep':rep} for rep in ('a','b')]
    assert all(not Path(j['path']).exists() for j in jobs+smokes)
    write(ROOT/'PREPARE_PASSED.json',{'state':'passed','formal_total':8,'short_repeats':2,'protected':protected,
                                   'source_hashes':launch['source_hashes']})
    if args.prepare_only:print('TRP1 prepare passed: 8 new I1, 40 preserved controls, 8 preserved I2');return
    assert not(ROOT/'suite_status.json').exists()
    active={};failure=None;gate=None;peak=0;reservation=3500;start=time.time()
    def status(state):
        write(ROOT/'suite_status.json',{'state':state,'task':'Reacher','round':'TRP1','total':8,
            'completed_count':sum(j['state']=='completed' for j in jobs),'jobs':jobs,'smoke_jobs':smokes,
            'active':{k:{'pid':v[0].pid,'gpu':1,'smoke':bool(v[2].get('smoke'))} for k,v in active.items()},
            'failure':failure,'engineering_gate':gate,'reservation_mib':reservation,
            'elapsed_seconds':time.time()-start,'coordinator_pid':os.getpid()})
    def launch_job(j):
        log=ROOT/(j['id']+'.log');handle=log.open('x');cmd=command(j)
        try:process=subprocess.Popen(cmd,cwd=ROOT/'source_i1',env=ENV,stdout=handle,stderr=subprocess.STDOUT)
        except BaseException:handle.close();raise
        j.update(state='running',pid=process.pid,log=str(log),command=cmd);active[j['id']]=(process,handle,j)
    status('queued')
    try:
        while True:
            free,memory=snapshot()
            for process,_,j in active.values():
                if j.get('smoke'):peak=max(peak,memory.get(process.pid,0))
            for key,(process,handle,j) in list(active.items()):
                code=process.poll()
                if code is None:continue
                handle.close();del active[key]
                try:
                    assert code==0,(j['id'],code)
                    j['metrics']=verify(j);j['state']='completed'
                except BaseException as e:
                    j['state']='failed'
                    if failure is None:failure={'id':j['id'],'error':repr(e),'log':j['log'],'traceback':traceback.format_exc()}
            if not failure and all(j['state']=='completed' for j in smokes) and gate is None:
                try:
                    pair=exact_pair(smokes[0]['path'],smokes[1]['path'],'innovation1')
                    assert peak>0
                    reservation=max(3500,peak+256)
                    gate={**pair,'peak_mib':peak,'reservation_mib':reservation,
                          'short_budget':SHORT,'seed':91081,'paths':[j['path'] for j in smokes],
                          'target_and_signal_replays_exact':True}
                    check_sources();verify_protected();write(ROOT/'SMOKE_VERIFIED.json',gate)
                except BaseException as e:
                    failure={'id':'engineering_gate','error':repr(e),'traceback':traceback.format_exc()}
            if failure:
                status('failure_active_workers_preserved' if active else 'failed')
                if not active:return 1
            elif all(j['state']=='completed' for j in jobs):
                check_sources();verify_protected();write(ROOT/'ANALYSIS.json',analyze(jobs));status('completed');return 0
            else:
                if gate is None:
                    if not active:
                        pending=next((j for j in smokes if j['state']=='pending'),None)
                        if pending and free[1]>3500+512:launch_job(pending)
                else:
                    while len(active)<8:
                        pending=next((j for j in jobs if j['state']=='pending'),None)
                        if pending is None:break
                        free,memory=snapshot()
                        outstanding=sum(max(0,reservation-memory.get(v[0].pid,0)) for v in active.values())
                        if free[1]-outstanding<reservation+512:break
                        launch_job(pending)
                status('running' if active else 'waiting_for_gpu_memory')
            time.sleep(2)
    except BaseException as e:
        failure={'id':'coordinator','error':repr(e),'traceback':traceback.format_exc()}
        status('failed_active_workers_preserved' if active else 'failed')
        # Never kill active trainers or retry scientific failures automatically.
        raise


if __name__=='__main__':sys.exit(main())
