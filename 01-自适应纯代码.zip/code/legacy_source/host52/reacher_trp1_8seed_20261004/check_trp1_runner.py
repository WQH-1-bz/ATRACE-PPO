"""Bounded CPU fixtures for TRP1 admission, exact artifacts and complete analysis."""
import copy
import ast
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics
import sys
import tempfile

sys.dont_write_bytecode = True
import torch
import run_trp1 as r


def rejected(function,*args,**kwargs):
    try:
        function(*args,**kwargs)
    except (AssertionError,KeyError,ValueError,TypeError):
        return
    raise AssertionError(f'{function.__name__} accepted an invalid fixture')


def analysis_checks():
    jobs=[{'metrics':{'seed':s,'final_return':-4.+(s-21)*.03,'auc':-5.+(s-21)*.05,
                     'maximum_lambda_deviation':.0004}} for s in r.SEEDS]
    bases=[{'method':m,'seed':s,'final_return':-4.5+(s-21)*.01,'auc':-5.5+(s-21)*.02}
           for m in r.METHODS for s in r.SEEDS]
    original_controls=r.controls
    r.controls=lambda:bases
    try:
        yes=r.analyze(jobs)
        assert yes['numerical_three_seed_development_pass'] and yes['next_action']=='stop_adjustment'
        assert yes['same_seed_beats_all_internal_on_both']==list(r.SEEDS)
        assert yes['groups']['prior3']['seeds']==[24,26,27]
        assert yes['groups']['prior5']['seeds']==[21,22,24,26,27]
        scores=[]
        for job in jobs:
            current=job['metrics'];seed=current['seed']
            normalized=[(current[e]-next(b[e] for b in bases if b['method']==m and b['seed']==seed))/
                        statistics.stdev(b[e] for b in bases if b['method']==m)
                        for m in r.METHODS for e in r.ENDPOINTS]
            scores.append((min(normalized),seed))
        ranking=[seed for _,seed in sorted(scores,key=lambda v:(-v[0],v[1]))]
        assert [x['seed'] for x in yes['descriptive_common_ranking']]==ranking
        assert yes['groups']['ranked3']['seeds']==ranking[:3]
        assert yes['groups']['ranked5']['seeds']==ranking[:5]
        tests=[yes['full8']['comparisons'][m][e] for m in r.METHODS for e in r.ENDPOINTS]
        assert len(tests)==10 and len(yes['base_rows'])==40 and len(yes['rows'])==8
        for m in r.METHODS:
            for e in r.ENDPOINTS:
                t=yes['full8']['comparisons'][m][e]
                assert t['n']==8 and t['df']==7 and t['ci95'][0]<t['mean_difference']<t['ci95'][1]
                delta=[j['metrics'][e]-next(b[e] for b in bases if b['method']==m and b['seed']==j['metrics']['seed']) for j in jobs]
                mean=sum(delta)/8
                exceed=sum(abs(sum(x*sign for x,sign in zip(delta,signs))/8)>=abs(mean)-1e-12
                           for signs in itertools.product((-1,1),repeat=8))
                assert t['exact_sign_flip_p_two_sided']==exceed/256
        carry=0.
        for rank,t in enumerate(sorted(tests,key=lambda v:v['p_two_sided'])):
            carry=max(carry,min(1.,(10-rank)*t['p_two_sided']))
            assert t['p_holm10']==carry
        for endpoint in r.ENDPOINTS:
            for row in bases:
                if row['method']=='linear':row[endpoint]=10.+(row['seed']-21)*.01
            no=r.analyze(jobs)
            assert not no['numerical_three_seed_development_pass']
            assert no['next_action']=='bounded_parent_review' and not no['automatic_next_candidate']
            assert not no['same_seed_beats_all_internal_on_both']
            assert all(not g['mean_both_beats_every_internal'] for g in no['groups'].values())
            for row in bases:
                if row['method']=='linear':
                    row[endpoint]=(-4.5 if endpoint=='final_return' else -5.5)+(row['seed']-21)*(.01 if endpoint=='final_return' else .02)
        no_activity=copy.deepcopy(jobs)
        no_activity[0]['metrics']['maximum_lambda_deviation']=2.**-53
        assert not r.analyze(no_activity)['numerical_three_seed_development_pass']
        rejected(r.analyze,jobs[:-1])
        rejected(r.analyze,[jobs[0],*jobs[:-1]])
        assert not yes['full8']['valid_independent_confirmation']
        assert all(not g['valid_independent_confirmation'] for g in yes['groups'].values())
        assert not yes['automatic_family_sweeps']
    finally:
        r.controls=original_controls


def return_checks():
    vector=torch.tensor([-3.,-1.],dtype=torch.float32)
    stats=r.replay_return_statistics(vector,'cpu')
    assert stats=={'training_return_count':2,'training_return_mean':-2.,'training_return_std':1.}
    assert r.verify_return_statistics(vector,stats,'cpu')==stats
    for bad in (torch.tensor([]),torch.tensor([math.nan]),torch.tensor([math.inf]),
                torch.tensor([1.],dtype=torch.float64),torch.ones((1,1))):
        rejected(r.validate_return_vector,bad)
    altered=dict(stats,training_return_mean=-2.+2.**-52)
    rejected(r.verify_return_statistics,vector,altered,'cpu')
    rejected(r.verify_return_statistics,vector,dict(stats,training_return_std=math.sqrt(2.)),'cpu')
    rejected(r.verify_return_statistics,vector,dict(stats,training_return_count=True),'cpu')
    rounded=torch.tensor([1e8,1.,-1e8],dtype=torch.float32)
    assert r.replay_return_statistics(rounded,'cpu')['training_return_mean']!=statistics.mean(rounded.tolist())
    assert len(r.return_names(153))==153 and r.return_names(153)[-1]=='training_episode_return_153.pt'
    assert len(r.return_names(8))==8
    values=torch.full((64,1024),math.nan,dtype=torch.float32)
    done=torch.zeros((64,1024),dtype=torch.bool)
    for position,value in zip(((0,1),(0,1023),(3,5),(63,0)),(1.,2.,-3.,0.)):
        done[position]=True;values[position]=value
    selected=values[done]
    record={'training_episode_values':values,'training_episode_return':selected.clone(),
            'done':done,'raw_training_return_signal_version':'TRP1'}
    r.validate_training_episode_audit(record,selected)
    bad=copy.deepcopy(record);bad['training_episode_values'][1,1]=0.
    rejected(r.validate_training_episode_audit,bad,selected)
    bad=copy.deepcopy(record);bad['training_episode_values'][0,1]=math.inf
    rejected(r.validate_training_episode_audit,bad,selected)
    bad=copy.deepcopy(record);bad['training_episode_values'][0,1]=math.nan
    rejected(r.validate_training_episode_audit,bad,selected)
    bad=copy.deepcopy(record);bad['training_episode_return'][0]+=1.
    rejected(r.validate_training_episode_audit,bad,selected)
    rejected(r.validate_training_episode_audit,record,selected.flip(0))


def tensor_checks():
    canonical=torch.tensor([0x7fc00000],dtype=torch.int32).view(torch.float32)
    alternate=torch.tensor([0x7fc00001],dtype=torch.int32).view(torch.float32)
    assert torch.isnan(canonical).all() and torch.isnan(alternate).all()
    assert not r.differences(canonical,canonical.clone())
    assert r.differences(canonical,alternate)
    assert r.differences(torch.tensor([0.]),torch.tensor([-0.]))
    assert r.differences(torch.tensor([1.]),torch.tensor([1.+2.**-52],dtype=torch.float64))
    assert r.differences(torch.tensor([1.]),torch.nextafter(torch.tensor([1.]),torch.tensor([2.])))
    assert not r.differences(torch.tensor(1.),torch.tensor(1.))
    assert not r.differences(torch.ones((3,2)).T,torch.ones((2,3)))
    old={key:torch.tensor([1.]) for key in r.OLD_AUDIT_KEYS}
    extended={**old,'target_device':'cuda:1','training_episode_values':canonical,
              'training_return_mean':-5.,'raw_training_return_signal_version':'TRP1'}
    assert not r.differences(r.old_audit_payload(old),r.old_audit_payload(extended))
    changed=dict(extended,actor_advantage=torch.tensor([2.]))
    assert r.differences(r.old_audit_payload(old),r.old_audit_payload(changed))


def pair_checks():
    with tempfile.TemporaryDirectory(prefix='trp1_runner_check_') as directory:
        paths=[Path(directory)/rep for rep in ('a','b')]
        for i,path in enumerate(paths):
            path.mkdir()
            config={'effective_steps':r.SHORT,'out':str(path),'device':'cuda:1'}
            (path/'config.json').write_text(json.dumps(config))
            checkpoint={'config':config,'model':{'w':torch.tensor([1.])},
                        'optimizer':{'state':{0:{'step':torch.tensor(5120.),'exp_avg':torch.tensor([.1]),'exp_avg_sq':torch.tensor([.2])}}},
                        'obs_stats':{'mean':torch.tensor([.3])},'reward_stats':{'var':torch.tensor(.4)},
                        'lambda_controller':{'value':.95001},'training_return_feedback':{'target':.95002}}
            for name in ('latest.pt','best.pt'):torch.save(checkpoint,path/name)
            for u,name in enumerate(r.return_names(8),1):torch.save(torch.tensor([float(-u)]),path/name)
            for u in r.audit_updates(config):
                torch.save({'update':u,'episode_values':torch.tensor([math.nan,1.])},path/f'fixed_critic_audit_{u:03d}.pt')
            for name in ('initial_evaluation.json','evaluations.jsonl','lambda_decisions.jsonl','stress_evaluation.json'):
                (path/name).write_text('{"mean": -1.0}\n')
            with (path/'progress.csv').open('w') as handle:
                writer=csv.DictWriter(handle,fieldnames=('steps','gae_lambda','elapsed_seconds','steps_per_second'))
                writer.writeheader()
                for u in range(1,9):writer.writerow({'steps':65536*u,'gae_lambda':.95,'elapsed_seconds':u+i,'steps_per_second':2+i})
        assert r.exact_pair(*paths)['state']=='passed'
        vector_path=paths[1]/'training_episode_return_007.pt'
        original=torch.load(vector_path,weights_only=False)
        torch.save(original+1,vector_path);rejected(r.exact_pair,*paths);torch.save(original,vector_path)
        audit_path=paths[1]/'fixed_critic_audit_005.pt'
        audit=torch.load(audit_path,weights_only=False)
        altered=copy.deepcopy(audit)
        altered['episode_values'].view(torch.int32)[0]=0x7fc00001
        torch.save(altered,audit_path);rejected(r.exact_pair,*paths);torch.save(audit,audit_path)
        checkpoint_path=paths[1]/'best.pt'
        checkpoint=torch.load(checkpoint_path,weights_only=False)
        for key,mutate in (
                ('model',lambda c:c['model']['w'].add_(1)),
                ('optimizer',lambda c:c['optimizer']['state'][0]['exp_avg'].add_(1)),
                ('obs_stats',lambda c:c['obs_stats']['mean'].add_(1)),
                ('reward_stats',lambda c:c['reward_stats']['var'].add_(1)),
                ('training_return_feedback',lambda c:c['training_return_feedback'].update(target=.99))):
            altered=copy.deepcopy(checkpoint);mutate(altered)
            torch.save(altered,checkpoint_path);rejected(r.exact_pair,*paths)
            torch.save(checkpoint,checkpoint_path)
        stress_path=paths[1]/'stress_evaluation.json'
        original_stress=stress_path.read_text();stress_path.write_text('{"mean": -2.0}\n')
        rejected(r.exact_pair,*paths);stress_path.write_text(original_stress)
        progress_path=paths[1]/'progress.csv'
        original_progress=progress_path.read_text();progress_path.write_text(original_progress.replace('0.95','0.96',1))
        rejected(r.exact_pair,*paths);progress_path.write_text(original_progress)
        assert r.exact_pair(*paths)['return_vector_count']==8


def main():
    torch.set_num_threads(1)
    analysis_checks();return_checks();tensor_checks();pair_checks()
    for smoke,budget in ((False,r.BUDGET),(True,r.SHORT)):
        cmd=r.command({'seed':21,'path':'/tmp/trp1_check_not_run','smoke':smoke})
        assert cmd[cmd.index('--steps')+1]==str(budget)
        assert cmd[cmd.index('--fixed-lambda')+1]=='.95'
        assert cmd[cmd.index('--fixed-critic-lambda')+1]=='.95'
        assert cmd[cmd.index('--device')+1]=='cuda:1'
        assert r.audit_updates({'effective_steps':budget})==[4,5,budget//65536]
    assert r.ENV['DPO_PPO_GRAPH']=='0' and r.ENV['DPO_WARP_DETERMINISTIC']=='run_to_run'
    assert r.SEEDS==tuple(range(21,29)) and r.BUDGET==10027008 and r.SHORT==524288
    tree=ast.parse((r.ROOT/'run_trp1.py').read_text())
    target=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='target_audits')
    audit_loop=next(node for node in target.body if isinstance(node,ast.For))
    replay_block=next(node for node in audit_loop.body if isinstance(node,ast.With))
    warmup=replay_block.body[0]
    assert isinstance(warmup,ast.For) and isinstance(warmup.iter,ast.Call)
    assert warmup.iter.func.id=='range' and warmup.iter.args[0].value==3
    assert len(warmup.body)==1 and isinstance(warmup.body[0],ast.Expr)
    call=warmup.body[0].value
    assert call.func.id=='replay' and [arg.value for arg in call.args[1:]]==[.99,.95]
    out={'state':'passed','checks':[
          'all8/all40 complete paired statistics, df7/CI/256 sign flips and Holm10',
          'all five controls and both endpoints required by each common group',
          'prior3/prior5 and common minimum-ten normalized-gain rank3/rank5 selection',
          'material adaptive activity and bounded stop/parent-review outcomes',
          'all153/formal and all8/short float32 return-vector contracts',
          'population mean/std/count exact checks and invalid vector rejection',
          'full done-mask/NaN selection and nonfinite completed-value rejection',
          'tensor byte equality including NaN payloads, signed zero and finite bits',
          'original audit-field-only preserved R4 prefix comparison',
          'A/B latest/best model, Adam, normalizers, controllers, every vector/audit/evaluation and non-time progress',
          'short/formal native command and fixed-target audit budget',
          'exactly three unconditional fixed95 warmup calls before each target audit'],
          'runner_sha256':hashlib.sha256((r.ROOT/'run_trp1.py').read_bytes()).hexdigest(),
          'check_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'no_environment_or_optimizer_calls':True,'reduction_fixture_device':'cpu',
          'native_admission_replay_device':'cuda:1'}
    (r.ROOT/'RUNNER_TRP1_CHECK.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out))


if __name__=='__main__':main()
