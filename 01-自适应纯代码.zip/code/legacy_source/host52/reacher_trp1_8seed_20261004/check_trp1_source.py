"""CPU admission of TRP1 raw-return selection, causality and native PPO isolation."""
import ast
from dataclasses import asdict
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import random
import sys

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'reacher_innovation12_r4_replayfix1_8seed_20261003/source_i1'
CPP = ROOT.parent / 'reacher_cpp3_8seed_20261003/source_i1'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(node):
    return ast.dump(node, include_attributes=False)


def main():
    name = 'source_checked_trp1'
    spec = importlib.util.spec_from_file_location(name, ROOT/'source_i1/lambda_training_return.py')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    C = module.TrainingReturn
    checks = []
    # Arithmetic must hold even non-binary constants exactly, not merely within tolerance.
    for raw_return in (-1e30, -10., -.3, 0., .3, 10., 1e30):
        c = C()
        for update in range(1, 154):
            assert c.step(update) == 0.
            c.observe(raw_return)
            assert c.value == c.target == .95 and c.trend == 0.
            assert c.fast_ema == c.slow_ema == raw_return
        assert all(math.isfinite(v) for v in asdict(c).values())
    checks.append('constant negative/zero/positive, non-binary and large finite returns retain95 exactly')
    c = C()
    for bad in (float('nan'), float('inf'), -float('inf')):
        before = asdict(c)
        try:
            c.observe(bad)
        except ValueError:
            pass
        else:
            raise AssertionError('invalid observation accepted')
        assert before == asdict(c)
    checks.append('nonfinite scalar rejected before observer mutation; negative and positive returns admitted')
    for start, after, direction in [(-10., -5., 1), (-5., -10., -1), (5., 10., 1), (10., 5., -1)]:
        c = C()
        values = []
        for update in range(1, 2001):
            old, target_before = c.value, c.target
            delta = c.step(update)
            values.append(c.value)
            assert c.observations == update - 1
            assert .90 <= c.value <= .99 and abs(delta) <= .001 + 1e-15
            if update <= 4:
                assert c.value == .95
            else:
                assert c.value == min(.99, max(.90, old + max(-.001, min(.001, .1*(target_before-old)))))
            fast, slow, target_before = c.fast_ema, c.slow_ema, c.target
            current = start if update <= 4 else after
            c.observe(current)
            if update == 1:
                assert c.fast_ema == c.slow_ema == current
            else:
                assert c.fast_ema == fast + .1*(current-fast)
                assert c.slow_ema == slow + .01*(current-slow)
            assert c.trend == min(1., max(-1., (c.fast_ema-c.slow_ema)/(abs(c.fast_ema)+abs(c.slow_ema)+1e-8)))
            if update % 4:
                assert c.target == target_before
            else:
                assert c.target == min(.99, max(.90, .95+.04*c.trend))
        assert direction*(values[8]-.95) > 1e-12
        assert abs(values[-1]-.95) < 1e-9
    checks.append('rising/falling signed returns show declared directions, bounds/cap and eventual return95 after a step')
    c = C()
    for update, raw_return in enumerate((-10., -9., -8., -7.), 1):
        assert c.step(update) == 0.
        c.observe(raw_return)
        if update < 4:
            assert c.target == .95
    assert c.target > .95 and c.value == .95
    target4 = c.target
    assert c.step(5) > 1e-12 and c.value == .95 + min(.001, .1*(target4-.95))
    value5 = c.value
    c.observe(-6.)
    assert c.value == value5 and c.target == target4
    checks.append('first target refresh4 changes labels only from5; current observation cannot affect current labels')
    c, shifted, scaled = C(), C(), C()
    for update in range(1, 9):
        raw_return = -10. + update
        for controller, value in [(c, raw_return), (shifted, raw_return+1000.), (scaled, 10.*raw_return)]:
            controller.step(update)
            controller.observe(value)
    assert c.trend > 0 and shifted.trend > 0
    assert abs(c.trend-shifted.trend) > .01
    assert abs(c.trend-scaled.trend) < 1e-9
    checks.append('additive reward-offset dependence demonstrated; approximate positive-scale normalization is bounded by epsilon')
    old_tree = ast.parse((OLD/'train_kl_relative.py').read_text())
    cpp_tree = ast.parse((CPP/'train_kl_relative.py').read_text())
    new_path = ROOT/'source_i1/train_kl_relative.py'
    new_tree = ast.parse(new_path.read_text())
    excluded = {'main', 'save_fixed_critic_audit', 'collect_training_return'}
    def definitions(tree):
        return {n.name: dump(n) for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name not in excluded}
    assert definitions(old_tree) == definitions(cpp_tree) == definitions(new_tree)
    def loop(tree, name):
        main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
        return [n for n in ast.walk(main) if isinstance(n, ast.For) and isinstance(n.target, ast.Name) and n.target.id == name]
    for label in ('epoch', 't'):
        original, current = loop(old_tree, label), loop(new_tree, label)
        assert len(original) == len(current) == 1
        assert dump(original[0]) == dump(current[0]), ('native loop changed', label)
    checks.append('ActorCritic, RunningStats, native GAE/masks/evaluate, fresh physics sampler and complete PPO epoch AST unchanged')
    collectors = [n for n in new_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'collect_training_return']
    assert len(collectors) == 1
    namespace = {'torch': torch, 'math': math}
    exec(compile(ast.fix_missing_locations(ast.Module(body=collectors, type_ignores=[])), str(new_path), 'exec'), namespace)
    collect = namespace['collect_training_return']
    done = torch.tensor([[True, False, True], [False, True, False]])
    raw = torch.tensor([[-3., float('nan'), 2.], [float('nan'), 0., float('nan')]], dtype=torch.float32)
    vector, mean, std = collect(raw, done)
    assert torch.equal(vector, torch.tensor([-3., 2., 0.]))
    assert mean == float(vector.mean()) and std == float(vector.std(unbiased=False))
    for invalid, invalid_done in [
        (torch.full_like(raw, float('nan')), torch.zeros_like(done)),
        (raw.masked_fill(done, float('nan')), done),
        (raw.masked_fill(done, float('inf')), done),
        (raw.masked_fill(~done, 0.), done),
        (raw.double(), done),
        (raw, done.float()),
        (raw, done[:1]),
    ]:
        try:
            collect(invalid, invalid_done)
        except RuntimeError:
            pass
        else:
            raise AssertionError('invalid raw return/done tensor admitted')
    checks.append('actual done selection preserves every negative/zero/positive entry; no completion/nonfinite done/invalid non-done/dtype/mask mismatch aborts')
    python_rng, numpy_rng, torch_rng = random.getstate(), np.random.get_state(), torch.random.get_rng_state().clone()
    for update in range(1, 9):
        c.step(update)
        c.observe(float(update))
        collect(raw, done)
    assert random.getstate() == python_rng
    after_numpy = np.random.get_state()
    assert numpy_rng[0] == after_numpy[0] and np.array_equal(numpy_rng[1], after_numpy[1]) and numpy_rng[2:] == after_numpy[2:]
    assert torch.equal(torch_rng, torch.random.get_rng_state())
    checks.append('controller and raw-return mean/std reductions consume no Python/NumPy/Torch RNG draws')
    source = new_path.read_text()
    assert source.index('collect_training_return(\n                        episode_tensor, dbuf[:end])') < source.index('delta=feedback.step(update)')
    assert source.index('torch.save(completed_returns.detach().cpu().clone()') < source.index('for epoch in range')
    assert source.index('feedback.observe(training_return_mean)') > source.index('optimizer.step()')
    assert source.count('feedback.observe(') == 1
    assert 'critic_predictability' not in source and 'normalized_critic_residual' not in source
    controller_ast = ast.parse((ROOT/'source_i1/lambda_training_return.py').read_text())
    used = {n.id for n in ast.walk(controller_ast) if isinstance(n, ast.Name)}
    assert not used.intersection({'seed', 'task', 'evaluate', 'eval_mean', 'final_return', 'auc', 'realized_kl', 'random', 'torch', 'numpy'})
    original_protocol = ROOT.parent.parent/'REACHER_TRP1_PROTOCOL.md'
    if original_protocol.is_file():
        assert (ROOT/'REACHER_TRP1_PROTOCOL.md').read_bytes() == original_protocol.read_bytes()
    checks.append('cached raw training mean alone observes after PPO; invalid completions abort before step; no KL/critic/task/seed/evaluation/RNG observer')
    paths = sorted(p for p in (ROOT/'source_i1').iterdir() if p.is_file())
    assert len(paths) == 19 and not (ROOT/'source_i1/lambda_critic_reference.py').exists()
    changed = [p.name for p in paths if not (CPP/p.name).exists() or sha(p) != sha(CPP/p.name)]
    assert sorted(changed) == ['lambda_training_return.py', 'train_kl_relative.py']
    assert all(sha(p) == sha(OLD/p.name) for p in paths if p.name not in changed)
    report = {'state': 'passed', 'checks': checks, 'source_changed_or_added': sorted(changed),
              'source_removed': ['lambda_critic_reference.py'], 'unchanged_original_support_files': 17,
              'source_hashes': {p.name: sha(p) for p in paths}, 'check_sha256': sha(Path(__file__)),
              'protocol_sha256': sha(ROOT/'REACHER_TRP1_PROTOCOL.md'),
              'scope': 'CPU/static admission only; strict native CUDA short A/B, return/target/controller replay remains required'}
    (ROOT/'SOURCE_TRP1_CHECK.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
