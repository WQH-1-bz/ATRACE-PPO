"""Prepare/freeze/start the reviewed candidate without changing old results."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import tarfile

ROOT=Path(__file__).resolve().parent
HOST='wch@192.168.5.52'
REMOTE='/home/mumu01/ssd3/wch/reacher_trp1_8seed_20261004'
ORIGIN='/home/mumu01/ssd3/wch/reacher_cpp3_8seed_20261003'
UNIT='dpo_reacher_trp1_8seed_20261004.service'
PROTOCOL='REACHER_TRP1_PROTOCOL.md'
PROGRAMS=['run_trp1.py','r4_verification_helpers.py','prepare_remote_trp1.py',
          'check_trp1_source.py','check_trp1_runner.py','SOURCE_TRP1_CHECK.json',
          'RUNNER_TRP1_CHECK.json','deploy_trp1.py',PROTOCOL,UNIT,
          'CPP3_DECOMPOSITION_PROVENANCE.json'] + [
          'CPP3_DECOMPOSITION_EVIDENCE/'+name for name in
          ['REACHER_CPP3_ADVANTAGE_DECOMPOSITION_PROTOCOL.md','ANALYSIS.json','INPUT_MANIFEST.json',
           'PRE_EXECUTION_REVIEW.json','PARENT_DIAGNOSTIC_INTERPRETATION.json','RESULTS.md',
           'decompose.py','PARENT_TERMINAL_INTERPRETATION.json']]


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n')


def ssh(cmd,timeout=180):
    r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',HOST,cmd],
                     text=True,capture_output=True,timeout=timeout)
    return {'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}


def scp(args):
    r=subprocess.run(['scp','-q','-o','BatchMode=yes','-o','ConnectTimeout=10',*args],
                     text=True,capture_output=True,timeout=180)
    assert r.returncode==0,(r.stdout,r.stderr)


def service_unit():
    return '\n'.join(['[Unit]','Description=Reacher TRP1 deterministic innovation1 eight-seed development','',
              '[Service]','Type=simple','Restart=no','KillMode=process','TimeoutStopSec=30',
              'Environment=PYTHONUNBUFFERED=1','Environment=PYTHONDONTWRITEBYTECODE=1',
              'Environment=PYTHONPATH='+REMOTE+'/analysis_dependencies',
              'Environment=OMP_NUM_THREADS=1','Environment=MKL_NUM_THREADS=1',
              'Environment=DPO_TORCH_DETERMINISTIC=1','Environment=DPO_WARP_DETERMINISTIC=run_to_run',
              'Environment=DPO_WARP_DETERMINISTIC_MAX_RECORDS=8','Environment=CUBLAS_WORKSPACE_CONFIG=:4096:8',
              'Environment=DPO_PPO_GRAPH=0','Environment=TMPDIR='+REMOTE+'/tmp',
              'WorkingDirectory='+REMOTE,'ExecStart='+REMOTE+'/.venv/bin/python '+REMOTE+'/run_trp1.py',
              'StandardOutput=append:'+REMOTE+'/launcher.log','StandardError=append:'+REMOTE+'/launcher.log',
              '','[Install]','WantedBy=default.target',''])


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['deploy','freeze','prepare','start'],required=True);args=ap.parse_args()
    q=shlex.quote;staging=ROOT/'deployment';staging.mkdir(exist_ok=True)
    if args.stage=='deploy':
        assert read(ROOT/'SOURCE_TRP1_CHECK.json')['state']=='passed'
        assert sha(ROOT/PROTOCOL)==sha(ROOT.parent.parent/PROTOCOL)
        (ROOT/UNIT).write_text(service_unit())
        reference=ROOT.parent/'reacher_baselines8_10m_20261001/ANALYSIS.json'
        rows=[r for r in read(reference)['rows'] if r['method'] in ['fixed90','fixed95','fixed99','linear','critic_aware']]
        assert len(rows)==40
        write(ROOT/'INTERNAL5_REFERENCE.json',{'state':'previously_verified','rows':rows,
              'original_analysis_sha256':sha(reference),'original_local_analysis':str(reference.resolve()),
              'selection':'all8 seeds for every internal baseline; no result recomputed or replaced'})
        initial=[name for name in PROGRAMS if name!='RUNNER_TRP1_CHECK.json']+['INTERNAL5_REFERENCE.json','source_i1']
        bundle=staging/'PREPARE_BUNDLE.tar.gz'
        with tarfile.open(bundle,'w:gz') as archive:
            for name in initial:archive.add(ROOT/name,arcname=name,filter=lambda e:None if '__pycache__' in e.name else e)
        result=ssh('\n'.join(['set -eu','test ! -e '+q(REMOTE),'mkdir '+q(REMOTE)]))
        write(staging/'CREATE_RESULT.json',result);assert result['returncode']==0,result
        scp([str(bundle),HOST+':'+REMOTE+'/PREPARE_BUNDLE.tar.gz'])
        cmd='\n'.join(['set -eu','tar -xzf '+q(REMOTE+'/PREPARE_BUNDLE.tar.gz')+' -C '+q(REMOTE),
             'python3 '+q(REMOTE+'/prepare_remote_trp1.py')+' --root '+q(REMOTE)+' --origin '+q(ORIGIN),
             'PYTHONPATH='+q(REMOTE+'/analysis_dependencies')+' PYTHONDONTWRITEBYTECODE=1 '+q(REMOTE+'/.venv/bin/python')+' '+q(REMOTE+'/check_trp1_source.py'),
             'PYTHONPATH='+q(REMOTE+'/analysis_dependencies')+' PYTHONDONTWRITEBYTECODE=1 '+q(REMOTE+'/.venv/bin/python')+' '+q(REMOTE+'/check_trp1_runner.py')])
        result=ssh(cmd)
    elif args.stage=='freeze':
        for name in ['REMOTE_PREPARED.json','PROTECTED_INVENTORY.json','SOURCE_TRP1_CHECK.json','RUNNER_TRP1_CHECK.json']:
            scp([HOST+':'+REMOTE+'/'+name,str(ROOT/name)])
        assert read(ROOT/'SOURCE_TRP1_CHECK.json')['state']=='passed'
        assert read(ROOT/'RUNNER_TRP1_CHECK.json')['state']=='passed'
        assert read(ROOT/'RUNNER_TRP1_CHECK.json')['runner_sha256']==sha(ROOT/'run_trp1.py')
        prepared=read(ROOT/'REMOTE_PREPARED.json');assert prepared['state']=='prepared'
        assert prepared['applicable_agents']==[],prepared['applicable_agents']
        sources={p.name:sha(p) for p in (ROOT/'source_i1').iterdir() if p.is_file()}
        assert len(sources)==19 and sources==read(ROOT/'SOURCE_TRP1_CHECK.json')['source_hashes']
        programs={name:sha(ROOT/name) for name in PROGRAMS}
        manifest={'state':'frozen','timestamp_utc':datetime.now(timezone.utc).isoformat(),
              'root':REMOTE,'host':HOST,'service':UNIT,'gpu':1,'max_concurrency':8,'formal_total':8,
              'seeds':list(range(21,29)),'smoke_seed':91081,'short_repeats':2,
              'source_hashes':sources,'program_hashes':programs,
              'protected_inventory_sha256':sha(ROOT/'PROTECTED_INVENTORY.json'),
              'internal_reference_sha256':sha(ROOT/'INTERNAL5_REFERENCE.json'),
              'formal_budget':10027008,'short_budget':524288,
              'controller_family':'raw_training_episode_return_trend','controller_version':'TRP1',
              'original_cpp3_root':ORIGIN,'original_cpp3_inherited_protected_count':789,
              'all_update_return_vectors_required':True,'mean_std_replay_device':'cuda:1',
              'strict_target_replay_warmup_count':3,'strict_target_replay_warmup_scope':'before each saved target audit',
              'short_minimum_lambda_activity':1e-12,'service_sha256':sha(ROOT/UNIT),
              'decomposition_provenance_scope':'copied local bytes verified; original local absolute paths are provenance only',
              'protected_internal_controls':40,'protected_innovation2_runs':8,
              'base_reruns':0,'i2_reruns':0,'numerical_acceptance':'three-seed means both beat all internal5'}
        write(ROOT/'LAUNCH_MANIFEST.json',manifest)
        (ROOT/UNIT).write_text(service_unit())
        scp([str(ROOT/'LAUNCH_MANIFEST.json'),str(ROOT/UNIT),HOST+':'+REMOTE+'/'])
        frozen=['LAUNCH_MANIFEST.json','PROTECTED_INVENTORY.json','INTERNAL5_REFERENCE.json',*PROGRAMS]
        cmd='\n'.join(['set -eu','chmod 444 '+q(REMOTE)+'/source_i1/*.*',
               'chmod 444 '+' '.join(q(REMOTE+'/'+n) for n in frozen),
               'mkdir -p "$HOME/.config/systemd/user"',
               'cp '+q(REMOTE+'/'+UNIT)+' "$HOME/.config/systemd/user/"','systemctl --user daemon-reload'])
        result=ssh(cmd)
        for p in (ROOT/'source_i1').iterdir():
            if p.is_file():p.chmod(0o444)
    elif args.stage=='prepare':
        result=ssh('PYTHONPATH='+q(REMOTE+'/analysis_dependencies')+' PYTHONDONTWRITEBYTECODE=1 '+q(REMOTE+'/.venv/bin/python')+' '+q(REMOTE+'/run_trp1.py')+' --prepare-only')
        if result['returncode']==0:scp([HOST+':'+REMOTE+'/PREPARE_PASSED.json',str(ROOT/'PREPARE_PASSED.json')])
    else:
        result=ssh('\n'.join(['set -eu','test -e '+q(REMOTE+'/PREPARE_PASSED.json'),
              'test ! -e '+q(REMOTE+'/suite_status.json'),'systemctl --user start '+q(UNIT),
              'systemctl --user show '+q(UNIT)+' -p ActiveState -p SubState -p MainPID -p ExecMainStatus -p Result']))
    record={'stage':args.stage,'host':HOST,'root':REMOTE,'timestamp_utc':datetime.now(timezone.utc).isoformat(),**result}
    write(staging/(args.stage.upper()+'_RESULT.json'),record);print(json.dumps(record))
    assert result['returncode']==0,result


if __name__=='__main__':main()
