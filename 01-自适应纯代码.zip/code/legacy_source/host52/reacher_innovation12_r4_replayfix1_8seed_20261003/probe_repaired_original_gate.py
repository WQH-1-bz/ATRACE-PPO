"""Verify the old completed engineering run with the versioned, strict replay repair."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('repair_native_complete_gate', root / 'run_innovation_adjustment_r4.py')
runner = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = runner
spec.loader.exec_module(runner)
source_hashes = runner.check_source()
old = '/home/mumu01/ssd3/wch/reacher_innovation12_r4_8seed_20261003/runs/smoke__innovation1__a'
job = {'id': 'smoke__innovation1__a', 'rep': 'a', 'arm': 'innovation1',
       'seed': 91081, 'gpu': 1, 'path': old}
metrics = runner.verify(job, 'Reacher', short=True)
assert metrics['fixed_critic_target_replay'] == 'passed'
assert metrics['r3_held_prefix_exact'] and metrics['fixed_critic_replay_warmup_count'] == 3
assert metrics['fixed_critic_replay_runtime']['comparison'] == 'torch.equal'
report = {'state': 'passed', 'scope': 'original completed engineering run only; no new training',
          'old_failed_gate_artifacts_preserved': True, 'original_gate_path': old,
          'formal_results': 0, 'metrics': metrics, 'source_hashes': source_hashes,
          'repaired_runner_sha256': hashlib.sha256((root / 'run_innovation_adjustment_r4.py').read_bytes()).hexdigest()}
(root / 'REPAIRED_GATE_REPLAY_ORIGINAL.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
print(json.dumps({'state': report['state'], 'target_replay': metrics['fixed_critic_target_replay'],
                  'r3_held_prefix_exact': metrics['r3_held_prefix_exact'], 'warmup_count': 3}))
