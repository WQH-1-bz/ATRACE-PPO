"""One bounded deterministic two-arm round; all eight matched seeds retained."""
import argparse
import ast
import copy
import csv
import hashlib
import importlib.util
import itertools
import json
import math
import os
from pathlib import Path
import statistics
import struct
import subprocess
import sys
import time
import traceback
import types

sys.dont_write_bytecode = True

import torch
from scipy import stats

ROOT = Path(__file__).resolve().parent
SOURCE_DIRS = {'innovation1': ROOT / 'source_i1', 'innovation2': ROOT / 'source_i2'}
SOURCE_MANIFESTS = {'innovation1': 'source_i1_hashes.json', 'innovation2': 'source_i2_hashes.json'}
BUDGET, SHORT, SWITCH, SHORT_SWITCH = 10027008, 524288, 4980736, 262144
FIXED_CRITIC_REPLAY_WARMUP_COUNT = 3
ARMS, SEEDS, ENDPOINTS = ('innovation1', 'innovation2'), tuple(range(21, 29)), ('final_return', 'auc')
FOCUS_GROUPS = {'3': [24, 26, 27], '5': [21, 22, 24, 26, 27]}
DET = {'torch': True, 'warp': 'run_to_run', 'warp_max_records': 8,
       'cublas_workspace_config': ':4096:8'}
ENV = {**os.environ, 'PYTHONUNBUFFERED': '1', 'PYTHONDONTWRITEBYTECODE': '1',
       'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1', 'DPO_TORCH_DETERMINISTIC': '1',
       'DPO_WARP_DETERMINISTIC': 'run_to_run', 'DPO_WARP_DETERMINISTIC_MAX_RECORDS': '8',
       'CUBLAS_WORKSPACE_CONFIG': ':4096:8', 'DPO_PPO_GRAPH': '0',
       'XDG_CACHE_HOME': str(ROOT / 'cache'), 'WARP_CACHE_PATH': str(ROOT / 'cache/warp'),
       'CUDA_CACHE_PATH': str(ROOT / 'cache/cuda'), 'TORCH_HOME': str(ROOT / 'cache/torch'),
       'TMPDIR': str(ROOT / 'tmp')}


def write(path, value):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def read(path):
    return json.loads(path.read_text())


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def same(a, b):
    assert abs(float(a) - float(b)) < 1e-10, (a, b)


def jsonl(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def check_source():
    launch = read(ROOT / 'LAUNCH_MANIFEST.json')
    assert launch['state'] == 'frozen' and launch['formal_total'] == 16
    assert launch['task'] == 'Reacher' and launch['gpus'] == [1] and launch['smoke_seed'] == 91081
    assert launch['seed_ids'] == list(SEEDS)
    assert sha(ROOT / 'run_innovation_adjustment_r4.py') == launch['runner_sha256']
    assert sha(ROOT / 'verify_parent_r4.py') == launch['verifier_sha256']
    protocol = Path(launch['protocol_file'])
    assert str(protocol) == 'REACHER_INNOVATION_R4_PROTOCOL.md'
    assert not protocol.is_absolute() and '..' not in protocol.parts
    assert sha(ROOT / protocol) == launch['protocol_sha256']
    assert sha(ROOT / 'R3_REFERENCE_MANIFEST.json') == launch['r3_reference_manifest_sha256']
    references = read(ROOT / 'R3_REFERENCE_MANIFEST.json')
    assert references['state'] == 'verified' and references['task'] == 'Reacher'
    assert set(references['formal']) == {str(seed) for seed in SEEDS}
    assert set(references['smokes']) == {'a', 'b'}
    hashes = {}
    for arm in ARMS:
        hashes[arm] = read(ROOT / SOURCE_MANIFESTS[arm])
        assert len(hashes[arm]) == 18 and hashes[arm] == launch['source_hashes'][arm]
        assert {p.name for p in SOURCE_DIRS[arm].iterdir() if p.is_file()} == set(hashes[arm])
        for name, expected in hashes[arm].items():
            path = SOURCE_DIRS[arm] / name
            assert sha(path) == expected, (arm, name)
            assert not (path.stat().st_mode & 0o222), ('source not frozen', path)
    return hashes


def controller_class():
    name = 'r4_frozen_kl_feedback'
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, SOURCE_DIRS['innovation1'] / 'lambda_kl_relative.py')
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return sys.modules[name].KLFeedback


def batch(evaluation, task):
    assert len(evaluation['returns']) == len(evaluation['lengths']) == 32
    assert all(math.isfinite(v) for v in evaluation['returns'])
    assert math.isfinite(evaluation['mean']) and math.isfinite(evaluation['std'])
    assert evaluation['lengths'] == [50 if task == 'Reacher' else 1000] * 32


def auc(path, budget, task):
    initial, evaluations = read(path / 'initial_evaluation.json'), jsonl(path / 'evaluations.jsonl')
    for evaluation in [initial, *evaluations]:
        batch(evaluation, task)
    points = [(0, initial['mean'])] + [(e['steps'], e['mean']) for e in evaluations]
    assert points[-1][0] == budget and all(a[0] < b[0] for a, b in zip(points, points[1:]))
    area = sum((b[0] - a[0]) * (a[1] + b[1]) / 2 for a, b in zip(points, points[1:])) / budget
    assert math.isfinite(area)
    return area, initial, evaluations


def verify_base(row, task):
    path = Path(row['path'])
    expected = row.get('artifact_hashes', row.get('artifact_sha256'))
    assert expected and len(expected) == 9
    if 'artifact_sha256' in row:
        assert expected == row['artifact_sha256']
    for name, digest in expected.items():
        assert sha(path / name) == digest, (path, name)
        assert not ((path / name).stat().st_mode & 0o222), ('writable Base', path, name)
    config, summary, status = (read(path / name) for name in ('config.json', 'summary.json', 'status.json'))
    assert config['seed'] == row['seed'] and config['task'].startswith(task + '-v4')
    assert config['determinism'] == DET and config['effective_steps'] == BUDGET
    assert config['noise_mode'] == 'none' and config['noise_scale'] == 0
    assert config['lambda_mode'] == 'fixed' and config['fixed_lambda'] == .95
    assert summary['state'] == status['state'] == 'completed' and summary['reload_check'] == 'passed'
    assert summary['steps'] == status['steps'] == BUDGET
    progress = list(csv.DictReader((path / 'progress.csv').open()))
    assert len(progress) == 153 and all(float(row['gae_lambda']) == .95 for row in progress)
    assert [int(row['steps']) for row in progress] == [i * 65536 for i in range(1, 154)]
    area, initial, evaluations = auc(path, BUDGET, task)
    assert [evaluation['steps'] for evaluation in evaluations] == [262144 * i for i in range(1, 39)] + [BUDGET]
    same(area, row['auc'])
    same(summary['final_eval']['mean'], row['final_return'])
    same(evaluations[-1]['mean'], row['final_return'])
    batch(summary['final_eval'], task)
    return {**row, 'initial_return': initial['mean'], 'xml_sha256': config['xml_sha256']}


def command(job, task, short=False):
    arm, budget = job['arm'], SHORT if short else BUDGET
    trainer = 'train_kl_relative.py' if arm == 'innovation1' else 'train_pae_baseline.py'
    cmd = [str(ROOT / '.venv/bin/python'), str(SOURCE_DIRS[arm] / trainer), '--out', job['path'],
           '--task', task, '--seed', str(job['seed']), '--device', f"cuda:{job['gpu']}",
           '--steps', str(budget), '--num-envs', '1024', '--rollout', '64', '--batch-size', '1024',
           '--eval-envs', '32', '--eval-every', '262144']
    switch = SHORT_SWITCH if short else SWITCH
    if arm == 'innovation1':
        cmd += ['--epochs', '10', '--kl-logratio-deadband', '0', '--adaptive-start-update', '4',
                '--adaptive-start-steps', str(switch), '--fixed-critic-lambda', '.95', '--save-fixed-critic-audit']
    else:
        cmd += ['--method', 'pae', '--staged-full', '--stage-switch-steps', str(switch),
                '--overlap-start-steps', '0', '--overlap-stop-steps', str(budget),
                '--retained-tail-steps', '16', '--retained-tail-correction', '--retained-tail-diagnostics']
    return cmd


def verify_config(job, task, short=False):
    config = read(Path(job['path']) / 'config.json')
    budget, switch = (SHORT, SHORT_SWITCH) if short else (BUDGET, SWITCH)
    assert config['seed'] == job['seed'] and config['task'].startswith(task)
    assert config['device'] == f"cuda:{job['gpu']}" and config['determinism'] == DET
    assert config['effective_steps'] == budget and config['steps'] == budget
    for key, expected in [('num_envs', 1024), ('rollout', 64), ('batch_size', 1024),
                          ('epochs', 10), ('eval_envs', 32), ('eval_every', 262144), ('gamma', .99)]:
        assert config[key] == expected, (key, config[key], expected)
    if job['arm'] == 'innovation1':
        assert config['lambda_mode'] == 'kl_feedback' and config['kl_logratio_deadband'] == 0
        assert config['noise_mode'] == 'none' and config['noise_scale'] == 0
        assert config['adaptive_start_update'] == 4 and config['adaptive_start_steps'] == switch
        assert (config['kl_fast_alpha'], config['kl_slow_alpha']) == (.1, .01)
        assert (config['kl_lower_bound'], config['kl_upper_bound']) == (.90, .99)
        assert config['initial_lambda'] == config['fixed_lambda'] == .95
        assert config['fixed_critic_lambda'] == .95 and config['save_fixed_critic_audit']
        fixed = config['fixed_critic_target_design']
        assert fixed['enabled'] and fixed['audit_enabled'] and fixed['critic_lambda'] == .95
        assert fixed['actor_advantage_lambda'] == 'causal adaptive KL feedback'
        assert fixed['critic_return_lambda'] == 'fixed 0.95' and fixed['targets_consumed_by_ppo']
        assert fixed['audit_updates'] == fixed_audit_updates(config)
        assert fixed['audit_files'] == fixed_audit_names(config)
        assert not any(config[k] for k in ['adaptive_overlap', 'readiness_boost', 'critic_readiness_gate',
                                           'adaptive_early_target_gate', 'kl_headroom_gain'])
        activation = config['lambda_design']['step_activation']
        assert activation['start_steps'] == switch and activation['observe_during_hold']
        assert not activation['reference_reinitialized'] and not activation['evaluation_return_used']
    else:
        assert config['staged_full'] and config['stage_switch_steps'] == switch
        assert config['pae_prefix'] == 48 and config['pae_tail'] == config['retained_tail_steps'] == 16
        assert config['pae_ratio'] == .75 and config['initial_lambda'] == .95
        assert config['retained_tail_diagnostics'] and config['retained_tail_correction']
        assert not any(config[k] for k in ['adaptive_kl', 'readiness_boost', 'force_pae_overlap', 'adaptive_overlap'])
        assert config['staged_full_design']['advantage_std_unbiased'] is False
        trace = config['retained_tail_trace_design']
        assert trace['enabled'] and trace['version'] == 'capped_future_action_trace_v1'
        assert trace['fixed_lambda'] == .95 and trace['ratio_cap'] == 1.0
        assert trace['targets_frozen_before_epochs'] and trace['fresh_ratio'] == 'exactly 1 at frozen-target construction'
        assert not any(trace[key] for key in ('unbiased_claim', 'original_impala_actor',
                       'evaluation_return_used', 'diagnostics_control_training',
                       'extra_environment_steps', 'extra_optimizer_steps', 'horizon_correction'))
        source_hashes = read(ROOT / SOURCE_MANIFESTS['innovation2'])
        for name, expected in config['source_sha256'].items():
            assert expected == source_hashes[name]
    return config


def checkpoint_steps(path, arm, expected):
    checkpoint = torch.load(path / 'latest.pt', map_location='cpu', weights_only=False)
    optimizers = {'ppo': checkpoint['optimizer']} if arm == 'innovation1' else checkpoint['optimizers']
    assert set(optimizers) == {'ppo'}
    for optimizer in optimizers.values():
        assert optimizer['state']
        for state in optimizer['state'].values():
            step = state['step'].item() if isinstance(state['step'], torch.Tensor) else state['step']
            assert step == expected, ('Adam steps', step, expected)
            for key in ('exp_avg', 'exp_avg_sq'):
                assert bool(torch.isfinite(state[key]).all()), ('nonfinite optimizer', key)
    assert all(bool(torch.isfinite(value).all()) for value in checkpoint['model'].values())
    assert checkpoint['config'] == read(path / 'config.json')
    return checkpoint


def fixed_audit_updates(config):
    return [4, 5, 8] if config['effective_steps'] == SHORT else [76, 77, 153]


def fixed_audit_names(config):
    return [f'fixed_critic_audit_{update:03d}.pt' for update in fixed_audit_updates(config)]


def source_gae():
    """Compile only the frozen source GAE function; no environment/model imports."""
    torch.use_deterministic_algorithms(True)
    torch.set_num_threads(1)
    name = 'r4_replayfix1_frozen_source_gae_replay'
    if name not in sys.modules:
        source = SOURCE_DIRS['innovation1'] / 'train_kl_relative.py'
        tree = ast.parse(source.read_text())
        functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'gae']
        assert len(functions) == 1
        function = functions[0]
        assert len(function.decorator_list) == 1
        decorator = function.decorator_list[0]
        assert isinstance(decorator, ast.Attribute) and decorator.attr == 'script'
        assert isinstance(decorator.value, ast.Attribute) and decorator.value.attr == 'jit'
        assert isinstance(decorator.value.value, ast.Name) and decorator.value.value.id == 'torch'
        module = types.ModuleType(name)
        module.__file__, module.torch = str(source), torch
        sys.modules[name] = module
        # Retained source positions let torch.jit inspect the real frozen function.
        program = ast.Module(body=[function], type_ignores=[])
        exec(compile(ast.fix_missing_locations(program), str(source), 'exec'), module.__dict__)
    return sys.modules[name].gae


def verify_fixed_critic_audits(job, config, short=False):
    path = Path(job['path'])
    decisions = {row['update']: row for row in jsonl(path / 'lambda_decisions.jsonl')}
    replay = source_gae()
    names, held = fixed_audit_names(config), 4 if short else 76
    rows, separated = [], 0
    float_keys = ('normalized_reward', 'values', 'next_values', 'actor_advantage', 'consumed_critic_return')
    for update, name in zip(fixed_audit_updates(config), names):
        record = torch.load(path / name, map_location='cpu', weights_only=False)
        assert record['update'] == update and record['steps'] == update * 65536
        assert record['prior_collected_steps'] == (update - 1) * 65536
        assert record['used_per_world'] == 64 and record['gamma'] == .99
        assert record['target_device'] == config['device']
        same(record['actor_lambda'], decisions[update]['actor_lambda_used'])
        same(record['actor_lambda'], decisions[update]['lambda_used'])
        assert record['critic_lambda'] == config['fixed_critic_lambda'] == .95
        for key in (*float_keys, 'terminated', 'done'):
            assert isinstance(record[key], torch.Tensor) and record[key].shape == (64, 1024), (name, key)
            assert record[key].device.type == 'cpu' and not record[key].requires_grad
            if key in float_keys:
                assert record[key].dtype == torch.float32 and bool(torch.isfinite(record[key]).all()), (name, key)
            else:
                assert record[key].dtype == torch.bool, (name, key)
        assert not bool((record['terminated'] & ~record['done']).any())
        device = torch.device(record['target_device'])
        if device.type == 'cuda':
            assert torch.cuda.is_available() and device == torch.device(job.get('device', f"cuda:{job['gpu']}"))
        inputs = [record[key].to(device) for key in ('normalized_reward', 'values', 'next_values', 'terminated', 'done')]
        with torch.no_grad():
            if not rows:
                # The trainer has already warmed GAE by its first saved update.
                # Use exactly three discarded calls, independent of comparisons.
                for _ in range(FIXED_CRITIC_REPLAY_WARMUP_COUNT):
                    replay(*inputs, .99, .95)
            actor, adaptive_return = replay(*inputs, .99, record['actor_lambda'])
            fixed_advantage, fixed_return = replay(*inputs, .99, .95)
            assert torch.equal(actor, record['actor_advantage'].to(device)), ('actor target replay', name)
            assert torch.equal(fixed_return, record['consumed_critic_return'].to(device)), ('critic target replay', name)
            differs = not torch.equal(actor, fixed_advantage)
            if update == held:
                assert record['actor_lambda'] == .95 and not differs
                assert torch.equal(adaptive_return, fixed_return)
            else:
                separated += int(differs and not torch.equal(adaptive_return, fixed_return))
        rows.append({'update': update, 'steps': record['steps'], 'actor_lambda': record['actor_lambda'],
                     'critic_lambda': .95, 'replay_device': str(device), 'actor_critic_targets_differ': differs,
                     'artifact_sha256': sha(path / name)})
        del inputs, actor, adaptive_return, fixed_advantage, fixed_return, record
    assert separated > 0, 'Saved post-activation actor and critic targets never separated'
    return {'fixed_critic_target_replay': 'passed', 'fixed_critic_audit_count': 3,
            'fixed_critic_audits': rows, 'post_activation_audits_with_separated_targets': separated,
            'fixed_critic_replay_warmup_count': FIXED_CRITIC_REPLAY_WARMUP_COUNT,
            'fixed_critic_replay_runtime': {
                'torch_version': torch.__version__, 'num_threads': torch.get_num_threads(),
                'deterministic_algorithms': torch.are_deterministic_algorithms_enabled(),
                'comparison': 'torch.equal', 'warmup_gamma': .99, 'warmup_lambda': .95,
                'warmup_shape': [64, 1024], 'warmup_device': config['device'],
                'warmup_before': 'first saved-target comparison', 'warmup_count_fixed': True}}


def verify_r3_prefix(job, short=False):
    manifest = read(ROOT / 'R3_REFERENCE_MANIFEST.json')
    launch = read(ROOT / 'LAUNCH_MANIFEST.json')
    assert sha(ROOT / 'R3_REFERENCE_MANIFEST.json') == launch['r3_reference_manifest_sha256']
    if short:
        rep = job.get('rep', job.get('id', '').rsplit('__', 1)[-1])
        reference = manifest['smokes'][rep]
    else:
        reference = manifest['formal'][str(job['seed'])]
    old, new = Path(reference['path']), Path(job['path'])
    names = ('initial_evaluation.json', 'evaluations.jsonl', 'lambda_decisions.jsonl')
    assert set(names) <= set(reference['artifact_hashes'])
    for name in names:
        assert sha(old / name) == reference['artifact_hashes'][name], ('R3 reference changed', old, name)
    assert (old / 'initial_evaluation.json').read_bytes() == (new / 'initial_evaluation.json').read_bytes()
    cutoff, held = (SHORT_SWITCH, 4) if short else (SWITCH, 76)
    def early_evaluations(path):
        return [line for line in (path / 'evaluations.jsonl').read_bytes().splitlines()
                if json.loads(line)['steps'] <= cutoff]
    old_evaluations, new_evaluations = early_evaluations(old), early_evaluations(new)
    assert old_evaluations == new_evaluations and len(old_evaluations) == (1 if short else 19), 'R3 held-period evaluations changed'
    old_decisions, new_decisions = jsonl(old / 'lambda_decisions.jsonl'), jsonl(new / 'lambda_decisions.jsonl')
    assert len(old_decisions) >= held and len(new_decisions) >= held
    keys = ('lambda_used', 'realized_kl', 'value', 'ema', 'reference', 'target', 'observations')
    for update, (previous, current) in enumerate(zip(old_decisions[:held], new_decisions[:held]), 1):
        assert previous['update'] == current['update'] == update
        assert previous['steps'] == current['steps'] == update * 65536
        for key in keys:
            if key == 'observations':
                assert previous[key] == current[key]
            else:
                assert struct.pack('!d', previous[key]) == struct.pack('!d', current[key]), ('R3 prefix decision changed', update, key)
    return {'r3_held_prefix_exact': True, 'r3_prefix_decisions': held,
            'r3_prefix_evaluations': len(old_evaluations), 'r3_reference_path': str(old)}


def verify_i1(progress, path, config, short):
    decisions = jsonl(path / 'lambda_decisions.jsonl')
    count, hold = (8, 4) if short else (153, 76)
    assert len(progress) == len(decisions) == count
    controller = controller_class()()
    lambdas, ready_updates = [], []
    for update, (decision, row) in enumerate(zip(decisions, progress), 1):
        prior = (update - 1) * 65536
        ready = prior >= config['adaptive_start_steps']
        assert decision['update'] == update and decision['prior_collected_steps'] == prior
        assert decision['adaptive_start_steps'] == config['adaptive_start_steps']
        assert decision['adaptive_steps_ready'] is ready
        assert int(row['steps']) == decision['steps'] == update * 65536
        assert int(row['fresh_steps_per_world']) == int(row['used_steps_per_world']) == 64
        delta = controller.step(update) if ready else 0.
        same(controller.value, decision['lambda_used'])
        same(decision['actor_lambda_used'], controller.value)
        same(decision['critic_lambda_used'], .95)
        assert math.isfinite(decision['actor_critic_target_diff_rmse']) and decision['actor_critic_target_diff_rmse'] >= 0
        if not ready:
            assert decision['actor_critic_target_diff_rmse'] == 0.
        same(row['gae_lambda'], controller.value)
        same(row['lambda_delta'], delta)
        controller.observe(decision['realized_kl'])
        for key, expected in controller.state_dict().items():
            same(expected, decision[key])
        assert not decision['overlap_active'] and row['overlap_active'].lower() == 'false'
        assert decision['headroom_gain'] == 1. and not decision['early_target_unlocked']
        assert not decision['critic_ready_latched']
        lambdas.append(decision['lambda_used'])
        if ready:
            ready_updates.append(update)
    assert lambdas[:hold] == [.95] * hold and ready_updates[0] == hold + 1
    assert controller.observations == count
    changed = sum(abs(value - .95) > 1e-12 for value in lambdas)
    assert changed > 0, 'Adaptive lambda never changed after activation'
    assert any(decision['actor_critic_target_diff_rmse'] > 0 for decision in decisions[hold:]), 'Actor and fixed critic targets never separated'
    return lambdas, {'controller_replay': 'passed', 'controller_observations': count,
                     'hold_updates': hold, 'first_adaptive_update': ready_updates[0],
                     'adaptive_ready_updates': len(ready_updates), 'changed_updates': changed,
                     'trained_transitions': count * 65536}


def verify_i2(progress, path, config, short):
    budget, switch = (SHORT, SHORT_SWITCH) if short else (BUDGET, SWITCH)
    tail, prefix = config['pae_tail'], config['pae_prefix']
    assert (tail, prefix) == (16, 48)
    assert len(progress) == (9 if short else 178)
    previous = trained = retained = flushes = early = 0
    incoming = []
    for row in progress:
        step, fresh, used = (int(row[key]) for key in ('steps', 'fresh_per_world', 'used_per_world'))
        overlap = row['overlap_active'].lower() == 'true'
        flush = row['stage_boundary_flush'].lower() == 'true'
        assert overlap == (previous < switch)
        incoming.append(retained)
        expected_fresh = min(64 - retained, (budget - previous) // 1024)
        if overlap:
            expected_fresh = min(expected_fresh, (switch - previous) // 1024)
        end = retained + expected_fresh
        assert fresh == expected_fresh and step - previous == fresh * 1024
        assert flush == (overlap and step == switch)
        assert used == (end if flush or not overlap or step == budget else min(prefix, end))
        assert int(row['retained_per_world']) == end - used
        assert float(row['gae_lambda_used']) == float(row['gae_lambda_next']) == .95
        retained, previous = end - used, step
        trained += used * 1024
        flushes += int(flush)
        early += int(overlap)
    assert previous == trained == budget and retained == 0 and flushes == 1
    assert early == (5 if short else 101)
    assert int(next(row for row in progress if row['stage_boundary_flush'].lower() == 'true')['used_per_world']) == 64
    diagnostics = jsonl(path / 'retained_tail_diagnostics.jsonl')
    assert len(diagnostics) == len(progress)
    for update, (diag, row, count) in enumerate(zip(diagnostics, progress, incoming), 1):
        assert diag['update'] == update and diag['steps'] == int(row['steps'])
        assert diag['retained_per_world'] == count and count in (0, tail)
        assert diag['retained_count'] == 1024 * count
        for key in ('fresh_per_world', 'used_per_world', 'stage_boundary_flush'):
            expected = row[key].lower() == 'true' if key == 'stage_boundary_flush' else int(row[key])
            assert diag[key] == expected
        assert diag['retained_out_per_world'] == int(row['retained_per_world'])
        for key in ('logprob_finite_count', 'value_finite_count', 'advantage_finite_count'):
            assert diag[key] == diag['retained_count'], (key, diag[key], diag['retained_count'])
        if count:
            assert 0 <= diag['importance_ratio_outside_clip_fraction'] <= 1
            for key in ('current_behavior_logprob_mean_abs_drift', 'refreshed_minus_stored_value_rmse',
                        'extended_refreshed_retained_advantage_mean_abs_drift',
                        'extended_refreshed_retained_advantage_rmse'):
                assert diag[key] is not None and diag[key] >= 0
        for key, value in diag.items():
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                assert math.isfinite(value), (key, value)
    correction = verify_correction(diagnostics, incoming, config)
    assert correction['active_correction_updates'] == (4 if short else 100)
    return [.95] * len(progress), {'stage_replay': 'passed', 'diagnostic_batches': len(diagnostics),
        'early_updates': early, 'late_updates': len(progress) - early, 'boundary_flushes': flushes,
        'trained_transitions': trained, **correction}


def verify_correction(diagnostics, incoming, config):
    """Replay correction activity/count constraints; fresh and late targets stay exact."""
    active = actor_nonzero = critic_nonzero = raw_nonfinite = capped_below_one = 0
    actor_rmse, critic_rmse = [], []
    for diag, retained in zip(diagnostics, incoming):
        retained_count = retained * 1024
        fresh_count = diag['fresh_per_world'] * 1024
        total_count = retained_count + fresh_count
        assert diag['trace_correction_enabled'] is True
        assert diag['trace_correction_version'] == config['retained_tail_trace_design']['version']
        assert diag['trace_lambda'] == .95 and diag['trace_ratio_cap'] == 1.
        for key in ('logratio_finite_count', 'capped_ratio_finite_count',
                    'actor_correction_finite_count', 'critic_correction_finite_count'):
            assert diag[key] == total_count, (key, diag[key], total_count)
        assert diag['fresh_capped_ratio_equal_one_count'] == fresh_count
        for kind in ('actor', 'critic'):
            assert diag[f'fresh_{kind}_correction_finite_count'] == fresh_count
            assert diag[f'fresh_{kind}_correction_nonzero_count'] == 0
            assert diag[f'fresh_{kind}_correction_max_abs'] == 0.
            assert 0 <= diag[f'{kind}_correction_nonzero_count'] <= retained_count
            assert diag[f'{kind}_correction_rmse'] is not None and diag[f'{kind}_correction_rmse'] >= 0
        finite = diag['importance_ratio_finite_count']
        nonfinite = diag['importance_ratio_nonfinite_count']
        assert 0 <= finite <= retained_count and 0 <= nonfinite <= retained_count
        assert finite + nonfinite == retained_count
        assert 0 <= diag['capped_ratio_min'] <= diag['capped_ratio_mean'] <= diag['capped_ratio_max'] == 1.
        below = diag['capped_ratio_below_one_count']
        assert 0 <= below <= retained_count
        assert diag['active_correction'] is bool(below)
        assert (diag['capped_ratio_min'] < 1.) == bool(below)
        if retained:
            assert diag['logratio_min'] <= diag['logratio_max']
        else:
            assert diag['logratio_min'] is None and diag['logratio_max'] is None
            assert diag['actor_correction_rmse'] == diag['critic_correction_rmse'] == 0.
            assert diag['actor_correction_nonzero_count'] == diag['critic_correction_nonzero_count'] == below == 0
        if finite:
            assert 0 <= diag['importance_ratio_min'] <= diag['importance_ratio_mean'] <= diag['importance_ratio_max']
            assert diag['importance_ratio_std'] >= 0
        else:
            assert all(diag[f'importance_ratio_{key}'] is None for key in ('min', 'max', 'mean', 'std'))
        active += int(diag['active_correction'])
        actor_nonzero += diag['actor_correction_nonzero_count']
        critic_nonzero += diag['critic_correction_nonzero_count']
        raw_nonfinite += nonfinite
        capped_below_one += below
        actor_rmse.append(diag['actor_correction_rmse'])
        critic_rmse.append(diag['critic_correction_rmse'])
    assert active > 0 and actor_nonzero > 0 and critic_nonzero > 0, 'Correction had no measured target effect'
    return {'correction_activity_checks': 'passed', 'active_correction_updates': active,
            'capped_ratio_below_one_total': capped_below_one,
            'actor_correction_nonzero_total': actor_nonzero, 'critic_correction_nonzero_total': critic_nonzero,
            'raw_importance_ratio_nonfinite_total': raw_nonfinite,
            'maximum_actor_correction_rmse': max(actor_rmse), 'maximum_critic_correction_rmse': max(critic_rmse),
            'fresh_and_late_correction_exactly_zero': True}


def verify(job, task, short=False):
    path, budget = Path(job['path']), SHORT if short else BUDGET
    config = verify_config(job, task, short)
    summary, status = read(path / 'summary.json'), read(path / 'status.json')
    assert summary == status and summary['state'] == 'completed' and summary['reload_check'] == 'passed'
    assert summary['steps'] == budget and (path / 'latest.pt').stat().st_size > 0
    batch(summary['final_eval'], task)
    progress = list(csv.DictReader((path / 'progress.csv').open()))
    if job['arm'] == 'innovation1':
        lambdas, detail = verify_i1(progress, path, config, short)
        detail.update(verify_fixed_critic_audits(job, config, short))
        detail.update(verify_r3_prefix(job, short))
    else:
        assert summary['training_transitions'] == summary['total_algorithm_transitions'] == budget
        assert summary['optimizer_steps'] == {'actor': budget // 1024 * 10, 'critic': budget // 1024 * 10, 'h': 0}
        assert summary['pae_retained_per_world'] == 0
        lambdas, detail = verify_i2(progress, path, config, short)
    checkpoint = checkpoint_steps(path, job['arm'], budget // 1024 * 10)
    assert checkpoint['steps'] == budget
    area, initial, evaluations = auc(path, budget, task)
    expected_evaluations, next_eval = [], 262144
    for row in progress:
        steps = int(row['steps'])
        if steps >= next_eval or steps == budget:
            expected_evaluations.append(steps)
            next_eval = (steps // 262144 + 1) * 262144
            assert row['eval_mean'] != ''
        else:
            assert row['eval_mean'] == ''
    assert [evaluation['steps'] for evaluation in evaluations] == expected_evaluations
    assert len(evaluations) == (2 if short else 39)
    same(evaluations[-1]['mean'], summary['final_eval']['mean'])
    assert evaluations[-1]['returns'] == summary['final_eval']['returns']
    if 'normalized_return_auc' in summary:
        same(area, summary['normalized_return_auc'])
    return {'final_return': summary['final_eval']['mean'], 'auc': area, 'initial_return': initial['mean'],
            'updates': len(progress), 'steps': budget, 'lambda_min': min(lambdas), 'lambda_max': max(lambdas),
            'xml_sha256': config['xml_sha256'], 'actor_optimizer_steps': budget // 1024 * 10,
            'critic_optimizer_steps': budget // 1024 * 10, 'auxiliary_optimizer_steps': 0, **detail}


def artifact_hashes(path, arm):
    names = ['config.json', 'status.json', 'summary.json', 'initial_evaluation.json',
             'evaluations.jsonl', 'progress.csv', 'latest.pt',
             'lambda_decisions.jsonl' if arm == 'innovation1' else 'retained_tail_diagnostics.jsonl']
    names += [name for name in ('best.pt', 'stress_evaluation.json') if (path / name).is_file()]
    if arm == 'innovation1':
        names += fixed_audit_names(read(path / 'config.json'))
    return {name: sha(path / name) for name in names}


def differences(a, b, path=''):
    if isinstance(a, torch.Tensor):
        return [] if isinstance(b, torch.Tensor) and a.dtype == b.dtype and a.shape == b.shape and torch.equal(a, b) else [path]
    if isinstance(a, dict):
        if not isinstance(b, dict) or a.keys() != b.keys():
            return [path + '.keys']
        return [d for key in a for d in differences(a[key], b[key], path + '.' + str(key))]
    if isinstance(a, (list, tuple)):
        if type(a) != type(b) or len(a) != len(b):
            return [path + '.length']
        return [d for i, (x, y) in enumerate(zip(a, b)) for d in differences(x, y, path + '.' + str(i))]
    return [] if a == b else [path]


def exact_pair(first, second, arm):
    paths = [Path(first), Path(second)]
    checkpoints = [torch.load(p / 'latest.pt', map_location='cpu', weights_only=False) for p in paths]
    for checkpoint in checkpoints:
        checkpoint = checkpoint['config']
        for name in ('device', 'out'):
            checkpoint.pop(name)
    delta = differences(*checkpoints)
    if arm == 'innovation1':
        for name in fixed_audit_names(checkpoints[0]['config']):
            records = [torch.load(path / name, map_location='cpu', weights_only=False) for path in paths]
            for record in records:
                for key in ('out', 'device'):
                    record.pop(key, None)
                if isinstance(record.get('config'), dict):
                    record['config'].pop('out', None)
                    record['config'].pop('device', None)
            delta.extend(differences(*records, path=name))
    names = ['initial_evaluation.json', 'evaluations.jsonl',
             'lambda_decisions.jsonl' if arm == 'innovation1' else 'retained_tail_diagnostics.jsonl']
    for name in names:
        if (paths[0] / name).read_bytes() != (paths[1] / name).read_bytes():
            delta.append(name)
    rows = [list(csv.DictReader((p / 'progress.csv').open())) for p in paths]
    assert len(rows[0]) == len(rows[1])
    for a, b in zip(*rows):
        assert a.keys() == b.keys()
        for key in a:
            if key not in ('elapsed_seconds', 'steps_per_second') and a[key] != b[key]:
                delta.append('progress.' + key)
    assert not delta, delta
    return {'state': 'passed', 'checkpoint_exact_except_device_out': True,
            'evaluation_and_decisions_exact': True, 'non_timing_progress_exact': True}


def paired(values, controls):
    delta = [a - b for a, b in zip(values, controls)]
    assert len(delta) == len(values) == len(controls) and all(math.isfinite(v) for v in delta)
    n, mean, sd = len(delta), statistics.mean(delta), statistics.stdev(delta)
    test = stats.ttest_rel(values, controls, alternative='two-sided') if sd else None
    half = float(stats.t.ppf(.975, n - 1)) * sd / math.sqrt(n)
    result = {'n': n, 'df': n - 1, 'mean_difference': mean, 'sd_difference': sd,
              't': float(test.statistic) if sd else None,
              'p_two_sided': float(test.pvalue) if sd else 1.,
              'constant_difference_test_unavailable': not bool(sd), 'ci95': [mean - half, mean + half]}
    if n == 8:
        possible = [abs(sum(s * x for s, x in zip(signs, delta)) / n)
                    for signs in itertools.product((-1, 1), repeat=n)]
        result['exact_sign_flip_p_two_sided'] = sum(v >= abs(mean) - 1e-12 for v in possible) / 256
    return result


def holm_four(tests):
    assert len(tests) == 4
    adjusted = 0.
    for rank, test in enumerate(sorted(tests, key=lambda t: t['p_two_sided'])):
        adjusted = max(adjusted, min(1., test['p_two_sided'] * (4 - rank)))
        test['p_holm_four_comparisons'] = adjusted
        test['positive_difference_and_holm_below05'] = test['mean_difference'] > 0 and adjusted < .05


def group_analysis(ids, lookup, base):
    result = {'seed_ids': ids, 'statistics': {}, 'development_flags': {},
              'valid_independent_confirmation': False, 'valid_confirmatory_significance': False}
    tests = []
    for arm in ARMS:
        result['statistics'][arm] = {}
        for endpoint in ENDPOINTS:
            values = [lookup[arm][seed][endpoint] for seed in ids]
            controls = [base[seed][endpoint] for seed in ids]
            test = {**paired(values, controls), 'ours_mean': statistics.mean(values),
                    'base_mean': statistics.mean(controls), 'ours_sd': statistics.stdev(values),
                    'base_sd': statistics.stdev(controls)}
            result['statistics'][arm][endpoint] = test
            tests.append(test)
    holm_four(tests)
    for arm in ARMS:
        arm_tests = list(result['statistics'][arm].values())
        result['development_flags'][arm] = {
            'each_seed_positive_both': all(lookup[arm][seed][ep] > base[seed][ep] for seed in ids for ep in ENDPOINTS),
            'both_raw_p_below05_and_positive': all(t['mean_difference'] > 0 and t['p_two_sided'] < .05 for t in arm_tests),
            'both_holm_p_below05_and_positive': all(t['positive_difference_and_holm_below05'] for t in arm_tests)}
    return result


def analyze(jobs, bases, task):
    rows = sorted([{'arm': j['arm'], 'seed': j['seed'], 'path': j['path'], **j['metrics']} for j in jobs],
                  key=lambda r: (r['arm'], r['seed']))
    assert len(rows) == 16 and {(r['arm'], r['seed']) for r in rows} == {(arm, seed) for arm in ARMS for seed in SEEDS}
    base = {r['seed']: r for r in bases}
    assert sorted(base) == list(SEEDS)
    lookup = {arm: {r['seed']: r for r in rows if r['arm'] == arm} for arm in ARMS}
    result = {'state': 'completed', 'round': 'reacher-adjustment-r4-replayfix1', 'task': task, 'total': 16,
              'seeds': list(SEEDS), 'rows': rows, 'base_rows': bases, 'summary': {}, 'paired': {},
              'inference_eight_seeds': {}, 'development_pass': {},
              'inference_scope': 'All eight seeds retained; paired developmental analysis. Prior-outcome-selected fixed groups and current-outcome-selected rankings are exploratory, not independent confirmation.',
              'holm_scope': 'four arm-by-endpoint tests within this Reacher round'}
    tests = []
    for arm in ARMS:
        rs = [lookup[arm][seed] for seed in SEEDS]
        delta = [{'seed': seed, 'final_difference': lookup[arm][seed]['final_return'] - base[seed]['final_return'],
                  'auc_difference': lookup[arm][seed]['auc'] - base[seed]['auc']} for seed in SEEDS]
        joint = sum(d['final_difference'] > 0 and d['auc_difference'] > 0 for d in delta)
        result['paired'][arm] = delta
        result['development_pass'][arm] = {'joint_positive_count': joint, 'target_at_least_three': joint >= 3}
        result['summary'][arm] = {'final_mean': statistics.mean(r['final_return'] for r in rs),
            'final_sd': statistics.stdev(r['final_return'] for r in rs),
            'auc_mean': statistics.mean(r['auc'] for r in rs), 'auc_sd': statistics.stdev(r['auc'] for r in rs)}
        result['inference_eight_seeds'][arm] = {}
        for endpoint in ENDPOINTS:
            test = paired([r[endpoint] for r in rs], [base[r['seed']][endpoint] for r in rs])
            result['inference_eight_seeds'][arm][endpoint] = test
            tests.append(test)
    holm_four(tests)
    result['fixed_prior_selected_groups_developmental'] = {}
    for size, ids in FOCUS_GROUPS.items():
        group = group_analysis(ids, lookup, base)
        group.update({'prespecified_before_this_round': True, 'selected_using_prior_visible_outcomes': True,
                      'all_eight_seeds_still_reported': True})
        result['fixed_prior_selected_groups_developmental'][size] = group
    base_sd = {endpoint: statistics.stdev(r[endpoint] for r in bases) for endpoint in ENDPOINTS}
    assert all(v > 0 for v in base_sd.values())
    ranking = []
    for seed in SEEDS:
        normalized = {arm: {ep: (lookup[arm][seed][ep] - base[seed][ep]) / base_sd[ep]
                            for ep in ENDPOINTS} for arm in ARMS}
        ranking.append({'seed': seed, 'minimum_normalized_difference': min(v for a in normalized.values() for v in a.values()),
            'mean_final_difference': statistics.mean(lookup[arm][seed]['final_return'] - base[seed]['final_return'] for arm in ARMS),
            'normalized_differences': normalized})
    ranking.sort(key=lambda r: (-r['minimum_normalized_difference'], -r['mean_final_difference'], r['seed']))
    result['common_outcome_selected_groups_exploratory'] = {'ranking': ranking,
        'selection_rule': 'descending minimum of final/Base_final_SD and AUC/Base_AUC_SD differences over both arms; then mean final difference descending, seed ascending',
        'selection_using_this_round_outcomes': True, 'selection_by_pvalue': False, 'subset_enumeration': False, 'groups': {}}
    for size in (3, 5):
        group = group_analysis([r['seed'] for r in ranking[:size]], lookup, base)
        group['all_eight_seeds_still_reported'] = True
        result['common_outcome_selected_groups_exploratory']['groups'][str(size)] = group
    return result


def snapshot():
    raw = subprocess.check_output(['nvidia-smi', '--query-gpu=index,memory.free', '--format=csv,noheader,nounits'], text=True)
    free = {int(line.split(',')[0]): int(line.split(',')[1]) for line in raw.splitlines() if line.strip()}
    raw = subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid,used_gpu_memory', '--format=csv,noheader,nounits'], text=True)
    used = {int(line.split(',')[0]): int(line.split(',')[1]) for line in raw.splitlines() if line.strip()}
    return free, used


def smoke_gpu(task, rep):
    assert task == 'Reacher' and rep in ('a', 'b')
    return 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--task', choices=('Reacher',), required=True)
    parser.add_argument('--gpus', type=int, nargs='+', required=True)
    parser.add_argument('--max-per-gpu', type=int, default=8)
    parser.add_argument('--smoke-seed', type=int, required=True)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    task = args.task
    assert args.gpus == [1]
    assert args.smoke_seed == 91081
    assert 1 <= args.max_per_gpu <= 8
    hashes, launch_manifest = check_source(), read(ROOT / 'LAUNCH_MANIFEST.json')
    for key in ('task', 'gpus', 'max_per_gpu', 'smoke_seed'):
        assert launch_manifest[key] == getattr(args, key), key
    pinned_launch = sha(ROOT / 'LAUNCH_MANIFEST.json')
    manifest = read(ROOT / 'BASE8_REUSE_MANIFEST.json')
    pinned_base_manifest = sha(ROOT / 'BASE8_REUSE_MANIFEST.json')
    assert manifest['state'] == 'verified' and manifest['task'] == task and len(manifest['rows']) == 8
    assert sorted(row['seed'] for row in manifest['rows']) == list(SEEDS)
    bases = [verify_base(row, task) for row in manifest['rows']]
    assert len({row['xml_sha256'] for row in bases}) == 1
    historical_initial = Path(manifest['control_gate_initial_path'])
    assert historical_initial.is_file()
    jobs = [{'id': f'{task}__{arm}__seed{seed}', 'arm': arm, 'seed': seed,
             'path': str(ROOT / 'runs' / f'{task}__{arm}__seed{seed}'), 'state': 'pending'}
            for seed in SEEDS for arm in ARMS]
    smoke_jobs = [{'id': f'smoke__{arm}__{rep}', 'arm': arm, 'seed': args.smoke_seed, 'rep': rep,
                   'gpu': smoke_gpu(task, rep), 'smoke': True,
                   'path': str(ROOT / 'runs' / f'smoke__{arm}__{rep}'), 'state': 'pending'}
                  for arm in ARMS for rep in ('a', 'b')]
    assert all(not Path(job['path']).exists() for job in [*jobs, *smoke_jobs])
    write(ROOT / 'PREPARE_PASSED.json', {'state': 'passed', 'task': task, 'formal_total': 16, 'base_reused': 8,
          'seeds': list(SEEDS), 'budget': BUDGET, 'gpus': args.gpus, 'base_rows': bases, 'source_hashes': hashes,
          'launch_manifest_sha256': pinned_launch, 'base_manifest_sha256': pinned_base_manifest})
    if args.prepare_only:
        print('Prepare passed: 16 fresh jobs, 8 preserved controls, four engineering smokes', flush=True)
        return
    assert not (ROOT / 'suite_status.json').exists()
    active, gates, estimates, failure = {}, {}, {}, None
    peaks, started = {arm: 0 for arm in ARMS}, time.time()

    def status(state):
        write(ROOT / 'suite_status.json', {'state': state, 'task': task, 'total': 16,
            'completed_count': sum(job['state'] == 'completed' for job in jobs),
            'active': {key: {'pid': value[0].pid, 'gpu': value[2]['gpu'], 'arm': value[2]['arm'],
                            'smoke': value[2].get('smoke', False)} for key, value in active.items()},
            'jobs': jobs, 'smoke_jobs': smoke_jobs, 'gates': gates, 'failure': failure,
            'admission_estimates_mib': estimates, 'elapsed_seconds': time.time() - started,
            'gpus': args.gpus, 'max_per_gpu': args.max_per_gpu, 'smoke_seed': args.smoke_seed,
            'coordinator_pid': os.getpid(), 'coordinator_command': [sys.executable, *sys.argv],
            'launch_manifest_sha256': pinned_launch, 'base_manifest_sha256': pinned_base_manifest})

    def fail(job_id, error, log=None):
        nonlocal failure
        if failure is None:
            failure = {'id': job_id, 'error': repr(error), 'log': log}

    def launch(job, gpu):
        job['gpu'] = gpu
        log = ROOT / (job['id'] + '.log')
        handle = log.open('x')
        cmd = command(job, task, job.get('smoke', False))
        try:
            process = subprocess.Popen(cmd, cwd=SOURCE_DIRS[job['arm']], env=ENV,
                                       stdout=handle, stderr=subprocess.STDOUT)
        except BaseException:
            handle.close()
            raise
        job.update(state='running', pid=process.pid, log=str(log), command=cmd)
        active[job['id']] = (process, handle, job)

    status('queued')
    while True:
        try:
            free, used = snapshot()
        except Exception as error:
            fail('gpu_snapshot', error)
            free, used = {}, {}
        for process, _, job in active.values():
            if job.get('smoke'):
                peaks[job['arm']] = max(peaks[job['arm']], used.get(process.pid, 0))
        for job_id, (process, handle, job) in list(active.items()):
            code = process.poll()
            if code is None:
                continue
            handle.close()
            del active[job_id]
            try:
                assert code == 0, (job_id, code)
                job['metrics'] = verify(job, task, job.get('smoke', False))
                job['artifact_hashes'] = artifact_hashes(Path(job['path']), job['arm'])
                assert job['metrics']['xml_sha256'] == bases[0]['xml_sha256']
                control = historical_initial if job.get('smoke') else Path(next(b for b in bases if b['seed'] == job['seed'])['path']) / 'initial_evaluation.json'
                assert (Path(job['path']) / 'initial_evaluation.json').read_bytes() == control.read_bytes(), 'paired initialization mismatch'
                job['state'] = 'completed'
            except Exception as error:
                job['state'] = 'failed'
                fail(job_id, error, job['log'])
        if not failure and all(job['state'] == 'completed' for job in smoke_jobs) and not gates:
            try:
                for arm in ARMS:
                    pair = [next(job for job in smoke_jobs if job['arm'] == arm and job['rep'] == rep) for rep in ('a', 'b')]
                    paths = [job['path'] for job in pair]
                    assert peaks[arm] > 0
                    gates[arm] = {**exact_pair(*paths, arm), 'paths': paths,
                        'gpu_pair': [job['gpu'] for job in pair], 'peak_mib': peaks[arm],
                        'metrics': [job['metrics'] for job in pair],
                        'artifact_hashes': [job['artifact_hashes'] for job in pair]}
                    estimates[arm] = max(3500, peaks[arm] + 256)
                check_source()
                assert sha(ROOT / 'LAUNCH_MANIFEST.json') == pinned_launch
                write(ROOT / 'SMOKE_VERIFIED.json', {'state': 'passed', 'task': task, 'gates': gates,
                    'short_budget': SHORT, 'seed': args.smoke_seed, 'source_hashes': hashes,
                    'historical_initial_sha256': sha(historical_initial), 'launch_manifest_sha256': pinned_launch})
            except Exception as error:
                gates.clear()
                fail('engineering_gates', error)
        if not failure and all(job['state'] == 'completed' for job in jobs):
            check_source()
            assert sha(ROOT / 'LAUNCH_MANIFEST.json') == pinned_launch
            assert sha(ROOT / 'BASE8_REUSE_MANIFEST.json') == pinned_base_manifest
            for row in manifest['rows']:
                verify_base(row, task)
            write(ROOT / 'ANALYSIS.json', analyze(jobs, bases, task))
            status('completed')
            return
        if failure and not active:
            status('failed')
            raise RuntimeError(f'Bounded round stopped after failure: {failure}')
        if not failure:
            for gpu in sorted(args.gpus, key=lambda g: free[g], reverse=True):
                active_gpu = [(process, job) for process, _, job in active.values() if job['gpu'] == gpu]
                if not gates:
                    pending = next((job for job in smoke_jobs if job['state'] == 'pending' and job['gpu'] == gpu), None)
                    if not active_gpu and pending and free[gpu] >= 7000:
                        try:
                            launch(pending, gpu)
                        except Exception as error:
                            pending['state'] = 'failed'
                            fail(pending['id'], error)
                else:
                    if len(active_gpu) >= args.max_per_gpu:
                        continue
                    reserve = sum(max(0, estimates[job['arm']] - used.get(process.pid, 0)) for process, job in active_gpu)
                    pending = next((job for job in jobs if job['state'] == 'pending' and
                                    free[gpu] - reserve >= estimates[job['arm']] + 512), None)
                    if pending:
                        try:
                            launch(pending, gpu)
                        except Exception as error:
                            pending['state'] = 'failed'
                            fail(pending['id'], error)
                if failure:
                    break
        status('attention_required' if failure else 'running' if gates else 'smoke_running')
        time.sleep(5)


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        write(ROOT / 'LAUNCH_ERROR.json', {'state': 'failed', 'error': repr(error), 'traceback': traceback.format_exc()})
        if (ROOT / 'suite_status.json').exists():
            suite = read(ROOT / 'suite_status.json')
            suite.update(state='failed', failure=suite.get('failure') or {'error': repr(error)})
            write(ROOT / 'suite_status.json', suite)
        traceback.print_exc()
        raise
