"""PPO with fixed GAE lambda and CUDA-resident rollout/physics/optimization."""
import argparse
from collections import deque
import csv
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import time

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
if os.environ.get("DPO_TORCH_DETERMINISTIC") == "1":
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
import numpy as np
import torch
from torch import nn
from locomotion_warp import LocomotionWarp, ASSETS, TASKS
from noisy_observation import NoisyObservation
from lambda_control import LambdaControl
from lambda_lookahead import choose_direction
from lambda_gradient_risk_gr3 import select_target
from lambda_kl_relative import KLFeedback

if os.environ.get("DPO_TORCH_DETERMINISTIC") == "1":
    torch.use_deterministic_algorithms(True)


def write_json(path, data):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")
    tmp.replace(path)


class RunningStats(nn.Module):
    def __init__(self, shape, device):
        super().__init__()
        self.register_buffer("mean", torch.zeros(shape, device=device))
        self.register_buffer("var", torch.ones(shape, device=device))
        self.register_buffer("count", torch.tensor(1e-4, device=device))

    @torch.no_grad()
    def update(self, x):
        mean = x.mean(0)
        var = x.var(0, unbiased=False)
        count = x.shape[0]
        delta, total = mean - self.mean, self.count + count
        new_var = (self.var * self.count + var * count + delta.square() * self.count * count / total) / total
        self.mean.add_(delta * count / total)
        self.var.copy_(new_var)
        self.count.copy_(total)

    def normalize(self, x):
        return ((x - self.mean) / (self.var + 1e-8).sqrt()).clamp(-10, 10)


class ActorCritic(nn.Module):
    def __init__(self, obs_dim=11, action_dim=3):
        super().__init__()
        def mlp(out, gain):
            layers = []
            for i, (nin, nout) in enumerate([(obs_dim, 64), (64, 64), (64, out)]):
                layer = nn.Linear(nin, nout)
                nn.init.orthogonal_(layer.weight, gain=gain if i == 2 else math.sqrt(2))
                nn.init.zeros_(layer.bias)
                layers.append(layer)
                if i != 2:
                    layers.append(nn.Tanh())
            return nn.Sequential(*layers)
        self.actor, self.critic = mlp(action_dim, .01), mlp(1, 1)
        self.log_std = nn.Parameter(torch.zeros(action_dim))

    def distribution(self, obs):
        return torch.distributions.Normal(self.actor(obs), self.log_std.exp(), validate_args=False)

    def value(self, obs):
        return self.critic(obs).squeeze(-1)


@torch.jit.script
def gae(rewards, values, next_values, terminated, done, gamma: float = .99, lam: float = .95):
    advantages = torch.zeros_like(rewards)
    carry = torch.zeros_like(rewards[0])
    for t in range(rewards.shape[0] - 1, -1, -1):
        delta = rewards[t] + gamma * (~terminated[t]).float() * next_values[t] - values[t]
        carry = delta + gamma * lam * (~done[t]).float() * carry
        advantages[t] = carry
    return advantages, advantages + values


def save_fixed_critic_audit(path, rewards, values, next_values, terminated, done,
                            flat_actor_advantage, flat_critic_return, actor_lambda,
                            critic_lambda, update, steps, prior_collected_steps, used_per_world):
    """Save the frozen inputs and the actual flattened tensors consumed by PPO."""
    payload = {
        'normalized_reward': rewards, 'values': values, 'next_values': next_values,
        'terminated': terminated, 'done': done,
        'actor_advantage': flat_actor_advantage.reshape(used_per_world, rewards.shape[1]),
        'consumed_critic_return': flat_critic_return.reshape(used_per_world, rewards.shape[1]),
    }
    payload = {key: tensor.detach().cpu().clone() for key, tensor in payload.items()}
    payload.update(actor_lambda=actor_lambda, critic_lambda=critic_lambda,
                   gamma=.99, update=update, steps=steps,
                   prior_collected_steps=prior_collected_steps,
                   used_per_world=used_per_world, target_device=str(rewards.device))
    torch.save(payload, path)


@torch.no_grad()
def evaluate(model, stats, env):
    obs = env.reset()
    active = torch.ones(env.num_envs, device=env.device, dtype=torch.bool)
    returns = torch.zeros(env.num_envs, device=env.device)
    lengths = torch.zeros(env.num_envs, device=env.device, dtype=torch.long)
    # Exactly one complete episode per world; do not favor quickly ending episodes.
    for _ in range(env.max_steps):
        actions = model.actor(stats.normalize(obs))
        obs, reward, term, trunc, _info = env.step(actions)
        returns.add_(reward * active)
        lengths.add_(active.long())
        active &= ~(term | trunc)
        if not bool(active.any()):
            break
    env.check_capacity()
    if not bool(torch.isfinite(returns).all()):
        raise RuntimeError("Non-finite evaluation return")
    return {"mean": returns.mean().item(), "std": returns.std(unbiased=False).item(),
            "returns": returns.cpu().tolist(), "lengths": lengths.cpu().tolist()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=1_000_000)
    parser.add_argument("--num-envs", type=int, default=1024)
    parser.add_argument("--rollout", type=int, default=64)
    parser.add_argument("--batch-size", type=int, default=1024)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--eval-every", type=int, default=1_000_000)
    parser.add_argument("--eval-envs", type=int, default=32)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--lambda-mode", choices=["fixed", "linear", "minimal", "lookahead", "gradient_risk"], default="fixed")
    parser.add_argument("--fixed-lambda", type=float, default=.95)
    parser.add_argument('--fixed-critic-lambda', type=float, choices=[.95], default=None)
    parser.add_argument('--save-fixed-critic-audit', action='store_true')
    parser.add_argument("--initial-lambda", type=float, default=.95)
    parser.add_argument('--task',choices=list(TASKS),default='Hopper')
    parser.add_argument('--noise-mode',choices=['none','gaussian','multiplicative'],default='none')
    parser.add_argument('--noise-scale',type=float,default=0.)
    parser.add_argument('--adaptive-start-update',type=int,default=4)
    parser.add_argument('--adaptive-start-steps',type=int,default=0)
    parser.add_argument('--adaptive-early-target-gate',action='store_true')
    parser.add_argument('--adaptive-early-target-threshold',type=float,default=.949)
    parser.add_argument('--critic-readiness-gate',action='store_true')
    parser.add_argument('--critic-readiness-threshold',type=float,default=.985)
    parser.add_argument('--critic-unready-up-only',action='store_true')
    parser.add_argument('--kl-fast-alpha',type=float,default=.1)
    parser.add_argument('--kl-slow-alpha',type=float,default=.01)
    parser.add_argument('--kl-logratio-deadband',type=float,default=0.)
    parser.add_argument('--kl-lower-bound',type=float,default=.90)
    parser.add_argument('--kl-upper-bound',type=float,default=.99)
    parser.add_argument('--kl-headroom-gain',action='store_true')
    parser.add_argument('--kl-headroom-scale',type=float,default=.01)
    parser.add_argument('--kl-headroom-floor',type=float,default=.25)
    parser.add_argument('--readiness-boost',action='store_true')
    parser.add_argument('--readiness-threshold',type=float,default=.45)
    parser.add_argument('--readiness-until-update',type=int,default=16)
    parser.add_argument('--readiness-target',type=float,default=.99)
    parser.add_argument('--readiness-max-step',type=float,default=.02)
    parser.add_argument('--adaptive-overlap',action='store_true')
    parser.add_argument('--overlap-lambda-threshold',type=float,default=.964)
    parser.add_argument('--overlap-start-steps',type=int,default=1572864)
    parser.add_argument('--overlap-stop-steps',type=int,default=8388608)
    parser.add_argument('--overlap-prefix',type=int,default=48)
    args = parser.parse_args()
    if args.save_fixed_critic_audit and args.fixed_critic_lambda is None:
        parser.error('--save-fixed-critic-audit requires --fixed-critic-lambda')
    if not math.isfinite(args.noise_scale) or args.noise_scale < 0:
        parser.error('noise scale must be finite and nonnegative')
    if args.adaptive_start_update < 4:
        parser.error('adaptive start update must be at least 4')
    if args.adaptive_start_steps < 0:
        parser.error('adaptive start steps must be nonnegative')
    if not .90 <= args.adaptive_early_target_threshold <= .99:
        parser.error('Adaptive early target threshold must be in [.90,.99]')
    if not -1 <= args.critic_readiness_threshold <= 1:
        parser.error('Critic readiness threshold must be in [-1,1]')
    if args.critic_unready_up_only and not args.critic_readiness_gate:
        parser.error('--critic-unready-up-only requires --critic-readiness-gate')
    if not 0 <= args.kl_fast_alpha <= 1 or not 0 <= args.kl_slow_alpha <= 1:
        parser.error('KL EMA alphas must be in [0,1]')
    if not math.isfinite(args.kl_logratio_deadband) or args.kl_logratio_deadband < 0:
        parser.error('KL log-ratio deadband must be finite and nonnegative')
    if not 0 <= args.kl_lower_bound < .95 < args.kl_upper_bound <= 1:
        parser.error('KL bounds must contain 0.95 and lie in [0,1]')
    if not math.isfinite(args.kl_headroom_scale) or args.kl_headroom_scale <= 0:
        parser.error('KL headroom scale must be finite and positive')
    if not 0 <= args.kl_headroom_floor <= 1:
        parser.error('KL headroom floor must be in [0,1]')
    if not -1 <= args.readiness_threshold <= 1 or args.readiness_until_update < 2:
        parser.error('Invalid readiness gate settings')
    if not .95 <= args.readiness_target <= args.kl_upper_bound or not 0 < args.readiness_max_step <= .04:
        parser.error('Invalid readiness target or step')
    if not .90 <= args.overlap_lambda_threshold <= .99:
        parser.error('Invalid adaptive-overlap lambda threshold')
    if not 0 < args.overlap_prefix < args.rollout:
        parser.error('Adaptive-overlap prefix must be within the rollout')
    if args.lambda_mode != 'fixed':
        parser.error('KLF2 entry uses fixed base plumbing only; adaptation is KLFeedback')
    if args.task == 'Ant':
        from ant_contact_compat import install
        install()
    obs_dim,action_dim={'Hopper':(11,3),'Walker2d':(17,6),'HalfCheetah':(17,6),'Ant':(27,8),'InvertedDoublePendulum':(11,1),'Swimmer':(8,2),'Reacher':(11,2)}[args.task]
    XML_PATH=ASSETS/TASKS[args.task][0]
    if not 0 <= args.fixed_lambda <= 1:
        parser.error("--fixed-lambda must be in [0,1]")
    if not .85 <= args.initial_lambda <= .99:
        parser.error("--initial-lambda must be in [.85,.99]")
    if min(args.steps, args.num_envs, args.rollout, args.batch_size, args.epochs, args.eval_every, args.eval_envs) <= 0:
        parser.error("All sizes must be positive")
    if torch.device(args.device).type != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for both physics and PPO")
    args.out.mkdir(parents=True, exist_ok=False)
    torch.set_num_threads(1)
    torch.cuda.set_device(args.device)
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    size = args.num_envs * args.rollout
    base_updates = math.ceil(args.steps / size)
    effective_steps = base_updates * size
    first_potential_adaptive_update = max(args.adaptive_start_update + 1,
                                          math.ceil(args.adaptive_start_steps / size) + 1)
    fixed_critic_audit_updates = sorted({first_potential_adaptive_update - 1,
                                        first_potential_adaptive_update, base_updates})
    if args.save_fixed_critic_audit and (len(fixed_critic_audit_updates) != 3 or
                                       fixed_critic_audit_updates[-1] != base_updates):
        parser.error('Fixed-critic audit needs distinct pre-activation, activation and final updates')
    if args.adaptive_start_steps > (base_updates - 1) * size:
        parser.error('adaptive start steps must leave at least one adaptive rollout')
    if args.adaptive_overlap and not 0 <= args.overlap_start_steps < args.overlap_stop_steps <= effective_steps:
        parser.error('Invalid adaptive-overlap step window')
    prefix = args.overlap_prefix
    total_time = effective_steps // args.num_envs
    updates = (1 + math.ceil(max(0, total_time - args.rollout) / prefix)) if args.adaptive_overlap else base_updates
    config = {**vars(args), "out": str(args.out), "effective_steps": effective_steps,
              "backend": "MuJoCo Warp", "task": args.task+"-v4 semantics / MJWarp backend",
              "gae_lambda": args.fixed_lambda if args.lambda_mode == "fixed" else (.90 if args.lambda_mode == "linear" else args.initial_lambda), "gamma": .99, "learning_rate": 3e-4,
              "lambda_design": {"fixed": args.fixed_lambda, "linear_start": .90, "linear_end": .99,
                  "minimal_init": args.initial_lambda, "bounds": [.85, .99], "entropy_window": 8,
                  "direction_interval": 4, "normalized_trend_deadband": .5,
                  "max_step": .003, "td_reference_ema_alpha": .1},
              "lookahead_design": {"candidate_offset": .02, "reference_lambda": 1.,
                  "split": "even/odd environment IDs", "virtual_epochs": 1,
                  "direction_interval": 4, "first_decision_update": 8,
                  "margin_rule": "paired world mean delta > max(1e-6,2*SE)"},
              "clip_range": .2, "value_coef": .5, "entropy_coef": 0., "max_grad_norm": .5,
              "network": [64, 64], "optimizer_eps": 1e-5, "additional_noise": {"mode":args.noise_mode,"scale":args.noise_scale,"location":"raw observation before running normalization","train_and_primary_eval":True,"reward_and_physics":"unmodified"},
              "reward_normalization": True, "observation_normalization": True,
              "xml_sha256": hashlib.sha256(XML_PATH.read_bytes()).hexdigest(),
              "gpu": torch.cuda.get_device_name(),
              "determinism": {"torch": torch.are_deterministic_algorithms_enabled(),
                  "warp": os.environ.get("DPO_WARP_DETERMINISTIC", "not_guaranteed"),
                  "warp_max_records": int(os.environ.get("DPO_WARP_DETERMINISTIC_MAX_RECORDS", "0")),
                  "cublas_workspace_config": os.environ.get("CUBLAS_WORKSPACE_CONFIG")},
              "versions": {p: importlib.metadata.version(p) for p in
                           ["torch", "mujoco", "mujoco-warp", "warp-lang", "gymnasium", "numpy"]}}
    if args.lambda_mode == "gradient_risk":
        config['lambda_design']={'initial':args.initial_lambda,'bounds':[.85,.99],'target_candidates':[.85,.90,.95,.99,'current'],'first_decision':8,'decision_interval':4,'fast_tracking_rate':.25,'max_step':.003,'reference_lambda':1.,'jackknife_groups':16,'gate':'estimated risk reduction > 2 jackknife SE','extra_environment_steps':0,'reference_warning':'truncated bootstrapped reference, projected gradient proxy','candidate_version':'GR3','risk_scope':'rollout risk plus conditional minibatch variance','risk_batch_size':args.batch_size,'advantage_normalization':'per-candidate rollout mean/std'}
        config.pop('lookahead_design',None)
    config['lambda_mode']='kl_feedback'
    variant='full' if (args.kl_fast_alpha,args.kl_slow_alpha)==(.1,.01) else 'without_fast_smoothing' if args.kl_fast_alpha==1 else 'without_slow_update' if args.kl_slow_alpha==0 else 'custom'
    if args.kl_logratio_deadband > 0:
        variant += '_deadband'
    config['lambda_design']={'version':'KLF2','ablation_variant':variant,'initial':.95,'bounds':[args.kl_lower_bound,args.kl_upper_bound],'warmup_updates':args.adaptive_start_update,'ema_alpha':args.kl_fast_alpha,'initial_ema':'first actual KL','reference_alpha':args.kl_slow_alpha,'initial_reference':'first actual KL','target_kl':'slow causal reference','target_interval':4,'target_amplitude':.04,'tracking_rate':.1,'max_step':.001,'logratio_deadband':args.kl_logratio_deadband,'signal':'exact Gaussian old||new KL over prior rollout, unweighted by advantages','extra_environment_steps':0,'caveat':'heuristic feedback; KL monotonic response to lambda is not assumed proven'}
    config['lambda_design']['step_activation']={'start_steps':args.adaptive_start_steps,'reference':'collected transitions before the current rollout','rule':'hold lambda at 0.95 until prior_collected_steps >= start_steps, then apply the existing update/readiness gates','observe_during_hold':True,'reference_reinitialized':False,'evaluation_return_used':False}
    config['fixed_critic_target_design'] = {
        'enabled': args.fixed_critic_lambda is not None,
        'actor_advantage_lambda': 'causal adaptive KL feedback',
        'critic_return_lambda': 'fixed 0.95' if args.fixed_critic_lambda is not None else 'same as actor',
        'critic_lambda': args.fixed_critic_lambda,
        'critic_return': 'GAE return from the same frozen normalized rollout at critic lambda',
        'scope': 'remove lambda-induced target mixing drift only; bootstrap values, reward normalization and policy distribution still change',
        'actor_advantage': 'unchanged adaptive actor GAE', 'targets_frozen_before_epochs': True,
        'targets_consumed_by_ppo': True,
        'extra_environment_steps': 0, 'extra_optimizer_steps': 0,
        'audit_enabled': args.save_fixed_critic_audit,
        'audit_updates': fixed_critic_audit_updates if args.save_fixed_critic_audit else [],
        'audit_files': [f'fixed_critic_audit_{u:03d}.pt' for u in fixed_critic_audit_updates]
                       if args.save_fixed_critic_audit else [],
        'audit_target_source': 'actual flat_adv and flat_ret passed to the PPO actor and critic losses'}
    config['lambda_design']['asymmetric_readiness']={'enabled':args.adaptive_early_target_gate,'early_threshold':args.adaptive_early_target_threshold,'minimum_observations':4,'fallback_start_update':args.adaptive_start_update,'rule':'unlock early when causal target <= threshold','evaluation_return_used':False}
    config['lambda_design']['critic_readiness_gate']={'enabled':args.critic_readiness_gate,'threshold':args.critic_readiness_threshold,'signal':'previous-update explained variance','latched':True,'evaluation_return_used':False}
    config['lambda_design']['critic_readiness_gate']['unready_up_only']=args.critic_unready_up_only
    config['lambda_design']['headroom_gain']={'enabled':args.kl_headroom_gain,'scale':args.kl_headroom_scale,'floor':args.kl_headroom_floor,'rule':'clip(abs(target-0.95)/scale,floor,1)','causal':True}
    config['lambda_design']['readiness_boost']={'enabled':args.readiness_boost,'signal':'previous-update explained variance','threshold':args.readiness_threshold,'until_update':args.readiness_until_update,'target':args.readiness_target,'max_step':args.readiness_max_step,'causal':True}
    config['adaptive_overlap_design']={'enabled':args.adaptive_overlap,'lambda_threshold':args.overlap_lambda_threshold,
        'start_steps':args.overlap_start_steps,'stop_steps':args.overlap_stop_steps,
        'prefix_steps':prefix,'retained_tail_steps':args.rollout-prefix,
        'signal':'causal KLF2 lambda state before collecting the next rollout','evaluation_return_used':False,
        'extra_environment_steps':0}
    config.pop('lookahead_design',None)
    config['ant_contact_compat']=args.task=='Ant'
    write_json(args.out / "config.json", config)
    write_json(args.out / "status.json", {"state": "compiling", "pid": os.getpid()})
    try:
        env = NoisyObservation(LocomotionWarp(args.num_envs, args.device, args.seed, task=args.task),args.noise_mode,args.noise_scale,args.seed+200000)
        eval_env = NoisyObservation(LocomotionWarp(args.eval_envs, args.device, args.seed + 10000,task=args.task),args.noise_mode,args.noise_scale,args.seed+300000)
        model = ActorCritic(obs_dim,action_dim).to(args.device)
        optimizer = torch.optim.Adam(model.parameters(), lr=3e-4, eps=1e-5)
        obs_stats = RunningStats((obs_dim,), args.device)
        reward_stats = RunningStats((), args.device)
        raw_obs = env.reset()
        obs_stats.update(raw_obs)
        obs = obs_stats.normalize(raw_obs)
        initial = evaluate(model, obs_stats, eval_env)
        write_json(args.out / "initial_evaluation.json", initial)
        print(f"Initial GPU evaluation: {initial['mean']:.1f}", flush=True)
        shape = (args.rollout, args.num_envs)
        obuf = torch.empty((*shape, obs_dim), device=args.device)
        nbuf = torch.empty_like(obuf)
        abuf = torch.empty((*shape, action_dim), device=args.device)
        logbuf, rbuf, vbuf, nvbuf = [torch.empty(shape, device=args.device) for _ in range(4)]
        tbuf, dbuf = [torch.empty(shape, dtype=torch.bool, device=args.device) for _ in range(2)]
        discounted_return = torch.zeros(args.num_envs, device=args.device)
        recent = deque(maxlen=100)
        latest_eval, best = initial, -float("inf")
        next_eval = args.eval_every
        controller = LambdaControl("lookahead" if args.lambda_mode == "gradient_risk" else args.lambda_mode, fixed_value=args.fixed_lambda,
                                   value=args.fixed_lambda if args.lambda_mode == "fixed" else (.90 if args.lambda_mode == "linear" else args.initial_lambda))
        feedback = KLFeedback(fast_alpha=args.kl_fast_alpha,slow_alpha=args.kl_slow_alpha,
                              deadband_log_ratio=args.kl_logratio_deadband,
                              lower_bound=args.kl_lower_bound,upper_bound=args.kl_upper_bound)
        risk_target = controller.value
        selector_seconds = 0.
        previous_explained_variance = None
        early_target_unlocked = False
        critic_ready_latched = False
        collected_time = 0
        filled = 0
        started = time.monotonic()
        fields = ["steps", "elapsed_seconds", "steps_per_second", "train_return_last_100",
                  "value_loss", "policy_loss", "entropy", "approx_kl", "clip_fraction",
                  "explained_variance", "eval_mean", "gae_lambda", "overlap_active",
                  "fresh_steps_per_world", "used_steps_per_world"]
        fields += ["lambda_delta", "lambda_direction", "lambda_step_size", "entropy_trend_score",
                   "signal_entropy", "td_abs_q90", "td_reference", "advantage_variance"]
        with (args.out / "progress.csv").open("w", buffering=1) as logfile:
            writer = csv.DictWriter(logfile, fieldnames=fields)
            writer.writeheader()
            for update in range(1, updates + 1):
                current_steps = collected_time * args.num_envs
                overlap_active = (args.adaptive_overlap and
                                  args.overlap_start_steps <= current_steps < args.overlap_stop_steps and
                                  feedback.value >= args.overlap_lambda_threshold)
                if not overlap_active and filled:
                    filled = 0
                if collected_time >= total_time and not filled:
                    break
                episode_values = []
                with torch.no_grad():
                    fresh = min(args.rollout - filled, total_time - collected_time)
                    end = filled + fresh
                    for t in range(filled, end):
                        obuf[t].copy_(obs)
                        dist = model.distribution(obs)
                        actions = dist.sample()
                        abuf[t].copy_(actions)
                        logbuf[t].copy_(dist.log_prob(actions).sum(-1))
                        vbuf[t].copy_(model.value(obs))
                        raw_obs, reward, term, trunc, info = env.step(actions)
                        done = term | trunc
                        # Bootstrap time limits from terminal observations, never reset observations.
                        nbuf[t].copy_(obs_stats.normalize(info["terminal_observation"]))
                        nvbuf[t].copy_(model.value(nbuf[t]))
                        discounted_return.mul_(.99).add_(reward)
                        reward_stats.update(discounted_return)
                        rbuf[t].copy_((reward / (reward_stats.var + 1e-8).sqrt()).clamp(-10, 10))
                        discounted_return.masked_fill_(done, 0)
                        tbuf[t].copy_(term)
                        dbuf[t].copy_(done)
                        episode_values.append(torch.where(done, info["episode_return"], torch.nan))
                        obs_stats.update(raw_obs)
                        obs = obs_stats.normalize(raw_obs)
                    collected_time += fresh
                    if filled:
                        vbuf[:end].copy_(model.value(obuf[:end]))
                        nvbuf[:end].copy_(model.value(nbuf[:end]))
                    td = rbuf[:end] + .99 * (~tbuf[:end]).float() * nvbuf[:end] - vbuf[:end]
                    signal_entropy = float((model.log_std + .5 * (1 + math.log(2 * math.pi))).sum())
                    adaptive_steps_ready=current_steps>=args.adaptive_start_steps
                    readiness_active=(adaptive_steps_ready and args.readiness_boost and update>1 and update<=args.readiness_until_update
                                      and previous_explained_variance is not None
                                      and previous_explained_variance>=args.readiness_threshold)
                    if readiness_active:
                        headroom_gain=1.
                        old_value=feedback.value
                        feedback.value=min(args.readiness_target,old_value+args.readiness_max_step)
                        delta=feedback.value-old_value
                    else:
                        headroom_gain=1.
                        if (args.adaptive_early_target_gate and feedback.observations>=4 and
                                feedback.target<=args.adaptive_early_target_threshold):
                            early_target_unlocked=True
                        adaptive_ready=(adaptive_steps_ready and
                                        (early_target_unlocked or update>args.adaptive_start_update))
                        if (args.critic_readiness_gate and update>args.adaptive_start_update and
                                previous_explained_variance is not None and
                                previous_explained_variance>=args.critic_readiness_threshold):
                            critic_ready_latched=True
                        if args.critic_readiness_gate:
                            adaptive_ready=adaptive_ready and (critic_ready_latched or args.critic_unready_up_only)
                        if not adaptive_ready:
                            delta=0.
                        else:
                            old_value=feedback.value
                            delta=feedback.step(update)
                            if (args.critic_readiness_gate and args.critic_unready_up_only and
                                    not critic_ready_latched and delta<0):
                                feedback.value=old_value
                                delta=0.
                            if args.kl_headroom_gain:
                                headroom_gain=min(1.,max(args.kl_headroom_floor,
                                    abs(feedback.target-.95)/args.kl_headroom_scale))
                                feedback.value=old_value+delta*headroom_gain
                                delta=feedback.value-old_value
                    control=controller.step(update,base_updates,signal_entropy,float(torch.quantile(td.abs().flatten(),.9)))
                    controller.value=feedback.value
                    control.update(gae_lambda=feedback.value,lambda_delta=delta,
                                   lambda_direction=1 if delta>0 else -1 if delta<0 else 0,lambda_step_size=abs(delta))
                    advantages, returns = gae(rbuf[:end], vbuf[:end], nvbuf[:end], tbuf[:end], dbuf[:end], .99, controller.value)
                    actor_lambda_used = controller.value
                    critic_lambda_used = controller.value if args.fixed_critic_lambda is None else args.fixed_critic_lambda
                    actor_critic_target_diff_rmse = 0.
                    if args.fixed_critic_lambda is not None and args.fixed_critic_lambda != controller.value:
                        _, critic_returns = gae(rbuf[:end], vbuf[:end], nvbuf[:end], tbuf[:end], dbuf[:end], .99, args.fixed_critic_lambda)
                        actor_critic_target_diff_rmse = float((returns - critic_returns).square().mean().sqrt())
                        returns = critic_returns
                    used = end if collected_time == total_time else (min(prefix, end) if overlap_active else end)
                    advantage_variance = float(advantages.var(unbiased=False))
                    recent_values = torch.stack(episode_values).flatten()
                    recent.extend(recent_values[torch.isfinite(recent_values)].cpu().tolist())
                env.check_capacity()
                flat_obs, flat_actions = obuf[:used].flatten(0, 1), abuf[:used].flatten(0, 1)
                flat_log, flat_adv, flat_ret = logbuf[:used].flatten(), advantages[:used].flatten(), returns[:used].flatten()
                if args.save_fixed_critic_audit and update in fixed_critic_audit_updates:
                    save_fixed_critic_audit(args.out / f'fixed_critic_audit_{update:03d}.pt',
                        rbuf[:end], vbuf[:end], nvbuf[:end], tbuf[:end], dbuf[:end], flat_adv, flat_ret,
                        actor_lambda_used, critic_lambda_used, update, collected_time * args.num_envs,
                        current_steps, used)
                train_size = used * args.num_envs
                with torch.no_grad():
                    old_dist=model.distribution(flat_obs)
                    old_mean=old_dist.loc.detach().clone()
                    old_scale=old_dist.scale.detach().clone()
                metrics = []
                for epoch in range(args.epochs):
                    permutation = torch.randperm(train_size, device=args.device)
                    for idx in permutation.split(args.batch_size):
                        dist = model.distribution(flat_obs[idx])
                        new_log = dist.log_prob(flat_actions[idx]).sum(-1)
                        log_ratio = new_log - flat_log[idx]
                        ratio = log_ratio.exp()
                        adv = flat_adv[idx]
                        adv = (adv - adv.mean()) / (adv.std(unbiased=False) + 1e-8)
                        pg = torch.maximum(-adv * ratio, -adv * ratio.clamp(.8, 1.2)).mean()
                        vl = (model.value(flat_obs[idx]) - flat_ret[idx]).square().mean()
                        entropy = dist.entropy().sum(-1).mean()
                        loss = pg + .5 * vl
                        optimizer.zero_grad(set_to_none=True)
                        loss.backward()
                        nn.utils.clip_grad_norm_(model.parameters(), .5)
                        optimizer.step()
                        with torch.no_grad():
                            metrics.append(torch.stack((vl, pg, entropy,
                                ((ratio - 1) - log_ratio).mean(), ((ratio - 1).abs() > .2).float().mean())))
                stats = torch.stack(metrics).mean(0).detach().cpu().tolist()
                if not all(math.isfinite(v) for v in stats):
                    raise RuntimeError("Non-finite PPO optimization metrics")
                with torch.no_grad():
                    old_policy=torch.distributions.Normal(old_mean,old_scale,validate_args=False)
                    realized_kl=float(torch.distributions.kl_divergence(old_policy,model.distribution(flat_obs)).sum(-1).mean())
                feedback.observe(realized_kl)
                with (args.out / 'lambda_decisions.jsonl').open('a') as f:
                    f.write(json.dumps({'update':update,'steps':collected_time*args.num_envs,
                        'prior_collected_steps':current_steps,
                        'adaptive_start_steps':args.adaptive_start_steps,
                        'adaptive_steps_ready':adaptive_steps_ready,
                        'lambda_used':controller.value,'realized_kl':realized_kl,
                        'actor_lambda_used':actor_lambda_used,'critic_lambda_used':critic_lambda_used,
                        'actor_critic_target_diff_rmse':actor_critic_target_diff_rmse,
                        'overlap_active':overlap_active,'headroom_gain':headroom_gain,
                        'early_target_unlocked':early_target_unlocked,
                        'critic_ready_latched':critic_ready_latched,
                        **feedback.state_dict()})+'\n')
                steps = collected_time * args.num_envs
                evaluated = steps >= next_eval or steps >= effective_steps or update == updates
                if evaluated:
                    latest_eval = evaluate(model, obs_stats, eval_env)
                    with (args.out / "evaluations.jsonl").open("a") as f:
                        f.write(json.dumps({"steps": steps, **latest_eval}) + "\n")
                    checkpoint = {"model": model.state_dict(), "optimizer": optimizer.state_dict(),
                                  "obs_stats": obs_stats.state_dict(), "reward_stats": reward_stats.state_dict(),
                                  "steps": steps, "config": config}
                    checkpoint["lambda_controller"] = controller.state_dict()
                    checkpoint["kl_feedback"] = feedback.state_dict()
                    checkpoint["gradient_risk_state"] = {"target":risk_target,"selector_seconds":selector_seconds}
                    torch.save(checkpoint, args.out / "latest.pt")
                    if latest_eval["mean"] > best:
                        best = latest_eval["mean"]
                        torch.save(checkpoint, args.out / "best.pt")
                    next_eval = (steps // args.eval_every + 1) * args.eval_every
                torch.cuda.synchronize()
                elapsed = time.monotonic() - started
                ret_var = flat_ret.var(unbiased=False)
                ev = (1 - (flat_ret - vbuf[:used].flatten()).var(unbiased=False) / (ret_var + 1e-8)).item()
                previous_explained_variance = ev
                row = dict(zip(fields, [steps, elapsed, steps / elapsed,
                    float(np.mean(recent)) if recent else None, *stats, ev,
                    latest_eval["mean"] if evaluated else None, controller.value,
                    overlap_active, fresh, used]))
                row.update(control)
                row["advantage_variance"] = advantage_variance
                writer.writerow(row)
                status = {**row, "state": "running", "pid": os.getpid(), "device": args.device,
                          "physics_device": str(env.qpos.device), "num_envs": args.num_envs,
                          "budget": effective_steps, "eta_seconds": (effective_steps - steps) / (steps / elapsed),
                          "retained_steps_per_world": end-used}
                write_json(args.out / "status.json", status)
                print(f"{steps}/{effective_steps} | {steps / elapsed:.0f} steps/s | train={row['train_return_last_100']} | eval={row['eval_mean']}", flush=True)
                filled = end - used
                if filled:
                    for buf in [obuf, nbuf, abuf, logbuf, rbuf, vbuf, nvbuf, tbuf, dbuf]:
                        buf[:filled].copy_(buf[used:end].clone())
        # Check that the saved model reloads exactly for a fixed observation batch.
        restored = ActorCritic(obs_dim,action_dim).to(args.device)
        restored.load_state_dict(torch.load(args.out / "latest.pt", weights_only=False)["model"])
        with torch.no_grad():
            torch.testing.assert_close(restored.actor(obs), model.actor(obs), rtol=0, atol=0)
        summary = {**status, "state": "completed", "initial_eval": initial,
                   "final_eval": latest_eval, "best_eval_mean": best, "reload_check": "passed",
                   "note": "GPU backend pilot; one seed; no convergence or cross-backend equivalence claim."}
        # Final-checkpoint stress curve, independent resets/noise and frozen normalizer.
        stress=[]
        for mode,scale in [('none',0.),('gaussian',.10),('gaussian',.15),('gaussian',.30),('multiplicative',.20),('multiplicative',.30)]:
            eval_env.env.rng.manual_seed(args.seed+400000)
            eval_env.configure(mode,scale,args.seed+500000)
            result=evaluate(model,obs_stats,eval_env)
            stress.append({'mode':mode,'scale':scale,**result})
        write_json(args.out / 'stress_evaluation.json',stress)
        summary['stress_evaluation']='stress_evaluation.json'
        summary['note']='Frozen lambda algorithm across tasks; paired seed is the training replicate; GPU v4-semantics adaptation, not a paper reproduction.'
        write_json(args.out / "summary.json", summary)
        write_json(args.out / "status.json", summary)
    except BaseException as exc:
        write_json(args.out / "status.json", {"state": "failed", "error": repr(exc), "pid": os.getpid()})
        raise


if __name__ == "__main__":
    main()
