"""Prepare only a new passive diagnostic; preserve all original artifacts."""
import argparse
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--origin', type=Path, required=True)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--native-proof-sha', required=True)
    args = parser.parse_args()
    origin = args.origin.resolve()
    proof = origin / 'PARENT_VERIFIED_terminal16.json'
    assert sha(proof) == args.native_proof_sha
    native, suite, launch = read(proof), read(origin / 'suite_status.json'), read(origin / 'LAUNCH_MANIFEST.json')
    assert native['state'] == 'passed' and native['analysis_recomputed_exact']
    assert suite['state'] == 'completed' and suite['completed_count'] == 16
    assert not suite['active'] and suite['failure'] is None
    for arm, directory in [('innovation1', 'source_i1'), ('innovation2', 'source_i2')]:
        assert len(launch['source_hashes'][arm]) == 18
        for name, expected in launch['source_hashes'][arm].items():
            assert sha(origin / directory / name) == expected
    base = read(origin / 'BASE8_REUSE_MANIFEST.json')
    assert base['state'] == 'verified' and len(base['rows']) == 8
    for row in base['rows']:
        hashes = row.get('artifact_hashes', row.get('artifact_sha256'))
        assert len(hashes) == 9
        for name, expected in hashes.items():
            assert sha(Path(row['path']) / name) == expected
    controls = {}
    for job in suite['smoke_jobs']:
        if job['arm'] == 'innovation1':
            assert job['state'] == 'completed' and job['seed'] == 91081
            for name, expected in job['artifact_hashes'].items():
                assert sha(Path(job['path']) / name) == expected
            controls[job['rep']] = job
    assert set(controls) == {'a', 'b'}
    protected = [job for job in suite['jobs'] if job['arm'] == 'innovation2']
    assert len(protected) == 8
    for job in protected:
        assert job['state'] == 'completed'
        for name, expected in job['artifact_hashes'].items():
            assert sha(Path(job['path']) / name) == expected
    args.root.mkdir(parents=True, exist_ok=False)
    root = args.root.resolve()
    (root / 'tmp').mkdir()
    (root / '.venv').symlink_to(origin / '.venv', target_is_directory=True)
    if (origin / 'analysis_dependencies').is_dir():
        (root / 'analysis_dependencies').symlink_to(origin / 'analysis_dependencies', target_is_directory=True)
    shutil.copytree(origin / 'cache', root / 'cache')
    cache_files = 0
    for path in (origin / 'cache').rglob('*'):
        if path.is_file():
            copied = root / 'cache' / path.relative_to(origin / 'cache')
            assert sha(copied) == sha(path) and copied.stat().st_ino != path.stat().st_ino
            cache_files += 1
    reference = {
        'state': 'verified', 'origin': str(origin), 'task': 'Reacher',
        'native_proof_sha256': sha(proof), 'origin_launch_sha256': sha(origin / 'LAUNCH_MANIFEST.json'),
        'origin_base_manifest_sha256': sha(origin / 'BASE8_REUSE_MANIFEST.json'),
        'origin_runner': str(origin / 'run_innovation_adjustment_r4.py'),
        'origin_runner_sha256': launch['runner_sha256'], 'source_hashes': launch['source_hashes'],
        'controls': controls, 'protected_innovation2': protected, 'base_manifest': base,
    }
    (root / 'REFERENCE_MANIFEST.json').write_text(json.dumps(reference, indent=2) + '\n')
    agents = []
    for ancestor in [root] + list(root.parents):
        path = ancestor / 'AGENTS.md'
        if path.is_file():
            agents.append({'path': str(path), 'text': path.read_text()})
    record = {
        'state': 'prepared', 'root': str(root), 'timestamp_utc': datetime.now(timezone.utc).isoformat(),
        'reference_manifest_sha256': sha(root / 'REFERENCE_MANIFEST.json'),
        'source_files_verified': 36, 'base_artifacts_verified': 72,
        'protected_innovation2_runs_verified': 8, 'controls_verified': 2,
        'cache_files': cache_files, 'disk_free_bytes': shutil.disk_usage(root).free,
        'applicable_agents': agents, 'trainers_started': False,
    }
    (root / 'REMOTE_PREPARED.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record))


if __name__ == '__main__':
    main()
