"""CPU-only formula, consumption, RNG, and exact-transition ledger verification."""
import ast
import difflib
import hashlib
import json
import math
from pathlib import Path
from types import SimpleNamespace
import tempfile

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
R3 = ROOT.parent / 'two_task_innovation_adjustment_r3_20261003'


def source_functions(path, names):
    tree = ast.parse(path.read_text(), filename=str(path))
    nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
    assert {n.name for n in nodes} == set(names)
    ns = {'torch': torch, 'math': math, '__name__': 'r4_cpu_audit_source'}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec'), ns)
    return ns


def independent_gae(rewards, values, next_values, terminated, done, gamma, lam):
    """Explicit discounted TD-sum, independent of backward-carry implementation."""
    delta = rewards + gamma * (~terminated).float() * next_values - values
    result = torch.zeros_like(rewards)
    for t in range(len(rewards)):
        weight = torch.ones_like(rewards[0])
        for k in range(t, len(rewards)):
            result[t] += weight * delta[k]
            weight = weight * (gamma * lam * (~done[k]).float()).double()
    return result, result + values


def independent_trace(rewards, values, next_values, terminated, done, ratios, gamma, lam):
    """Explicit future ratio products; actor excludes own ratio, critic includes it."""
    delta = rewards + gamma * (~terminated).float() * next_values - values
    actor = torch.zeros_like(rewards)
    for t in range(len(rewards)):
        weight = torch.ones_like(rewards[0])
        for k in range(t, len(rewards)):
            actor[t] += weight * delta[k]
            if k + 1 < len(rewards):
                weight = weight * (gamma * lam * (~done[k]).float()).double() * ratios[k + 1]
    return actor, values + ratios * actor


def fixed_target_block(path):
    tree = ast.parse(path.read_text())
    for n in ast.walk(tree):
        if isinstance(n, ast.With):
            for i, item in enumerate(n.body):
                if (isinstance(item, ast.Assign) and isinstance(item.targets[0], ast.Tuple)
                    and [x.id for x in item.targets[0].elts] == ['advantages', 'returns']):
                    nodes = n.body[i:i + 5]
                    assert isinstance(nodes[-1], ast.If)
                    return compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec')
    raise AssertionError('Actual frozen target block not found')


def verify_i1():
    path = ROOT / 'source_i1/train_kl_relative.py'
    ns = source_functions(path, ['gae', 'save_fixed_critic_audit'])
    legacy = source_functions(R3 / 'source_i1/train_kl_relative.py', ['gae'])['gae']
    block = fixed_target_block(path)
    x = torch.arange(64 * 4, dtype=torch.float64).reshape(64, 4)
    r, v, nv = x.sin() * .2, x.cos() * .3, (x + .7).cos() * .3
    term, done = torch.zeros_like(x, dtype=torch.bool), torch.zeros_like(x, dtype=torch.bool)
    term[9, 0] = True
    done[9, 0] = True
    done[21, 1] = True  # Time limit: retain bootstrap, stop trace.
    term[-1, 2] = True
    done[-1, 2] = True
    assert not torch.equal(independent_gae(r, v, nv, term, done, .99, .95)[0],
                           independent_gae(r, v, nv, done, done, .99, .95)[0])
    initial_rng = torch.get_rng_state().clone()
    cases = []
    for lam in [.95, .934, .96]:
        for fixed in [None, .95]:
            env = dict(ns, args=SimpleNamespace(fixed_critic_lambda=fixed),
                       controller=SimpleNamespace(value=lam),
                       rbuf=r, vbuf=v, nvbuf=nv, tbuf=term, dbuf=done, end=64)
            exec(block, env)
            a, ret = env['advantages'], env['returns']
            legacy_a, legacy_ret = legacy(r, v, nv, term, done, .99, lam)
            assert torch.equal(a, legacy_a)
            expected = independent_gae(r, v, nv, term, done, .99, lam if fixed is None else fixed)[1]
            torch.testing.assert_close(ret, expected, rtol=1e-13, atol=1e-13)
            if fixed is None or lam == .95:
                assert torch.equal(ret, legacy_ret)
                assert env['actor_critic_target_diff_rmse'] == 0
            else:
                assert torch.count_nonzero(ret - legacy_ret) > 0
                assert env['actor_critic_target_diff_rmse'] > 0
            with tempfile.TemporaryDirectory(prefix='source_audit_', dir=ROOT) as td:
                p = Path(td) / 'synthetic_helper_check.pt'
                ns['save_fixed_critic_audit'](p, r, v, nv, term, done, a.flatten(), ret.flatten(),
                                            lam, lam if fixed is None else fixed, 77,
                                            5046272, 4980736, 64)
                payload = torch.load(p, weights_only=False)
                assert torch.equal(payload['actor_advantage'], a)
                assert torch.equal(payload['consumed_critic_return'], ret)
                for key in ['normalized_reward', 'values', 'next_values', 'terminated', 'done',
                            'actor_advantage', 'consumed_critic_return']:
                    assert payload[key].device.type == 'cpu' and not payload[key].requires_grad
                consumed_loss = (v.flatten() - payload['consumed_critic_return'].flatten()).square().mean()
                assert torch.equal(consumed_loss, (v.flatten() - ret.flatten()).square().mean())
            cases.append({'actor_lambda': lam, 'fixed_critic_lambda': fixed,
                          'target_diff_rmse': env['actor_critic_target_diff_rmse']})
    assert torch.equal(initial_rng, torch.get_rng_state())
    code = path.read_text()
    assert 'adv = flat_adv[idx]' in code
    assert 'vl = (model.value(flat_obs[idx]) - flat_ret[idx]).square().mean()' in code
    assert 'dbuf[:end], flat_adv, flat_ret,' in code
    audit_schedules = {}
    for name, steps, cut in [('full', 10027008, 4980736), ('short', 524288, 262144)]:
        updates = math.ceil(steps / 65536)
        activation = max(5, math.ceil(cut / 65536) + 1)
        audits = sorted({activation - 1, activation, updates})
        assert audits == ([76, 77, 153] if name == 'full' else [4, 5, 8])
        audit_schedules[name] = {'updates': updates, 'audit_updates': audits,
                                'optimizer_steps': updates * 64 * 10,
                                'fresh_transitions': updates * 65536,
                                'trained_transitions': updates * 65536}
    return {'formula_and_actual_source_target_block': 'passed', 'none_flag_legacy_exact': 'passed',
            'actor_advantage_legacy_exact': 'passed', 'audit_helper_roundtrip': 'passed',
            'rng_unchanged': True, 'training_audits_created': False,
            'synthetic_cases': cases, 'schedule': audit_schedules}


def sample_id_ledger(steps, cut, tail):
    envs, rollout, epochs = 1024, 64, 10
    prefix, total_time, switch = rollout - tail, steps // envs, cut // envs
    fresh_count, trained_count, optimizer, early_count, late_count = 0, 0, 0, 0, 0
    counts = np.zeros((total_time, envs), dtype=np.uint8)
    retained, rows = [], []
    while fresh_count < total_time or retained:
        prior = fresh_count
        staged = fresh_count < switch
        fresh = min(rollout - len(retained), total_time - fresh_count)
        if staged:
            fresh = min(fresh, switch - fresh_count)
        batch = retained + list(range(fresh_count, fresh_count + fresh))
        fresh_count += fresh
        flush = staged and fresh_count >= switch
        used = len(batch) if fresh_count == total_time or flush else min(prefix if staged else rollout, len(batch))
        counts[batch[:used], :] += 1  # Sample ID is (fresh time index, environment ID).
        trained_count += used * envs
        optimizer += math.ceil(used * envs / envs) * epochs
        rows.append({'prior_per_world': prior, 'fresh_per_world': fresh,
                     'incoming_retained_per_world': len(retained), 'used_per_world': used,
                     'retained_out_per_world': len(batch) - used, 'flush': flush, 'early': staged})
        retained = batch[used:]
        early_count += int(staged)
        late_count += int(not staged)
    assert np.all(counts == 1)
    assert fresh_count * envs == trained_count == steps
    assert len([r for r in rows if r['flush']]) == 1
    assert all(r['incoming_retained_per_world'] == r['retained_out_per_world'] == 0 for r in rows if not r['early'])
    if tail == 16:
        assert [r for r in rows if r['flush']][0]['used_per_world'] == 64
        assert all(r['incoming_retained_per_world'] == 16 for r in rows[1:early_count])
    return {'updates': len(rows), 'early_updates': early_count, 'late_updates': late_count,
            'fresh_transitions': fresh_count * envs, 'trained_transitions': trained_count,
            'actor_optimizer_steps': optimizer, 'critic_optimizer_steps': optimizer,
            'boundary_window': next(r for r in rows if r['flush']),
            'every_sample_id_consumed_exactly_once': True, 'tail': tail, 'prefix': prefix}


def verify_i2():
    path = ROOT / 'source_i2/train_pae_baseline.py'
    ns = source_functions(path, ['capped_tail_trace', 'trace_correction_diagnostics', 'finite_drift_metrics'])
    legacy = source_functions(R3 / 'source_i2/train_pae_baseline.py', ['capped_tail_trace'])['capped_tail_trace']
    gae = source_functions(ROOT / 'source_i1/train_kl_relative.py', ['gae'])['gae']
    x = torch.arange(64 * 4, dtype=torch.float64).reshape(64, 4)
    r, v, nv = x.sin() * .2, x.cos() * .3, (x + .7).cos() * .3
    term, done = torch.zeros_like(x, dtype=torch.bool), torch.zeros_like(x, dtype=torch.bool)
    term[7, 0] = True
    done[7, 0] = True
    done[12, 1] = True
    before_rng = torch.get_rng_state().clone()
    for tail in [8, 16]:
        logs = torch.zeros_like(x)
        logs[:tail] = -.01 * (1 + x[:tail].remainder(9))
        ratios = logs.clamp(max=0).exp()
        actual = ns['capped_tail_trace'](r, v, nv, term, done, ratios, .99, .95)
        expected = independent_trace(r, v, nv, term, done, ratios, .99, .95)
        old = legacy(r, v, nv, term, done, ratios, .99, .95)
        raw = gae(r, v, nv, term, done, .99, .95)
        for a, e, o, u in zip(actual, expected, old, raw):
            torch.testing.assert_close(a, e, rtol=1e-13, atol=1e-13)
            assert torch.equal(a, o)
            assert torch.equal(a[tail:], u[tail:])
        d = ns['trace_correction_diagnostics'](logs, ratios, actual[0] - raw[0], actual[1] - raw[1], tail, .95)
        assert d['active_correction']
        assert d['fresh_actor_correction_nonzero_count'] == d['fresh_critic_correction_nonzero_count'] == 0
    for a, b in zip(ns['capped_tail_trace'](r, v, nv, term, done, torch.ones_like(r), .99, .95),
                    gae(r, v, nv, term, done, .99, .95)):
        assert torch.equal(a, b)
    assert torch.equal(before_rng, torch.get_rng_state())
    ledgers = {name: sample_id_ledger(steps, cut, 16)
               for name, steps, cut in [('full', 10027008, 4980736), ('short', 524288, 262144)]}
    assert (ledgers['full']['early_updates'], ledgers['full']['late_updates']) == (101, 77)
    assert (ledgers['short']['early_updates'], ledgers['short']['late_updates']) == (5, 4)
    assert ledgers['full']['actor_optimizer_steps'] == 97920
    assert ledgers['short']['actor_optimizer_steps'] == 5120
    assert sample_id_ledger(10027008, 4980736, 8)['updates'] == 164
    return {'independent_future_ratio_product_formula': 'passed', 'r3_trace_bit_exact': 'passed',
            'fresh_suffix_and_all_late_exact_gae': 'passed', 'ratio_one_exact_gae': 'passed',
            'termination_and_truncation_masks': 'passed', 'rng_unchanged': True, 'ledger': ledgers}


def main():
    result = {'state': 'passed', 'runtime': {'torch': torch.__version__, 'device': 'cpu'},
              'i1': verify_i1(), 'i2': verify_i2(), 'source_provenance': {}}
    for arm, changed in [('source_i1', 'train_kl_relative.py'), ('source_i2', 'train_pae_baseline.py')]:
        files = sorted(p for p in (ROOT / arm).iterdir() if p.is_file())
        assert len(files) == 18
        hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
        different = [p.name for p in files if p.read_bytes() != (R3 / arm / p.name).read_bytes()]
        assert different == [changed]
        for p in files:
            if p.suffix == '.py':
                compile(p.read_text(), str(p), 'exec')
        before, after = (R3 / arm / changed).read_text(), (ROOT / arm / changed).read_text()
        diff = ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                           fromfile=f'R3/{arm}/{changed}', tofile=f'R4/{arm}/{changed}'))
        (ROOT / f'SOURCE_R4_{arm}_DIFF.patch').write_text(diff)
        result['source_provenance'][arm] = {'file_count': 18, 'unchanged_support_files': 17,
                                          'changed_file': changed, 'sha256': hashes}
    (ROOT / 'SOURCE_R4_VERIFIED.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
