"""One-shot parent audit of frozen inputs, engineering gates and live/completed jobs."""
import argparse
import csv
import datetime
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
FATAL = re.compile(r'Traceback \(most recent call last\)|(?:CUDA|torch\.).*(?:out of memory|OutOfMemoryError)|RuntimeError:|AssertionError:|Segmentation fault|FloatingPointError:', re.I)


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def read(path):
    return json.loads(path.read_text())


def probe(command):
    process = subprocess.run(command, text=True, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, timeout=20)
    return dict(command=command, returncode=process.returncode,
                stdout=process.stdout.strip(), stderr=process.stderr.strip())


def proc(pid):
    path = Path('/proc') / str(pid)
    if not path.exists():
        return dict(pid=pid, alive=False)
    try:
        command = [v.decode() for v in (path / 'cmdline').read_bytes().split(b'\0') if v]
        # Comm can contain spaces; stat fields begin after its closing parenthesis.
        fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
        age = float(Path('/proc/uptime').read_text().split()[0]) - int(fields[19]) / os.sysconf('SC_CLK_TCK')
        return dict(pid=pid, alive=bool(command) and fields[0] != 'Z',
                    command=command, age_seconds=age, process_state=fields[0])
    except FileNotFoundError:
        return dict(pid=pid, alive=False)


def same_command(actual, expected):
    if len(actual) != len(expected):
        return False
    # Interpreter and script symlinks do not alter the requested command.
    for index, (a, b) in enumerate(zip(actual, expected)):
        if a == b:
            continue
        if index < 2 and Path(a).resolve() == Path(b).resolve():
            continue
        return False
    return True


def log_health(path):
    require(path.is_file(), ('expected log missing', str(path)))
    with path.open('rb') as handle:
        handle.seek(max(0, path.stat().st_size - 262144))
        text = handle.read().decode(errors='replace')
    fatal = [line[-1000:] for line in text.splitlines() if FATAL.search(line)]
    require(not fatal, ('fatal log evidence', str(path), fatal[-8:]))
    return dict(path=str(path), present=True, size_bytes=path.stat().st_size, fatal=[])


def unit_health(task, launch, suite, terminal, evidence):
    expected = 'dpo_' + task.lower() + '_innovation12_r4_replayfix1_8seed_20261003.service'
    name = launch['service_name']
    require(name == expected, ('unexpected service name', name, expected))
    result = probe(['systemctl', '--user', 'show', name, '--property=ActiveState,SubState,Result,MainPID,ExecMainStatus'])
    evidence['unit_probe'] = result
    require(result['returncode'] == 0, ('unit query failed', result))
    state = dict(line.split('=', 1) for line in result['stdout'].splitlines() if '=' in line)
    evidence['unit_state'] = state
    require(state.get('ActiveState') != 'failed', ('unhealthy service', state))
    coordinator = proc(int(suite['coordinator_pid']))
    evidence['coordinator'] = coordinator
    if terminal and state.get('ActiveState') == 'inactive':
        require(state.get('Result') == 'success' and state.get('ExecMainStatus') == '0', ('unsuccessful terminal service', state))
        require(not coordinator['alive'], ('inactive unit with live coordinator', coordinator))
    elif terminal:
        require(state.get('ActiveState') in ('active', 'activating', 'deactivating'), ('unexpected terminal service state', state))
        require(state.get('Result') == 'success' and state.get('ExecMainStatus') == '0', ('unsuccessful terminal service', state))
        if coordinator['alive']:
            require(int(state.get('MainPID', 0)) == suite['coordinator_pid'], ('unit coordinator PID mismatch', state))
            require(same_command(coordinator['command'], suite['coordinator_command']), ('coordinator command mismatch', coordinator))
        evidence['terminal_service_exit_grace'] = True
    else:
        require(state.get('ActiveState') in ('active', 'activating'), ('coordinator unit not active', state))
        require(coordinator['alive'], ('coordinator is not alive', coordinator))
        require(int(state.get('MainPID', 0)) == suite['coordinator_pid'], ('unit coordinator PID mismatch', state))
        require(same_command(coordinator['command'], suite['coordinator_command']), ('coordinator command mismatch', coordinator))
    since = datetime.datetime.fromtimestamp(time.time() - float(suite.get('elapsed_seconds', 0)) - 5).strftime('%Y-%m-%d %H:%M:%S')
    journal = probe(['journalctl', '--user', '-u', name, '--since', since, '-n', '120', '--no-pager', '-o', 'cat'])
    evidence['unit_journal_probe'] = journal
    require(journal['returncode'] == 0, ('unit log query failed', journal))
    fatal = [line[-1000:] for line in journal['stdout'].splitlines() if FATAL.search(line)]
    require(not fatal, ('fatal service log', fatal[-8:]))


def active_health(runner, job, task, active_entry):
    path = Path(job['path'])
    process = proc(int(active_entry['pid']))
    result = dict(id=job['id'], process=process)
    require(active_entry['pid'] == job['pid'] and active_entry['gpu'] == job['gpu']
            and active_entry['arm'] == job['arm'] and not active_entry['smoke'], ('active identity mismatch', job['id']))
    expected = runner.command(job, task, False)
    require(job['command'] == expected, ('job command mismatch', job['id']))
    if process['alive']:
        require(same_command(process['command'], expected), ('live process command mismatch', result))
    else:
        # A trainer may have exited within the coordinator's five-second update interval.
        require((path / 'summary.json').is_file(), ('active process disappeared without completion', result))
        result['completed_pending_coordinator'] = runner.verify(job, task, False)
    if (path / 'config.json').is_file():
        runner.verify_config(job, task, False)
        result['config_verified'] = True
    else:
        require(process.get('age_seconds', 999) < 60, ('active config missing after startup grace', result))
        result['config_pending_startup'] = True
    if (path / 'status.json').is_file():
        status = read(path / 'status.json')
        require(status['state'] in ('compiling', 'running', 'completed'), ('failed training status', job['id'], status))
        require(status.get('pid', job['pid']) == job['pid'], ('training PID mismatch', job['id']))
        result['training_state'] = status['state']
    if (path / 'progress.csv').is_file():
        rows = list(csv.DictReader((path / 'progress.csv').open()))
        if rows:
            row = rows[-1]
            require(0 < int(row['steps']) <= runner.BUDGET, ('invalid active progress', job['id'], row))
            for key in ('value_loss', 'policy_loss', 'entropy', 'approx_kl', 'explained_variance', 'steps_per_second'):
                if row.get(key) not in (None, ''):
                    require(math.isfinite(float(row[key])), ('nonfinite active metric', job['id'], key))
            age = time.time() - (path / 'progress.csv').stat().st_mtime
            require(age < 900, ('active progress stale for over 15 minutes', job['id'], age))
            result.update(progress_rows=len(rows), last_steps=int(row['steps']), progress_age_seconds=age)
    result['log'] = log_health(Path(job['log']))
    return result


def audit(args, evidence):
    spec = importlib.util.spec_from_file_location('frozen_r4_replayfix1_runner_parent', ROOT / 'run_innovation_adjustment_r4.py')
    runner = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = runner
    spec.loader.exec_module(runner)
    launch, base_manifest, suite = (read(ROOT / name) for name in ('LAUNCH_MANIFEST.json', 'BASE8_REUSE_MANIFEST.json', 'suite_status.json'))
    task = args.task or launch['task']
    require(task == launch['task'] == base_manifest['task'] == suite['task'] == 'Reacher', 'task mismatch')
    require(launch['gpus'] == [1] and launch['smoke_seed'] == 91081, 'Reacher device/seed mismatch')
    evidence['task'] = task
    hashes = runner.check_source()
    launch_sha, base_sha = runner.sha(ROOT / 'LAUNCH_MANIFEST.json'), runner.sha(ROOT / 'BASE8_REUSE_MANIFEST.json')
    require(suite['launch_manifest_sha256'] == launch_sha and suite['base_manifest_sha256'] == base_sha, 'pinned manifest changed')
    require(base_manifest['state'] == 'verified' and len(base_manifest['rows']) == 8, 'Base manifest invalid')
    require(sorted(r['seed'] for r in base_manifest['rows']) == list(runner.SEEDS), 'Base seeds mismatch')
    bases = [runner.verify_base(row, task) for row in base_manifest['rows']]
    evidence.update(source_hashes=hashes, launch_manifest_sha256=launch_sha, base_manifest_sha256=base_sha, preserved_base_count=len(bases))
    prepared = read(ROOT / 'PREPARE_PASSED.json')
    require(prepared['state'] == 'passed' and prepared['task'] == task and prepared['source_hashes'] == hashes, 'prepare/source mismatch')
    require(prepared['base_rows'] == bases and prepared['base_manifest_sha256'] == base_sha and prepared['launch_manifest_sha256'] == launch_sha, 'prepare pinned inputs mismatch')
    require(suite['failure'] is None and suite['state'] not in ('failed', 'attention_required'), ('suite failure', suite.get('failure')))
    for name in ('gpus', 'max_per_gpu', 'smoke_seed'):
        require(suite[name] == launch[name], ('suite/launch mismatch', name))
    jobs, smokes = suite['jobs'], suite['smoke_jobs']
    require(suite['total'] == len(jobs) == 16, 'formal job count mismatch')
    require({(j['arm'], j['seed']) for j in jobs} == {(a, s) for a in runner.ARMS for s in runner.SEEDS}, 'formal matrix mismatch')
    require(len(smokes) == 4 and {(j['arm'], j['rep']) for j in smokes} == {(a, r) for a in runner.ARMS for r in ('a', 'b')}, 'four smoke matrix mismatch')
    smoke_metrics = {}
    for job in smokes:
        require(job['state'] == 'completed' and job['seed'] == suite['smoke_seed'], ('smoke incomplete', job['id']))
        require(job['gpu'] == runner.smoke_gpu(task, job['rep']), ('smoke GPU mismatch', job['id']))
        metrics = runner.verify(job, task, True)
        require(metrics == job['metrics'], ('saved smoke metrics changed', job['id']))
        require(runner.artifact_hashes(Path(job['path']), job['arm']) == job['artifact_hashes'], ('smoke artifacts changed', job['id']))
        control = Path(base_manifest['control_gate_initial_path'])
        require((Path(job['path']) / 'initial_evaluation.json').read_bytes() == control.read_bytes(), ('smoke initial mismatch', job['id']))
        smoke_metrics[job['id']] = metrics
        log_health(Path(job['log']))
    gates = suite['gates']
    require(set(gates) == set(runner.ARMS), 'engineering gates missing')
    for arm in runner.ARMS:
        pair = [next(j for j in smokes if j['arm'] == arm and j['rep'] == r) for r in ('a', 'b')]
        gate, exact = gates[arm], runner.exact_pair(pair[0]['path'], pair[1]['path'], arm)
        require(all(gate[k] == v for k, v in exact.items()), ('saved exact pair mismatch', arm))
        require(gate['paths'] == [j['path'] for j in pair] and gate['gpu_pair'] == [j['gpu'] for j in pair], ('gate paths/GPU mismatch', arm))
        require(gate['metrics'] == [j['metrics'] for j in pair] and gate['artifact_hashes'] == [j['artifact_hashes'] for j in pair] and gate['peak_mib'] > 0, ('gate evidence mismatch', arm))
        require(suite['admission_estimates_mib'][arm] == max(3500, gate['peak_mib'] + 256), ('memory admission estimate mismatch', arm))
    smoke = read(ROOT / 'SMOKE_VERIFIED.json')
    require(smoke['state'] == 'passed' and smoke['task'] == task and smoke['gates'] == gates, 'SMOKE_VERIFIED gates mismatch')
    require(smoke['source_hashes'] == hashes and smoke['launch_manifest_sha256'] == launch_sha and smoke['short_budget'] == runner.SHORT and smoke['seed'] == suite['smoke_seed'], 'SMOKE_VERIFIED pinned inputs mismatch')
    require(smoke['historical_initial_sha256'] == runner.sha(Path(base_manifest['control_gate_initial_path'])), 'historical initial changed')
    evidence['smoke_metrics'] = smoke_metrics
    completed = [j for j in jobs if j['state'] == 'completed']
    require(suite['completed_count'] == len(completed), 'completed counter mismatch')
    require(all(j['state'] in ('pending', 'running', 'completed') for j in jobs), 'unexpected formal job state')
    evidence['verified_completed'] = []
    for job in completed:
        metrics = runner.verify(job, task, False)
        require(metrics == job['metrics'], ('saved formal metrics changed', job['id']))
        require(runner.artifact_hashes(Path(job['path']), job['arm']) == job['artifact_hashes'], ('formal artifacts changed', job['id']))
        base = next(b for b in bases if b['seed'] == job['seed'])
        require((Path(job['path']) / 'initial_evaluation.json').read_bytes() == (Path(base['path']) / 'initial_evaluation.json').read_bytes(), ('formal paired initial mismatch', job['id']))
        require(metrics['xml_sha256'] == base['xml_sha256'], ('XML mismatch', job['id']))
        log_health(Path(job['log']))
        evidence['verified_completed'].append(dict(id=job['id'], metrics=metrics, artifact_hashes=job['artifact_hashes']))
    active = suite['active']
    running = [j for j in jobs if j['state'] == 'running']
    require(set(active) == {j['id'] for j in running}, 'active/running identity mismatch')
    require(all(j['gpu'] in suite['gpus'] for j in jobs if j['state'] != 'pending'), 'admitted job GPU outside planned devices')
    for gpu in suite['gpus']:
        require(sum(j['gpu'] == gpu for j in running) <= suite['max_per_gpu'] <= 8, ('GPU concurrency cap exceeded', gpu))
    evidence['active_health'] = [active_health(runner, j, task, active[j['id']]) for j in running]
    evidence.update(completed_count=len(completed), active_count=len(active), pending_count=sum(j['state'] == 'pending' for j in jobs))
    if args.phase == 'startup':
        require(len(completed) + len(running) >= 1, 'no formal job admitted')
    elif args.phase == 'stage8':
        require(len(completed) >= 8, 'fewer than eight formal jobs completed')
    else:
        require(len(completed) == 16 and not active and suite['state'] == 'completed', 'terminal suite incomplete')
        analysis = runner.analyze(jobs, bases, task)
        require(analysis == read(ROOT / 'ANALYSIS.json'), 'saved ANALYSIS differs from exact reanalysis')
        evidence['analysis_sha256'] = runner.sha(ROOT / 'ANALYSIS.json')
        evidence['analysis_recomputed_exact'] = True
    unit_health(task, launch, suite, args.phase == 'terminal16', evidence)
    evidence['gpu_snapshot'] = probe(['nvidia-smi', '--query-gpu=index,name,memory.total,memory.used,utilization.gpu', '--format=csv,noheader'])
    require(evidence['gpu_snapshot']['returncode'] == 0, 'GPU snapshot failed')
    available_gpus = {int(line.split(',')[0]) for line in evidence['gpu_snapshot']['stdout'].splitlines() if line.strip()}
    require(set(suite['gpus']) <= available_gpus, 'planned GPU missing from snapshot')
    evidence['gpu_processes'] = probe(['nvidia-smi', '--query-compute-apps=pid,used_gpu_memory', '--format=csv,noheader'])
    require(evidence['gpu_processes']['returncode'] == 0, 'GPU process query failed')
    evidence['launcher_log'] = log_health(ROOT / 'launcher.log')
    if (ROOT / 'coordinator.log').is_file():
        evidence['coordinator_log'] = log_health(ROOT / 'coordinator.log')
    # Pinning is checked again after reading mutable status and potentially large checkpoints.
    require(runner.check_source() == hashes and runner.sha(ROOT / 'LAUNCH_MANIFEST.json') == launch_sha and runner.sha(ROOT / 'BASE8_REUSE_MANIFEST.json') == base_sha, 'inputs changed during parent verification')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=('startup', 'stage8', 'terminal16'), required=True)
    parser.add_argument('--task', choices=('Reacher',))
    args = parser.parse_args()
    evidence = dict(state='failed', phase=args.phase, root=str(ROOT),
                    timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    try:
        audit(args, evidence)
        evidence['state'] = 'passed'
    except Exception as error:
        evidence.update(error=repr(error), traceback=traceback.format_exc())
    destination = ROOT / ('PARENT_VERIFIED_' + args.phase + '.json')
    temporary = destination.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(evidence, indent=2, allow_nan=False)+'\n')
    temporary.replace(destination)
    print(json.dumps({key: evidence.get(key) for key in ('state', 'phase', 'task', 'completed_count', 'active_count', 'error')}))
    raise SystemExit(0 if evidence['state'] == 'passed' else 1)


if __name__ == '__main__':
    main()
