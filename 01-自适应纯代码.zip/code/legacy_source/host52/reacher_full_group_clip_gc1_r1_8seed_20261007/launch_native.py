"""Launch one USER unit only after exact root review, active Luna and phase gates."""
import argparse
from pathlib import Path
import subprocess
import sys
from execution_contract import ROOT, NATIVE_ROOT, read, write
from coordinator import validate_owner


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=('saved', 'short', 'formal'), required=True)
    args = parser.parse_args()
    assert ROOT == NATIVE_ROOT
    assert not (ROOT / (args.phase.upper() + '_SUITE_STATUS.json')).exists()
    owner = validate_owner(args.phase)
    name = 'reacher-fullgc1-group-' + args.phase + '-20261007.service'
    unit = ROOT / name
    destination = Path.home() / '.config/systemd/user' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert not destination.exists(), 'Preserve every previously installed unit/outcome'
    with destination.open('xb') as output: output.write(unit.read_bytes())
    destination.chmod(0o644)
    results = []
    for argv in (['systemctl', '--user', 'daemon-reload'], ['systemctl', '--user', 'start', name]):
        child = subprocess.Popen(argv, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = child.communicate(timeout=30)
        results.append({'actual_argv': argv, 'pid': child.pid, 'exit_code': child.returncode,
                        'stdout': stdout, 'stderr': stderr})
        if child.returncode:
            break
    write(ROOT / (args.phase.upper() + '_LAUNCH_RECEIPT.json'),
          {'state': 'launched' if all(r['exit_code'] == 0 for r in results) else 'failed',
           'phase': args.phase, 'luna_goal_id': owner['luna_goal_id'],
           'actual_calls': results, 'automatic_retry': False})
    assert len(results) == 2 and all(r['exit_code'] == 0 for r in results), results
    print('Root-authorized USER unit launched; Luna owns declared execution observation.')


if __name__ == '__main__':
    sys.dont_write_bytecode = True
    main()
