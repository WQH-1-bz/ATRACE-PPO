"""Native optimization replay from literal production-loss AST; no environment imports."""
import ast
import copy
import hashlib
import math
import types


def snapshot(torch, value):
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().clone()
    if isinstance(value, dict):
        return {k: snapshot(torch, v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return type(value)(snapshot(torch, v) for v in value)
    return copy.deepcopy(value)


def digest(torch, value):
    h = hashlib.sha256()
    def visit(v):
        if isinstance(v, torch.Tensor):
            h.update(str((str(v.dtype), tuple(v.shape))).encode())
            h.update(v.detach().cpu().contiguous().reshape(-1).view(torch.uint8).numpy().tobytes())
        elif isinstance(v, dict):
            h.update(b'dict')
            for key in sorted(v, key=lambda k: (type(k).__name__, repr(k))):
                visit(key); visit(v[key])
        elif isinstance(v, (tuple, list)):
            h.update(type(v).__name__.encode())
            for item in v: visit(item)
        else:
            h.update((type(v).__name__ + ':' + repr(v)).encode())
    visit(value)
    return h.hexdigest()


def equal(torch, a, b, label):
    assert digest(torch, a) == digest(torch, b), 'Strict scientific bytes differ: ' + label


def definitions(torch, source):
    ns = {'torch': torch, 'nn': torch.nn, 'math': math}
    cls = next(n for n in ast.parse((source / 'train_noisy_warp.py').read_text()).body
               if isinstance(n, ast.ClassDef) and n.name == 'ActorCritic')
    exec(compile(ast.fix_missing_locations(ast.Module(body=[cls], type_ignores=[])),
                 str(source / 'train_noisy_warp.py'), 'exec'), ns)
    # Extract the literal ordinary Full loss statements, without rewriting the scalar expression.
    tree = ast.parse((source / 'train_pae_baseline.py').read_text())
    loop = next(n for n in ast.walk(tree) if isinstance(n, ast.For)
                and isinstance(n.target, ast.Name) and n.target.id == 'group')
    start = next(i for i, n in enumerate(loop.body) if isinstance(n, ast.Assign)
                 and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'dist')
    stop = next(i for i, n in enumerate(loop.body) if isinstance(n, ast.Assign)
                and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'pg')
    vl = next(n for n in ast.walk(loop) if isinstance(n, ast.Assign)
              and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'vl'
              and 'fr[idx]' in ast.unparse(n.value) and 'maximum' not in ast.unparse(n.value))
    args = ast.arguments(posonlyargs=[], args=[ast.arg(arg=n) for n in
                         ('model', 'fo', 'fa', 'fl', 'fad', 'fr', 'idx')],
                         kwonlyargs=[], kw_defaults=[], defaults=[])
    body = copy.deepcopy(loop.body[start:stop + 1] + [vl])
    body.append(ast.Return(value=ast.BinOp(left=ast.Name(id='pg', ctx=ast.Load()),
                                         op=ast.Add(), right=ast.Name(id='vl', ctx=ast.Load()))))
    fn = ast.FunctionDef(name='production_loss', args=args, body=body, decorator_list=[])
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn], type_ignores=[])),
                 str(source / 'train_pae_baseline.py'), 'exec'), ns)
    return ns['ActorCritic'], ns['production_loss']


def operands(record, device):
    used = record['used_per_world']
    return [record[name][:used].flatten(0, 1).to(device) if name in ('observations', 'actions')
            else record[name][:used].flatten().to(device)
            for name in ('observations', 'actions', 'original_behavior_logprob',
                         'actor_advantage', 'fixed95_critic_return')]


def restore(torch, Model, record):
    model = Model(11, 2).to('cuda:1')
    model.load_state_dict(record['frozen_model_state'])
    model.train()
    optimizer = torch.optim.Adam(model.parameters(), lr=3e-4, eps=1e-5)
    optimizer.load_state_dict(copy.deepcopy(record['frozen_optimizer_state']))
    return model, optimizer


def replay_window(torch, source, grouped, record, next_record, checkpoint, equal_fn):
    Model, loss_fn = definitions(torch, source)
    with torch.random.fork_rng(devices=[1]):
        model, optimizer = restore(torch, Model, record)
        groups = grouped.parameter_groups(model, optimizer)
        torch.set_rng_state(record['pre_ppo_cpu_rng'])
        torch.cuda.set_rng_state(record['pre_ppo_device_rng'], 'cuda:1')
        xs = operands(record, 'cuda:1')
        size = record['used_per_world'] * 1024
        total = size // 1024 * 10
        number = 0
        captures = []
        for epoch in range(10):
            indices = torch.randperm(size, device='cuda:1').split(1024)
            for idx in indices:
                capture = None
                if number in (0, total - 1):
                    before = record['model_optimizer_clock_pre_ppo']['actor'] + number
                    capture = {'update': record['update'], 'epoch': epoch, 'minibatch': number,
                               'indices': idx.detach().cpu().clone(),
                               'model_optimizer_clock_before': {'actor': before, 'critic': before, 'h': 0}}
                    captures.append(capture)
                grouped.step_loss(torch, loss_fn(model, *xs, idx), optimizer, groups, capture)
                number += 1
        assert number == total and len(captures) == 2
        equal_fn(captures, record['group_clip_observer'], 'production raw/clipped group gradients/indices/norms/clocks')
        equal_fn(torch.get_rng_state(), record['post_ppo_cpu_rng'], 'post PPO CPU RNG')
        equal_fn(torch.cuda.get_rng_state('cuda:1'), record['post_ppo_device_rng'], 'post PPO physical GPU1 RNG')
        expected_model = next_record['frozen_model_state'] if next_record else checkpoint['model']
        expected_adam = next_record['frozen_optimizer_state'] if next_record else checkpoint['optimizers']['ppo']
        equal_fn(snapshot(torch, model.state_dict()), expected_model, 'chronological actual post PPO model')
        equal_fn(snapshot(torch, optimizer.state_dict()), expected_adam, 'chronological actual post PPO Adam')
    return total
