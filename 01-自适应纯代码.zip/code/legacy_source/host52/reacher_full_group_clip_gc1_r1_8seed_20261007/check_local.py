"""Bounded Python3.11 stdlib checks only; native imports/launches are forbidden here."""
import ast
import copy
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import sys
import tempfile
import types

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'reacher_full_current_crossfit_cm2_r1_8seed_20261007'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    assert sys.version_info[:2] == (3, 11)
    assert 'torch' not in sys.modules
    sys.path.insert(0, str(ROOT))
    checked = []
    for p in ROOT.rglob('*.py'):
        compile(p.read_text(), str(p), 'exec')
    checked.append('all prospective Python parsed/compiled without execution')
    old_manifest = json.loads((OLD / 'SOURCE_MANIFEST.json').read_text())
    assert sha(OLD / 'SOURCE_MANIFEST.json') == 'c012937606cc6b492ac30ccb0bdfe38f0b736ce3265318684f077022358c7618'
    for name, digest in old_manifest['files'].items():
        assert sha(OLD / name) == digest, 'Historical CM2 source was changed'
    checked.append('actual53file oldCM2 immutable source hash identity')
    changed = []
    for old in (OLD / 'source_full').iterdir():
        new = ROOT / 'source_full' / old.name
        if old.read_bytes() != new.read_bytes():
            changed.append(old.name)
    assert changed == ['train_pae_baseline.py']
    assert sha(ROOT / 'source_full/external_baseline_algorithms.py') == sha(OLD / 'source_full/external_baseline_algorithms.py')
    for name in ('actor_constant_mode.py', 'lambda_training_return.py', 'train_noisy_warp.py', 'locomotion_warp.py'):
        assert (ROOT / 'source_full' / name).read_bytes() == (OLD / 'source_full' / name).read_bytes()
    checked.append('19of20 scientific CM2files byteidentical; estimator/controller/physics/models unchanged')
    original = ast.parse((OLD / 'source_full/train_pae_baseline.py').read_text())
    new = ast.parse((ROOT / 'source_full/train_pae_baseline.py').read_text())
    old_defs = {n.name: ast.dump(n, include_attributes=False) for n in original.body
                if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name != 'main'}
    new_defs = {n.name: ast.dump(n, include_attributes=False) for n in new.body
                if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name != 'main'}
    assert old_defs == new_defs
    checked.append('all trainer non-main recurrence/observer/helper ASTs equal')
    class RemoveDeclaredHooks(ast.NodeTransformer):
        def visit_Import(self, node):
            return None if any(n.name == 'grouped_ppo_step' for n in node.names) else node

        def visit_Constant(self, node):
            replacements = {'reacher_full_group_clip_gc1_v1': 'reacher_full_current_crossfit_cm2_v1',
                            'group_clip_may_change_realized_critic_step': 'joint_clip_may_change_realized_critic_step'}
            if isinstance(node.value, str) and node.value in replacements:
                node.value = replacements[node.value]
            return node

        def visit_Assign(self, node):
            target = ast.unparse(node.targets[0])
            if target in ('clip_groups', 'group_clip_observer', 'minibatch_number', 'window_adam_calls', 'capture'):
                return None
            if target in ("config['source_sha256']['grouped_ppo_step.py']", "config['optimization_design']",
                          "constant_audit['group_clip_observer']", "constant_audit['post_ppo_cpu_rng']",
                          "constant_audit['post_ppo_device_rng']"):
                return None
            return self.generic_visit(node)

        def visit_If(self, node):
            if ast.unparse(node.test) == 'minibatch_number in (0, window_adam_calls - 1)':
                return None
            return self.generic_visit(node)

        def visit_AugAssign(self, node):
            return None if ast.unparse(node.target) == 'minibatch_number' else self.generic_visit(node)

        def visit_Assert(self, node):
            return None if 'minibatch_number == window_adam_calls' in ast.unparse(node.test) else self.generic_visit(node)

        def visit_Expr(self, node):
            if isinstance(node.value, ast.Call) and ast.unparse(node.value.func) == 'grouped_ppo_step.step_loss':
                return ast.parse('step_loss(pg + vl, optimizer, list(model.parameters()))').body[0]
            return self.generic_visit(node)
    normalized = RemoveDeclaredHooks().visit(copy.deepcopy(new))
    assert ast.dump(normalized, include_attributes=False) == ast.dump(original, include_attributes=False)
    checked.append('ENTIRE trainer AST equals CM2 after removing only enumerated clip/observer/config hooks')
    replay = module('gc1_local_replay', ROOT / 'optimization_replay.py')
    dummy = types.SimpleNamespace(nn=types.SimpleNamespace(Module=object))
    old_loss = replay.definitions(dummy, OLD / 'source_full')[1]
    new_loss = replay.definitions(dummy, ROOT / 'source_full')[1]
    assert old_loss.__code__.co_code == new_loss.__code__.co_code
    assert old_loss.__code__.co_consts == new_loss.__code__.co_consts
    assert old_loss.__code__.co_names == new_loss.__code__.co_names
    def loss_statements(tree):
        loop = next(n for n in ast.walk(tree) if isinstance(n, ast.For)
                    and isinstance(n.target, ast.Name) and n.target.id == 'group')
        return [ast.dump(n, include_attributes=False) for n in loop.body if isinstance(n, ast.Assign)
                and isinstance(n.targets[0], ast.Name) and n.targets[0].id in ('dist', 'logratio', 'ratio', 'ba', 'pg')]
    assert loss_statements(original) == loss_statements(new)
    checked.append('literal model/advantage normalization/ratio/PPO/MSE loss compiled identity; no local loss evaluation')
    grouping = module('gc1_local_group_membership', ROOT / 'source_full/grouped_ppo_step.py')
    names = list(grouping.EXPECTED_ACTOR + grouping.EXPECTED_CRITIC)
    named = [(name, types.SimpleNamespace(requires_grad=True)) for name in names]
    model = types.SimpleNamespace(named_parameters=lambda: iter(named))
    optimizer = types.SimpleNamespace(param_groups=[{'params': [p for _, p in named], 'lr': 3e-4, 'eps': 1e-5}])
    result = grouping.parameter_groups(model, optimizer)
    assert len(result['actor']) == 7 and len(result['critic']) == 6
    rejected = []
    for case in ('overlap', 'missing', 'reordered', 'extra', 'wrong_optimizer_order'):
        bad_named = list(named)
        bad_params = [p for _, p in named]
        if case == 'overlap': bad_named[-1] = (bad_named[-1][0], bad_named[0][1])
        elif case == 'missing': bad_named.pop()
        elif case == 'reordered': bad_named[1], bad_named[2] = bad_named[2], bad_named[1]
        elif case == 'extra': bad_named.append(('extra', types.SimpleNamespace(requires_grad=True)))
        elif case == 'wrong_optimizer_order': bad_params.reverse()
        bad_model = types.SimpleNamespace(named_parameters=lambda: iter(bad_named))
        bad_optimizer = types.SimpleNamespace(param_groups=[{'params': bad_params, 'lr': 3e-4, 'eps': 1e-5}])
        try: grouping.parameter_groups(bad_model, bad_optimizer)
        except AssertionError: rejected.append(case)
        else: raise AssertionError('Invalid native group topology accepted: ' + case)
    assert len(rejected) == 5
    checked.append('ordered/disjoint/exhaustive13 membership and five corruption rejections; no gradient objects fabricated')
    step = next(n for n in ast.parse((ROOT / 'source_full/grouped_ppo_step.py').read_text()).body
                if isinstance(n, ast.FunctionDef) and n.name == 'step_loss')
    calls = [n for n in ast.walk(step) if isinstance(n, ast.Call)]
    assert sum(isinstance(n.func, ast.Attribute) and n.func.attr == 'zero_grad' for n in calls) == 1
    assert sum(isinstance(n.func, ast.Attribute) and n.func.attr == 'backward' for n in calls) == 1
    assert sum(isinstance(n.func, ast.Attribute) and n.func.attr == 'step' for n in calls) == 1
    native_clip = next(n for n in calls if isinstance(n.func, ast.Attribute) and n.func.attr == 'clip_grad_norm_')
    assert any(k.arg == 'error_if_nonfinite' and isinstance(k.value, ast.Constant) and k.value.value is True for k in native_clip.keywords)
    assert not any(isinstance(n, ast.Assign) and any(isinstance(t, ast.Attribute) and t.attr == 'grad' for t in n.targets) for n in ast.walk(step))
    checked.append('one zero_grad/backward/sharedAdam and native finite clipping AST; no grad assignment')
    # Scalar geometry illustrates the exact declared change, without pretending to measure native gradients.
    for actor, critic in ((.3, .4), (8., 6.), (10., .001)):
        ac = actor * min(1., .5 / (actor + 1e-6))
        cc = critic * min(1., .5 / (critic + 1e-6))
        assert math.hypot(ac, cc) <= math.sqrt(.5 ** 2 + .5 ** 2)
    assert .5 / math.hypot(10., .001) < .051 and min(1., .5 / (.001 + 1e-6)) == 1
    checked.append('bounded scalar group/global clip geometry and disclosed sqrt2 bound; no performance inference')
    contract = module('execution_contract', ROOT / 'execution_contract.py')
    formal, short = contract.schedule(False), contract.schedule(True)
    assert len(formal) == 178 and sum(r['used_per_world'] for r in formal) * 10 == 97920
    assert len(short) == 9 and sum(r['used_per_world'] for r in short) * 10 == 5120
    checked.append('direct-once transition ledger10,027,008/178/97,920 and524,288/9/5,120 with oneboundaryflush')
    coordinator = module('gc1_local_coordinator', ROOT / 'coordinator.py')
    for phase, count in (('saved', 3), ('short', 7), ('formal', 25)):
        jobs = coordinator.tasks(phase)
        assert len(jobs) == count and all(j['exit_code'] is None and j['state'] == 'pending' for j in jobs)
    assert not any(j['kind'] == 'training' for j in coordinator.tasks('saved'))
    checked.append('savedA/B->compare DAG has no training; two NEWshorts; all8formal cohort tasks')
    tree = ast.parse((ROOT / 'coordinator.py').read_text())
    launcher = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == 'launch')
    with tempfile.TemporaryDirectory(prefix='gc1_local_deadline_') as tmp:
        path = Path(tmp); (path / 'logs').mkdir()
        for moments in ((2.,), (0., 2.)):
            ticks = iter(moments)
            invoked = []
            env = {'time': types.SimpleNamespace(monotonic=lambda: next(ticks)), 'started': 0., 'deadline': 1.,
                   'ROOT': path, 'subprocess': types.SimpleNamespace(Popen=lambda *a, **k: invoked.append(a)),
                   'active': {}, 'env': {}}
            exec(compile(ast.fix_missing_locations(ast.Module(body=[launcher], type_ignores=[])), 'actual_gc1_launch_AST', 'exec'), env)
            try: env['launch']({'id': str(len(moments)), 'command': ['NEVER_EXECUTE']})
            except RuntimeError as exc: assert 'deadline' in str(exc)
            else: raise AssertionError('Expired actual dispatch accepted')
            assert invoked == []
    checked.append('actual nested launch AST rejects elapsed deadline both before log and immediately before Popen; zero subprocess calls')
    pins = json.loads((ROOT / 'SAVED_INPUT_REFERENCES.json').read_text())
    assert [(r['seed'], r['update']) for r in pins['states']] == [(s, u) for s in range(21, 29) for u in (2, 101, 178)]
    assert len({r['path'] for r in pins['states']}) == 24 and all(len(r['sha256']) == 64 for r in pins['states'])
    comparisons = json.loads((ROOT / 'COMPARISON_REFERENCE.json').read_text())['rows']
    old_raw = json.loads(Path(pins['completed_CM2_RAW_NATIVE_local_path']).read_text())
    assert comparisons[:112] == old_raw['comparators']
    assert len({(r['method'], r['seed']) for r in comparisons}) == 120
    checked.append('complete24 actualhash states; original112 comparators equal and8uniqueCM2 appended with model/primary/source pins')
    assert 'torch' not in sys.modules
    result = {'state': 'passed', 'actual_stdlib_pid': os.getpid(), 'python': sys.version,
              'checks': checked, 'native_Torch_GPU_SSH_service_deployment_training_evaluation_calls': 0,
              'scientific_configuration_count': 1, 'native_results_pending': True}
    (ROOT / 'LOCAL_CHECKS.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
