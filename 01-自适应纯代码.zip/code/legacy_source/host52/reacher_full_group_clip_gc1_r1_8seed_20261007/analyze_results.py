"""Full-eight descriptive comparison; identical seed subsets across every declared method."""
import itertools
import math
from pathlib import Path
import statistics
from scipy import stats
from execution_contract import ROOT, SEEDS, BUDGET, read, write, sha, reference


def paired(a, b):
    delta = [x - y for x, y in zip(a, b)]
    mean, sd = statistics.mean(delta), statistics.stdev(delta)
    half = float(stats.t.ppf(.975, 7)) * sd / math.sqrt(8)
    test = stats.ttest_rel(a, b, alternative='two-sided') if sd else None
    sign_means = [abs(sum(s * x for s, x in zip(signs, delta)) / 8)
                  for signs in itertools.product((-1, 1), repeat=8)]
    return {'n': 8, 'df': 7, 'paired_differences': dict(zip(SEEDS, delta)),
            'mean_difference': mean, 'sample_sd_difference': sd, 'ci95': [mean - half, mean + half],
            'p_t_two_sided': float(test.pvalue) if sd else 1.,
            'constant_difference_t_unavailable': not bool(sd),
            'p_exact_sign_flip_two_sided': sum(v >= abs(mean) - 1e-12 for v in sign_means) / 256}


def holm(records, key):
    carry = 0.0
    for rank, record in enumerate(sorted(records, key=lambda r: r[key])):
        carry = max(carry, min(1., (len(records) - rank) * record[key]))
        record[key + '_holm30'] = carry


def main():
    controls = reference('COMPARISON_REFERENCE.json')['rows']
    base = {(r['method'], r['seed']): r for r in controls}
    methods = sorted({r['method'] for r in controls})
    assert len(base) == 120 and len(methods) == 15
    assert all(sorted(s for m, s in base if m == method) == list(SEEDS) for method in methods)
    ours = {}
    for seed in SEEDS:
        receipt = read(ROOT / 'receipts' / ('seed' + str(seed) + '_verify.json'))
        assert receipt['state'] == 'passed' and receipt['seed'] == seed and receipt['steps'] == BUDGET
        assert receipt['all_window_native_replay_exact'] and receipt['updates'] == 178
        for name, digest in receipt['artifact_hashes'].items():
            assert sha(Path(receipt['path']) / name) == digest
        ours[seed] = receipt
    all_values = [r[e] for r in [*ours.values(), *controls] for e in ('final_return', 'auc')]
    assert all(math.isfinite(v) for v in all_values)
    results, families = {}, []
    for method in methods:
        results[method] = {}
        for endpoint in ('final_return', 'auc'):
            a = [ours[s][endpoint] for s in SEEDS]
            b = [base[(method, s)][endpoint] for s in SEEDS]
            record = paired(a, b)
            record.update(ours_mean=statistics.mean(a), ours_sample_sd=statistics.stdev(a),
                          comparator_mean=statistics.mean(b), comparator_sample_sd=statistics.stdev(b))
            results[method][endpoint] = record
            families.append(record)
    holm(families, 'p_t_two_sided')
    holm(families, 'p_exact_sign_flip_two_sided')
    required = ['fixed95', 'accepted_trp1', 'accepted_i2_r4', 'critic_aware',
                'gradient_ppo', 'reward_profiling', 'pae']
    subsets = {}
    for size in (3, 5):
        passing, all_subsets = [], []
        for seeds in itertools.combinations(SEEDS, size):
            means = {endpoint: {'FullGC1': statistics.mean(ours[s][endpoint] for s in seeds),
                               **{m: statistics.mean(base[(m, s)][endpoint] for s in seeds) for m in required}}
                     for endpoint in ('final_return', 'auc')}
            passes = all(v['fixed95'] < v['accepted_trp1'] < v['FullGC1']
                   and v['fixed95'] < v['accepted_i2_r4'] < v['FullGC1']
                   and all(v['FullGC1'] > v[m] for m in ('critic_aware', 'gradient_ppo', 'reward_profiling', 'pae'))
                   for v in means.values())
            all_subsets.append({'seeds': seeds, 'means': means, 'joint_order_pass': passes})
            if passes:
                passing.append({'seeds': seeds, 'means': means})
        subsets[str(size)] = {'enumerated': 56, 'passing_count': len(passing), 'passing_subsets': passing, 'all_subsets': all_subsets}
    write(ROOT / 'ANALYSIS.json', {'state': 'completed', 'candidate': 'Reacher FullGC1 native disjoint group clip r1',
          'seeds': SEEDS, 'rows': [ours[s] for s in SEEDS], 'comparisons': results,
          'complete_eight_mean_both_above_every_comparator': all(r['ours_mean'] > r['comparator_mean'] for r in families),
          'common_joint_order_subsets': subsets,
          'joint_order_descriptive_pass': any(v['passing_count'] for v in subsets.values()),
          'all_unique_comparators': methods, 'preserved_historical_rows': 120,
          'multiple_testing': 'Two separate Holm30 families: t and exact sign flips',
          'inference': 'Reused development seeds; retrospective subsets are descriptive, not independent confirmation',
          'baseline_or_standalone_reruns': 0, 'score_mixing_or_alias_duplication': False,
          'next_action': 'parent_terminal_verification_and_mechanism_review', 'automatic_next_candidate': False,
          'old_standalone_recipes_are_historical_comparators_not_matching_GC1_ablations': True})


if __name__ == '__main__':
    main()
