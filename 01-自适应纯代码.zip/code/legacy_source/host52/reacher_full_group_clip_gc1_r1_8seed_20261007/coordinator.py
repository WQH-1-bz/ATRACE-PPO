"""Three explicitly gated phases with managed helper children; parent process never imports CUDA/Torch."""
import argparse
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback
from execution_contract import (ROOT, NATIVE_ROOT, PREFIX_ROOT, PYTHON, GPU_UUID, SEEDS, SHORT, bundle,
                                command, environment, read, write, sha, protected, prefix_reference)

GIB = 1024 ** 3


def rss(pid):
    try:
        values = dict(line.split(':', 1) for line in (Path('/proc') / str(pid) / 'status').read_text().splitlines() if ':' in line)
        return int(values['VmRSS'].split()[0]) * 1024, int(values['VmHWM'].split()[0]) * 1024
    except (FileNotFoundError, KeyError, ProcessLookupError):
        return 0, 0


def resources():
    def output(args):
        return subprocess.check_output(args, text=True, timeout=15).strip().splitlines()
    rows = output(['nvidia-smi', '-i', '1', '--query-gpu=uuid,memory.free', '--format=csv,noheader,nounits'])
    assert len(rows) == 1
    identity, free = (v.strip() for v in rows[0].split(','))
    assert identity == GPU_UUID
    processes = {}
    for line in output(['nvidia-smi', '-i', '1', '--query-compute-apps=gpu_uuid,pid,used_gpu_memory', '--format=csv,noheader,nounits']):
        parts = [v.strip() for v in line.split(',')]
        assert len(parts) == 3 and parts[0] == GPU_UUID
        processes[int(parts[1])] = int(parts[2])
    memory = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
    return {'gpu_free_mib': int(free), 'gpu_process_mib': processes,
            'host_available_bytes': int(memory['MemAvailable'].split()[0]) * 1024,
            'disk_free_bytes': shutil.disk_usage(ROOT).free}


def validate_owner(phase):
    bundle()
    prepared = read(ROOT / 'NATIVE_PREPARED.json')
    marker = read(ROOT / (phase.upper() + '_EXECUTION_READY.json'))
    digest = sha(ROOT / 'SOURCE_MANIFEST.json')
    assert prepared['state'] == 'passed' and prepared['manifest_sha256'] == digest
    assert marker['manifest_sha256'] == digest and marker['phase'] == phase
    review = read(ROOT / 'INDEPENDENT_REVIEW.json')
    assert review['review_passed'] is True and review['manifest_sha256'] == digest
    assert marker['review_sha256'] == sha(ROOT / 'INDEPENDENT_REVIEW.json')
    assert marker['luna_state'] == 'ACTIVE' and marker['luna_goal_id'] and marker['luna_agent_id']
    assert marker['initial_snapshot_sha256'] == sha(ROOT / marker['initial_snapshot_file'])
    assert marker['same_parent_wake_validated'] is True
    assert marker['new_GC1_source'] is True
    if phase in ('short', 'formal'):
        saved = read(ROOT / 'SAVED_DATA_ADMISSION.json')
        assert saved['state'] == 'passed' and saved['strict_scientific_AB'] and saved['states'] == 24
        assert saved['native_Adam_engineering_calls'] == 96 and saved['changed_states'] > 0
        root_saved = read(ROOT / 'ROOT_SAVED_MECHANISM_ADMISSION.json')
        assert root_saved['state'] == 'passed' and root_saved['manifest_sha256'] == digest
        assert root_saved['saved_data_admission_sha256'] == sha(ROOT / 'SAVED_DATA_ADMISSION.json')
        assert root_saved['complete24_effects_interpreted'] is True
        assert root_saved['Adam_scale_adaptation_considered'] is True
        assert root_saved['effect_interpretation'] and root_saved['short_launch_admitted'] is True
        assert marker['root_saved_mechanism_admission_sha256'] == sha(ROOT / 'ROOT_SAVED_MECHANISM_ADMISSION.json')
        assert marker['luna_goal_id'] != read(ROOT / 'SAVED_EXECUTION_READY.json')['luna_goal_id']
    if phase == 'short':
        assert marker['new_complete_short_A_and_B'] is True
        assert read(ROOT / 'SAVED_SUITE_STATUS.json')['state'] == 'saved_audits_completed_awaiting_root_mechanism_admission'
    if phase == 'formal':
        admission = read(ROOT / 'SHORT_ADMISSION.json')
        assert admission['state'] == 'passed'
        assert marker['short_admission_sha256'] == sha(ROOT / 'SHORT_ADMISSION.json')
        assert marker['luna_goal_id'] != read(ROOT / 'SHORT_EXECUTION_READY.json')['luna_goal_id']
        assert marker['saved_data_admission_sha256'] == sha(ROOT / 'SAVED_DATA_ADMISSION.json')
        acceptance = read(ROOT / 'ROOT_SHORT_ACCEPTANCE.json')
        assert acceptance['state'] == 'passed' and acceptance['manifest_sha256'] == digest
        assert acceptance['short_admission_sha256'] == sha(ROOT / 'SHORT_ADMISSION.json')
        assert acceptance['short_resources_sha256'] == sha(ROOT / 'SHORT_RESOURCES.json')
        assert acceptance['all_actual_children_exit0'] is True
        assert marker['root_short_acceptance_sha256'] == sha(ROOT / 'ROOT_SHORT_ACCEPTANCE.json')
        assert marker['short_resources_sha256'] == sha(ROOT / 'SHORT_RESOURCES.json')
    return marker


def job(ident, kind, argv, dependencies=(), path=None, receipt=None):
    return {'id': ident, 'kind': kind, 'command': argv, 'dependencies': list(dependencies),
            'path': str(path) if path else None, 'receipt': str(receipt) if receipt else None,
            'state': 'pending', 'peak_gpu_mib': 0, 'peak_host_rss_bytes': 0,
            'started_monotonic': None, 'exit_code': None}


def tasks(phase):
    receipts = ROOT / 'receipts'
    if phase == 'saved':
        result = []
        for tag, dependencies in (('a', []), ('b', ['saved_a'])):
            receipt = receipts / ('saved_' + tag + '.json')
            result.append(job('saved_' + tag, 'helper', [PYTHON, str(ROOT / 'native_saved_checks.py'),
                '--tag', tag, '--receipt', str(receipt)], dependencies, receipt=receipt))
        receipt = ROOT / 'SAVED_DATA_ADMISSION.json'
        result.append(job('saved_compare', 'cpu_helper', [PYTHON, str(ROOT / 'native_saved_checks.py'),
            '--compare', str(receipts / 'saved_a.json'), str(receipts / 'saved_b.json'),
            '--receipt', str(receipt)], ['saved_b'], receipt=receipt))
        return result
    if phase == 'short':
        first, second = ROOT / 'runs/short_a', ROOT / 'runs/short_b'
        result = []
        for suffix, path, dependencies in (('short_a', first, []),
                                            ('short_b', second, ['short_a_verify'])):
            result.append(job(suffix, 'training', command(path, 91081, True), dependencies, path))
            result.append(job(suffix + '_stress', 'helper', [PYTHON, str(ROOT / 'stress_full.py'),
                              '--job', str(path), '--device', 'cuda:1'], [suffix], path))
            receipt = receipts / (suffix + '_verify.json')
            result.append(job(suffix + '_verify', 'helper', [PYTHON, str(ROOT / 'native_verify.py'),
                              '--job', str(path), '--seed', '91081', '--short', '--receipt', str(receipt)],
                              [suffix + '_stress'], path, receipt))
        result.append(job('short_admission', 'cpu_helper', [PYTHON, str(ROOT / 'native_verify.py'),
                          '--admit', str(PREFIX_ROOT), str(first), str(second),
                          '--receipt', str(ROOT / 'SHORT_ADMISSION.json')],
                          ['short_a_verify', 'short_b_verify'], receipt=ROOT / 'SHORT_ADMISSION.json'))
        return result
    result = []
    for seed in SEEDS:
        ident = 'seed' + str(seed)
        path = ROOT / 'runs' / ('Reacher__fullgc1__' + ident)
        result.append(job(ident, 'training', command(path, seed), path=path))
        result.append(job(ident + '_stress', 'helper', [PYTHON, str(ROOT / 'stress_full.py'),
                          '--job', str(path), '--device', 'cuda:1'], [ident], path))
        receipt = receipts / (ident + '_verify.json')
        result.append(job(ident + '_verify', 'helper', [PYTHON, str(ROOT / 'native_verify.py'),
                          '--job', str(path), '--seed', str(seed), '--receipt', str(receipt)],
                          [ident + '_stress'], path, receipt))
    result.append(job('terminal_analysis', 'cpu_helper', [PYTHON, str(ROOT / 'analyze_results.py')],
                      ['seed' + str(s) + '_verify' for s in SEEDS], receipt=ROOT / 'ANALYSIS.json'))
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=('saved', 'short', 'formal'), required=True)
    args = parser.parse_args()
    assert ROOT == NATIVE_ROOT
    assert not (ROOT / (args.phase.upper() + '_SUITE_STATUS.json')).exists(), 'No hidden repeat or automatic resume'
    env = environment()
    owner = validate_owner(args.phase)
    before = protected()
    for name in ('receipts', 'logs'):
        (ROOT / name).mkdir(exist_ok=True)
    jobs = tasks(args.phase)
    assert all(not Path(j['path']).exists() for j in jobs if j['kind'] == 'training')
    active, failure = {}, None
    started = time.monotonic()
    deadline = {'saved': 2 * 3600, 'short': 4 * 3600, 'formal': 24 * 3600}[args.phase]
    if args.phase == 'formal':
        measured = read(ROOT / 'SHORT_RESOURCES.json')
        assert measured['state'] == 'passed'
        reservation = measured['gpu_reservation_mib']
        host_reservation = measured['host_reservation_bytes']
        output_reservation = measured['formal_output_reservation_bytes_per_seed']
        assert all(type(v) in (int, float) and math.isfinite(v) and v > 0 for v in
                   (reservation, host_reservation, output_reservation))
        assert measured['training_peak_driver_mib'] > 0 and measured['managed_helper_peak_driver_mib'] > 0
        assert measured['actual_group_observer_payload_serialized_bytes_per_short'] > 0
    else:
        reservation, host_reservation, output_reservation = 3500, 3 * GIB, 3 * GIB

    def status(state):
        write(ROOT / (args.phase.upper() + '_SUITE_STATUS.json'), {
            'state': state, 'phase': args.phase, 'coordinator_pid': os.getpid(), 'gpu': 1,
            'gpu_uuid': GPU_UUID, 'luna_goal_id': owner['luna_goal_id'], 'jobs': jobs,
            'active': {name: {'pid': process.pid, 'kind': j['kind'], 'state': 'running_or_initializing'}
                       for name, (process, stream, j) in active.items()}, 'failure': failure,
            'elapsed_seconds': time.monotonic() - started, 'gpu_reservation_mib': reservation,
            'host_reservation_bytes': host_reservation, 'formal_output_reservation_bytes_per_seed': output_reservation,
            'completed_training_count': sum(j['kind'] == 'training' and j['state'] == 'completed' for j in jobs),
            'new_GC1_short_trajectory_count': 2 if args.phase == 'short' else 0,
            'old_CM1_A_reused_as_GC1_trajectory': False, 'immutable_prefix_reference': str(PREFIX_ROOT)})

    def launch(j):
        if time.monotonic() - started >= deadline:
            raise RuntimeError('Phase deadline reached before Popen; no new child')
        log = ROOT / 'logs' / (j['id'] + '.log')
        stream = log.open('x')
        try:
            if time.monotonic() - started >= deadline:
                raise RuntimeError('Phase deadline reached immediately before Popen')
            process = subprocess.Popen(j['command'], cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
        except BaseException:
            stream.close()
            raise
        j.update(state='running', pid=process.pid, started_monotonic=time.monotonic(), log=str(log))
        # Immediately reserve initializing children before looking at any current driver usage.
        active[j['id']] = (process, stream, j)

    def reap(snapshot=None):
        """The same drain is used around blocking resource queries and directly before dispatch."""
        nonlocal failure
        changed = False
        for ident, (process, stream, j) in list(active.items()):
            current_rss, peak_rss = rss(process.pid)
            j['peak_host_rss_bytes'] = max(j['peak_host_rss_bytes'], peak_rss)
            if snapshot is not None:
                j['peak_gpu_mib'] = max(j['peak_gpu_mib'], snapshot['gpu_process_mib'].get(process.pid, 0))
            code = process.poll()
            if code is None:
                continue
            stream.close()
            del active[ident]
            changed = True
            j['exit_code'] = code
            j['finished_monotonic'] = time.monotonic()
            j['state'] = 'completed' if code == 0 else 'failed'
            if code == 0 and j['receipt']:
                receipt = read(j['receipt'])
                assert receipt['state'] == ('completed' if ident == 'terminal_analysis' else 'passed')
                j['receipt_sha256'] = sha(j['receipt'])
            if code != 0 and failure is None:
                failure = {'id': ident, 'exit_code': code, 'log': j['log'], 'automatic_retry': False}
        return changed

    def snapshot_and_reap():
        reap()
        snapshot = resources()
        reap(snapshot)
        return snapshot

    status('queued')
    try:
        while True:
            snapshot = snapshot_and_reap()
            if failure:
                status('failed_active_children_preserved' if active else 'failed')
                if not active:
                    return 1
            elif all(j['state'] == 'completed' for j in jobs):
                bundle()
                after = protected()
                assert before == after
                if args.phase == 'saved':
                    assert len(jobs) == 3 and all(j['exit_code'] == 0 for j in jobs)
                    status('saved_audits_completed_awaiting_root_mechanism_admission')
                elif args.phase == 'short':
                    train = [j for j in jobs if j['kind'] == 'training']
                    helpers = [j for j in jobs if j['kind'] == 'helper']
                    assert len(train) == 2 and all(j['exit_code'] == 0 for j in jobs)
                    train_peak = max(j['peak_gpu_mib'] for j in train)
                    helper_peak = max(j['peak_gpu_mib'] for j in helpers)
                    host_peak = max(j['peak_host_rss_bytes'] for j in jobs)
                    assert train_peak > 0 and helper_peak > 0 and host_peak > 0
                    size = max(sum(p.stat().st_size for p in path.rglob('*') if p.is_file())
                               for path in (ROOT / 'runs/short_a', ROOT / 'runs/short_b'))
                    write(ROOT / 'SHORT_RESOURCES.json', {'state': 'passed', 'training_peak_driver_mib': train_peak,
                          'managed_helper_peak_driver_mib': helper_peak, 'all_process_host_HWM_peak_bytes': host_peak,
                          'short_output_bytes': size, 'gpu_reservation_mib': max(3500, train_peak + 512, helper_peak + 512),
                          'host_reservation_bytes': max(GIB, host_peak + 256 * 1024 ** 2),
                          'formal_output_reservation_bytes_per_seed': max(3 * GIB, math.ceil(size * 178 / 9) + 512 * 1024 ** 2),
                          'includes_constant_and_group_gradient_observer_copy_and_serialization_cost': True,
                          'constant_and_group_observer_short_audit_bytes': max(sum(p.stat().st_size for p in path.glob('constant_mode_audits/*.pt')) for path in (ROOT / 'runs/short_a', ROOT / 'runs/short_b')),
                          'actual_group_observer_payload_serialized_bytes_per_short': max(read(ROOT / 'receipts' / (tag + '_verify.json'))['actual_observer_payload_serialized_bytes'] for tag in ('short_a', 'short_b')),
                          'observer_specific_estimated_tensor_bytes_per_window': read(ROOT / 'OBSERVER_STORAGE_PLAN.json')['gradient_tensor_bytes_per_window'],
                          'observer_bytes_are_budgeted_without_fake_driver_measurements': True,
                          'only_actual_new_GC1_short_training_helper_peaks': True,
                          'new_complete_training_children': 2, 'all_actual_child_exits': [j['exit_code'] for j in jobs],
                          'sampling_seconds': 2, 'driver_peak_is_sampled_lower_bound': True})
                    status('short_admitted_waiting_for_new_formal_luna_and_root_marker')
                else:
                    status('completed')
                return 0
            else:
                if time.monotonic() - started > deadline:
                    failure = {'id': 'phase_deadline', 'seconds': deadline, 'active_children_preserved': True}
                    continue
                lookup = {j['id']: j for j in jobs}
                ready = [j for j in jobs if j['state'] == 'pending'
                         and all(lookup[d]['state'] == 'completed' for d in j['dependencies'])]
                ready.sort(key=lambda j: j['kind'] == 'training')
                limit = 8 if args.phase == 'formal' else 1
                for j in ready:
                    if len(active) >= limit:
                        break
                    snapshot = snapshot_and_reap()
                    if failure:
                        break
                    outstanding_gpu = sum(max(0, reservation - snapshot['gpu_process_mib'].get(p.pid, 0))
                                          for p, _, child in active.values() if child['kind'] != 'cpu_helper')
                    outstanding_host = sum(max(0, host_reservation - rss(p.pid)[0]) for p, _, _ in active.values())
                    remaining_training = sum(child['kind'] == 'training' and child['state'] != 'completed' for child in jobs)
                    required_disk = remaining_training * output_reservation + 4 * GIB
                    if snapshot['host_available_bytes'] - outstanding_host < host_reservation + GIB:
                        break
                    if snapshot['disk_free_bytes'] < required_disk:
                        break
                    if j['kind'] != 'cpu_helper' and snapshot['gpu_free_mib'] - outstanding_gpu < reservation + 512:
                        break
                    # Exits during CPU/disk admission arithmetic also stop new dispatch.
                    if reap():
                        break  # Refresh resource/eligibility evidence next loop.
                    if failure:
                        break
                    launch(j)
                status('running' if active else 'waiting_for_measured_resource_headroom')
            time.sleep(2)
    except BaseException as exc:
        failure = {'id': 'coordinator', 'error': repr(exc), 'traceback': traceback.format_exc(),
                   'active_children_preserved': True}
        status('failed_active_children_preserved' if active else 'failed')
        raise


if __name__ == '__main__':
    sys.dont_write_bytecode = True
    sys.exit(main())
