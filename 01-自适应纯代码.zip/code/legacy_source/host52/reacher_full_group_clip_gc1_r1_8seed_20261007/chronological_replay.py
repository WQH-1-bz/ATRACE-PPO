"""Source-faithful saved-window target chronology, proven in the isolated native diagnostic."""
import ast
import sys
import types

LABELS = ('actor_advantage', 'actor_return', 'fixed95_critic_return', 'original_actor_advantage',
          'calibration_only_actor_delta', 'same_calibrated_values_actor_trace_delta',
          'original_values_fixed95_critic_trace_delta')


def primitive_namespace(torch, source):
    """Only the exact two recurrence definitions and literal Full1 target function are compiled."""
    name = 'saved_cm2_cold_primitives'
    assert name not in sys.modules, 'One fresh compiled namespace per complete chronological run'
    namespace = types.ModuleType(name)
    namespace.torch = torch
    sys.modules[name] = namespace
    for filename, names in [('train_noisy_warp.py', ['gae']),
                            ('train_pae_baseline.py', ['capped_tail_trace', 'full_targets'])]:
        path = source / filename
        nodes = [n for n in ast.parse(path.read_text()).body if isinstance(n, ast.FunctionDef) and n.name in names]
        assert [n.name for n in nodes] == names
        exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), str(path), 'exec'), namespace.__dict__)
    return namespace


def training_labels(torch, namespace, helper, xs, weights, actor_lambda, offsets):
    # Exact chronological source calls, including the extra original-label full_targets call.
    a, ret, actor_delta, critic_delta, actor_return = helper.full_constant_targets(
        torch, namespace.full_targets, namespace.gae, namespace.capped_tail_trace,
        *xs, weights, actor_lambda, offsets)
    if helper.zero_offsets(offsets):
        original_a = a
    else:
        original_a, _, _, _, _ = namespace.full_targets(*xs, weights, actor_lambda)
    return dict(zip(LABELS, (a, actor_return, ret, original_a, a - original_a, actor_delta, critic_delta)))
