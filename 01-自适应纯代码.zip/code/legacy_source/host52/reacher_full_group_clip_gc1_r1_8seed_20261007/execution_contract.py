"""Shared stdlib launch contract; importing this file never launches or imports native code."""
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
NATIVE_ROOT = Path('/home/mumu01/ssd3/wch/reacher_full_group_clip_gc1_r1_8seed_20261007')
PREFIX_ROOT = Path('/home/mumu01/ssd3/wch/reacher_full_practical_adjustment_r1_8seed_20261007/runs/old_full1_prefix')
PYTHON = '/home/mumu01/ssd3/wch/reacher_update_capture_8seed_20261004/.venv/bin/python'
GPU_UUID = 'GPU-0fbea1d5-c9c9-392e-5241-f31b8aec2518'
SEEDS = tuple(range(21, 29))
BUDGET, SHORT, SWITCH, SHORT_SWITCH = 10027008, 524288, 4980736, 262144
DET = {'torch': True, 'warp': 'run_to_run', 'warp_max_records': 8,
       'cublas_workspace_config': ':4096:8'}


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    path = Path(path)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temp.replace(path)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def environment():
    # A device mask would change the physical cuda:1 identity. Reject inherited masks.
    if 'CUDA_VISIBLE_DEVICES' in os.environ or 'NVIDIA_VISIBLE_DEVICES' in os.environ:
        raise RuntimeError('CUDA device masking is forbidden')
    return {**os.environ, 'PYTHONUNBUFFERED': '1', 'PYTHONDONTWRITEBYTECODE': '1',
            'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1',
            'DPO_TORCH_DETERMINISTIC': '1', 'DPO_WARP_DETERMINISTIC': 'run_to_run',
            'DPO_WARP_DETERMINISTIC_MAX_RECORDS': '8', 'CUBLAS_WORKSPACE_CONFIG': ':4096:8',
            'DPO_PPO_GRAPH': '0', 'XDG_CACHE_HOME': str(ROOT / 'cache'),
            'WARP_CACHE_PATH': str(ROOT / 'cache/warp'), 'CUDA_CACHE_PATH': str(ROOT / 'cache/cuda'),
            'TORCH_HOME': str(ROOT / 'cache/torch'), 'TMPDIR': str(ROOT / 'tmp')}


def command(path, seed, short=False):
    if type(seed) is not int or (short and seed != 91081) or (not short and seed not in SEEDS):
        raise RuntimeError('Seed outside frozen complete cohort/short contract')
    budget, cutoff = (SHORT, SHORT_SWITCH) if short else (BUDGET, SWITCH)
    source = 'source_full'
    return [PYTHON, str(ROOT / source / 'train_pae_baseline.py'), '--out', str(path),
            '--method', 'pae', '--task', 'Reacher', '--seed', str(seed), '--device', 'cuda:1',
            '--steps', str(budget), '--num-envs', '1024', '--rollout', '64',
            '--batch-size', '1024', '--eval-envs', '32', '--eval-every', '262144',
            '--staged-full', '--stage-switch-steps', str(cutoff), '--overlap-start-steps', '0',
            '--overlap-stop-steps', str(budget), '--retained-tail-steps', '16',
            '--retained-tail-correction', '--retained-tail-diagnostics']


def schedule(short=False):
    """Independent direct-once transition ledger, including the stage boundary flush."""
    total, cutoff = (SHORT, SHORT_SWITCH) if short else (BUDGET, SWITCH)
    collected = retained = direct = 0
    rows = []
    while collected < total:
        overlap = collected < cutoff
        fresh = min(64 - retained, (total - collected) // 1024)
        if overlap:
            fresh = min(fresh, (cutoff - collected) // 1024)
        end = retained + fresh
        steps = collected + fresh * 1024
        flush = overlap and steps == cutoff
        used = end if flush or not overlap or steps == total else min(48, end)
        start, stop = collected // 1024, steps // 1024
        assert start - retained == direct
        direct += used
        rows.append({'update': len(rows) + 1, 'steps': steps, 'prior_collected_steps': collected,
                     'fresh_per_world': fresh, 'used_per_world': used,
                     'incoming_retained_per_world': retained, 'retained_per_world': end - used,
                     'overlap_active': overlap, 'stage_boundary_flush': bool(flush),
                     'fresh_start_per_world': start, 'fresh_end_per_world': stop,
                     'window_start_per_world': start - retained, 'window_end_per_world': stop,
                     'training_return_count': (stop // 50 - start // 50) * 1024})
        retained, collected = end - used, steps
    assert total == collected == direct * 1024 and retained == 0
    assert len(rows) == (9 if short else 178)
    assert sum(r['overlap_active'] for r in rows) == (5 if short else 101)
    assert sum(r['used_per_world'] for r in rows) * 10 == (5120 if short else 97920)
    assert sum(r['stage_boundary_flush'] for r in rows) == 1
    return rows


def bundle():
    manifest = read(ROOT / 'SOURCE_MANIFEST.json')
    for name, digest in manifest['files'].items():
        path = ROOT / name
        if sha(path) != digest or path.stat().st_mode & 0o222:
            raise RuntimeError('Frozen source changed or writable: ' + name)
    actual = {str(p.relative_to(ROOT)) for d in ('source_full', 'references')
              for p in (ROOT / d).rglob('*') if p.is_file()}
    expected = {n for n in manifest['files'] if n.startswith(('source_full/', 'references/'))}
    if actual != expected:
        raise RuntimeError('Unexpected/missing frozen source file')
    return manifest



def reference(name):
    if name == 'COMPARISON_REFERENCE.json':
        return read(ROOT / name)
    binding = read(ROOT / 'INHERITED_REFERENCES.json')['references'][name]
    path = Path(binding['native_path'] if ROOT == NATIVE_ROOT else binding['local_path'])
    if sha(path) != binding['sha256']:
        raise RuntimeError('Immutable referenced evidence changed: ' + str(path))
    return read(path)


def prefix_reference():
    """Only the immutable zero-offset reference; old CM1 A is never a CM2 trajectory."""
    binding = read(ROOT / 'IMMUTABLE_PREFIX_REFERENCE.json')
    assert binding['path'] == str(PREFIX_ROOT) and binding['CM1_short_A_reuse'] is False
    assert binding['root_prefix_exit'] == {'pid': 2840570, 'exit_code': 0, 'state': 'completed'}
    assert len(binding['files']) == binding['file_count'] == 11
    actual = {str(p) for p in PREFIX_ROOT.rglob('*') if p.is_file()}
    assert actual == set(binding['files'])
    for filename, digest in binding['files'].items():
        path = Path(filename)
        assert path.is_relative_to(PREFIX_ROOT) and sha(path) == digest
        stat = path.stat()
        assert {'bytes': stat.st_size, 'mtime_ns': stat.st_mtime_ns,
                'mode': oct(stat.st_mode & 0o777)} == binding['metadata'][filename]
    return {'state': 'passed', 'prefix_files': len(actual), 'prefix_training_reruns': 0,
            'old_CM1_A_trajectory_reused': False,
            'reference_validity_requires_native_zero_window_exact_control': True}


def protected():
    pins = reference('INPUT_PINS.json')
    assert len(pins['files']) == pins['known_total'] == 25097
    expected = dict(pins['files'])
    comparisons = reference('COMPARISON_REFERENCE.json')['rows']
    for row in comparisons:
        for name, digest in row['artifact_hashes'].items():
            filename = str(Path(row['path']) / name)
            if filename in expected: assert expected[filename] == digest
            expected[filename] = digest
        if 'source_identity' not in row:
            assert row['method'] == 'accepted_full_v4'
            manifest = reference('references/full4_launch_manifest.json')
            source = Path(row['path']).parents[1] / 'source_full'
            for name, digest in manifest['source_hashes'].items(): expected[str(source / name)] = digest
        else:
            identity = row['source_identity']
            for name, digest in identity['frozen_manifest_source_hashes'].items():
                filename = str(Path(identity['source_path']) / name)
                if filename in expected: assert expected[filename] == digest
                expected[filename] = digest
            expected[identity['source_manifest_path']] = identity['source_manifest_sha256']
    native_base = Path(read(ROOT / 'INHERITED_REFERENCES.json')['references']['SOURCE_MANIFEST.json']['native_path']).parent
    for name, digest in reference('SOURCE_MANIFEST.json')['files'].items():
        expected[str(native_base / name)] = digest
    cm2_binding = read(ROOT / 'INHERITED_REFERENCES.json')['references']['CM2_SOURCE_MANIFEST.json']
    cm2_root = Path(cm2_binding['native_path']).parent
    expected[cm2_binding['native_path']] = cm2_binding['sha256']
    for name, digest in reference('CM2_SOURCE_MANIFEST.json')['files'].items():
        expected[str(cm2_root / name)] = digest
    for filename, digest in expected.items():
        if sha(filename) != digest: raise RuntimeError('Protected historical source/input changed: ' + filename)
    for filename, digest in reference('NATIVE_RUNTIME_PINS.json')['files'].items():
        if sha(filename) != digest: raise RuntimeError('Pinned existing runtime changed: ' + filename)
    for filename, digest in reference('EXISTING_NATIVE_METADATA.json')['existing_files'].items():
        if sha(filename) != digest: raise RuntimeError('Pinned native metadata changed: ' + filename)
    return {'state': 'passed', 'inherited_protected_count': 25097,
            'protected_with_comparator_and_frozen_r2_source_count': len(expected),
            'comparators': len(comparisons), 'historical_CM2_source_and_all8_artifacts_pinned': True, 'immutable_first_window_reference': prefix_reference()}
