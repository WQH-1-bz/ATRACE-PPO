"""Native file-only preflight. No scientific/GPU imports, package installs or cache copies."""
import ast
import hashlib
import importlib.metadata
import os
from pathlib import Path
import subprocess
import sys
from execution_contract import ROOT, NATIVE_ROOT, PYTHON, GPU_UUID, bundle, environment, read, sha, write, protected, reference


def main():
    assert ROOT == NATIVE_ROOT, 'Native preflight belongs only on host52 SSD output root'
    environment()
    review = read(ROOT / 'INDEPENDENT_REVIEW.json')
    marker = read(ROOT / 'SAVED_EXECUTION_READY.json')
    digest = sha(ROOT / 'SOURCE_MANIFEST.json')
    assert review['review_passed'] is True and review['manifest_sha256'] == digest
    assert marker['manifest_sha256'] == digest and marker['phase'] == 'saved'
    assert marker['review_sha256'] == sha(ROOT / 'INDEPENDENT_REVIEW.json')
    assert marker['luna_state'] == 'ACTIVE' and marker['luna_agent_id'] and marker['luna_goal_id']
    assert marker['same_parent_wake_validated'] is True
    assert marker['initial_snapshot_sha256'] == sha(ROOT / marker['initial_snapshot_file'])
    manifest = bundle()
    assert Path(sys.executable).resolve() == Path(PYTHON).resolve(), 'Use existing pinned native Python'
    pins = reference('NATIVE_RUNTIME_PINS.json')
    assert sys.version == pins['python']
    versions = {name: importlib.metadata.version(name) for name in pins['versions']}
    assert versions == pins['versions']
    # Read-only management query, only physical GPU1; it does not create a CUDA context.
    gpu = subprocess.check_output(['nvidia-smi', '-i', '1', '--query-gpu=uuid',
                                   '--format=csv,noheader'], text=True, timeout=15).strip()
    assert gpu == GPU_UUID, 'Wrong host or physical GPU1 identity'
    proof = protected()
    metadata = reference('EXISTING_NATIVE_METADATA.json')
    for path, digest in metadata['existing_files'].items():
        assert sha(path) == digest
    source = Path(metadata['original_source_path'])
    assert sha(source) == metadata['original_source_sha256']
    for name, digest in metadata['original_native_AST_hashes'].items():
        node = next(n for n in ast.parse(source.read_text()).body
                    if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name == name)
        assert hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest() == digest
    for name in ('runs', 'tmp', 'cache'):
        (ROOT / name).mkdir(exist_ok=False)
    write(ROOT / 'NATIVE_PREPARED.json', {'state': 'passed', 'manifest_sha256': sha(ROOT / 'SOURCE_MANIFEST.json'),
          'versions': versions, 'python': sys.version, 'gpu': 1, 'gpu_uuid': gpu,
          'packages_installed': 0, 'scientific_imports': 0, 'GPU_contexts_created': 0,
          'existing_runtime_reused': True, **proof})
    print('Native file-only preflight passed; execution still requires parent review and active Luna handoff.')


if __name__ == '__main__':
    sys.dont_write_bytecode = True
    main()
