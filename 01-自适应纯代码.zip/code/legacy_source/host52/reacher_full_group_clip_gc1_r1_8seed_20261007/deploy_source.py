"""Root-owned deployment of exact reviewed source only; never part of source preparation."""
import argparse
import io
import json
from pathlib import Path
import shlex
import subprocess
import tarfile
import time
from execution_contract import ROOT, NATIVE_ROOT, PYTHON, bundle, read, sha, write

HOST = 'wch@192.168.5.52'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--review', type=Path, required=True)
    parser.add_argument('--handoff', type=Path, required=True)
    parser.add_argument('--snapshot', type=Path, required=True)
    args = parser.parse_args()
    assert ROOT != NATIVE_ROOT
    manifest = bundle()
    digest = sha(ROOT / 'SOURCE_MANIFEST.json')
    review, handoff = read(args.review), read(args.handoff)
    assert review['review_passed'] is True and review['manifest_sha256'] == digest
    assert handoff['manifest_sha256'] == digest and handoff['phase'] == 'saved'
    assert handoff['review_sha256'] == sha(args.review)
    assert handoff['luna_state'] == 'ACTIVE' and handoff['luna_goal_id'] and handoff['luna_agent_id']
    assert handoff['same_parent_wake_validated'] is True
    assert handoff['new_GC1_source'] is True
    assert handoff['new_saved_mechanism_phase'] is True
    assert handoff['initial_snapshot_file'] == 'SAVED_INITIAL_SNAPSHOT.json'
    assert handoff['initial_snapshot_sha256'] == sha(args.snapshot)
    stream = io.BytesIO()
    with tarfile.open(fileobj=stream, mode='w') as archive:
        for name in [*manifest['files'], 'SOURCE_MANIFEST.json']:
            archive.add(ROOT / name, arcname=name, recursive=False)
        for name, path in [('INDEPENDENT_REVIEW.json', args.review),
                           ('SAVED_EXECUTION_READY.json', args.handoff),
                           ('SAVED_INITIAL_SNAPSHOT.json', args.snapshot)]:
            archive.add(path, arcname=name, recursive=False)
    remote = """import hashlib, io, json, pathlib, sys, tarfile
root = pathlib.Path(sys.argv[1])
payload = sys.stdin.buffer.read()
with tarfile.open(fileobj=io.BytesIO(payload), mode='r:') as archive:
    manifest = json.loads(archive.extractfile('SOURCE_MANIFEST.json').read())
    expected = set(manifest['files']) | {'SOURCE_MANIFEST.json', 'INDEPENDENT_REVIEW.json', 'SAVED_EXECUTION_READY.json', 'SAVED_INITIAL_SNAPSHOT.json'}
    names = [member.name for member in archive.getmembers()]
    assert set(names) == expected and len(names) == len(expected)
    assert all(member.isfile() and not member.name.startswith('/') and '..' not in pathlib.PurePosixPath(member.name).parts for member in archive.getmembers())
    root.mkdir(parents=False, exist_ok=False)
    for member in archive.getmembers():
        data = archive.extractfile(member).read()
        if member.name in manifest['files']:
            assert hashlib.sha256(data).hexdigest() == manifest['files'][member.name]
        path = root / member.name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as output: output.write(data)
        path.chmod(0o444)
print(json.dumps({'state': 'exact_reviewed_source_deployed', 'native_root': str(root), 'source_files': len(manifest['files']), 'source_manifest_sha256': hashlib.sha256((root / 'SOURCE_MANIFEST.json').read_bytes()).hexdigest(), 'Torch_GPU_training_evaluation_calls': 0}))
"""
    argv = ['ssh', '-o', 'BatchMode=yes', HOST,
            shlex.join([PYTHON, '-c', remote, str(NATIVE_ROOT)])]
    result = subprocess.run(argv, input=stream.getvalue(), capture_output=True, timeout=120)
    receipt = {'actual_argv': argv, 'exit_code': result.returncode,
               'source_manifest_sha256': digest, 'archive_bytes': stream.tell(),
               'stdout': result.stdout.decode(), 'stderr': result.stderr.decode(),
               'review_sha256': sha(args.review), 'handoff_sha256': sha(args.handoff),
               'snapshot_sha256': sha(args.snapshot), 'automatic_retry': False}
    write(ROOT / 'builder_receipts' / ('DEPLOYMENT_EXECUTION_' + str(time.time_ns()) + '.json'), receipt)
    assert result.returncode == 0, receipt
    print(result.stdout.decode(), end='')


if __name__ == '__main__':
    main()
