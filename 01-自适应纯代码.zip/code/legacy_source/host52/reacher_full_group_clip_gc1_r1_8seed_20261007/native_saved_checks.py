"""Exactly 24 fixed CM2 states, two one-step native branches, two isolated processes."""
import argparse
import json
from pathlib import Path
import sys
from execution_contract import ROOT, NATIVE_ROOT, bundle, read, write, sha, reference


def compare(first, second, receipt):
    import torch
    from optimization_replay import equal, digest
    a, b = read(first), read(second)
    assert a['state'] == b['state'] == 'passed'
    assert a['manifest_sha256'] == b['manifest_sha256'] == sha(ROOT / 'SOURCE_MANIFEST.json')
    for report in (a, b):
        assert report['states'] == 24 and report['native_Adam_engineering_calls'] == 48
        assert sha(report['scientific_file']) == report['scientific_file_sha256']
    left = torch.load(a['scientific_file'], map_location='cpu', weights_only=False)
    right = torch.load(b['scientific_file'], map_location='cpu', weights_only=False)
    equal(torch, left, right, 'two fresh saved-native A/B processes complete24 scientific outputs')
    changed = [r for r in left['rows'] if r['actual_clipped_gradient_changed'] and r['actual_Adam_state_changed']]
    # Inert candidates fail. No magnitude, return or performance-fitted threshold is used.
    assert changed, 'Inert candidate: no current clipped-gradient/Adam-state mechanism'
    result = {'state': 'passed', 'manifest_sha256': sha(ROOT / 'SOURCE_MANIFEST.json'),
              'native_saved_data_checks': True, 'states': 24, 'strict_scientific_AB': True,
              'scientific_sha256': digest(torch, left), 'changed_states': len(changed),
              'native_Adam_engineering_calls': 96, 'environment_samples': 0, 'evaluation_calls': 0,
              'saved_receipt_sha256': [sha(first), sha(second)],
              'complete24_descriptive_rows': [{k: v for k, v in r.items() if k != 'branches'} for r in left['rows']],
              'performance_proven': False, 'automatic_short_admission': False,
              'next_boundary': 'saved_audits_completed_awaiting_root_mechanism_admission'}
    write(receipt, result)


def run(tag, receipt):
    import torch
    sys.path.insert(0, str(ROOT / 'source_full'))
    import grouped_ppo_step as grouped
    from optimization_replay import definitions, restore, operands, snapshot, digest, equal
    assert ROOT == NATIVE_ROOT
    bundle()
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.cuda.set_device('cuda:1')
    inputs = read(ROOT / 'SAVED_INPUT_REFERENCES.json')
    assert [(r['seed'], r['update']) for r in inputs['states']] == [(s, u) for s in range(21, 29) for u in (2, 101, 178)]
    old_manifest = reference('CM2_SOURCE_MANIFEST.json')
    old_source = Path(old_manifest['native_root']) / 'source_full'
    for name, expected in old_manifest['files'].items():
        if name.startswith('source_full/'):
            assert sha(old_source.parent / name) == expected
    Model, loss_fn = definitions(torch, old_source)
    cpu_before, device_before = torch.get_rng_state(), torch.cuda.get_rng_state('cuda:1')
    results = []
    calls = 0
    for binding in inputs['states']:
        path = Path(binding['path'])
        assert sha(path) == binding['sha256']
        record = torch.load(path, map_location='cpu', weights_only=False)
        assert record['schema'] == binding['original_record_schema'] and record['update'] == binding['update']
        assert record['source_target_device'] == 'cuda:1'
        original = digest(torch, record)
        branches = {}
        for branch in ('joint', 'grouped'):
            with torch.random.fork_rng(devices=[1]):
                model, optimizer = restore(torch, Model, record)
                groups = grouped.parameter_groups(model, optimizer)
                pre_model = snapshot(torch, model.state_dict())
                pre_adam = snapshot(torch, optimizer.state_dict())
                equal(torch, pre_model, record['frozen_model_state'], 'cloned saved pre-model')
                equal(torch, pre_adam, record['frozen_optimizer_state'], 'cloned saved pre-Adam')
                torch.set_rng_state(record['pre_ppo_cpu_rng'])
                torch.cuda.set_rng_state(record['pre_ppo_device_rng'], 'cuda:1')
                xs = operands(record, 'cuda:1')
                idx = torch.randperm(record['used_per_world'] * 1024, device='cuda:1').split(1024)[0]
                loss = loss_fn(model, *xs, idx)
                optimizer.zero_grad(set_to_none=True)
                loss.backward()
                raw = grouped.gradients(torch, groups)
                if branch == 'joint':
                    norm = torch.nn.utils.clip_grad_norm_(list(model.parameters()), .5, error_if_nonfinite=True)
                    norms = {'joint': norm.detach().cpu().clone(),
                             **{n: torch.nn.utils.get_total_norm([g.to('cuda:1') for g in raw[n].values()], 2., error_if_nonfinite=True).cpu() for n in groups}}
                else:
                    norms = {n: torch.nn.utils.clip_grad_norm_([p for _, p in named], .5, error_if_nonfinite=True).detach().cpu().clone() for n, named in groups.items()}
                clipped = grouped.gradients(torch, groups)
                optimizer.step()
                calls += 1
                post_model, post_adam = snapshot(torch, model.state_dict()), snapshot(torch, optimizer.state_dict())
                delta_model = {n: post_model[n] - pre_model[n] for n in pre_model}
                delta_moments = {i: {n: post_adam['state'][i][n] - pre_adam['state'][i][n]
                                    for n in ('exp_avg', 'exp_avg_sq')} for i in pre_adam['state']}
                branches[branch] = {'pre_model_sha256': digest(torch, pre_model), 'pre_Adam_sha256': digest(torch, pre_adam),
                    'indices': idx.cpu().clone(), 'loss': loss.detach().cpu().clone(), 'raw': raw, 'clipped': clipped,
                    'native_norms': norms, 'coefficients': {n: (.5 / (v + 1e-6)).clamp(max=1) for n, v in norms.items()},
                    'parameter_delta': delta_model, 'moment_delta': delta_moments,
                    'post_model_sha256': digest(torch, post_model), 'post_Adam_sha256': digest(torch, post_adam),
                    'post_permutation_cpu_rng': torch.get_rng_state().clone(),
                    'post_permutation_device_rng': torch.cuda.get_rng_state('cuda:1').clone(),
                    'post_step_counters': [v['step'].clone() for v in post_adam['state'].values()]}
        a, b = branches['joint'], branches['grouped']
        for name in ('pre_model_sha256', 'pre_Adam_sha256', 'indices', 'loss', 'raw',
                     'post_permutation_cpu_rng', 'post_permutation_device_rng', 'post_step_counters'):
            equal(torch, a[name], b[name], 'isolated branches identical ' + name)
        inactive = bool(a['native_norms']['joint'] + 1e-6 <= .5) and all(bool(v + 1e-6 <= .5) for v in b['native_norms'].values())
        if inactive:
            for name in ('clipped', 'parameter_delta', 'moment_delta', 'post_model_sha256', 'post_Adam_sha256'):
                equal(torch, a[name], b[name], 'actual inactive-clipping negative control ' + name)
        changed_gradient = digest(torch, a['clipped']) != digest(torch, b['clipped'])
        changed_adam = a['post_Adam_sha256'] != b['post_Adam_sha256']
        branches['differences'] = {
            'parameter_delta': {n: b['parameter_delta'][n] - a['parameter_delta'][n] for n in a['parameter_delta']},
            'moment_delta': {i: {n: b['moment_delta'][i][n] - a['moment_delta'][i][n] for n in ('exp_avg', 'exp_avg_sq')} for i in a['moment_delta']},
            'clipped_gradients': {g: {n: b['clipped'][g][n] - a['clipped'][g][n] for n in a['clipped'][g]} for g in a['clipped']}}
        group_parameter_effect = {g: {
            'joint_update_L2': float(torch.sqrt(sum(a['parameter_delta'][n].double().square().sum() for n, _ in named))),
            'group_update_L2': float(torch.sqrt(sum(b['parameter_delta'][n].double().square().sum() for n, _ in named))),
            'branch_difference_L2': float(torch.sqrt(sum(branches['differences']['parameter_delta'][n].double().square().sum() for n, _ in named)))} for g, named in groups.items()}
        results.append({'seed': binding['seed'], 'update': binding['update'], 'saved_sha256': binding['sha256'],
                        'actual_clipped_gradient_changed': changed_gradient, 'actual_Adam_state_changed': changed_adam,
                        'actual_parameter_state_changed': a['post_model_sha256'] != b['post_model_sha256'],
                        'actual_inactive_clipping_negative_control': inactive,
                        'parameter_branch_difference_L2': float(torch.sqrt(sum((a['parameter_delta'][n] - b['parameter_delta'][n]).double().square().sum() for n in a['parameter_delta']))),
                        'group_norms': {n: float(v) for n, v in b['native_norms'].items()},
                        'joint_norm': float(a['native_norms']['joint']),
                        'joint_clip_coefficient': float(a['coefficients']['joint']),
                        'group_clip_coefficients': {n: float(v) for n, v in b['coefficients'].items()},
                        'actual_group_parameter_effects': group_parameter_effect, 'branches': branches})
        equal(torch, digest(torch, record), original, 'untouched saved tensors')
        assert sha(path) == binding['sha256']
    assert calls == 48
    for name, expected in old_manifest['files'].items():
        if name.startswith('source_full/'):
            assert sha(old_source.parent / name) == expected
    equal(torch, torch.get_rng_state(), cpu_before, 'preserved current CPU RNG')
    equal(torch, torch.cuda.get_rng_state('cuda:1'), device_before, 'preserved current physical GPU1 RNG')
    scientific = {'rows': results, 'states': 24, 'native_Adam_engineering_calls': calls,
                  'source_loss_AST': 'literal completed CM2 ordinary Full minibatch statements',
                  'historical_first_step_poststate_gold_used': False,
                  'target_chronological_proof_sha256': inputs['completed_CM2_RAW_NATIVE_sha256'],
                  'environment_samples': 0, 'evaluation_calls': 0}
    output = ROOT / 'receipts' / ('saved_' + tag + '_scientific.pt')
    assert not output.exists()
    torch.save(scientific, output)
    write(receipt, {'state': 'passed', 'manifest_sha256': sha(ROOT / 'SOURCE_MANIFEST.json'),
          'tag': tag, 'states': 24, 'native_Adam_engineering_calls': calls,
          'scientific_file': str(output), 'scientific_file_sha256': sha(output),
          'CPU_and_physical_GPU1_RNG_preserved': True, 'environment_samples': 0, 'evaluation_calls': 0})


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--tag', choices=('a', 'b'))
    p.add_argument('--compare', nargs=2, type=Path)
    p.add_argument('--receipt', required=True, type=Path)
    a = p.parse_args()
    assert bool(a.tag) != bool(a.compare)
    assert not a.receipt.exists(), 'No overwrite/retry of saved audit'
    compare(*a.compare, a.receipt) if a.compare else run(a.tag, a.receipt)
