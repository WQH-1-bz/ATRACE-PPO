"""Frozen native verification utilities reused from accepted Reacher R4/TRP1."""
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics
import torch
from scipy import stats

def write(path, value):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)

def read(path):
    return json.loads(path.read_text())

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def jsonl(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]

def batch(evaluation, task):
    assert len(evaluation['returns']) == len(evaluation['lengths']) == 32
    assert all(math.isfinite(v) for v in evaluation['returns'])
    assert math.isfinite(evaluation['mean']) and math.isfinite(evaluation['std'])
    assert evaluation['lengths'] == [50 if task == 'Reacher' else 1000] * 32

def auc(path, budget, task):
    initial, evaluations = read(path / 'initial_evaluation.json'), jsonl(path / 'evaluations.jsonl')
    for evaluation in [initial, *evaluations]:
        batch(evaluation, task)
    points = [(0, initial['mean'])] + [(e['steps'], e['mean']) for e in evaluations]
    assert points[-1][0] == budget and all(a[0] < b[0] for a, b in zip(points, points[1:]))
    area = sum((b[0] - a[0]) * (a[1] + b[1]) / 2 for a, b in zip(points, points[1:])) / budget
    assert math.isfinite(area)
    return area, initial, evaluations

def checkpoint_steps(path, arm, expected):
    checkpoint = torch.load(path / 'latest.pt', map_location='cpu', weights_only=False)
    optimizers = {'ppo': checkpoint['optimizer']} if arm == 'innovation1' else checkpoint['optimizers']
    assert set(optimizers) == {'ppo'}
    for optimizer in optimizers.values():
        assert optimizer['state']
        for state in optimizer['state'].values():
            step = state['step'].item() if isinstance(state['step'], torch.Tensor) else state['step']
            assert step == expected, ('Adam steps', step, expected)
            for key in ('exp_avg', 'exp_avg_sq'):
                assert bool(torch.isfinite(state[key]).all()), ('nonfinite optimizer', key)
    assert all(bool(torch.isfinite(value).all()) for value in checkpoint['model'].values())
    assert checkpoint['config'] == read(path / 'config.json')
    return checkpoint

def paired(values, controls):
    delta = [a - b for a, b in zip(values, controls)]
    assert len(delta) == len(values) == len(controls) and all(math.isfinite(v) for v in delta)
    n, mean, sd = len(delta), statistics.mean(delta), statistics.stdev(delta)
    test = stats.ttest_rel(values, controls, alternative='two-sided') if sd else None
    half = float(stats.t.ppf(.975, n - 1)) * sd / math.sqrt(n)
    result = {'n': n, 'df': n - 1, 'mean_difference': mean, 'sd_difference': sd,
              't': float(test.statistic) if sd else None,
              'p_two_sided': float(test.pvalue) if sd else 1.,
              'constant_difference_test_unavailable': not bool(sd), 'ci95': [mean - half, mean + half]}
    if n == 8:
        possible = [abs(sum(s * x for s, x in zip(signs, delta)) / n)
                    for signs in itertools.product((-1, 1), repeat=n)]
        result['exact_sign_flip_p_two_sided'] = sum(v >= abs(mean) - 1e-12 for v in possible) / 256
    return result
