"""Exact same-device target and grouped optimization replay; engineering Adam calls only, no physics."""
import argparse
import ast
import csv
import importlib.util
import io
import json
import math
from pathlib import Path
import struct
import sys
import types
import torch
from execution_contract import ROOT, BUDGET, SHORT, SWITCH, SHORT_SWITCH, DET, schedule, read, sha, write, reference, prefix_reference, PREFIX_ROOT

sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('fullgc1_preserved_full1_verification', ROOT / 'references/full1_run_full.py')
v1 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v1)
v1.ROOT = ROOT
sys.path.insert(0, str(ROOT / 'source_full'))
from actor_constant_mode import residual, estimate_crossfit, CurrentCrossfitConstantMode, zero_offsets
import actor_constant_mode as constant_helper
from chronological_replay import primitive_namespace, training_labels
import grouped_ppo_step
from optimization_replay import replay_window


def load(path):
    return torch.load(path, map_location='cpu', weights_only=False)


def equal(a, b, label):
    differences = v1.differences(a, b, label)
    assert not differences, differences[:20]


def isolated_definitions():
    """Construct only exact saved-source classes/functions, without importing environment modules."""
    module = types.ModuleType('fullcm2_saved_replay_classes')
    module.__dict__.update(torch=torch, nn=torch.nn, math=math)
    nodes = ast.parse((ROOT / 'source_full/train_noisy_warp.py').read_text()).body
    selected = [n for n in nodes if isinstance(n, ast.ClassDef) and n.name in ('ActorCritic', 'RunningStats')]
    assert len(selected) == 2
    exec(compile(ast.fix_missing_locations(ast.Module(body=selected, type_ignores=[])),
                 str(ROOT / 'source_full/train_noisy_warp.py'), 'exec'), module.__dict__)
    return module.ActorCritic


def frozen_model_operands(record, incoming):
    Model = isolated_definitions()
    # Constructor draws are restored; physical GPU1 is the only CUDA RNG observed.
    with torch.random.fork_rng(devices=[1]):
        model = Model(11, 2).to('cuda:1')
        model.load_state_dict(record['frozen_model_state'])
        model.eval()
        observations = record['observations'].to('cuda:1')
        next_observations = record['next_observations'].to('cuda:1')
        actions = record['actions'].to('cuda:1')
        with torch.no_grad():
            equal(model.value(observations).cpu(), record['values_unshifted'], 'source current V')
            equal(model.value(next_observations).cpu(), record['next_values_unshifted'], 'source current Vnext')
            logratios = torch.zeros_like(record['original_behavior_logprob'], device='cuda:1')
            if incoming:
                logratios[:incoming].copy_(model.distribution(observations[:incoming]).log_prob(
                    actions[:incoming]).sum(-1) - record['original_behavior_logprob'][:incoming].to('cuda:1'))
            equal(logratios.cpu(), record['trace_logratios'], 'original behavior density')
    del model


def verify_window(record, raw, ledger, decision, constant_decision, constant_mode, prior_adam_calls, namespace, proxy_rows):
    u = ledger['update']
    assert record['schema'] == 'fullcm2_current_crossfit_causal_window_v1' and record['update'] == u
    assert record['source_target_device'] == 'cuda:1'
    for key in ('fresh_per_world', 'incoming_retained_per_world', 'used_per_world', 'stage_boundary_flush'):
        equal(record[key], ledger[key], key)
    incoming, fresh, used = (ledger[k] for k in ('incoming_retained_per_world', 'fresh_per_world', 'used_per_world'))
    whole = incoming + fresh
    keys = ('normalized_reward', 'values_unshifted', 'next_values_unshifted', 'terminated', 'done',
            'trace_logratios', 'capped_ratios', 'actor_advantage', 'fixed95_critic_return', 'actor_return',
            'original_actor_advantage', 'calibration_only_actor_delta',
            'same_calibrated_values_actor_trace_delta', 'original_values_fixed95_critic_trace_delta')
    for key in keys:
        value = record[key]
        assert isinstance(value, torch.Tensor) and value.shape == (whole, 1024) and value.device.type == 'cpu'
        assert not value.requires_grad
        if key in ('terminated', 'done'):
            assert value.dtype == torch.bool
        else:
            assert value.dtype == torch.float32 and bool(torch.isfinite(value).all()), key
    for key, dimensions in [('observations', 11), ('next_observations', 11), ('actions', 2)]:
        value = record[key]
        assert value.shape == (whole, 1024, dimensions) and value.dtype == torch.float32
        assert value.device.type == 'cpu' and bool(torch.isfinite(value).all())
    assert record['original_behavior_logprob'].shape == (whole, 1024)
    equal(record['window_positions'], torch.arange(ledger['window_start_per_world'], ledger['window_end_per_world']), 'sample positions')
    equal(record['world_ids'], torch.arange(1024), 'all worlds')
    equal(record['fresh_row_mask'], torch.arange(whole) >= incoming, 'fresh donor mask')
    equal(record['directly_consumed_row_mask'], torch.arange(whole) < used, 'directly consumed sample mask')
    equal(record['done'][incoming:], raw['done'], 'actual fresh completion mask')
    equal(record['frozen_TRP1_state'], raw['controller_before_observe'], 'frozen actor controller')
    equal(record['actor_lambda'], decision['lambda_used'], 'current actor lambda')
    equal(record['critic_lambda'], .95, 'fixed critic lambda')
    equal(record['gamma'], .99, 'gamma')
    equal(record['world_folds'], torch.arange(1024) % 2, 'fixed world-fold assignment')
    equal(record['model_optimizer_clock_pre_ppo'],
          {'actor': prior_adam_calls, 'critic': prior_adam_calls, 'h': 0}, 'current critic/optimizer version')
    equal(record['collected_steps_pre_ppo'], ledger['steps'], 'current completed rollout clock')
    equal(record['first_window_bypass'], u == 1, 'literal first-window bypass')
    adam = record['frozen_optimizer_state']
    assert len(adam['param_groups']) == 1 and adam['param_groups'][0]['params'] == list(range(13))
    assert adam['param_groups'][0]['lr'] == .0003 and adam['param_groups'][0]['eps'] == 1e-5
    if prior_adam_calls:
        assert set(adam['state']) == set(range(13))
        for state in adam['state'].values():
            assert state['step'].item() == prior_adam_calls
            assert bool(torch.isfinite(state['exp_avg']).all()) and bool(torch.isfinite(state['exp_avg_sq']).all())
    else:
        assert not adam['state']
    frozen_model_operands(record, incoming)
    xs = [record[k].to('cuda:1') for k in keys[:5]]
    rewards, values, next_values, terminated, done = xs
    weights = record['capped_ratios'].to('cuda:1')
    actor_lambda = record['actor_lambda']
    with torch.no_grad():
        delta, k = residual(torch, rewards, values, next_values, terminated)
        equal(delta[incoming:].cpu(), record['delta_fresh_source_float32'], 'actual source F32 delta')
        equal(k[incoming:].cpu(), record['k_fresh_source_float32'], 'actual source F32 k')
        current, donors = estimate_crossfit(torch, delta[incoming:], k[incoming:])
        # Independently spell out donor->recipient pooling on only current fresh rows.
        for recipient, donor_fold in (('even', 1), ('odd', 0)):
            dd, kk = delta[incoming:, donor_fold::2], k[incoming:, donor_fold::2]
            numerator, denominator = dd.detach().double().cpu().sum(), kk.detach().double().cpu().sum()
            equal(current[recipient], float(numerator / denominator), 'opposite-fold arithmetic ' + recipient)
            assert donors[recipient]['donor_row_count'] == fresh * 512
            assert donors[recipient]['donor_world_count'] == 512
        equal(current, record['current_estimates_pre_ppo'], 'current opposite-fold estimates')
        equal(donors, record['donor_summary'], 'current fresh donor counts and F64 sums')
        c = constant_mode.begin(u, current)
        equal(c, record['c_used'], 'current pre-PPO applied offsets')
        equal(constant_mode.state_dict(), record['constant_state_during_ppo'], 'current offsets frozen during PPO')
        equal(record['trace_logratios'].to('cuda:1').clamp(max=0).exp().cpu(), record['capped_ratios'], 'ratio cap')
        equal(weights[incoming:].cpu(), torch.ones((fresh, 1024)), 'fresh weights exactly one')
        equal(record['trace_logratios'][incoming:], torch.zeros((fresh, 1024)), 'fresh logratio exactly zero')
        # One shared cold namespace, in the trainer's literal chronological order.
        # Every later recurrence call (including the original-label call) matters to JIT history.
        labels = training_labels(torch, namespace, constant_helper, xs, weights, actor_lambda, c)
        for name, actual in labels.items():
            equal(actual.cpu(), record[name], 'native frozen target ' + name)
        assert torch.count_nonzero(labels['same_calibrated_values_actor_trace_delta'][incoming:]) == 0
        assert torch.count_nonzero(labels['original_values_fixed95_critic_trace_delta'][incoming:]) == 0
        actor_return, critic_return = labels['actor_return'], labels['fixed95_critic_return']
        equal(float((actor_return[:used] - critic_return[:used]).square().mean().sqrt()),
              decision['actor_critic_target_diff_rmse'], 'actor/critic target difference')
        # Descriptive heldout TD proxy and label changes: report every window,
        # including harms. These quantities never admit performance or tune c.
        offset = constant_helper.offset_tensor(torch, values, c)
        shifted_delta, _ = residual(torch, rewards, values + offset, next_values + offset, terminated)
        folds = {}
        for recipient, fold in (('even', 0), ('odd', 1)):
            before = float(delta[incoming:, fold::2].detach().double().cpu().mean())
            after = float(shifted_delta[incoming:, fold::2].detach().double().cpu().mean())
            label_delta = labels['calibration_only_actor_delta'][:, fold::2].detach().double().cpu()
            folds[recipient] = {'applied_c': c[recipient], 'current_c': current[recipient],
                'unshifted_source_F32_delta_mean_CPU_F64': before,
                'shifted_source_F32_delta_mean_CPU_F64': after,
                'squared_pooled_mean_TD_proxy_increased': after * after > before * before,
                'all_row_actor_label_change_RMSE_CPU_F64': float(label_delta.square().mean().sqrt())}
        proxy_rows.append({'update': u, 'steps': ledger['steps'], 'first_window_bypass': u == 1,
                           'fresh_per_world': fresh, 'folds': folds})
    post = constant_mode.finish_after_ppo(u)
    equal(record['constant_state_after_ppo'], post, 'current clock after successful PPO')
    equal(constant_decision, {'update': u, 'c_used': c, 'current_estimates_pre_ppo': current,
                            'donor_summary': donors, 'first_window_bypass': u == 1,
                            'fresh_count': fresh * 1024, 'retained_excluded_count': incoming * 1024,
                            'frozen_before_ppo': True, 'clock_completed_after_successful_ppo': True,
                            **post}, 'current opposite-fold decision')
    restored = CurrentCrossfitConstantMode()
    restored.load_state_dict(post)
    equal(restored.state_dict(), post, 'per-window constant checkpoint restoration')
    return c


def verify_run(path, seed, short=False):
    path = Path(path)
    config, summary = read(path / 'config.json'), read(path / 'summary.json')
    equal(summary, read(path / 'status.json'), 'terminal status')
    assert summary['state'] == 'completed' and summary['reload_check'] == 'passed'
    budget, cutoff = (SHORT, SHORT_SWITCH) if short else (BUDGET, SWITCH)
    ledger = schedule(short)
    assert config['seed'] == seed and config['device'] == 'cuda:1' and config['determinism'] == DET
    assert config['algorithm_version'] == summary['algorithm_version'] == 'reacher_full_group_clip_gc1_v1'
    assert config['task'] == 'Reacher' and config['method'] == 'pae'
    for key, value in [('effective_steps', budget), ('steps', budget), ('stage_switch_steps', cutoff),
                       ('num_envs', 1024), ('rollout', 64), ('retained_tail_steps', 16), ('epochs', 10),
                       ('batch_size', 1024), ('eval_envs', 32), ('eval_every', 262144), ('gamma', .99)]:
        equal(config[key], value, key)
    assert config['staged_full'] and config['retained_tail_correction'] and config['retained_tail_diagnostics']
    assert not any(config[k] for k in ('adaptive_kl', 'readiness_boost', 'adaptive_overlap', 'force_pae_overlap'))
    for name, digest in config['source_sha256'].items():
        assert sha(ROOT / 'source_full' / name) == digest
    assert config['xml_sha256'] == reference('NATIVE_RUNTIME_PINS.json')['xml_sha256']
    assert summary['training_transitions'] == summary['total_algorithm_transitions'] == budget
    assert summary['optimizer_steps'] == {'actor': budget // 1024 * 10, 'critic': budget // 1024 * 10, 'h': 0}
    assert summary['pae_retained_per_world'] == 0
    rows = list(csv.DictReader((path / 'progress.csv').open()))
    decisions = v1.jsonl(path / 'lambda_decisions.jsonl')
    constants = v1.jsonl(path / 'constant_mode_decisions.jsonl')
    diagnostics = v1.jsonl(path / 'retained_tail_diagnostics.jsonl')
    csv_decisions = list(csv.DictReader((path / 'trp1_controller.csv').open()))
    assert len(rows) == len(decisions) == len(constants) == len(diagnostics) == len(csv_decisions) == len(ledger)
    names = {f'update_{u:04d}.pt' for u in range(1, len(ledger) + 1)}
    assert {p.name for p in (path / 'constant_mode_audits').iterdir()} == names
    assert {p.name for p in (path / 'raw_training_returns').iterdir()} == names
    controller = v1.controller_class()()
    namespace = primitive_namespace(torch, ROOT / 'source_full')
    cpu_rng_before, gpu_rng_before = torch.get_rng_state(), torch.cuda.get_rng_state('cuda:1')
    constant_mode = CurrentCrossfitConstantMode()
    prior_adam_calls = 0
    used_constants, used_lambdas, proxy_rows = [], [], []
    checkpoint_for_replay = load(path / 'latest.pt')
    engineering_replay_calls = 0
    observer_serialized_bytes = 0
    for l, row, d, constant, csv_d, diagnostic in zip(ledger, rows, decisions, constants, csv_decisions, diagnostics):
        u = l['update']
        raw = load(path / 'raw_training_returns' / f'update_{u:04d}.pt')
        vector = v1.validate_training_episode_audit(raw, l)
        for key in ('update', 'steps', 'prior_collected_steps', 'overlap_active'):
            equal(d[key], l[key], 'actual controller clock ' + key)
        assert d['signal_version'] == 'TRP1'
        for key in ('update', 'steps', 'fresh_per_world', 'used_per_world', 'stage_boundary_flush'):
            equal(diagnostic[key], l[key], 'actual trace diagnostic clock ' + key)
        equal(diagnostic['retained_per_world'], l['incoming_retained_per_world'], 'incoming retained count')
        equal(diagnostic['retained_count'], l['incoming_retained_per_world'] * 1024, 'retained samples')
        equal(diagnostic['retained_out_per_world'], l['retained_per_world'], 'retained outgoing tail')
        equal(raw['controller_before_step'], controller.state_dict(), 'prior raw-return controller')
        delta = controller.step(u)
        equal(raw['controller_before_observe'], controller.state_dict(), 'pre-PPO controller')
        for key in ('lambda_used', 'lambda_current', 'actor_lambda_used'):
            equal(d[key], controller.value, key)
        equal(d['lambda_delta'], delta, 'controller delta')
        equal(d['critic_lambda_used'], .95, 'decision fixed critic lambda')
        stats = v1.verify_return_statistics(vector, raw)
        v1.verify_return_statistics(vector, d)
        record = load(path / 'constant_mode_audits' / f'update_{u:04d}.pt')
        observer_stream = io.BytesIO()
        torch.save({k: record[k] for k in ('group_clip_observer', 'post_ppo_cpu_rng', 'post_ppo_device_rng')}, observer_stream)
        observer_serialized_bytes += observer_stream.tell()
        del observer_stream
        used_lambdas.append(controller.value)
        c = verify_window(record, raw, l, d, constant, constant_mode, prior_adam_calls, namespace, proxy_rows)
        used_constants.append(c)
        next_record = load(path / 'constant_mode_audits' / f'update_{u + 1:04d}.pt') if u < len(ledger) else None
        engineering_replay_calls += replay_window(torch, ROOT / 'source_full', grouped_ppo_step,
            record, next_record, checkpoint_for_replay, equal)
        del next_record
        prior_adam_calls += l['used_per_world'] * 10
        if vector.numel():
            controller.observe(stats['training_return_mean'])
        for key, value in controller.state_dict().items():
            equal(d[key], value, 'controller final ' + key)
        assert d['valid_observation'] is bool(vector.numel())
        assert d['target_observation_count'] == controller.observations - controller.observations % 4
        for key, value in d.items():
            text = csv_d[key]
            if value is None:
                assert text == ''
            elif isinstance(value, bool):
                assert text.lower() == str(value).lower()
            elif isinstance(value, (int, float)):
                equal(value, type(value)(text), 'controller csv ' + key)
            elif isinstance(value, str):
                assert text == value
            else:
                equal(value, json.loads(text), 'controller csv ' + key)
        for key in ('steps', 'fresh_per_world', 'used_per_world', 'retained_per_world'):
            assert int(row[key]) == l[key]
        for key in ('overlap_active', 'stage_boundary_flush'):
            assert (row[key].lower() == 'true') is l[key]
        equal(float(row['gae_lambda_used']), controller.value, 'progress lambda')
        equal(float(row['gae_lambda_next']), controller.value, 'progress next lambda')
        for key in ('value_loss', 'policy_loss', 'approx_kl', 'explained_variance'):
            assert math.isfinite(float(row[key]))
        if u in config['fixed_critic_target_design']['audit_updates']:
            original = load(path / f'target_audit_update_{u:04d}.pt')
            for key, candidate_key in [('normalized_reward', 'normalized_reward'), ('values', 'values_unshifted'),
                                       ('next_values', 'next_values_unshifted'), ('done', 'done'),
                                       ('terminated', 'terminated'), ('capped_ratios', 'capped_ratios')]:
                equal(original[key], record[candidate_key], 'inherited audit operands ' + key)
            equal(original['actor_advantage'], record['actor_advantage'][:l['used_per_world']], 'actual fad labels')
            equal(original['consumed_critic_return'], record['fixed95_critic_return'][:l['used_per_world']], 'actual fr labels')
    assert zero_offsets(used_constants[0]) and not zero_offsets(used_constants[1])
    assert used_lambdas[:4] == [.95] * 4 and any(abs(v - .95) > 1e-12 for v in used_lambdas[4:])
    correction = v1.verify_correction(diagnostics, ledger, decisions)
    checkpoint = v1.helper.checkpoint_steps(path, 'innovation2', budget // 1024 * 10)
    equal(checkpoint['training_return_feedback'], controller.state_dict(), 'terminal controller')
    equal(checkpoint['lambda_controller'], controller.state_dict(), 'terminal controller alias')
    equal(checkpoint['actor_constant_mode'], constant_mode.state_dict(), 'terminal current-fold state')
    restored = CurrentCrossfitConstantMode()
    restored.load_state_dict(checkpoint['actor_constant_mode'])
    equal(restored.state_dict(), constant_mode.state_dict(), 'terminal constant checkpoint restoration')
    area, initial, evaluations = v1.helper.auc(path, budget, 'Reacher')
    expected, next_evaluation = [], 262144
    for l, row in zip(ledger, rows):
        if l['steps'] >= next_evaluation or l['steps'] == budget:
            expected.append(l['steps'])
            next_evaluation = (l['steps'] // 262144 + 1) * 262144
            assert row['eval_mean'] != ''
        else:
            assert row['eval_mean'] == ''
    assert [e['steps'] for e in evaluations] == expected and len(evaluations) == (2 if short else 39)
    for evaluation in (initial, *evaluations, summary['final_eval']):
        v1.native_batch(evaluation)
    equal(evaluations[-1]['returns'], summary['final_eval']['returns'], 'final primary returns')
    # Source uses NumPy trapz; retain its saved endpoint and audit arithmetic without changing it.
    import numpy as np
    source_area = float(np.trapz([initial['mean'], *[e['mean'] for e in evaluations]],
                                [0, *[e['steps'] for e in evaluations]]) / budget)
    equal(source_area, summary['normalized_return_auc'], 'source normalized AUC')
    assert abs(area - source_area) <= 1e-12
    if not short:
        fixed = next(r for r in reference('COMPARISON_REFERENCE.json')['rows']
                     if r['method'] == 'fixed95' and r['seed'] == seed)
        assert (path / 'initial_evaluation.json').read_bytes() == (Path(fixed['path']) / 'initial_evaluation.json').read_bytes()
    stress = read(path / 'stress_evaluation.json')
    assert [(r['mode'], r['scale']) for r in stress] == list(v1.STRESS)
    for evaluation in stress:
        v1.native_batch(evaluation)
    stress_proof = read(path / 'STRESS_CHILD_VERIFIED.json')
    assert stress_proof['state'] == 'passed' and stress_proof['child_process']
    assert stress_proof['device'] == 'cuda:1' and stress_proof['checkpoint_sha256'] == sha(path / 'latest.pt')
    assert stress_proof['stress_sha256'] == sha(path / 'stress_evaluation.json')
    artifacts = {str(p.relative_to(path)): sha(p) for p in path.rglob('*') if p.is_file()}
    equal(torch.get_rng_state(), cpu_rng_before, 'verifier CPU RNG preserved')
    equal(torch.cuda.get_rng_state('cuda:1'), gpu_rng_before, 'verifier physical GPU1 RNG preserved')
    return {'state': 'passed', 'seed': seed, 'path': str(path), 'updates': len(ledger),
            'final_return': summary['final_eval']['mean'], 'auc': source_area,
            'steps': budget, 'shared_adam_calls': prior_adam_calls, 'all_window_native_replay_exact': True,
            'replay_call_order': 'cold_literal_training_chronology_CM2_v1',
            'actual_grouped_optimization_chronology_exact': True,
            'engineering_Adam_replay_calls': engineering_replay_calls,
            'actual_observer_payload_serialized_bytes': observer_serialized_bytes,
            'actual_constant_and_gradient_audit_file_bytes': sum(p.stat().st_size for p in (path / 'constant_mode_audits').iterdir()),
            'production_first_last_gradients_indices_norms_clocks_exact': True,
            'CPU_and_physical_GPU1_RNG_preserved': True,
            'c_min': min(v for offsets in used_constants for v in offsets.values()),
            'c_max': max(v for offsets in used_constants for v in offsets.values()),
            'current_opposite_fold_clock_and_checkpoint_exact': True,
            'all_window_cross_world_fresh_proxy_and_label_change_rows': proxy_rows,
            'squared_mean_TD_proxy_is_not_advantage_truth_or_performance_admission': True,
            'actor_lambda_min': min(used_lambdas), 'actor_lambda_max': max(used_lambdas),
            'artifact_hashes': artifacts, **correction}


def zero_window_control(prefix, candidate):
    prefix, candidate = Path(prefix), Path(candidate)
    # Optimization changes the post-PPO state; only the exact PRE-PPO inputs remain a valid old control.
    for name in ('zero_offset_first_window_inputs.pt',):
        equal(load(prefix / name), load(candidate / name), 'old-Full1 zero-window ' + name)
    assert (prefix / 'initial_evaluation.json').read_bytes() == (candidate / 'initial_evaluation.json').read_bytes()
    old = load(prefix / 'old_full1_first_window_target.pt')
    new = load(candidate / 'constant_mode_audits/update_0001.pt')
    assert zero_offsets(new['c_used']) and new['first_window_bypass'] is True
    for key in ('normalized_reward', 'values_unshifted', 'next_values_unshifted', 'terminated', 'done',
                'trace_logratios', 'capped_ratios', 'actor_advantage', 'fixed95_critic_return', 'actor_return',
                'actor_lambda', 'used_per_world', 'incoming_retained_per_world', 'fresh_per_world'):
        equal(old[key], new[key], 'old-Full1 literal labels ' + key)
    equal(old['raw_return_payload'], load(candidate / 'raw_training_returns/update_0001.pt'), 'old-Full1 raw-return inputs')
    state = load(prefix / 'zero_offset_first_window_state.pt')
    # Collection normalizers do not change during PPO and are valid PRE-PPO controls.
    equal(state['obs_stats'], new['frozen_obs_stats'], 'old-Full1 first-window observation normalizer')
    equal(state['reward_stats'], new['frozen_reward_stats'], 'old-Full1 first-window reward normalizer')
    assert new['model_optimizer_clock_pre_ppo'] == {'actor': 0, 'critic': 0, 'h': 0}
    assert not new['frozen_optimizer_state']['state']
    old_adam_config = state['optimizer']['param_groups']
    equal(old_adam_config, new['frozen_optimizer_state']['param_groups'], 'same initial sharedAdam configuration')
    assert state['optimizer_steps'] == {'actor': 480, 'critic': 480, 'h': 0}
    assert state['collected_time'] == 64 and state['filled'] == 16
    assert set(state['cuda_rng']) == {'cuda:1'}
    assert not (prefix / 'summary.json').exists() and not (prefix / 'latest.pt').exists()
    return {'state': 'passed', 'fresh_transitions': 65536, 'direct_consumed': 49152,
            'unconsumed_tail': 16384, 'shared_adam_calls': 480,
            'CPU_and_physical_GPU1_pre_PPO_RNG_equal': True,
            'old_post_PPO_model_Adam_equality_removed_due_to_group_clip': True,
            'opaque_Warp_state_identity_claim': False}


def strict_pair(first, second):
    first, second = Path(first), Path(second)
    # Exact tensor bytes include NaN payloads and signed zeros. Paths are the sole config exemption.
    for name in ['latest.pt', 'zero_offset_first_window_inputs.pt', 'zero_offset_first_window_state.pt',
                 *[f'constant_mode_audits/update_{u:04d}.pt' for u in range(1, 10)],
                 *[f'raw_training_returns/update_{u:04d}.pt' for u in range(1, 10)],
                 *[f'target_audit_update_{u:04d}.pt' for u in (4, 5, 6, 9)]]:
        a, b = load(first / name), load(second / name)
        if name == 'latest.pt':
            a['config'].pop('out')
            b['config'].pop('out')
        equal(a, b, 'strict A/B ' + name)
    for name in ('initial_evaluation.json', 'evaluations.jsonl', 'lambda_decisions.jsonl',
                 'constant_mode_decisions.jsonl', 'trp1_controller.csv', 'retained_tail_diagnostics.jsonl',
                 'stress_evaluation.json'):
        assert (first / name).read_bytes() == (second / name).read_bytes(), name
    a, b = read(first / 'config.json'), read(second / 'config.json')
    a.pop('out'); b.pop('out'); equal(a, b, 'strict A/B config')
    rows_a, rows_b = (list(csv.DictReader((p / 'progress.csv').open())) for p in (first, second))
    assert len(rows_a) == len(rows_b) == 9
    for i, (a, b) in enumerate(zip(rows_a, rows_b), 1):
        for key in ('elapsed_seconds', 'steps_per_second'):
            a.pop(key); b.pop(key)
        equal(a, b, 'strict A/B non-timing progress ' + str(i))
    return {'state': 'passed', 'windows': 9, 'all_model_Adam_normalizer_controller_labels_RNG_exact': True,
            'exemptions': ['output path', 'elapsed_seconds', 'steps_per_second',
                           'process IDs and resource/timing metadata outside scientific comparison']}


def admission(prefix, first, second):
    assert Path(prefix) == PREFIX_ROOT
    saved = read(ROOT / 'SAVED_DATA_ADMISSION.json')
    assert saved['state'] == 'passed' and saved['native_saved_data_checks'] is True
    assert saved['strict_scientific_AB'] and saved['states'] == 24
    assert saved['manifest_sha256'] == sha(ROOT / 'SOURCE_MANIFEST.json')
    for suffix in ('short_a', 'short_b'):
        proof = read(ROOT / 'receipts' / (suffix + '_verify.json'))
        assert proof['state'] == 'passed' and proof['all_window_native_replay_exact'] and proof['updates'] == 9
        assert proof['replay_call_order'] == 'cold_literal_training_chronology_CM2_v1'
        assert proof['CPU_and_physical_GPU1_RNG_preserved']
        for name, digest in proof['artifact_hashes'].items():
            assert sha(Path(proof['path']) / name) == digest
    return {'state': 'passed', 'first_zero_window': zero_window_control(prefix, first),
            'second_zero_window': zero_window_control(prefix, second),
            'strict_short_AB': strict_pair(first, second), 'formal_launched': False,
            'immutable_old_Full1_prefix_reference': prefix_reference(),
            'saved_data_admission_sha256': sha(ROOT / 'SAVED_DATA_ADMISSION.json'),
            'two_new_complete_GC1_trajectories': True,
            'requires_new_formal_Luna_and_root_marker': True}


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--job', type=Path)
    p.add_argument('--seed', type=int)
    p.add_argument('--short', action='store_true')
    p.add_argument('--admit', type=Path, nargs=3, metavar=('OLD_PREFIX', 'SHORT_A', 'SHORT_B'))
    p.add_argument('--receipt', type=Path, required=True)
    a = p.parse_args()
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    if not a.admit:
        torch.cuda.set_device('cuda:1')
    result = admission(*a.admit) if a.admit else verify_run(a.job, a.seed, a.short)
    write(a.receipt, result)
    print(json.dumps({k: v for k, v in result.items() if k != 'artifact_hashes'}, allow_nan=False))
