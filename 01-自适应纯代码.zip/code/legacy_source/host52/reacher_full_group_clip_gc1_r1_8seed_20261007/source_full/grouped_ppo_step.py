"""FullGC1 native group clipping; no synthetic gradients or extra optimizer step."""

BOUND = .5
EXPECTED_ACTOR = ('log_std', 'actor.0.weight', 'actor.0.bias', 'actor.2.weight',
                  'actor.2.bias', 'actor.4.weight', 'actor.4.bias')
EXPECTED_CRITIC = ('critic.0.weight', 'critic.0.bias', 'critic.2.weight',
                   'critic.2.bias', 'critic.4.weight', 'critic.4.bias')


def parameter_groups(model, optimizer):
    named = list(model.named_parameters())
    assert all(p.requires_grad for _, p in named), 'Unexpected frozen model parameter'
    names = [name for name, _ in named]
    assert len(named) == 13 and len({id(p) for _, p in named}) == 13
    assert tuple(names) == EXPECTED_ACTOR + EXPECTED_CRITIC, 'Native model order changed'
    actor = [(n, p) for n, p in named if n == 'log_std' or n.startswith('actor.')]
    critic = [(n, p) for n, p in named if n.startswith('critic.')]
    assert tuple(n for n, _ in actor) == EXPECTED_ACTOR
    assert tuple(n for n, _ in critic) == EXPECTED_CRITIC
    assert not ({id(p) for _, p in actor} & {id(p) for _, p in critic})
    assert {id(p) for _, p in actor + critic} == {id(p) for _, p in named}
    assert len(optimizer.param_groups) == 1
    assert [id(p) for p in optimizer.param_groups[0]['params']] == [id(p) for _, p in named]
    assert optimizer.param_groups[0]['lr'] == 3e-4 and optimizer.param_groups[0]['eps'] == 1e-5
    return {'actor': actor, 'critic': critic}


def gradients(torch, groups):
    result = {}
    for group, named in groups.items():
        result[group] = {}
        for name, parameter in named:
            assert parameter.grad is not None, 'Missing production gradient: ' + name
            assert not parameter.grad.is_sparse and bool(torch.isfinite(parameter.grad).all())
            result[group][name] = parameter.grad.detach().cpu().clone()
    return result


def step_loss(torch, loss, optimizer, groups, observe=None):
    optimizer.zero_grad(set_to_none=True)
    loss.backward()
    # Validation never fills absent gradients; this is the actual loss.backward result.
    for named in groups.values():
        for name, parameter in named:
            assert parameter.grad is not None, 'Missing production gradient: ' + name
    raw = gradients(torch, groups) if observe is not None else None
    norms = {name: torch.nn.utils.clip_grad_norm_([p for _, p in named], BOUND,
             error_if_nonfinite=True) for name, named in groups.items()}
    if observe is not None:
        observe.update(raw=raw, clipped=gradients(torch, groups),
                       native_norms={name: value.detach().cpu().clone() for name, value in norms.items()},
                       parameter_names={name: [n for n, _ in named] for name, named in groups.items()},
                       clip_bound=BOUND, loss=loss.detach().cpu().clone())
    optimizer.step()
