"""TRP1: causal trend of completed raw training-episode return means."""
import math
from dataclasses import asdict, dataclass


@dataclass
class TrainingReturn:
    value: float = .95
    fast_ema: float = 0.
    slow_ema: float = 0.
    target: float = .95
    observations: int = 0
    fast_alpha: float = .1
    slow_alpha: float = .01
    trend: float = 0.
    last_training_return: float = 0.

    def observe(self, training_return):
        if not math.isfinite(training_return):
            raise ValueError('Completed raw training-return mean must be finite')
        self.last_training_return = training_return
        self.observations += 1
        if self.observations == 1:
            self.fast_ema = self.slow_ema = training_return
        else:
            self.fast_ema += .1 * (training_return - self.fast_ema)
            self.slow_ema += .01 * (training_return - self.slow_ema)
        self.trend = min(1., max(-1., (self.fast_ema - self.slow_ema) /
                                    (abs(self.fast_ema) + abs(self.slow_ema) + 1e-8)))
        if self.observations % 4 == 0:
            self.target = min(.99, max(.90, .95 + .04 * self.trend))

    def step(self, update):
        old = self.value
        if update > 4:
            self.value = min(.99, max(.90,
                old + max(-.001, min(.001, .1 * (self.target - old)))))
        return self.value - old

    def state_dict(self):
        return asdict(self)
