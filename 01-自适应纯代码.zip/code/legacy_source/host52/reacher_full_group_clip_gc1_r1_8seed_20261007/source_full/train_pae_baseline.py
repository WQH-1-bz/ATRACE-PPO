"""GPU MuJoCo matched-backbone ports; not original-paper score reproductions."""
import argparse
import copy
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import time
os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
if os.environ.get('DPO_TORCH_DETERMINISTIC') == '1':
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import numpy as np
import torch
from torch import nn
from train_noisy_warp import ActorCritic, RunningStats, gae, evaluate, write_json
from locomotion_warp import LocomotionWarp, ASSETS, TASKS
from external_baseline_algorithms import critic_lambda, tdrc_losses, copy_policy, restore_lookback, step_loss
import grouped_ppo_step
from lambda_kl_relative import KLFeedback
from lambda_training_return import TrainingReturn
from actor_constant_mode import (CurrentCrossfitConstantMode, residual, estimate_crossfit, zero_offsets, full_constant_targets,
                                 first_window_state, nested_cpu_snapshot)

if os.environ.get('DPO_TORCH_DETERMINISTIC') == '1':
    torch.use_deterministic_algorithms(True)


def append_json(path, data):
    with path.open('a') as f:
        f.write(json.dumps(data, allow_nan=False) + '\n')


def finite_drift_metrics(delta):
    """Descriptive retained-sample drift; filter nonfinite values explicitly."""
    values = delta.detach().double()
    values = values[torch.isfinite(values)]
    if not values.numel():
        return {'finite_count': 0, 'mean_abs': None, 'rmse': None}
    return {'finite_count': values.numel(), 'mean_abs': float(values.abs().mean()),
            'rmse': float(values.square().mean().sqrt())}


@torch.jit.script
def capped_tail_trace(rewards, values, next_values, terminated, done, capped_ratios,
                      gamma: float = .99, lam: float = .95):
    """Capped future-action trace: actor excludes its own action weight.

    D_t = b_t A_t, A_t = delta_t + gamma*lambda*(1-done_t)*D_(t+1).
    Critic targets are V_t + D_t.  This is a lambda-GAE-compatible
    V-trace variant, not the original IMPALA actor or an unbiased target.
    """
    advantages = torch.zeros_like(rewards)
    corrections = torch.zeros_like(rewards)
    carry = torch.zeros_like(rewards[0])
    for t in range(rewards.shape[0] - 1, -1, -1):
        delta = rewards[t] + gamma * (~terminated[t]).float() * next_values[t] - values[t]
        actor_advantage = delta + gamma * lam * (~done[t]).float() * carry
        advantages[t] = actor_advantage
        carry = capped_ratios[t] * actor_advantage
        corrections[t] = carry
    return advantages, corrections + values


def trace_correction_diagnostics(logratios, capped_ratios, actor_delta, critic_delta,
                                 retained_per_world, used_lambda):
    """Frozen-target measurements only; no sampling or training feedback."""
    retained = logratios[:retained_per_world].detach().double()
    raw_ratios = retained.exp()
    finite_raw_ratios = raw_ratios[torch.isfinite(raw_ratios)]
    ratio_scale = finite_raw_ratios.max() if finite_raw_ratios.numel() else None
    scaled_ratios = finite_raw_ratios / ratio_scale if ratio_scale is not None and ratio_scale > 0 else finite_raw_ratios
    capped = capped_ratios.detach().double()
    actor = finite_drift_metrics(actor_delta)
    critic = finite_drift_metrics(critic_delta)
    fresh_actor = actor_delta[retained_per_world:]
    fresh_critic = critic_delta[retained_per_world:]
    return {
        'trace_correction_version': 'capped_future_action_trace_v1',
        'trace_correction_enabled': True,
        'trace_lambda': used_lambda,
        'trace_ratio_cap': 1.0,
        'active_correction': bool((capped < 1).any()),
        'logratio_min': float(retained.min()) if retained.numel() else None,
        'logratio_max': float(retained.max()) if retained.numel() else None,
        'importance_ratio_min': float(finite_raw_ratios.min()) if finite_raw_ratios.numel() else None,
        'importance_ratio_max': float(finite_raw_ratios.max()) if finite_raw_ratios.numel() else None,
        'importance_ratio_mean': float(ratio_scale * scaled_ratios.mean()) if finite_raw_ratios.numel() else None,
        'importance_ratio_std': float(ratio_scale * scaled_ratios.std(unbiased=False)) if finite_raw_ratios.numel() else None,
        'importance_ratio_finite_count': finite_raw_ratios.numel(),
        'importance_ratio_nonfinite_count': raw_ratios.numel() - finite_raw_ratios.numel(),
        'capped_ratio_min': float(capped.min()),
        'capped_ratio_max': float(capped.max()),
        'capped_ratio_mean': float(capped.mean()),
        'capped_ratio_below_one_count': int((capped < 1).sum()),
        'capped_ratio_finite_count': int(torch.isfinite(capped).sum()),
        'fresh_capped_ratio_equal_one_count': int((capped[retained_per_world:] == 1).sum()),
        'logratio_finite_count': int(torch.isfinite(logratios).sum()),
        'actor_correction_rmse': actor['rmse'],
        'critic_correction_rmse': critic['rmse'],
        'actor_correction_finite_count': actor['finite_count'],
        'critic_correction_finite_count': critic['finite_count'],
        'actor_correction_nonzero_count': int(torch.count_nonzero(actor_delta)),
        'critic_correction_nonzero_count': int(torch.count_nonzero(critic_delta)),
        'fresh_actor_correction_nonzero_count': int(torch.count_nonzero(fresh_actor)),
        'fresh_critic_correction_nonzero_count': int(torch.count_nonzero(fresh_critic)),
        'fresh_actor_correction_max_abs': float(fresh_actor.abs().max()) if fresh_actor.numel() else 0.0,
        'fresh_critic_correction_max_abs': float(fresh_critic.abs().max()) if fresh_critic.numel() else 0.0,
        'fresh_actor_correction_finite_count': int(torch.isfinite(fresh_actor).sum()),
        'fresh_critic_correction_finite_count': int(torch.isfinite(fresh_critic).sum()),
    }


@torch.no_grad()
def collect_training_return(episode_tensor, done):
    """Select all actual fresh completions, including an explicitly empty batch."""
    if (episode_tensor.dtype != torch.float32 or done.dtype != torch.bool
            or episode_tensor.shape != done.shape or episode_tensor.device != done.device):
        raise RuntimeError('Training episode-return tensor and actual done mask disagree')
    completed_returns = episode_tensor[done]
    if not bool(torch.isfinite(completed_returns).all()):
        raise RuntimeError('Invalid completed raw training episode return')
    if not bool(torch.isnan(episode_tensor[~done]).all()):
        raise RuntimeError('Non-done training episode-return entries must be NaN')
    if not completed_returns.numel():
        return completed_returns, None, None
    mean = float(completed_returns.mean())
    std = float(completed_returns.std(unbiased=False))
    if not math.isfinite(mean) or not math.isfinite(std):
        raise RuntimeError('Non-finite raw training-return population statistics')
    return completed_returns, mean, std


@torch.no_grad()
def full_targets(rewards, values, next_values, terminated, done, capped_ratios, actor_lambda):
    """One original path at95; otherwise actor-own trace and fixed95 critic trace."""
    uncorrected_adv, uncorrected_actor_ret = gae(
        rewards, values, next_values, terminated, done, .99, actor_lambda)
    adv, actor_ret = capped_tail_trace(
        rewards, values, next_values, terminated, done, capped_ratios, .99, actor_lambda)
    if actor_lambda == .95:
        ret = actor_ret
        uncorrected_critic_ret = uncorrected_actor_ret
    else:
        _, uncorrected_critic_ret = gae(
            rewards, values, next_values, terminated, done, .99, .95)
        _, ret = capped_tail_trace(
            rewards, values, next_values, terminated, done, capped_ratios, .99, .95)
    return adv, ret, adv - uncorrected_adv, ret - uncorrected_critic_ret, actor_ret


def cpu_snapshot(payload):
    return {key: value.detach().cpu().clone() if isinstance(value, torch.Tensor) else value
            for key, value in payload.items()}


def save_target_audit(path, rewards, values, next_values, terminated, done,
                      trace_logratios, capped_ratios, flat_actor_advantage, flat_critic_return,
                      actor_lambda, used_per_world, raw_payload, stage_boundary_flush):
    """Record the full frozen window and the labels actually consumed by PPO."""
    payload = {
        'normalized_reward': rewards, 'values': values, 'next_values': next_values,
        'terminated': terminated, 'done': done, 'trace_logratios': trace_logratios,
        'capped_ratios': capped_ratios,
        'actor_advantage': flat_actor_advantage.reshape(used_per_world, rewards.shape[1]),
        'consumed_critic_return': flat_critic_return.reshape(used_per_world, rewards.shape[1]),
        **{key: value for key, value in raw_payload.items() if key != 'done'},
        'fresh_done': raw_payload['done'], 'actor_lambda': actor_lambda, 'critic_lambda': .95,
        'gamma': .99, 'used_per_world': used_per_world,
        'stage_boundary_flush': stage_boundary_flush,
        'window_positions': torch.arange(raw_payload['fresh_start_per_world'] -
            raw_payload['incoming_retained_per_world'], raw_payload['fresh_end_per_world'],
            dtype=torch.int64),
    }
    torch.save(cpu_snapshot(payload), path)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--method', choices=['pae'], required=True)
    p.add_argument('--task', choices=['Hopper', 'Walker2d', 'HalfCheetah', 'Ant', 'Swimmer', 'InvertedDoublePendulum', 'Reacher'], required=True)
    p.add_argument('--seed', type=int, required=True)
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--steps', type=int, default=10027008)
    p.add_argument('--num-envs', type=int, default=1024)
    p.add_argument('--rollout', type=int, default=64)
    p.add_argument('--batch-size', type=int, default=1024)
    p.add_argument('--eval-envs', type=int, default=32)
    p.add_argument('--eval-every', type=int, default=262144)
    p.add_argument('--profile-chunks', type=int, default=10)
    p.add_argument('--adaptive-kl', action='store_true')
    p.add_argument('--readiness-boost', action='store_true')
    p.add_argument('--staged-full', action='store_true')
    p.add_argument('--stage-switch-steps', type=int, default=1048576)
    p.add_argument('--retained-tail-steps', type=int, default=16)
    p.add_argument('--retained-tail-diagnostics', action='store_true')
    p.add_argument('--retained-tail-correction', action='store_true')
    p.add_argument('--adaptive-overlap', action='store_true')
    p.add_argument('--force-pae-overlap', action='store_true')
    p.add_argument('--overlap-lambda-threshold', type=float, default=.964)
    p.add_argument('--overlap-start-steps', type=int, default=1572864)
    p.add_argument('--overlap-stop-steps', type=int, default=8388608)
    a = p.parse_args()
    assert min(a.steps, a.num_envs, a.rollout, a.batch_size, a.eval_envs, a.eval_every, a.profile_chunks) > 0
    assert a.stage_switch_steps > 0 and a.stage_switch_steps % a.num_envs == 0
    assert 0 <= a.retained_tail_steps < a.rollout
    if a.retained_tail_correction:
        assert a.retained_tail_diagnostics, 'Trace correction requires retained-tail diagnostics on every window'
        assert a.staged_full and a.rollout == 64 and a.retained_tail_steps in (8, 16)
        assert not (a.adaptive_kl or a.readiness_boost or a.adaptive_overlap or a.force_pae_overlap), 'Trace correction uses the fixed staged schedule and lambda=0.95'
    assert a.task == 'Reacher' and a.method == 'pae'
    assert a.staged_full and a.retained_tail_correction and a.retained_tail_diagnostics
    assert a.retained_tail_steps == 16 and a.rollout == 64 and a.num_envs == 1024
    assert a.batch_size == 1024 and a.eval_envs == 32 and a.eval_every == 262144
    assert (a.steps, a.stage_switch_steps) in ((524288, 262144), (10027008, 4980736))
    assert a.device == 'cuda:1'
    assert (a.seed == 91081 if a.steps == 524288 else a.seed in range(21, 29))
    # World folds are fixed before any reward or environment rollout is observed.
    world_folds = torch.arange(a.num_envs, dtype=torch.int64) % 2
    assert .90 <= a.overlap_lambda_threshold <= .99
    assert a.rollout % 32 == 0 and a.batch_size % 32 == 0
    assert torch.cuda.is_available() and a.device.startswith('cuda:')
    a.out.mkdir(parents=True, exist_ok=False)
    torch.set_num_threads(1)
    torch.cuda.set_device(a.device)
    torch.random.default_generator.manual_seed(a.seed)
    torch.cuda.manual_seed(a.seed)
    np.random.seed(a.seed)
    size = a.rollout * a.num_envs
    effective_steps = math.ceil(a.steps / a.num_envs) * a.num_envs
    assert 0 <= a.overlap_start_steps < a.overlap_stop_steps <= effective_steps
    tail = a.retained_tail_steps
    prefix = a.rollout - tail
    total_time = effective_steps // a.num_envs
    stage_switch_time = a.stage_switch_steps // a.num_envs
    updates = 1 + math.ceil(max(0, total_time - a.rollout) / prefix)
    if a.staged_full:
        assert a.rollout <= stage_switch_time < total_time
        early_updates = 1 + math.ceil(max(0, stage_switch_time - a.rollout) / prefix)
        updates = early_updates + math.ceil((total_time - stage_switch_time) / a.rollout)
    collected_time = 0
    filled = 0
    epochs = 4 if a.method == 'gradient_ppo' else 10
    config = {**vars(a), 'out': str(a.out), 'effective_steps': effective_steps, 'pae_prefix': prefix, 'pae_tail': tail, 'pae_ratio': prefix / a.rollout,
              'epochs': epochs, 'gamma': .99, 'initial_lambda': .95,
              'backend': 'GPU MuJoCo Warp, v4 semantics; matched-backbone port',
              'normalization': 'running observation and discounted-return reward normalization',
              'network': [64, 64], 'clip': .2, 'grad_clip': .5, 'adam_eps': 1e-5,
              'actor_lr': 3e-4, 'critic_lr': .003 if a.method == 'gradient_ppo' else .0003,
              'anneal_lr': a.method == 'critic_aware',
              'method_spec': 'EXTERNAL_BASELINE_PROTOCOL.md',
              'determinism': {'torch': torch.are_deterministic_algorithms_enabled(),
                  'warp': os.environ.get('DPO_WARP_DETERMINISTIC', 'not_guaranteed'),
                  'warp_max_records': int(os.environ.get('DPO_WARP_DETERMINISTIC_MAX_RECORDS', '0')),
                  'cublas_workspace_config': os.environ.get('CUBLAS_WORKSPACE_CONFIG')},
              'xml_sha256': hashlib.sha256((ASSETS / TASKS[a.task][0]).read_bytes()).hexdigest(),
              'source_sha256': {f: hashlib.sha256(Path(__file__).with_name(f).read_bytes()).hexdigest()
                                for f in ['train_pae_baseline.py', 'external_baseline_algorithms.py', 'locomotion_warp.py', 'train_noisy_warp.py', 'ant_contact_compat.py']}}
    config['adaptive_lambda_design'] = {'enabled': a.adaptive_kl, 'version': 'KLF2+readiness',
        'readiness_enabled': a.readiness_boost, 'readiness_signal': 'previous-window explained variance',
        'readiness_threshold': .45, 'readiness_until_update': 16, 'readiness_target': .99,
        'readiness_max_step': .02, 'kl_fast_alpha': .1, 'kl_slow_alpha': .01,
        'kl_bounds': [.90,.99], 'extra_environment_steps': 0}
    config['staged_full_design'] = {'enabled':a.staged_full,'switch_steps':a.stage_switch_steps,
        'early_stage':f'PAE prefix={prefix} tail={tail}',
        'late_stage':'standard non-overlap rollout=64, causal TRP1 actor and fixed95 critic',
        'boundary_policy':'train the complete final early-stage window before switching',
        'advantage_std_unbiased':False,
        'switch_signal':'cumulative training transitions only','evaluation_return_used':False}
    config['adaptive_overlap_design'] = {'enabled':a.adaptive_overlap,
        'lambda_threshold':a.overlap_lambda_threshold,'start_steps':a.overlap_start_steps,
        'stop_steps':a.overlap_stop_steps,
        'rule':f'reuse a {tail}-step tail only while the causal KLF2 lambda state is at or above the threshold',
        'evaluation_return_used':False,'extra_environment_steps':0}
    config['retained_tail_trace_design'] = {
        'enabled': a.retained_tail_correction, 'version': 'capped_future_action_trace_v1',
        'label': 'capped future-action trace / lambda-GAE-compatible V-trace variant',
        'actor_lambda': 'causal TRP1 scalar', 'critic_lambda': .95, 'ratio_cap': 1.0, 'lower_ratio_clip': None,
        'ratio_definition': 'exp(current frozen Gaussian latent-action logdensity minus original behavior logdensity)',
        'fresh_ratio': 'exactly 1 at frozen-target construction',
        'capped_ratio': 'exp(min(logratio, 0))',
        'delta': 'reward + gamma*(1-terminated)*next_value - value',
        'critic_correction': 'D_t = b_t*(delta_t + gamma*lambda*(1-done_t)*D_next)',
        'actor_advantage': 'A_t = delta_t + gamma*lambda*(1-done_t)*D_next; own b_t excluded',
        'critic_return': 'value_t + D_t', 'ppo_ratio': 'epoch policy / original behavior; unchanged',
        'horizon_correction': 0.0, 'truncation_bootstrap': 'stored final observation; stop trace at done',
        'targets_frozen_before_epochs': True, 'unbiased_claim': False,
        'original_impala_actor': False, 'evaluation_return_used': False,
        'diagnostics_control_training': False, 'extra_environment_steps': 0,
        'extra_optimizer_steps': 0}
    audit_updates = [4, 5, 6, 9] if effective_steps == 524288 else [4, 5, 100, 101, 102, 178]
    config['algorithm'] = 'Full'
    config['algorithm_version'] = 'reacher_full_group_clip_gc1_v1'
    config['method_plumbing'] = 'pae invokes accepted R4 I2 collector/PPO backbone'
    config['scientific_composition'] = 'Unchanged Full1 TRP1/capped trace plus current opposite-world-fold actor-only constant mode; unshifted fixed95 critic'
    config['lambda_mode'] = 'training_return'
    config['lambda_design'] = {
        'version': 'TRP1', 'initial': .95, 'bounds': [.90, .99],
        'warmup_updates': 4, 'first_adaptive_update': 5, 'fast_alpha': .1, 'slow_alpha': .01,
        'initial_averages': 'first valid actual fresh raw training-return mean',
        'target_interval': 4, 'target_clock': 'valid nonempty fresh completion batches',
        'tracking_clock': 'every actual PPO window', 'target': 'clip(.95+.04*z,.90,.99)',
        'trend': 'clip((F-S)/(abs(F)+abs(S)+1e-8),-1,1)', 'trend_scale': .04,
        'tracking_rate': .1, 'max_step': .001, 'signal_observed_after_ppo': True,
        'signal': 'native CUDA float32 population mean/std of all fresh actual done entries',
        'empty_batch': 'save empty vector/count0/null statistics; skip observe without resetting',
        'completed_return_selection': 'episode_tensor[done[filled:end]] before any finite filter',
        'evaluation_return_used': False, 'kl_drives_controller': False,
        'critic_statistics_drive_controller': False,
        'signal_vector_files': [f'raw_training_returns/update_{u:04d}.pt' for u in range(1, updates + 1)],
        'signal_reduction_device': a.device, 'signal_reduction_dtype': 'float32',
        'expected_empty_updates': [] if effective_steps == 524288 else [9, 34, 59, 84],
        'extra_environment_steps': 0, 'extra_optimizer_steps': 0}
    config['fixed_critic_target_design'] = {
        'enabled': True, 'actor_advantage_lambda': 'causal completed raw training-return trend',
        'critic_lambda': .95, 'critic_return': 'same capped future-action trace at fixed95',
        'shared_original_path_at95': 'only c0; otherwise independent unshifted fixed95', 'targets_frozen_before_epochs': True,
        'targets_consumed_by_ppo': True, 'audit_enabled': True, 'audit_updates': audit_updates,
        'audit_files': [f'target_audit_update_{u:04d}.pt' for u in audit_updates],
        'extra_environment_steps': 0, 'extra_optimizer_steps': 0}
    config['source_sha256']['lambda_training_return.py'] = hashlib.sha256(
        Path(__file__).with_name('lambda_training_return.py').read_bytes()).hexdigest()
    config['source_sha256']['actor_constant_mode.py'] = hashlib.sha256(
        Path(__file__).with_name('actor_constant_mode.py').read_bytes()).hexdigest()
    config['actor_constant_mode_design'] = {
        'version': 'FullCM2_current_opposite_world_fold_v1', 'initial_c': {'even': 0.0, 'odd': 0.0}, 'gamma': .99,
        'source_operands_dtype': 'float32', 'pooled_reduction': 'source F32 to F64 CPU sum, Torch one thread',
        'estimator': 'sum(r+.99*(1-terminated)*Vnext-V)/sum(1-.99*(1-terminated))',
        'donors': 'Current fresh temporal rows including budgeted lookahead; even recipients use odd worlds and odd recipients use even worlds; incoming retained rows excluded',
        'world_fold': 'fixed world ID modulo2, chosen before rewards',
        'causality': 'window u uses current-critic/current-fresh opposite-fold estimates frozen before PPO; first window literal zero',
        'first_possible_active_update': 2, 'per_epoch_recalibration': False,
        'actor_only_copied_values': True, 'critic_values_unshifted': True, 'critic_lambda': .95,
        'literal_full1_path_at_c0': True, 'epsilon_cap_filter_fallback': None,
        'runtime_world_crossfit': True, 'extra_environment_steps': 0, 'extra_optimizer_steps': 0,
        'causal_audit_files': [f'constant_mode_audits/update_{u:04d}.pt' for u in range(1, updates + 1)],
        'first_window_state_file': 'zero_offset_first_window_state.pt',
        'group_clip_may_change_realized_critic_step': True}
    config['source_sha256']['grouped_ppo_step.py'] = hashlib.sha256(
        Path(__file__).with_name('grouped_ppo_step.py').read_bytes()).hexdigest()
    config['optimization_design'] = {'version': 'FullGC1_native_disjoint_group_clip_v1',
        'actor_parameter_count': 7, 'critic_parameter_count': 6, 'clip_bound_each': .5,
        'global_bound_max': math.sqrt(.5 ** 2 + .5 ** 2),
        'loss': 'pg + .5*MSE', 'shared_Adam': True, 'zero_grad_calls_per_minibatch': 1,
        'backward_calls_per_minibatch': 1, 'Adam_calls_per_minibatch': 1,
        'extra_environment_samples': 0, 'auxiliary_optimizer_calls': 0,
        'standard_optimization_change_not_third_innovation': True}
    (a.out / 'constant_mode_audits').mkdir()
    (a.out / 'raw_training_returns').mkdir()
    write_json(a.out / 'config.json', config)
    write_json(a.out / 'status.json', {'state': 'compiling', 'pid': os.getpid(), 'device': a.device})
    try:
        started = time.monotonic()
        if a.task == 'Ant':
            from ant_contact_compat import install
            install()
        env = LocomotionWarp(a.num_envs, a.device, a.seed, task=a.task)
        ev = LocomotionWarp(a.eval_envs, a.device, a.seed + 10000, task=a.task)
        pe = LocomotionWarp(5, a.device, a.seed + 20000, task=a.task) if a.method == 'reward_profiling' else None
        model = ActorCritic(env.obs_dim, env.action_dim).to(a.device)
        normal = RunningStats((env.obs_dim,), a.device)
        rnormal = RunningStats((), a.device)
        optimizer = torch.optim.Adam(model.parameters(), lr=3e-4, eps=1e-5)
        optimizers = {'ppo': optimizer}
        actor_params = list(model.actor.parameters()) + [model.log_std]
        clip_groups = grouped_ppo_step.parameter_groups(model, optimizer)
        hnet = None
        if a.method == 'gradient_ppo':
            hnet = ActorCritic(env.obs_dim, env.action_dim).to(a.device).critic
            # Independently initialized auxiliary network, as in the author implementation.
            ao = torch.optim.Adam(actor_params, lr=3e-4, eps=1e-5)
            co = torch.optim.Adam(model.critic.parameters(), lr=.003, eps=1e-5)
            ho = torch.optim.Adam(hnet.parameters(), lr=.003, eps=1e-5)
            optimizers = {'actor': ao, 'critic': co, 'h': ho}
        raw = env.reset()
        normal.update(raw)
        obs = normal.normalize(raw)
        initial = evaluate(model, normal, ev)
        write_json(a.out / 'initial_evaluation.json', initial)
        shape = (a.rollout, a.num_envs)
        ob = torch.empty((*shape, env.obs_dim), device=a.device)
        nb = torch.empty_like(ob)
        ac = torch.empty((*shape, env.action_dim), device=a.device)
        lp, rw, va, nv = [torch.empty(shape, device=a.device) for _ in range(4)]
        te, dn = [torch.empty(shape, device=a.device, dtype=torch.bool) for _ in range(2)]
        discounted = torch.zeros(a.num_envs, device=a.device)
        lam, prev_loss, extra_valid, extra_simulated = .95, float('inf'), 0, 0
        feedback = TrainingReturn()
        constant_mode = CurrentCrossfitConstantMode(a.num_envs)
        counts = {'actor': 0, 'critic': 0, 'h': 0}
        latest, next_eval, history = initial, a.eval_every, [(0, initial['mean'])]
        boundaries = set(math.ceil(k * updates / min(a.profile_chunks, updates)) for k in range(1, min(a.profile_chunks, updates) + 1))
        old = None
        previous_tail_adv = None
        fields = ['steps', 'elapsed_seconds', 'steps_per_second', 'eval_mean', 'gae_lambda_used', 'gae_lambda_next', 'overlap_active',
                  'value_loss', 'policy_loss', 'approx_kl', 'explained_variance', 'profiling_extra_transitions', 'profiling_simulated_transitions',
                  'fresh_per_world', 'used_per_world', 'retained_per_world', 'stage_boundary_flush',
                  'training_return_mean', 'training_return_count', 'training_return_std']
        controller_fields = ['update', 'steps', 'prior_collected_steps', 'lambda_used', 'lambda_current',
            'lambda_delta', 'signal_version', 'training_return_mean', 'training_return_count',
            'training_return_std', 'target_observation_count', 'actor_lambda_used', 'critic_lambda_used',
            'actor_critic_target_diff_rmse', 'overlap_active', 'valid_observation',
            *feedback.state_dict().keys()]
        with (a.out / 'progress.csv').open('w', buffering=1) as f, \
                (a.out / 'trp1_controller.csv').open('w', buffering=1) as controller_file:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            controller_writer = csv.DictWriter(controller_file, fieldnames=controller_fields)
            controller_writer.writeheader()
            for update in range(1, updates + 1):
                current_steps = collected_time * a.num_envs
                staged_overlap = a.staged_full and collected_time < stage_switch_time
                adaptive_overlap = (a.adaptive_overlap and a.overlap_start_steps <= current_steps < a.overlap_stop_steps
                                    and lam >= a.overlap_lambda_threshold)
                # The default PAE setting reuses the final 16 steps of each
                # 64-step window.  Adaptive/staged experiments opt into
                # their own conditional schedules instead.
                overlap_active = a.force_pae_overlap or staged_overlap or adaptive_overlap
                if not overlap_active and filled:
                    filled = 0
                    previous_tail_adv = None
                if collected_time >= total_time and not filled:
                    break
                active_prefix = prefix if overlap_active else a.rollout
                if a.method == 'reward_profiling' and old is None:
                    old = copy_policy(model)
                if a.method == 'critic_aware':
                    optimizer.param_groups[0]['lr'] = 3e-4 * (1 - (update - 1) / updates)
                controller_before_step = feedback.state_dict()
                episode_values = []
                with torch.no_grad():
                    fresh = min(a.rollout - filled, total_time - collected_time)
                    if staged_overlap:
                        fresh = min(fresh, stage_switch_time - collected_time)
                    end = filled + fresh
                    for t in range(filled, end):
                        ob[t].copy_(obs)
                        dist = model.distribution(obs)
                        actions = dist.sample()
                        ac[t].copy_(actions)
                        lp[t].copy_(dist.log_prob(actions).sum(-1))
                        va[t].copy_(model.value(obs))
                        raw, reward, term, trunc, info = env.step(actions)
                        done = term | trunc
                        episode_values.append(torch.where(done, info['episode_return'], torch.nan))
                        nb[t].copy_(normal.normalize(info['terminal_observation']))
                        nv[t].copy_(model.value(nb[t]))
                        discounted.mul_(.99).add_(reward)
                        rnormal.update(discounted)
                        rw[t].copy_((reward / (rnormal.var + 1e-8).sqrt()).clamp(-10, 10))
                        discounted.masked_fill_(done, 0)
                        te[t].copy_(term)
                        dn[t].copy_(done)
                        normal.update(raw)
                        obs = normal.normalize(raw)
                    episode_tensor = torch.stack(episode_values)
                    completed_returns, training_return_mean, training_return_std = collect_training_return(
                        episode_tensor, dn[filled:end])
                    training_return_count = completed_returns.numel()
                    # Invalid completions abort before controller tracking or any optimizer mutation.
                    lambda_delta = feedback.step(update)
                    lam = used_lambda = feedback.value
                    raw_payload = {
                        'training_episode_values': episode_tensor, 'done': dn[filled:end],
                        'training_episode_return': completed_returns,
                        'training_return_mean': training_return_mean, 'training_return_std': training_return_std,
                        'training_return_count': training_return_count, 'update': update,
                        'prior_collected_steps': current_steps, 'steps': (collected_time + fresh) * a.num_envs,
                        'fresh_per_world': fresh, 'incoming_retained_per_world': filled,
                        'fresh_start_per_world': collected_time, 'fresh_end_per_world': collected_time + fresh,
                        'collection_positions': torch.arange(collected_time, collected_time + fresh, dtype=torch.int64),
                        'target_device': str(rw.device), 'signal_version': 'TRP1',
                        'controller_before_step': controller_before_step,
                        'controller_before_observe': feedback.state_dict(),
                    }
                    torch.save(cpu_snapshot(raw_payload), a.out / 'raw_training_returns' / f'update_{update:04d}.pt')
                    collected_time += fresh
                    stored_retained_values = va[:filled].clone() if a.retained_tail_diagnostics and filled else None
                    # Author code recomputes current values on the entire overlap window.
                    va[:end].copy_(model.value(ob[:end]))
                    nv[:end].copy_(model.value(nb[:end]))
                    trace_logratios = None
                    if a.retained_tail_correction:
                        # New rows were sampled by this frozen current actor.  Only
                        # incoming old rows require a behavior-density correction.
                        trace_logratios = torch.zeros_like(lp[:end])
                        if filled:
                            trace_logratios[:filled].copy_(
                                model.distribution(ob[:filled]).log_prob(ac[:filled]).sum(-1) - lp[:filled])
                        if not torch.isfinite(trace_logratios).all():
                            raise RuntimeError('Nonfinite retained current/behavior logdensity ratio')
                        capped_ratios = trace_logratios.clamp(max=0).exp()
                        pre_ppo_delta, pre_ppo_k = residual(
                            torch, rw[:end], va[:end], nv[:end], te[:end])
                        current_estimates, donor_summary = estimate_crossfit(
                            torch, pre_ppo_delta[filled:], pre_ppo_k[filled:])
                        c_used = constant_mode.begin(update, current_estimates)
                        adv, ret, actor_delta, critic_delta, actor_return = full_constant_targets(
                            torch, full_targets, gae, capped_tail_trace,
                            rw[:end], va[:end], nv[:end], te[:end], dn[:end], capped_ratios, used_lambda, c_used)
                        if zero_offsets(c_used):
                            original_actor_advantage = adv
                        else:
                            original_actor_advantage, _, _, _, _ = full_targets(
                                rw[:end], va[:end], nv[:end], te[:end], dn[:end], capped_ratios, used_lambda)
                        # Future-only correction cannot affect the fresh suffix,
                        # including every complete late-stage window after flush.
                        if torch.count_nonzero(actor_delta[filled:]) or torch.count_nonzero(critic_delta[filled:]):
                            raise RuntimeError('Trace correction changed a fresh-row GAE target')
                    stage_boundary_flush = bool(staged_overlap and collected_time >= stage_switch_time)
                    used = end if collected_time == total_time or stage_boundary_flush else min(active_prefix, end)
                    if a.retained_tail_diagnostics:
                        diagnostic = {'update': update, 'steps': collected_time * a.num_envs,
                            'retained_count': filled * a.num_envs, 'retained_per_world': filled,
                            'fresh_per_world': fresh, 'used_per_world': used,
                            'retained_out_per_world': end - used, 'stage_boundary_flush': stage_boundary_flush,
                            'current_behavior_logprob_mean_abs_drift': None,
                            'importance_ratio_outside_clip_fraction': None,
                            'refreshed_minus_stored_value_rmse': None,
                            'extended_refreshed_retained_advantage_mean_abs_drift': None,
                            'extended_refreshed_retained_advantage_rmse': None,
                            'logprob_finite_count': 0, 'value_finite_count': 0, 'advantage_finite_count': 0}
                        if a.retained_tail_correction:
                            diagnostic.update(trace_correction_diagnostics(trace_logratios, capped_ratios,
                                actor_delta, critic_delta, filled, used_lambda))
                            diagnostic.update(actor_lambda=used_lambda, critic_lambda=.95,
                                actor_correction_reference_lambda=used_lambda,
                                critic_correction_reference_lambda=.95)
                        if filled:
                            logratio = (trace_logratios[:filled] if trace_logratios is not None else
                                model.distribution(ob[:filled]).log_prob(ac[:filled]).sum(-1) - lp[:filled])
                            policy_drift = finite_drift_metrics(logratio)
                            finite_logratio = logratio[torch.isfinite(logratio)]
                            diagnostic['current_behavior_logprob_mean_abs_drift'] = policy_drift['mean_abs']
                            diagnostic['logprob_finite_count'] = policy_drift['finite_count']
                            if finite_logratio.numel():
                                diagnostic['importance_ratio_outside_clip_fraction'] = float(
                                    ((finite_logratio < math.log(.8)) | (finite_logratio > math.log(1.2))).double().mean())
                            value_drift = finite_drift_metrics(va[:filled] - stored_retained_values)
                            diagnostic['refreshed_minus_stored_value_rmse'] = value_drift['rmse']
                            diagnostic['value_finite_count'] = value_drift['finite_count']
                            if previous_tail_adv is not None:
                                advantage_drift = finite_drift_metrics(adv[:filled] - previous_tail_adv)
                                diagnostic['extended_refreshed_retained_advantage_mean_abs_drift'] = advantage_drift['mean_abs']
                                diagnostic['extended_refreshed_retained_advantage_rmse'] = advantage_drift['rmse']
                                diagnostic['advantage_finite_count'] = advantage_drift['finite_count']
                        # Descriptive replay drift combines critic refresh and new GAE context.
                        # It is not a true-advantage error and never controls training.
                        append_json(a.out / 'retained_tail_diagnostics.jsonl', diagnostic)
                env.check_capacity()
                fo, fa, fl, fad, fr, fv = ob[:used].flatten(0, 1), ac[:used].flatten(0, 1), lp[:used].flatten(), adv[:used].flatten(), ret[:used].flatten(), va[:used].flatten()
                actor_critic_target_diff_rmse = float((actor_return[:used] - ret[:used]).square().mean().sqrt())
                if update in audit_updates:
                    save_target_audit(a.out / f'target_audit_update_{update:04d}.pt',
                        rw[:end], va[:end], nv[:end], te[:end], dn[:end], trace_logratios, capped_ratios,
                        fad, fr, used_lambda, used, raw_payload, stage_boundary_flush)
                # Detach/clone before optimizer epochs: audit owns independent CPU storage.
                constant_audit = nested_cpu_snapshot(torch, {
                    'schema': 'fullcm2_current_crossfit_causal_window_v1', 'update': update, 'c_used': c_used,
                    'current_estimates_pre_ppo': current_estimates, 'donor_summary': donor_summary,
                    'first_window_bypass': update == 1,
                    'model_optimizer_clock_pre_ppo': counts.copy(),
                    'collected_steps_pre_ppo': collected_time * a.num_envs,
                    'constant_state_during_ppo': constant_mode.state_dict(),
                    'normalized_reward': rw[:end], 'values_unshifted': va[:end],
                    'next_values_unshifted': nv[:end], 'terminated': te[:end], 'done': dn[:end],
                    'delta_fresh_source_float32': pre_ppo_delta[filled:],
                    'k_fresh_source_float32': pre_ppo_k[filled:],
                    'trace_logratios': trace_logratios, 'capped_ratios': capped_ratios,
                    'actor_advantage': adv, 'fixed95_critic_return': ret, 'actor_return': actor_return,
                    'original_actor_advantage': original_actor_advantage,
                    'calibration_only_actor_delta': adv - original_actor_advantage,
                    'same_calibrated_values_actor_trace_delta': actor_delta,
                    'original_values_fixed95_critic_trace_delta': critic_delta,
                    'actor_lambda': used_lambda, 'critic_lambda': .95, 'gamma': .99,
                    'fresh_per_world': fresh, 'incoming_retained_per_world': filled,
                    'used_per_world': used, 'stage_boundary_flush': stage_boundary_flush,
                    'window_positions': torch.arange(raw_payload['fresh_start_per_world'] - filled,
                        raw_payload['fresh_end_per_world'], dtype=torch.int64),
                    'world_ids': torch.arange(a.num_envs, dtype=torch.int64),
                    'world_folds': world_folds,
                    'fresh_row_mask': torch.arange(end, dtype=torch.int64) >= filled,
                    'directly_consumed_row_mask': torch.arange(end, dtype=torch.int64) < used,
                    'source_target_device': str(rw.device),
                    'observations': ob[:end], 'next_observations': nb[:end],
                    'actions': ac[:end], 'original_behavior_logprob': lp[:end],
                    'frozen_model_state': model.state_dict(),
                    'frozen_optimizer_state': optimizer.state_dict(),
                    'frozen_obs_stats': normal.state_dict(), 'frozen_reward_stats': rnormal.state_dict(),
                    'frozen_TRP1_state': feedback.state_dict(),
                    'pre_ppo_cpu_rng': torch.get_rng_state(),
                    'pre_ppo_device_rng': torch.cuda.get_rng_state(a.device),
                })
                if update == 1:
                    torch.save(nested_cpu_snapshot(torch, {
                        'observations': ob[:end], 'next_observations': nb[:end],
                        'actions': ac[:end], 'original_behavior_logprob': lp[:end],
                        'frozen_model_state': model.state_dict(),
                        'pre_ppo_cpu_rng': torch.get_rng_state(),
                        'pre_ppo_device_rng': torch.cuda.get_rng_state(a.device)}),
                        a.out / 'zero_offset_first_window_inputs.pt')
                train_size = used * a.num_envs
                if a.adaptive_kl:
                    with torch.no_grad():
                        old_dist = model.distribution(fo)
                        old_mean = old_dist.loc.detach().clone()
                        old_scale = old_dist.scale.detach().clone()
                metrics = []
                group_clip_observer = []
                minibatch_number = 0
                window_adam_calls = epochs * ((train_size + a.batch_size - 1) // a.batch_size)
                if a.method == 'gradient_ppo':
                    # Each row indexes exactly 32 consecutive times of ONE world.
                    sequence_ids = torch.arange(size, device=a.device).reshape(a.rollout, a.num_envs).T.reshape(-1, 32)
                for epoch in range(epochs):
                    if a.method == 'gradient_ppo':
                        groups = sequence_ids[torch.randperm(len(sequence_ids), device=a.device)].split(a.batch_size // 32)
                    else:
                        groups = torch.randperm(train_size, device=a.device).split(a.batch_size)
                    for group in groups:
                        idx = group.flatten()
                        dist = model.distribution(fo[idx])
                        logratio = dist.log_prob(fa[idx]).sum(-1) - fl[idx]
                        ratio = logratio.exp()
                        ba = fad[idx]
                        ba = (ba - ba.mean()) / (ba.std(unbiased=False) + 1e-8)
                        pg = torch.maximum(-ba * ratio, -ba * ratio.clamp(.8, 1.2)).mean()
                        if a.method == 'gradient_ppo':
                            # Use all32 transitions with stored terminal next-observations;
                            # unlike author array slicing, no transition lost at each sequence end.
                            tids = group.T
                            values = model.value(fo[tids])
                            next_values = model.value(nb.flatten(0, 1)[tids])
                            hv = hnet(fo[tids]).squeeze(-1)
                            cl, hl, dl = tdrc_losses(values, next_values, rw.flatten()[tids], te.flatten()[tids], dn.flatten()[tids], hv, list(hnet.parameters()))
                            vl = .5 * dl.detach().square().mean()
                            step_loss(pg, ao, actor_params)
                            # These losses have disjoint parameter graphs and share PRE-update values.
                            co.zero_grad(set_to_none=True)
                            ho.zero_grad(set_to_none=True)
                            cl.backward()
                            hl.backward()
                            nn.utils.clip_grad_norm_(model.critic.parameters(), .5, error_if_nonfinite=True)
                            nn.utils.clip_grad_norm_(hnet.parameters(), .5, error_if_nonfinite=True)
                            co.step()
                            ho.step()
                            counts['actor'] += 1; counts['critic'] += 1; counts['h'] += 1
                        elif a.method == 'critic_aware':
                            value = model.value(fo[idx])
                            clipped = fv[idx] + (value - fv[idx]).clamp(-.2, .2)
                            vl = .5 * torch.maximum((value - fr[idx]).square(), (clipped - fr[idx]).square()).mean()
                            if epoch % 2 == 0:
                                step_loss(pg, optimizer, list(model.parameters()))
                                counts['actor'] += 1
                            step_loss(vl, optimizer, list(model.parameters()))
                            counts['critic'] += 1
                        else:
                            vl = .5 * (model.value(fo[idx]) - fr[idx]).square().mean()
                            capture = None
                            if minibatch_number in (0, window_adam_calls - 1):
                                capture = {'update': update, 'epoch': epoch, 'minibatch': minibatch_number,
                                    'indices': idx.detach().cpu().clone(),
                                    'model_optimizer_clock_before': counts.copy()}
                                group_clip_observer.append(capture)
                            grouped_ppo_step.step_loss(torch, pg + vl, optimizer, clip_groups, capture)
                            counts['actor'] += 1; counts['critic'] += 1
                        minibatch_number += 1
                        metrics.append(torch.stack((vl.detach(), pg.detach(), ((ratio - 1) - logratio).mean().detach())))
                stats = torch.stack(metrics).mean(0).cpu().tolist()
                if not all(math.isfinite(v) for v in stats):
                    raise RuntimeError('Nonfinite optimization metrics')
                # Only now have all epochs consumed the immutable current labels.
                assert minibatch_number == window_adam_calls and len(group_clip_observer) == 2
                constant_audit['group_clip_observer'] = group_clip_observer
                constant_audit['post_ppo_cpu_rng'] = torch.get_rng_state().clone()
                constant_audit['post_ppo_device_rng'] = torch.cuda.get_rng_state(a.device).clone()
                constant_audit['constant_state_after_ppo'] = constant_mode.finish_after_ppo(update)
                torch.save(constant_audit, a.out / 'constant_mode_audits' / f'update_{update:04d}.pt')
                append_json(a.out / 'constant_mode_decisions.jsonl', {
                    'update': update, 'c_used': c_used, 'current_estimates_pre_ppo': current_estimates,
                    'donor_summary': donor_summary, 'first_window_bypass': update == 1,
                    'fresh_count': fresh * a.num_envs, 'retained_excluded_count': filled * a.num_envs,
                    'frozen_before_ppo': True, 'clock_completed_after_successful_ppo': True, **constant_mode.state_dict()})
                steps = collected_time * a.num_envs
                ev_score = float(1 - (fr - fv).var(unbiased=False) / (fr.var(unbiased=False) + 1e-8))
                if training_return_count:
                    feedback.observe(training_return_mean)
                decision = {
                    'update': update, 'steps': steps, 'prior_collected_steps': current_steps,
                    'lambda_used': used_lambda, 'lambda_current': feedback.value, 'lambda_delta': lambda_delta,
                    'signal_version': 'TRP1', 'training_return_mean': training_return_mean,
                    'training_return_count': training_return_count, 'training_return_std': training_return_std,
                    'target_observation_count': feedback.observations - feedback.observations % 4,
                    'actor_lambda_used': used_lambda, 'critic_lambda_used': .95,
                    'actor_critic_target_diff_rmse': actor_critic_target_diff_rmse,
                    'overlap_active': overlap_active, 'valid_observation': bool(training_return_count),
                    **feedback.state_dict(),
                }
                append_json(a.out / 'lambda_decisions.jsonl', decision)
                controller_writer.writerow(decision)
                if a.adaptive_kl:
                    with torch.no_grad():
                        old_policy=torch.distributions.Normal(old_mean,old_scale,validate_args=False)
                        realized_kl=float(torch.distributions.kl_divergence(old_policy,model.distribution(fo)).sum(-1).mean())
                    feedback.observe(realized_kl)
                    readiness_active=(a.readiness_boost and update<16 and ev_score>=.45)
                    if readiness_active:
                        feedback.value=min(.99,feedback.value+.02)
                    elif a.staged_full and steps<=a.stage_switch_steps:
                        feedback.value=.95
                    else:
                        feedback.step(update+1)
                    lam=feedback.value
                    append_json(a.out/'lambda_decisions.jsonl',{'update':update,'steps':steps,'used':used_lambda,
                        'next':lam,'realized_kl':realized_kl,'explained_variance':ev_score,
                        'readiness_active':readiness_active,'overlap_active':overlap_active,**feedback.state_dict()})
                if a.method == 'critic_aware':
                    last_loss = float(vl.detach())
                    lam = critic_lambda(lam, prev_loss, last_loss, steps / (effective_steps))
                    append_json(a.out / 'lambda_decisions.jsonl', {'update': update, 'used': used_lambda, 'next': lam, 'last_minibatch_value_loss': last_loss, 'previous_loss': prev_loss if math.isfinite(prev_loss) else None})
                    prev_loss = last_loss
                if a.method == 'reward_profiling' and update in boundaries:
                    new = copy_policy(model)
                    # Common current normalizer, independent profiling resets and training RNG.
                    # Report-evaluation environment is NEVER used for policy selection.
                    model.load_state_dict(old)
                    old_eval = evaluate(model, normal, pe)
                    model.load_state_dict(new)
                    new_eval = evaluate(model, normal, pe)
                    chosen = restore_lookback(model, old, new, old_eval['mean'], new_eval['mean'])
                    valid = sum(old_eval['lengths']) + sum(new_eval['lengths'])
                    simulated = 5 * (max(old_eval['lengths']) + max(new_eval['lengths']))
                    extra_valid += valid; extra_simulated += simulated
                    append_json(a.out / 'profiling_decisions.jsonl', {'steps': steps, 'chosen': chosen, 'old': old_eval, 'new': new_eval, 'extra_transitions': valid, 'simulated_transitions': simulated, 'optimizer': 'kept current', 'normalizer': 'shared current frozen stats for both candidates'})
                    old = None
                evaluated = steps >= next_eval or steps >= effective_steps or update == updates
                if evaluated:
                    latest = evaluate(model, normal, ev)
                    append_json(a.out / 'evaluations.jsonl', {'steps': steps, **latest})
                    history.append((steps, latest['mean']))
                    state = {'model': model.state_dict(), 'obs_stats': normal.state_dict(), 'reward_stats': rnormal.state_dict(),
                             'optimizers': {k: v.state_dict() for k, v in optimizers.items()},
                             'hnet': hnet.state_dict() if hnet is not None else None,
                             'lambda_next': lam, 'previous_value_loss': prev_loss, 'steps': steps, 'config': config,
                             'profiling_old': old, 'optimizer_steps': counts.copy(),
                             'kl_feedback': None, 'training_return_feedback': feedback.state_dict(),
                             'lambda_controller': feedback.state_dict(),
                             'actor_constant_mode': constant_mode.state_dict()}
                    torch.save(state, a.out / 'latest.tmp')
                    (a.out / 'latest.tmp').replace(a.out / 'latest.pt')
                    next_eval = (steps // a.eval_every + 1) * a.eval_every
                torch.cuda.synchronize()
                elapsed = time.monotonic() - started
                row = dict(zip(fields, [steps, elapsed, steps / elapsed, latest['mean'] if evaluated else None,
                                       used_lambda, lam, overlap_active, *stats, ev_score, extra_valid, extra_simulated,
                                       fresh, used, end - used, stage_boundary_flush]))
                row.update(training_return_mean=training_return_mean,
                           training_return_count=training_return_count, training_return_std=training_return_std)
                writer.writerow(row)
                status = {**row, 'pae_retained_per_world': end - used, 'pae_fresh_per_world': fresh, 'pae_used_per_world': used, 'state': 'running', 'pid': os.getpid(), 'device': a.device, 'physics_device': str(env.qpos.device),
                          'budget': effective_steps, 'optimizer_steps': counts.copy(), 'peak_torch_memory_bytes': torch.cuda.max_memory_reserved()}
                write_json(a.out / 'status.json', status)
                print(f'{steps}/{effective_steps} | {steps / elapsed:.0f} steps/s | lambda={lam:.4f} | eval={row["eval_mean"]}', flush=True)
                # Reuse tail transitions and their original behavior log-probabilities.
                filled = end - used
                if a.retained_tail_diagnostics:
                    previous_tail_adv = adv[used:end].clone() if filled else None
                if filled:
                    for buf in [ob, nb, ac, lp, rw, va, nv, te, dn]:
                        buf[:filled].copy_(buf[used:end].clone())
                if update == 1:
                    torch.save(first_window_state(torch, np, model, optimizer, normal, rnormal, feedback,
                        env, ev, {'ob': ob[:end], 'nb': nb[:end], 'ac': ac[:end], 'lp': lp[:end],
                                 'rw': rw[:end], 'va': va[:end], 'nv': nv[:end], 'te': te[:end], 'dn': dn[:end]},
                        raw, obs, discounted, counts, collected_time, filled),
                        a.out / 'zero_offset_first_window_state.pt')

        # Reload the exact final checkpoint, including the normalizer used in evaluations.
        saved = torch.load(a.out / 'latest.pt', weights_only=False)
        restored = ActorCritic(env.obs_dim, env.action_dim).to(a.device)
        restored.load_state_dict(saved['model'])
        restored_stats = RunningStats((env.obs_dim,), a.device)
        restored_stats.load_state_dict(saved['obs_stats'])
        with torch.no_grad():
            torch.testing.assert_close(restored.actor(restored_stats.normalize(raw)), model.actor(normal.normalize(raw)), rtol=0, atol=0)
            torch.testing.assert_close(restored.value(obs), model.value(obs), rtol=0, atol=0)
        auc = float(np.trapz([x[1] for x in history], [x[0] for x in history]) / (effective_steps))
        summary = {**status, 'state': 'completed', 'algorithm': 'Full',
                   'algorithm_version': 'reacher_full_group_clip_gc1_v1',
                   'final_eval': latest, 'initial_eval': initial, 'normalized_return_auc': auc,
                   'reload_check': 'passed', 'training_transitions': effective_steps,
                   'total_algorithm_transitions': effective_steps + extra_valid,
                   'note': 'Matched GPU backbone port with declared deviations; not original-paper numerical reproduction.'}
        write_json(a.out / 'summary.json', summary)
        write_json(a.out / 'status.json', summary)
    except BaseException as exc:
        write_json(a.out / 'status.json', {'state': 'failed', 'pid': os.getpid(), 'error': repr(exc)})
        raise

if __name__ == '__main__':
    main()
