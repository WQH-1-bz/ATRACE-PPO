"""Current opposite-world-fold actor-only intercepts; torch is injected by the trainer.

This module can be parsed and its state machine exercised using stdlib only.
It never instantiates a model, optimizer, environment, generator or launcher.
"""
import math


def residual(torch, rewards, values, next_values, terminated):
    if not (rewards.dtype == values.dtype == next_values.dtype == torch.float32
            and terminated.dtype == torch.bool
            and rewards.shape == values.shape == next_values.shape == terminated.shape
            and rewards.device == values.device == next_values.device == terminated.device
            and rewards.ndim == 2 and rewards.numel() > 0):
        raise RuntimeError('Invalid constant-mode source operands')
    if not all(bool(torch.isfinite(x).all()) for x in (rewards, values, next_values)):
        raise RuntimeError('Nonfinite constant-mode source input')
    # Literal audited source-native float32 operands; do not reassociate/promote.
    delta = rewards + .99 * (~terminated).float() * next_values - values
    k = 1 - .99 * (~terminated).float()
    if not all(bool(torch.isfinite(x).all()) for x in (delta, k)) or not bool((k > 0).all()):
        raise RuntimeError('Invalid constant-mode residual/coefficient')
    return delta, k


def estimate(torch, delta, k):
    if not (delta.dtype == k.dtype == torch.float32 and delta.shape == k.shape
            and delta.ndim == 2 and delta.numel() > 0 and delta.device == k.device):
        raise RuntimeError('Invalid or empty constant-mode fresh residuals')
    if not all(bool(torch.isfinite(x).all()) for x in (delta, k)):
        raise RuntimeError('Nonfinite constant-mode fresh residuals')
    if not bool((k > 0).all()) or torch.get_num_threads() != 1:
        raise RuntimeError('Invalid coefficient or unfrozen CPU reduction threads')
    # Exactly the audited estimator semantics: source F32 -> F64 -> CPU -> sum.
    # Native Torch version, CPU reduction kernel and one thread are pinned.
    numerator = delta.detach().double().cpu().sum()
    denominator = k.detach().double().cpu().sum()
    if not math.isfinite(float(numerator)) or not math.isfinite(float(denominator)) or float(denominator) <= 0:
        raise RuntimeError('Invalid constant-mode pooled sum/denominator')
    c = float(numerator / denominator)
    if not math.isfinite(c):
        raise RuntimeError('Nonfinite constant-mode pooled estimate')
    return c


ESTIMATOR = 'FullCM2_current_opposite_world_fold_v1'
FOLDS = ('even', 'odd')


def estimate_crossfit(torch, delta, k):
    """Recipient naming: even receives odd donors; odd receives even donors.

    Call only on current fresh rows, including budgeted lookahead. Each fold is
    sliced before the inherited source-F32 -> F64 -> CPU one-thread pool.
    """
    if not (delta.ndim == k.ndim == 2 and delta.shape == k.shape
            and delta.shape[0] > 0 and delta.shape[1] >= 2):
        raise RuntimeError('Empty current fresh rows or empty world fold')
    estimates, donors = {}, {}
    for recipient, donor_fold in (('even', 1), ('odd', 0)):
        donor_delta, donor_k = delta[:, donor_fold::2], k[:, donor_fold::2]
        c = estimate(torch, donor_delta, donor_k)
        numerator = float(donor_delta.detach().double().cpu().sum())
        denominator = float(donor_k.detach().double().cpu().sum())
        estimates[recipient] = c
        donors[recipient] = {'recipient_fold': 0 if recipient == 'even' else 1,
                            'donor_fold': donor_fold, 'donor_world_count': donor_delta.shape[1],
                            'donor_row_count': donor_delta.numel(),
                            'source_delta_sum_cpu_float64': numerator,
                            'source_k_sum_cpu_float64': denominator}
    return estimates, donors


def valid_offsets(offsets):
    return (type(offsets) is dict and tuple(offsets) == FOLDS
            and all(type(value) is float and math.isfinite(value) for value in offsets.values()))


class CurrentCrossfitConstantMode:
    """Current pre-PPO estimates freeze once; successful epochs advance only the clock."""
    def __init__(self, world_count=1024):
        if type(world_count) is not int or world_count < 2:
            raise RuntimeError('Empty current constant-mode world fold')
        self.world_count = world_count
        self.completed_update = 0
        self.pending_update = None
        self.current_estimates = dict(even=0.0, odd=0.0)
        self.applied_offsets = dict(even=0.0, odd=0.0)

    def begin(self, update, current_estimates):
        if (type(update) is not int or update != self.completed_update + 1
                or self.pending_update is not None or not valid_offsets(current_estimates)):
            raise RuntimeError('Invalid current constant-mode pre-PPO begin order/estimate')
        self.pending_update = update
        self.current_estimates = current_estimates.copy()
        self.applied_offsets = (dict(even=0.0, odd=0.0) if update == 1 else current_estimates.copy())
        return self.applied_offsets.copy()

    def finish_after_ppo(self, update):
        if type(update) is not int or update != self.pending_update or update != self.completed_update + 1:
            raise RuntimeError('Invalid current constant-mode post-PPO completion')
        self.completed_update = update
        self.pending_update = None
        return self.state_dict()

    def state_dict(self):
        return {'estimator': ESTIMATOR, 'world_count': self.world_count,
                'completed_update': self.completed_update, 'pending_update': self.pending_update,
                'current_estimates': self.current_estimates.copy(),
                'applied_offsets': self.applied_offsets.copy()}

    def load_state_dict(self, state):
        if (type(state) is not dict or set(state) != set(self.state_dict())
                or state['estimator'] != ESTIMATOR or state['world_count'] != self.world_count
                or type(state['completed_update']) is not int or state['completed_update'] < 0
                or not valid_offsets(state['current_estimates']) or not valid_offsets(state['applied_offsets'])
                or (state['pending_update'] is not None and
                    (type(state['pending_update']) is not int
                     or state['pending_update'] != state['completed_update'] + 1))):
            raise RuntimeError('Invalid current constant-mode checkpoint')
        update = state['pending_update'] if state['pending_update'] is not None else state['completed_update']
        expected = dict(even=0.0, odd=0.0) if update <= 1 else state['current_estimates']
        if state['applied_offsets'] != expected:
            raise RuntimeError('Invalid current constant-mode checkpoint offset clock')
        self.completed_update = state['completed_update']
        self.pending_update = state['pending_update']
        self.current_estimates = state['current_estimates'].copy()
        self.applied_offsets = state['applied_offsets'].copy()


def zero_offsets(offsets):
    if not valid_offsets(offsets):
        raise RuntimeError('Invalid current opposite-fold offsets')
    return offsets['even'] == 0.0 and offsets['odd'] == 0.0


def offset_tensor(torch, values, offsets):
    """A single 1xN F32 actor copy offset, broadcast over temporal context."""
    zero_offsets(offsets)  # Validate even on the literal-zero branch.
    if values.ndim != 2 or values.shape[1] < 2:
        raise RuntimeError('Invalid actor world-fold context')
    result = torch.empty((1, values.shape[1]), dtype=values.dtype, device=values.device)
    result[:, 0::2] = offsets['even']
    result[:, 1::2] = offsets['odd']
    if not bool(torch.isfinite(result).all()):
        raise RuntimeError('Nonfinite source-F32 actor offsets')
    return result


def full_constant_targets(torch, full_targets, gae, capped_tail_trace,
                          rewards, values, next_values, terminated, done,
                          capped_ratios, actor_lambda, offsets):
    """Keep first-window c0 literal Full1; current opposite-fold actor values never enter critic."""
    if not (done.dtype == torch.bool and capped_ratios.dtype == torch.float32
            and done.shape == capped_ratios.shape == rewards.shape
            and done.device == capped_ratios.device == rewards.device):
        raise RuntimeError('Invalid constant-mode actor trace masks/weights')
    if not valid_offsets(offsets) or not math.isfinite(actor_lambda):
        raise RuntimeError('Nonfinite locked constant-mode offset or actor lambda')
    if zero_offsets(offsets):
        return full_targets(rewards, values, next_values, terminated, done,
                            capped_ratios, actor_lambda)
    offset = offset_tensor(torch, values, offsets)
    actor_values = values + offset
    actor_next_values = next_values + offset
    if not all(bool(torch.isfinite(x).all()) for x in (actor_values, actor_next_values)):
        raise RuntimeError('Nonfinite calibrated actor values')
    uncorrected_adv, _ = gae(rewards, actor_values, actor_next_values,
                            terminated, done, .99, actor_lambda)
    adv, actor_ret = capped_tail_trace(rewards, actor_values, actor_next_values,
                                     terminated, done, capped_ratios, .99, actor_lambda)
    _, uncorrected_critic_ret = gae(rewards, values, next_values, terminated, done, .99, .95)
    _, ret = capped_tail_trace(rewards, values, next_values, terminated, done, capped_ratios, .99, .95)
    return adv, ret, adv - uncorrected_adv, ret - uncorrected_critic_ret, actor_ret


def nested_cpu_snapshot(torch, obj):
    """Independent storage, with no RNG draws or mutation of the live state."""
    if isinstance(obj, torch.Tensor):
        return obj.detach().cpu().clone()
    if isinstance(obj, dict):
        return {key: nested_cpu_snapshot(torch, value) for key, value in obj.items()}
    if isinstance(obj, list):
        return [nested_cpu_snapshot(torch, value) for value in obj]
    if isinstance(obj, tuple):
        return tuple(nested_cpu_snapshot(torch, value) for value in obj)
    return obj


def first_window_state(torch, np, model, optimizer, normal, rnormal, feedback,
                       env, ev, buffers, raw, obs, discounted, counts, collected_time, filled):
    """Concrete future old-Full1 observer contract; not a restorable physics checkpoint.

    Compare listed state and all visible tensor attributes of each environment.
    Opaque Warp data/internal integration arrays are not claimed to be saved.
    """
    def environment(e):
        return {'visible_tensors': {key: value for key, value in vars(e).items()
                                   if isinstance(value, torch.Tensor)},
                'generator_state': e.rng.get_state()}
    np_state = np.random.get_state()
    payload = {'schema': 'fullcm1_zero_offset_first_window_state_gpu1_v2',
               'model': model.state_dict(), 'optimizer': optimizer.state_dict(),
               'obs_stats': normal.state_dict(), 'reward_stats': rnormal.state_dict(),
               'training_return_feedback': feedback.state_dict(),
               'training_environment': environment(env), 'evaluation_environment': environment(ev),
               'buffers': buffers, 'raw': raw, 'obs': obs, 'discounted': discounted,
               'optimizer_steps': counts.copy(), 'collected_time': collected_time, 'filled': filled,
               'cpu_rng': torch.get_rng_state(),
               'cuda_rng': {'cuda:1': torch.cuda.get_rng_state('cuda:1')},
               'numpy_rng': (np_state[0], np_state[1].tobytes(), *np_state[2:])}
    return nested_cpu_snapshot(torch, payload)
