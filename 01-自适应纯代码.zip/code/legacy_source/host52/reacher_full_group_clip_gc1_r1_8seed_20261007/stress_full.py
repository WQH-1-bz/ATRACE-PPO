"""Independent frozen-checkpoint six-condition stress child, excluded from primary AUC."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys

sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source_full'))
import torch
from train_noisy_warp import ActorCritic,RunningStats,evaluate
from locomotion_warp import LocomotionWarp
from noisy_observation import NoisyObservation

CONDITIONS=(('none',0.),('gaussian',.10),('gaussian',.15),('gaussian',.30),('multiplicative',.20),('multiplicative',.30))

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    p=argparse.ArgumentParser();p.add_argument('--job',type=Path,required=True);p.add_argument('--device',default='cuda:1');p.add_argument('--verify-existing',action='store_true');a=p.parse_args()
    assert a.device=='cuda:1' and torch.cuda.is_available()
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True);torch.cuda.set_device(a.device)
    path=a.job.resolve();checkpoint=path/'latest.pt';digest=sha(checkpoint)
    if a.verify_existing:
        assert (path/'stress_evaluation.json').is_file() and (path/'STRESS_CHILD_VERIFIED.json').is_file()
    else:assert not(path/'stress_evaluation.json').exists() and not(path/'STRESS_CHILD_VERIFIED.json').exists()
    saved=torch.load(checkpoint,map_location=a.device,weights_only=False);config=json.loads((path/'config.json').read_text())
    assert saved['config']==config and config['algorithm']=='Full' and saved['steps']==config['effective_steps']
    seed=config['seed'];torch.random.default_generator.manual_seed(seed);torch.cuda.manual_seed(seed)
    env=NoisyObservation(LocomotionWarp(32,a.device,seed+10000,task='Reacher'),'none',0.,seed+300000)
    model=ActorCritic(env.obs_dim,env.action_dim).to(a.device);model.load_state_dict(saved['model']);model.eval()
    stats=RunningStats((env.obs_dim,),a.device);stats.load_state_dict(saved['obs_stats'])
    before={k:v.detach().clone() for k,v in model.state_dict().items()};normal_before={k:v.detach().clone() for k,v in stats.state_dict().items()}
    results=[]
    with torch.no_grad():
        for mode,scale in CONDITIONS:
            env.env.rng.manual_seed(seed+400000);env.configure(mode,scale,seed+500000)
            result=evaluate(model,stats,env)
            assert len(result['returns'])==32 and result['lengths']==[50]*32
            results.append({'mode':mode,'scale':scale,**result})
    assert all(torch.equal(v,model.state_dict()[k]) for k,v in before.items())
    assert all(torch.equal(v,stats.state_dict()[k]) for k,v in normal_before.items())
    assert sha(checkpoint)==digest
    out=path/'stress_evaluation.json'
    if a.verify_existing:
        assert json.loads(out.read_text())==results,'Frozen-policy stress native child replay differs'
        proof=json.loads((path/'STRESS_CHILD_VERIFIED.json').read_text())
        assert proof['checkpoint_sha256']==digest and proof['stress_sha256']==sha(out)
        print(json.dumps({'state':'passed','frozen_stress_recomputed_exact':True,'checkpoint_sha256':digest,'training_transitions':0,'optimizer_calls':0}));return
    out.write_text(json.dumps(results,indent=2,allow_nan=False)+'\n')
    proof={'state':'passed','child_process':True,'child_pid':os.getpid(),'checkpoint_sha256':digest,
           'stress_sha256':sha(out),'conditions':[list(x) for x in CONDITIONS],'device':a.device,
           'frozen_model_normalizers_exact_after_all_conditions':True,'optimizer_calls':0,'training_transitions':0,
           'primary_evaluation_or_auc_used':False,'physics_reset_seed':seed+400000,'noise_seed':seed+500000}
    (path/'STRESS_CHILD_VERIFIED.json').write_text(json.dumps(proof,indent=2,allow_nan=False)+'\n')

if __name__=='__main__':main()
