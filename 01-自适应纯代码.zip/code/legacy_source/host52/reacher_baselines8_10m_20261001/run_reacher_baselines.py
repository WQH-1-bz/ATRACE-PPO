"""Deterministic 10M Reacher controls: eight methods, all eight paired seeds."""
import argparse
import csv
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time
import traceback
import torch

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source'
OLD = ROOT.parent / 'reacher_trial_20261001'
PREVIOUS = ROOT.parent / 'reacher_baselines8_20261001'
PYTHON = ROOT / '.venv/bin/python'
METHODS = ('fixed95', 'fixed90', 'fixed99', 'linear', 'critic_aware', 'gradient_ppo', 'reward_profiling', 'pae')
EXTERNAL = ('critic_aware', 'gradient_ppo', 'reward_profiling', 'pae')
SEEDS = tuple(range(21, 29))
BUDGET, SHORT, GPU, MAX_ACTIVE = 10027008, 524288, 1, 8
DET = {'torch': True, 'warp': 'run_to_run', 'warp_max_records': 8, 'cublas_workspace_config': ':4096:8'}
ENV = {**os.environ, 'PYTHONUNBUFFERED': '1', 'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1',
       'DPO_TORCH_DETERMINISTIC': '1', 'DPO_WARP_DETERMINISTIC': 'run_to_run',
       'DPO_WARP_DETERMINISTIC_MAX_RECORDS': '8', 'CUBLAS_WORKSPACE_CONFIG': ':4096:8',
       'XDG_CACHE_HOME': str(ROOT/'cache'), 'WARP_CACHE_PATH': str(ROOT/'cache/warp'),
       'CUDA_CACHE_PATH': str(ROOT/'cache/cuda'), 'TORCH_HOME': str(ROOT/'cache/torch'), 'TMPDIR': str(ROOT/'tmp')}
sys.path.insert(0, str(SOURCE))
from external_baseline_algorithms import critic_lambda


def write(p, data):
    q = p.with_suffix(p.suffix+'.tmp')
    q.write_text(json.dumps(data, indent=2, allow_nan=False)+'\n'); q.replace(p)


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def process_identity(pid):
    p = Path('/proc')/str(pid)
    try:
        state = (p/'stat').read_text().split(') ', 1)[1].split()
        if state[0] == 'Z': return None
        return {'pid': pid, 'start_ticks': state[19], 'cmdline': (p/'cmdline').read_bytes().replace(b'\0', b' ').decode()}
    except FileNotFoundError:
        return None


class Adopted:
    def __init__(self, identity): self.pid=identity['pid']; self.identity=identity
    def poll(self):
        current=process_identity(self.pid)
        if current is None: return 0
        assert current == self.identity, ('PID identity changed', self.pid)
        return None


def snapshot():
    raw=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'],text=True)
    free={int(x.split(',')[0]):int(x.split(',')[1]) for x in raw.splitlines() if x.strip()}
    raw=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,used_gpu_memory','--format=csv,noheader,nounits'],text=True)
    used={int(x.split(',')[0]):int(x.split(',')[1]) for x in raw.splitlines() if x.strip()}
    return free,used


def command(j, short=False):
    method=j['method']; budget=SHORT if short else BUDGET
    trainer='train_pae_baseline.py' if method=='pae' else 'train_external_baseline.py' if method in EXTERNAL else 'train_internal_base.py'
    cmd=[str(PYTHON),str(SOURCE/trainer),'--out',j['path'],'--task','Reacher','--seed',str(j['seed']),
         '--device','cuda:1','--steps',str(budget),'--num-envs','1024','--rollout','64','--batch-size','1024',
         '--eval-envs','32','--eval-every','262144']
    if method in EXTERNAL: cmd+=['--method',method]
    elif method=='linear': cmd+=['--epochs','10','--lambda-mode','linear']
    else: cmd+=['--epochs','10','--lambda-mode','fixed','--fixed-lambda',str({'fixed90':.90,'fixed95':.95,'fixed99':.99}[method])]
    if method=='pae': cmd+=['--force-pae-overlap','--overlap-start-steps','0','--overlap-stop-steps',str(budget)]
    return cmd


def verify(j, short=False):
    p=Path(j['path']); method=j['method']; budget=SHORT if short else BUDGET
    updates=(1+math.ceil((budget//1024-64)/48)) if method=='pae' else budget//65536
    c=json.loads((p/'config.json').read_text()); s=json.loads((p/'summary.json').read_text()); status=json.loads((p/'status.json').read_text())
    assert c['seed']==j['seed'] and c['effective_steps']==budget and c['determinism']==DET
    assert c['num_envs']==1024 and c['rollout']==64 and c['batch_size']==1024 and c['eval_envs']==32 and c['eval_every']==262144
    assert c['device']=='cuda:1' and c['epochs']==(4 if method=='gradient_ppo' else 10)
    assert s['state']==status['state']=='completed' and s['reload_check']=='passed'
    assert s['steps']==budget and s['physics_device']=='cuda:1'
    assert (p/'latest.pt').stat().st_size>0
    rs=list(csv.DictReader((p/'progress.csv').open())); assert len(rs)==updates
    extra={}; total=budget
    if method not in EXTERNAL:
        assert c['task'].startswith('Reacher-v4') and c['noise_mode']=='none' and c['noise_scale']==0
        assert (p/'best.pt').stat().st_size>0 and (p/'stress_evaluation.json').exists()
        ls=[float(x['gae_lambda']) for x in rs]
        if method=='linear':
            assert c['lambda_mode']=='linear'
            assert all(abs(x-(.90+.09*i/(updates-1)))<1e-12 for i,x in enumerate(ls))
        else:
            value={'fixed90':.90,'fixed95':.95,'fixed99':.99}[method]
            assert c['lambda_mode']=='fixed' and c['fixed_lambda']==value and all(x==value for x in ls)
        extra['lambda_check']='passed'
    else:
        assert c['task']=='Reacher' and c['method']==method and s['training_transitions']==budget
        for name, value in c['source_sha256'].items(): assert sha(SOURCE/name)==value,(method,name)
        ls=[float(x['gae_lambda_used']) for x in rs]; counts=s['optimizer_steps']
        if method=='critic_aware':
            decisions=[json.loads(x) for x in (p/'lambda_decisions.jsonl').read_text().splitlines()]
            assert len(decisions)==updates
            value=.95; previous=float('inf')
            for i, (r, progress) in enumerate(zip(decisions,rs),1):
                assert r['update']==i and r['used']==value and float(progress['gae_lambda_used'])==value
                assert r['previous_loss']==(None if math.isinf(previous) else previous)
                previous=r['last_minibatch_value_loss']; value=critic_lambda(value,float('inf') if i==1 else decisions[i-2]['last_minibatch_value_loss'],previous,i/updates)
                assert abs(r['next']-value)<1e-12 and float(progress['gae_lambda_next'])==r['next'] and .7<=value<=.99
            assert counts['actor']==updates*5*64 and counts['critic']==updates*10*64 and counts['h']==0
            extra['controller_replay']='passed'
        elif method=='gradient_ppo':
            assert counts=={'actor':updates*4*64,'critic':updates*4*64,'h':updates*4*64}
            ckpt=torch.load(p/'latest.pt',map_location='cpu',weights_only=False)
            assert ckpt['hnet'] and set(ckpt['optimizers'])=={'actor','critic','h'}
            assert all(x==.95 for x in ls); extra['auxiliary_optimizer_check']='passed'
        elif method=='reward_profiling':
            decisions=[json.loads(x) for x in (p/'profiling_decisions.jsonl').read_text().splitlines()]
            n=min(10,updates); boundaries={math.ceil(k*updates/n)*65536 for k in range(1,n+1)}
            assert len(decisions)==n and {r['steps'] for r in decisions}==boundaries
            for r in decisions:
                assert r['chosen']==('old' if r['old']['mean']>=r['new']['mean'] else 'new')
                assert r['old']['lengths']==r['new']['lengths']==[50]*5 and r['extra_transitions']==500
            assert all(x==.95 for x in ls)
            total=budget+500*n; assert s['total_algorithm_transitions']==total
            extra['profiling_decision_replay']='passed'
        elif method=='pae':
            assert c['force_pae_overlap'] and c['pae_prefix']==48 and c['pae_tail']==16
            assert not any(c[x] for x in ['adaptive_kl','readiness_boost','staged_full','adaptive_overlap'])
            assert c['overlap_start_steps']==0 and c['overlap_stop_steps']==budget
            assert all(x['overlap_active'].lower()=='true' for x in rs) and all(x==.95 for x in ls)
            assert s['pae_retained_per_world']==0; extra['overlap_check']='passed'
        if method!='reward_profiling': assert s['total_algorithm_transitions']==budget
    initial=json.loads((p/'initial_evaluation.json').read_text()); ev=[json.loads(x) for x in (p/'evaluations.jsonl').read_text().splitlines()]
    for e in [initial,*ev,s['final_eval']]:
        assert len(e['returns'])==32 and e['lengths']==[50]*32 and all(math.isfinite(x) for x in e['returns'])
    pts=[(0,initial['mean'])]+[(e['steps'],e['mean']) for e in ev]
    assert pts[-1][0]==budget and ev[-1]['mean']==s['final_eval']['mean']
    assert all(a[0]<b[0] for a,b in zip(pts,pts[1:]))
    auc=sum((b[0]-a[0])*(a[1]+b[1])/2 for a,b in zip(pts,pts[1:]))/budget
    assert math.isfinite(auc) and math.isfinite(s['final_eval']['mean'])
    if method in EXTERNAL: assert abs(auc-s['normalized_return_auc'])<1e-10
    return {'final_return':s['final_eval']['mean'],'auc':auc,'initial_return':initial['mean'],'updates':updates,
            'steps':budget,'total_algorithm_transitions':total,'lambda_min':min(ls),'lambda_max':max(ls),**extra}


def differences(a,b,path=''):
    if isinstance(a,torch.Tensor): return [] if isinstance(b,torch.Tensor) and a.dtype==b.dtype and a.shape==b.shape and torch.equal(a,b) else [path]
    if isinstance(a,dict):
        if not isinstance(b,dict) or a.keys()!=b.keys(): return [path+'.keys']
        return [d for k in a for d in differences(a[k],b[k],path+'.'+str(k))]
    if isinstance(a,(list,tuple)):
        if type(a)!=type(b) or len(a)!=len(b): return [path+'.length']
        return [d for i,(x,y) in enumerate(zip(a,b)) for d in differences(x,y,path+'.'+str(i))]
    return [] if a==b else [path]


def exact_repeat(a,b,method):
    a=Path(a); b=Path(b)
    x=torch.load(a/'latest.pt',map_location='cpu',weights_only=False); y=torch.load(b/'latest.pt',map_location='cpu',weights_only=False)
    x.pop('config',None); y.pop('config',None); errors=differences(x,y)
    files=['initial_evaluation.json','evaluations.jsonl']
    if method=='critic_aware': files+=['lambda_decisions.jsonl']
    if method=='reward_profiling': files+=['profiling_decisions.jsonl']
    for n in files:
        if (a/n).read_bytes()!=(b/n).read_bytes(): errors.append(n)
    xs=list(csv.DictReader((a/'progress.csv').open())); ys=list(csv.DictReader((b/'progress.csv').open())); assert len(xs)==len(ys)
    for x,y in zip(xs,ys):
        for k in x:
            if k not in ('elapsed_seconds','steps_per_second') and x[k]!=y[k]: errors.append('progress.'+k)
    assert not errors,errors
    return {'state':'passed','checkpoint_exact':True,'decisions_and_evaluations_byte_exact':True,'non_timing_progress_exact':True}


def prepare():
    hashes=json.loads((ROOT/'source_hashes.json').read_text()); previous_hashes=json.loads((PREVIOUS/'source_hashes.json').read_text())
    assert hashes==previous_hashes,'Training source must remain byte-identical across budget change'
    for n,h in hashes.items(): assert sha(SOURCE/n)==h,n
    audit=json.loads((OLD/'SEMANTIC_AUDIT.json').read_text()); gate=json.loads((OLD/'PREFLIGHT_VERIFIED.json').read_text())
    assert audit['state']==gate['state']=='passed' and not audit['failures']
    assert gate['same_gpu_exact_repeats']==2
    prior=json.loads((PREVIOUS/'HANDOFF_10M.json').read_text()); prior_jobs={j['id']:j for j in prior['jobs']}
    assert prior['state']=='running' and prior['failure'] is None and len(prior['gates'])==8
    jobs=[]; legacy=[]
    for seed in SEEDS:
        for method in METHODS:
            jid=f'Reacher__{method}__seed{seed}'; j={'id':jid,'method':method,'seed':seed,'path':str(ROOT/'runs'/jid),'state':'pending','origin':'host52_fresh10M'}
            assert not Path(j['path']).exists(),('Formal10M output must start fresh',jid)
            jobs.append(j)
    for jid, info in prior['active'].items():
        assert not info['smoke'] and info['gpu']==GPU
        pid=info['pid']; identity=process_identity(pid); old=prior_jobs[jid]
        item={'id':jid,'pid':pid,'path':old['path'],'budget':2031616,'scope':'separate2Mpilot, excluded from10Mmatrix'}
        if identity:
            assert old['path'] in identity['cmdline'] and '--steps 2031616' in identity['cmdline']
            item.update(identity=identity,state='running')
        else: item['state']='finished_outside_baseline_scope'
        legacy.append(item)
    gates={}; estimates={}; smoke_done={}
    for method in METHODS:
        old_gate=prior['gates'][method]; assert old_gate['state']=='passed'
        paths=old_gate.get('paths',[str(OLD/'runs'/f'smoke__fixed95__{rep}') for rep in ('a','b')])
        assert len(paths)==2
        for rep,path in zip(('a','b'),paths):
            j={'method':method,'seed':91081,'path':path}
            j['metrics']=verify(j,True); smoke_done[(method,rep)]=j
        repeat=exact_repeat(paths[0],paths[1],method)
        peak=old_gate.get('peak_mib',gate['peak_mib']); assert peak>0
        gates[method]={**repeat,'peak_mib':peak,'paths':paths,'origin':'verified identical-source8update gate reuse'}
        estimates[method]=max(4000,peak+256)
    write(ROOT/'REUSED_SMOKES_VERIFIED.json',{'state':'passed','methods':gates,'short_budget':SHORT,'source_hashes':hashes})
    write(ROOT/'PREPARE_PASSED.json',{'state':'passed','total_unique_runs':64,'seeds':SEEDS,'methods':METHODS,'budget':BUDGET,
          'formal_runs_reused':0,'fresh_initializations':64,'legacy_drain':legacy,'semantic_gate_reused_from':str(OLD),
          'short_exact_pairs_reused':8,'source_hashes':hashes})
    return hashes,jobs,legacy,gates,estimates,smoke_done


def main(prepare_only=False):
    hashes,jobs,legacy,gates,estimates,smoke_done=prepare()
    if prepare_only: print('64-row handoff preflight passed',flush=True); return
    assert not (ROOT/'suite_status.json').exists()
    started=time.time(); active={}; failure=None
    pending_smokes=[]
    for j in jobs:
        if j['state']=='running': active[j['id']]=(Adopted(j['identity']),None,j)
    versions={n:importlib.metadata.version(n) for n in ('torch','mujoco','mujoco-warp','warp-lang','gymnasium','numpy')}
    write(ROOT/'environment.json',{'versions':versions,'source_hashes':hashes,'device':'physical GPU1','budget':BUDGET,
          'determinism':DET,'external_scope':'matched GPU backbone ports; not original-paper numerical reproductions'})

    def status(state):
        write(ROOT/'suite_status.json',{'state':state,'total':64,'formal_budget':BUDGET,'completed_count':sum(j['state']=='completed' for j in jobs),
              'active':{k:{'pid':v[0].pid,'method':v[2]['method'],'smoke':v[2].get('short',False),'gpu':GPU} for k,v in active.items()},
              'jobs':jobs,'gates':gates,'pending_smokes':[j['id'] for j in pending_smokes],
              'smoke_completed':[f'{m}__{rep}' for m,rep in smoke_done],'legacy_drain':legacy,
              'failure':failure,'elapsed_seconds':time.time()-started,'max_workers_gpu1':MAX_ACTIVE,'estimates_mib':estimates})

    status('running')
    while True:
        for jid,(proc,handle,j) in list(active.items()):
            code=proc.poll()
            if code is None: continue
            if handle: handle.close()
            del active[jid]
            try:
                assert code==0,(jid,code); j['metrics']=verify(j,j.get('short',False)); j['state']='completed'
                if j.get('short'):
                    smoke_done[(j['method'],j['rep'])]=j
                    pair=[smoke_done.get((j['method'],rep)) for rep in ('a','b')]
                    if all(pair):
                        result=exact_repeat(pair[0]['path'],pair[1]['path'],j['method'])
                        peak=max(x['peak_mib'] for x in pair); assert peak>0
                        estimates[j['method']]=max(4000,peak+256)
                        gates[j['method']]={**result,'peak_mib':peak,'paths':[x['path'] for x in pair]}
                        write(ROOT/'SMOKE_VERIFIED.json',{'state':'passed' if len(gates)==8 else 'partial','methods':gates})
            except Exception as exc:
                j['state']='failed'; failure={'id':jid,'error':repr(exc),'log':j.get('log')}
        for j in legacy:
            if j['state']=='running' and Adopted(j['identity']).poll() is not None:
                j['state']='finished_outside_baseline_scope'; j['note']='Preserved separately; never counted in baseline matrix'
        if all(j['state']=='completed' for j in jobs):
            for n,h in hashes.items(): assert sha(SOURCE/n)==h,n
            rows=[{'task':'Reacher','method':j['method'],'seed':j['seed'],'path':j['path'],'origin':j['origin'],**verify(j)} for j in jobs]
            assert len({(r['method'],r['seed']) for r in rows})==64
            summary={}
            for method in METHODS:
                rs=[r for r in rows if r['method']==method]; assert len(rs)==8
                summary[method]={k:f(r[field] for r in rs) for k,field,f in [('final_mean','final_return',statistics.mean),('final_sd','final_return',statistics.stdev),('auc_mean','auc',statistics.mean),('auc_sd','auc',statistics.stdev)]}
            write(ROOT/'ANALYSIS.json',{'state':'completed','total_unique_runs':64,'task':'Reacher-v4 semantics GPU backend','seeds':SEEDS,
                  'rows':rows,'summary':summary,'external_methods':EXTERNAL,'baseline_methods':METHODS[:5],
                  'deduplication':'critic_aware is one shared eight-seed cell in both comparison tables',
                  'formal_budget':BUDGET,'scope':'Uniform10M fresh-initialization controls; no2M results mixed; all eight seeds retained; no automatic tuning'})
            status('completed'); return
        if failure and not active: status('failed'); raise SystemExit(1)
        free,used=snapshot()
        for proc,_,j in active.values():
            if j.get('short'): j['peak_mib']=max(j['peak_mib'],used.get(proc.pid,0))
        live_legacy=[j for j in legacy if j['state']=='running']
        if not failure and len(active)+len(live_legacy)<MAX_ACTIVE:
            # Method gates consume initial slots; once a gate passes, its formal rows are eligible.
            choices=pending_smokes+[j for j in jobs if j['state']=='pending' and j['method'] in gates]
            reserved=sum(max(0,estimates.get(j['method'],6000)-used.get(proc.pid,0)) for proc,_,j in active.values())
            reserved+=sum(max(0,4000-used.get(j['pid'],0)) for j in live_legacy)
            for j in choices:
                estimate=estimates.get(j['method'],6000)
                if free[GPU]-reserved<estimate+512: continue
                log=ROOT/(j['id']+'.log'); handle=log.open('x')
                proc=subprocess.Popen(command(j,j.get('short',False)),env=ENV,cwd=SOURCE,stdout=handle,stderr=subprocess.STDOUT)
                j.update(state='running',pid=proc.pid,gpu=GPU,log=str(log)); active[j['id']]=(proc,handle,j)
                if j.get('short'): pending_smokes.remove(j)
                break
        status('attention_required' if failure else 'running'); time.sleep(5)


if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--prepare-only',action='store_true'); args=parser.parse_args()
    try: main(args.prepare_only)
    except BaseException as exc:
        if not isinstance(exc,SystemExit):
            write(ROOT/'LAUNCH_ERROR.json',{'state':'failed','error':repr(exc)}); traceback.print_exc()
            p=ROOT/'suite_status.json'
            if p.exists():
                s=json.loads(p.read_text()); s.update(state='failed',failure={'error':repr(exc)}); write(p,s)
        raise
