"""Local lambda direction from a common held-out surrogate after virtual updates."""
import copy
import math
import torch


@torch.enable_grad()
def choose_direction(model, optimizer, obs, actions, old_log, rewards, values,
                     next_values, terminated, done, current, gae_fn, batch_size=1024,
                     candidates=None):
    if obs.shape[1] < 4:
        raise ValueError("Need at least four independent environments")
    candidates = sorted(set([max(.85,current-.02),current,min(.99,current+.02)])) if candidates is None else list(candidates)
    # Split entire environment histories, preserving all adjacent time steps together.
    train_obs = obs[:, ::2].flatten(0,1).detach()
    train_actions = actions[:, ::2].flatten(0,1).detach()
    train_log = old_log[:, ::2].flatten().detach()
    test_obs = obs[:, 1::2].flatten(0,1).detach()
    test_actions = actions[:, 1::2].flatten(0,1).detach()
    test_log = old_log[:, 1::2].detach()
    with torch.no_grad():
        reference,_ = gae_fn(rewards,values,next_values,terminated,done,.99,1.)
        reference = reference[:,1::2]
        reference = (reference-reference.mean())/(reference.std(unbiased=False)+1e-8)
    scores = []
    for candidate in candidates:
        shadow = copy.deepcopy(model)
        opt = torch.optim.Adam(shadow.parameters(),lr=3e-4,eps=1e-5)
        opt.load_state_dict(copy.deepcopy(optimizer.state_dict()))
        with torch.no_grad():
            advantage,_ = gae_fn(rewards,values,next_values,terminated,done,.99,float(candidate))
            advantage = advantage[:,::2].flatten().detach()
        # One identical virtual epoch; fixed minibatch order consumes no experiment RNG.
        for start in range(0,len(train_obs),batch_size):
            sl=slice(start,start+batch_size)
            dist=shadow.distribution(train_obs[sl])
            ratio=(dist.log_prob(train_actions[sl]).sum(-1)-train_log[sl]).exp()
            adv=advantage[sl]
            adv=(adv-adv.mean())/(adv.std(unbiased=False)+1e-8)
            loss=torch.maximum(-adv*ratio,-adv*ratio.clamp(.8,1.2)).mean()
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(shadow.parameters(),.5)
            opt.step()
        with torch.no_grad():
            log=shadow.distribution(test_obs).log_prob(test_actions).sum(-1).reshape(test_log.shape)
            lr=log-test_log; ratio=lr.exp()
            # Identical reference advantage for all candidates, never each one's own target.
            per_world=torch.minimum(ratio*reference,ratio.clamp(.8,1.2)*reference).mean(0)
            if not bool(torch.isfinite(per_world).all()):
                raise RuntimeError("Non-finite lookahead candidate score")
            scores.append((float(candidate),per_world.detach().clone(),float(((ratio-1)-lr).mean())))
        del shadow,opt
    base = next(score for candidate,score,_ in scores if abs(candidate-current)<1e-10)
    diagnostics=[]; chosen=current; best_margin=0.
    for candidate,score,kl in scores:
        differences=score-base
        mean=float(differences.mean())
        se=float(differences.std(unbiased=True))/math.sqrt(len(differences))
        # Paired per-world uncertainty heuristic, not a formal significance test.
        qualifies=mean>max(1e-6,2*se)
        diagnostics.append({'lambda':candidate,'score':float(score.mean()),'delta_vs_current':mean,
                            'paired_se':se,'virtual_kl':kl,'qualifies':qualifies})
        if qualifies and mean>best_margin:
            chosen,best_margin=candidate,mean
    direction=1 if chosen>current+1e-10 else (-1 if chosen<current-1e-10 else 0)
    return direction,{'current_lambda':current,'chosen_candidate':chosen,'direction':direction,
                     'candidates':diagnostics,'heldout_worlds':len(base),
                     'reference_lambda':1.,'virtual_epochs':1}
