"""Separate per-step additive and per-episode multiplicative observation corruptions."""
import torch

class NoisyObservation:
    def __init__(self, env, mode='none', scale=0., seed=0):
        self.env, self.mode, self.scale = env, mode, scale
        self.noise_rng = torch.Generator(device=env.device).manual_seed(seed)
        self.factor = torch.ones((env.num_envs,1),device=env.device)
    def __getattr__(self, key):
        return getattr(self.env,key)
    def configure(self, mode, scale, seed):
        if mode not in ['none','gaussian','multiplicative'] or scale < 0:
            raise ValueError('Invalid observation corruption')
        self.mode,self.scale=mode,scale
        self.noise_rng.manual_seed(seed)
    def _factor_reset(self, mask):
        if self.mode=='multiplicative':
            sample=1+self.scale*(2*torch.rand(self.factor.shape,device=self.device,generator=self.noise_rng)-1)
            self.factor.copy_(torch.where(mask[:,None],sample,self.factor))
    def corrupt(self, obs):
        if self.mode=='gaussian' and self.scale>0:
            return obs+torch.randn(obs.shape,device=self.device,generator=self.noise_rng)*self.scale
        if self.mode=='multiplicative':
            return obs*self.factor
        return obs
    def reset(self):
        obs=self.env.reset()
        self._factor_reset(torch.ones(self.num_envs,device=self.device,dtype=torch.bool))
        return self.corrupt(obs)
    def step(self, actions):
        obs,reward,term,trunc,info=self.env.step(actions)
        # Bootstrap sees the exact same noisy next observation as the policy when not done.
        terminal=self.corrupt(info['terminal_observation'])
        done=term|trunc
        self._factor_reset(done)
        reset_obs=self.corrupt(obs)
        obs=torch.where(done[:,None],reset_obs,terminal)
        return obs,reward,term,trunc,{**info,'terminal_observation':terminal}
