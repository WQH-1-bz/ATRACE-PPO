"""Lambda step control with fixed, scheduled, entropy or external directions."""
from dataclasses import dataclass, field, asdict
import math


@dataclass
class LambdaControl:
    mode: str = "fixed"
    value: float = .95
    direction: int = 0
    td_reference: float = 0.
    history: list = field(default_factory=list)
    fixed_value: float = .95

    def step(self, update, total_updates, entropy, td_q90):
        if not (math.isfinite(entropy) and math.isfinite(td_q90) and td_q90 >= 0):
            raise ValueError("Invalid controller signal")
        self.history = (self.history + [entropy])[-8:]
        reference = self.td_reference if self.td_reference > 0 else max(td_q90, 1e-8)
        score, step_size = 0., 0.
        old = self.value
        if self.mode == "fixed":
            if not 0 <= self.fixed_value <= 1:
                raise ValueError("fixed_value must be in [0, 1]")
            self.value = self.fixed_value
        elif self.mode == "linear":
            self.value = .90 + .09 * (update - 1) / max(1, total_updates - 1)
        elif self.mode in ["minimal", "lookahead"]:
            # Eight samples ordered old -> new; direction refreshed every four updates.
            if len(self.history) == 8:
                center = sum(self.history) / 8
                slope = sum((i - 3.5) * (h - center) for i, h in enumerate(self.history)) / 42
                scale = math.sqrt(sum((h - center)**2 for h in self.history) / 8)
                score = slope * 7 / max(scale, 1e-6)
                if self.mode == "minimal" and update % 4 == 0:
                    self.direction = 1 if score < -.5 else (-1 if score > .5 else 0)
                step_size = .003 / (1 + td_q90 / reference)
                self.value = min(.99, max(.85, self.value + self.direction * step_size))
        else:
            raise ValueError(self.mode)
        self.td_reference = .9 * reference + .1 * td_q90
        return {"gae_lambda": self.value, "lambda_delta": self.value - old,
                "lambda_direction": self.direction, "lambda_step_size": step_size,
                "entropy_trend_score": score, "signal_entropy": entropy,
                "td_abs_q90": td_q90, "td_reference": reference}

    def state_dict(self):
        return asdict(self)
