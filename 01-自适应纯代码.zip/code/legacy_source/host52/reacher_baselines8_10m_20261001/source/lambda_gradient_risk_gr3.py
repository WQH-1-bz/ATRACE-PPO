"""Experimental lambda selection from projected policy-gradient risk.
Risk is relative to a bootstrapped lambda=1 reference, NOT true gradient MSE.
No environment samples, shadow optimizer, or model mutation.
"""
import math
import torch


def normalize_advantage(adv):
    return (adv-adv.mean())/adv.std(unbiased=False).clamp_min(1e-8)

def minibatch_variance(g,second,steps_per_world,batch_size):
    # Conditional finite-population variance trace of a without-replacement
    # minibatch mean, given this rollout and fixed normalization/Fisher.
    m=g.shape[0]*steps_per_world
    if batch_size<=0:raise ValueError('Positive batch size required')
    b=min(batch_size,m)
    if m<=1 or b==m:return g.new_zeros(())
    population_variance=(second.mean()-g.mean(0).square().sum()).clamp_min(0.)
    return population_variance*(m-b)/(b*(m-1))


def risk(g,reference,second=None,steps_per_world=64,batch_size=1024):
    n=g.shape[0]
    if n<2:raise ValueError('Need independent world histories')
    d=g-reference
    # Unbiased squared difference of expectations + variance of sample mean,
    # under independent world-gradient observations and fixed scaling.
    base=d.mean(0).square().sum()-d.var(0,unbiased=True).sum()/n+g.var(0,unbiased=True).sum()/n
    return base if second is None else base+minibatch_variance(g,second,steps_per_world,batch_size)

@torch.no_grad()
def select_target(model,obs,actions,rewards,values,next_values,terminated,done,current,gae_fn,groups=16,batch_size=1024):
    t,n,_=obs.shape
    if n<groups or n%groups:raise ValueError('World count must be divisible by jackknife groups')
    features=model.actor[:-1](obs)
    features=torch.cat([features,torch.ones_like(features[...,:1])],-1)
    mean=model.actor[-1](features[...,:-1]);inv_var=(-2*model.log_std).exp()
    score_mean=(actions-mean)*inv_var
    score_std=(actions-mean).square()*inv_var-1
    # Common diagonal Fisher estimate in actor output-layer/log-std subspace.
    fw=torch.einsum('tna,tnh->ah',score_mean.square(),features.square())/(t*n)
    fs=score_std.square().mean((0,1))
    fisher=torch.cat([fw.flatten(),fs]).clamp_min(1e-8).sqrt()
    # Per-transition squared norm without materializing [T,N,A,H] gradients.
    score_norm2=torch.einsum('tna,tnh,ah->tn',score_mean.square(),features.square(),fw.clamp_min(1e-8).reciprocal())
    score_norm2+=(score_std.square()/fs.clamp_min(1e-8)).sum(-1)
    reference,_=gae_fn(rewards,values,next_values,terminated,done,.99,1.)
    def gradient(adv):
        adv=normalize_advantage(adv)
        weights=torch.einsum('tn,tna,tnh->nah',adv,score_mean,features)/t
        std=(adv.unsqueeze(-1)*score_std).mean(0)
        return torch.cat([weights.flatten(1),std],-1)/fisher,(adv.square()*score_norm2).mean(0)
    refg,_=gradient(reference)
    candidates=sorted(set([.85,.90,.95,.99,float(current)]));gs={}
    for lam in candidates:
        adv,_=gae_fn(rewards,values,next_values,terminated,done,.99,float(lam));gs[lam]=gradient(adv)
    base=risk(gs[current][0],refg,gs[current][1],t,batch_size);rows=[];chosen=current;best=0.
    idx=torch.arange(n,device=obs.device)
    for lam,(g,second) in gs.items():
        raw=risk(g,refg,second,t,batch_size);delta=base-raw
        leave=[]
        for fold in range(groups):
            mask=idx%groups!=fold
            leave.append(risk(gs[current][0][mask],refg[mask],gs[current][1][mask],t,batch_size)-risk(g[mask],refg[mask],second[mask],t,batch_size))
        leave=torch.stack(leave)
        se=((groups-1)/groups*((leave-leave.mean()).square().sum())).sqrt()
        good=float(delta)>max(1e-8,2*float(se))
        rows.append({'lambda':lam,'estimated_risk':float(raw),'improvement_vs_current':float(delta),'jackknife_se':float(se),'qualifies':good,'minibatch_variance':float(minibatch_variance(g,second,t,batch_size))})
        if good and float(delta)>best:chosen=lam;best=float(delta)
    if not all(math.isfinite(v) for row in rows for v in [row['estimated_risk'],row['improvement_vs_current'],row['jackknife_se']]):raise RuntimeError('Nonfinite gradient-risk estimate')
    return chosen,{'current_lambda':current,'target_lambda':chosen,'candidates':rows,'worlds':n,'jackknife_groups':groups,'reference_lambda':1.,'risk_scope':'rollout risk plus conditional minibatch variance','minibatch_size':batch_size,'subspace':'actor output layer plus log_std','advantage_normalization':'per-candidate rollout mean/std, approximates PPO minibatch normalization','warning':'relative normalized gradient risk proxy, not true MSE or independent novelty validation'}
