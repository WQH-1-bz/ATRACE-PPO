"""Ant-only plane/capsule contact tangent compatibility with CPU MuJoCo.

Installed MJWarp falls back to a fixed tangent when the projected capsule axis
has length <0.5. CPU MuJoCo retains that direction for nondegenerate projections.
With pyramidal friction these rotations change the contact forces materially.
Apply after collision detection, before constraint construction, entirely on GPU.
No installed dependency files are modified. See ant_contact_compat_checks.json.
"""
import warp as wp
from mujoco_warp._src import collision_driver

@wp.kernel
def _align_capsule_tangents(nacon: wp.array[int], geom: wp.array[wp.vec2i], worldid: wp.array[int],
                            geom_type: wp.array[int], geom_xmat: wp.array2d[wp.mat33],
                            frame: wp.array[wp.mat33]):
    i = wp.tid()
    if i >= nacon[0]:
        return
    pair = geom[i]
    if geom_type[pair[0]] == 0 and geom_type[pair[1]] == 3:
        mat = geom_xmat[worldid[i], pair[1]]
        axis = wp.vec3(mat[0,2],mat[1,2],mat[2,2])
        f = frame[i]
        n = wp.vec3(f[0,0],f[0,1],f[0,2])
        projected = axis - wp.dot(axis,n) * n
        length = wp.length(projected)
        if length > 1.e-10:
            b = projected / length
            c = wp.cross(n,b)
            frame[i] = wp.mat33(n[0],n[1],n[2],b[0],b[1],b[2],c[0],c[1],c[2])


def install():
    if getattr(collision_driver.collision, '_ant_compat', False):
        return
    original = collision_driver.collision
    def compatible(m, d, *args, **kwargs):
        original(m, d, *args, **kwargs)
        if m.nq == 15 and m.nv == 14 and m.nu == 8:
            wp.launch(_align_capsule_tangents, dim=d.naconmax,
                      inputs=[d.nacon, d.contact.geom, d.contact.worldid, m.geom_type, d.geom_xmat, d.contact.frame],
                      device=d.qpos.device)
    compatible._ant_compat = True
    collision_driver.collision = compatible
