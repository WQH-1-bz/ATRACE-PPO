"""Auditable algorithm cores for matched-backbone external baseline ports.
See EXTERNAL_BASELINE_PROTOCOL.md for paper/code discrepancies and adaptations.
"""
import copy
import torch
from torch import nn


def critic_lambda(value, previous_loss, loss, progress):
    step = .090 - .085 * progress
    if loss < previous_loss:
        return max(.7, value - step)
    if loss > previous_loss:
        return min(.99, value + step)
    return value


def tdrc_losses(values, next_values, rewards, terminated, done, h, h_parameters,
                gamma=.99, lam=.95, beta=1.):
    # Time-major contiguous sequences; reset trace at BOTH terminal and time-limit.
    delta = rewards + gamma * (~terminated).to(values.dtype) * next_values - values
    carry = torch.zeros_like(delta[0])
    trace = []
    for t in range(delta.shape[0] - 1, -1, -1):
        carry = delta[t] + gamma * lam * (~done[t]).to(values.dtype) * carry
        trace.append(carry)
    dlambda = torch.stack(trace[::-1])
    # Paper equations (40) and (41): each parameter family has its own objective.
    critic = (h.detach() * dlambda - (dlambda - h).detach() * values).mean()
    auxiliary = .5 * (dlambda.detach() - h).square().mean()
    auxiliary = auxiliary + .5 * beta * sum(p.square().sum() for p in h_parameters)
    return critic, auxiliary, dlambda


def copy_policy(model):
    # state_dict alone aliases live tensors, so it is not an old-policy backup.
    return copy.deepcopy(model.state_dict())


def restore_lookback(model, old, new, old_mean, new_mean):
    chosen = 'old' if old_mean >= new_mean else 'new'
    model.load_state_dict(old if chosen == 'old' else new)
    return chosen


def step_loss(loss, optimizer, parameters):
    optimizer.zero_grad(set_to_none=True)
    loss.backward()
    nn.utils.clip_grad_norm_(parameters, .5, error_if_nonfinite=True)
    optimizer.step()
