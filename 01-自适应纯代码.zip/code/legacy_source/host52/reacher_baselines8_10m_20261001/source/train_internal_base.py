"""Fixed PPO entry point; Ant uses the same compatibility patch as external controls."""
import sys
from train_gradient_risk_gr3 import main
if __name__ == '__main__':
    if '--task' in sys.argv and sys.argv[sys.argv.index('--task')+1] == 'Ant':
        from ant_contact_compat import install
        install()
    main()
