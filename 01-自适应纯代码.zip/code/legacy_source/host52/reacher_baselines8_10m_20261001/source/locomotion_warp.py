"""GPU-resident locomotion with Gymnasium v4 task semantics.

MJWarp uses float32/newer MuJoCo; it is a separate backend, not a bitwise v4 replay.
"""
from pathlib import Path
import os
import gymnasium
import mujoco
import torch
import warp as wp

_WARP_DETERMINISTIC = os.environ.get("DPO_WARP_DETERMINISTIC", "").strip().lower()
if _WARP_DETERMINISTIC:
    _DETERMINISTIC_MODES = {
        "run_to_run": wp.DeterministicMode.RUN_TO_RUN,
        "gpu_to_gpu": wp.DeterministicMode.GPU_TO_GPU,
    }
    if _WARP_DETERMINISTIC not in _DETERMINISTIC_MODES:
        raise ValueError(f"Unsupported DPO_WARP_DETERMINISTIC={_WARP_DETERMINISTIC!r}")
    wp.config.deterministic = _DETERMINISTIC_MODES[_WARP_DETERMINISTIC]
    wp.config.deterministic_max_records = int(
        os.environ.get("DPO_WARP_DETERMINISTIC_MAX_RECORDS", "64")
    )

import mujoco_warp as mjw


ASSETS = Path(gymnasium.__file__).parent / "envs/mujoco/assets"
TASKS = {"Hopper": ("hopper.xml",4,.005,.001), "Walker2d": ("walker2d.xml",4,.005,.001),
         "HalfCheetah": ("half_cheetah.xml",5,.1,.1), "Ant": ("ant.xml",5,.1,.5),
         "InvertedDoublePendulum": ("inverted_double_pendulum.xml",5,.1,0.),
         "Swimmer": ("swimmer.xml",4,.1,.0001),
         "Reacher": ("reacher.xml",2,.1,1.)}
_STREAMS = {}  # One Warp wrapper per CUDA stream; duplicate wrappers unregister each other on GC.


class LocomotionWarp:
    def __init__(self, num_envs=1024, device="cuda:0", seed=0, max_steps=1000, task="Hopper"):
        self.task = task
        spec = TASKS[task]
        self.frame_skip, self.reset_scale, self.control_cost = spec[1:]
        self.xml_path = ASSETS / spec[0]
        self.num_envs, self.device, self.max_steps = num_envs, device, max_steps
        if task == "Reacher": self.max_steps = 50
        self.rng = torch.Generator(device=device).manual_seed(seed)
        wp.init()
        wp.set_device(device)
        # Use the same CUDA stream for Torch and Warp zero-copy tensors.
        # CUDA graphs cannot capture the legacy/default stream (handle 0).
        if torch.cuda.current_stream(device).cuda_stream == 0:
            torch.cuda.set_stream(torch.cuda.Stream(device=device))
        self.torch_stream = torch.cuda.current_stream(device)
        stream_key = (device, self.torch_stream.cuda_stream)
        if stream_key not in _STREAMS:
            _STREAMS[stream_key] = (self.torch_stream, wp.stream_from_torch(self.torch_stream))
        self.stream = _STREAMS[stream_key][1]
        wp.set_stream(self.stream)
        self.cpu_model = mujoco.MjModel.from_xml_path(str(self.xml_path))
        # MJWarp compiles generic tactile kernels even for sensor-free models.
        # Deterministic codegen rejects one mixed-reduction tactile kernel, so
        # bypass the semantically empty sensor stage when the model has none.
        if _WARP_DETERMINISTIC and self.cpu_model.nsensor == 0:
            self.cpu_model.opt.disableflags |= int(mujoco.mjtDisableBit.mjDSBL_SENSOR)
        self.dt = self.cpu_model.opt.timestep * self.frame_skip
        self.model = mjw.put_model(self.cpu_model)
        self.data = mjw.make_data(self.cpu_model, nworld=num_envs, nconmax=128, njmax=256)
        self.qpos = wp.to_torch(self.data.qpos)
        self.qvel = wp.to_torch(self.data.qvel)
        self.ctrl = wp.to_torch(self.data.ctrl)
        self.xipos = wp.to_torch(self.data.xipos)
        self.site_xpos = wp.to_torch(self.data.site_xpos)
        self.constraint_force = wp.to_torch(self.data.qfrc_constraint)
        self.ant_x = torch.zeros(num_envs, device=device)
        self.torso_id = mujoco.mj_name2id(self.cpu_model, mujoco.mjtObj.mjOBJ_BODY, "torso")
        self.obs_dim = self.cpu_model.nq + self.cpu_model.nv - (2 if task in ["Ant", "Swimmer"] else 1)
        if task == "InvertedDoublePendulum": self.obs_dim = 11
        if task == "Reacher":
            self.obs_dim = 11
            self.fingertip_id = mujoco.mj_name2id(self.cpu_model, mujoco.mjtObj.mjOBJ_BODY, "fingertip")
            self.target_id = mujoco.mj_name2id(self.cpu_model, mujoco.mjtObj.mjOBJ_BODY, "target")
            # Gymnasium's get_body_com returns the body frame position (xpos).
            self.xpos = wp.to_torch(self.data.xpos)
            # These are all outputs of mjw.kinematics. Masked reset preserves
            # every continuing world's last RK4-stage derived state exactly.
            self.reacher_kinematic_tensors = [
                wp.to_torch(getattr(self.data, name)) for name in (
                    "xpos", "xquat", "xanchor", "xaxis", "xmat", "xipos", "ximat",
                    "geom_xpos", "geom_xmat", "site_xpos", "site_xmat",
                )
            ]
        self.action_dim = self.cpu_model.nu
        self.qpos0 = torch.as_tensor(self.cpu_model.qpos0.copy(), device=device, dtype=torch.float32)
        self.reset_mask = torch.ones(num_envs, device=device, dtype=torch.bool)
        self.wp_reset_mask = wp.from_torch(self.reset_mask)
        self.lengths = torch.zeros(num_envs, device=device, dtype=torch.long)
        self.returns = torch.zeros(num_envs, device=device)
        self.overflow_seen = torch.zeros((), device=device, dtype=torch.bool)
        self.nonfinite_seen = torch.zeros((), device=device, dtype=torch.bool)
        self.ctrl.zero_()
        print(f"Compiling {task} physics for {num_envs} worlds on {device}...", flush=True)
        # Warm kernels, then capture fixed-shape physics and masked reset graphs.
        mjw.step(self.model, self.data)
        mjw.reset_data(self.model, self.data, self.wp_reset_mask)
        if task == "Reacher": mjw.kinematics(self.model, self.data)
        wp.synchronize()
        with wp.ScopedCapture(stream=self.stream) as capture:
            for _ in range(self.frame_skip):
                mjw.step(self.model, self.data)
        self.physics_graph = capture.graph
        with wp.ScopedCapture(stream=self.stream) as capture:
            mjw.reset_data(self.model, self.data, self.wp_reset_mask)
        self.reset_graph = capture.graph
        if task == "Reacher":
            with wp.ScopedCapture(stream=self.stream) as capture:
                mjw.kinematics(self.model, self.data)
            self.reacher_forward_graph = capture.graph
        self.reset()
        print(f"Physics ready: qpos={self.qpos.device}, ctrl={self.ctrl.device}", flush=True)

    def observation(self):
        if self.task == "Reacher":
            theta = self.qpos[:, :2]
            vec = self.xpos[:, self.fingertip_id] - self.xpos[:, self.target_id]
            return torch.cat((theta.cos(), theta.sin(), self.qpos[:, 2:], self.qvel[:, :2], vec), dim=-1)
        if self.task == "InvertedDoublePendulum":
            return torch.cat((self.qpos[:,:1],self.qpos[:,1:].sin(),self.qpos[:,1:].cos(),self.qvel.clamp(-10,10),self.constraint_force.clamp(-10,10)),dim=-1)
        skip = 2 if self.task in ["Ant", "Swimmer"] else 1
        vel = self.qvel.clamp(-10,10) if self.task in ["Hopper","Walker2d"] else self.qvel
        return torch.cat((self.qpos[:, skip:], vel), dim=-1)

    def reset(self, mask=None):
        if mask is None:
            self.reset_mask.fill_(True)
        else:
            self.reset_mask.copy_(mask)
        if self.task == "Reacher":
            previous_kinematics = [tensor.clone() for tensor in self.reacher_kinematic_tensors]
        wp.capture_launch(self.reset_graph, stream=self.stream)
        pos = self.qpos0 + (torch.rand(self.qpos.shape, device=self.device, generator=self.rng) * 2 - 1) * self.reset_scale
        vel = (torch.rand(self.qvel.shape, device=self.device, generator=self.rng) * 2 - 1) * self.reset_scale
        if self.task == "Reacher":
            # sqrt(U) radius and uniform angle are distributionally equivalent
            # to Gymnasium's square-rejection sample from the radius-0.2 disk.
            polar = torch.rand((self.num_envs, 2), device=self.device, generator=self.rng)
            radius, angle = .2 * polar[:, :1].sqrt(), 2 * torch.pi * polar[:, 1:]
            goal = radius * torch.cat((angle.cos(), angle.sin()), dim=-1)
            # Keep the open-disk condition when float32 rounding hits its edge.
            goal = torch.where(goal.norm(dim=-1, keepdim=True) >= .2,
                               goal * (1 - 4 * torch.finfo(goal.dtype).eps), goal)
            pos[:, -2:] = goal
            vel *= .05
            vel[:, -2:] = 0
        if self.task in ["Ant", "HalfCheetah", "InvertedDoublePendulum"]:
            vel = torch.randn(self.qvel.shape,device=self.device,generator=self.rng) * self.reset_scale
        self.qpos.copy_(torch.where(self.reset_mask[:, None], pos, self.qpos))
        self.qvel.copy_(torch.where(self.reset_mask[:, None], vel, self.qvel))
        if self.task == "Reacher":
            wp.capture_launch(self.reacher_forward_graph, stream=self.stream)
            for tensor, previous in zip(self.reacher_kinematic_tensors, previous_kinematics):
                mask_shape = (self.num_envs,) + (1,) * (tensor.ndim - 1)
                tensor.copy_(torch.where(self.reset_mask.view(mask_shape), tensor, previous))
        self.ant_x.copy_(torch.where(self.reset_mask, self.qpos[:,0], self.ant_x))
        self.lengths.masked_fill_(self.reset_mask, 0)
        self.returns.masked_fill_(self.reset_mask, 0)
        return self.observation()

    @torch.no_grad()
    def step(self, actions):
        if self.task == "Reacher":
            # v4 evaluates both distance and raw-action cost before physics.
            vec = self.xpos[:, self.fingertip_id] - self.xpos[:, self.target_id]
            reacher_reward = -vec.norm(dim=-1) - actions.square().sum(-1)
        actions = actions.clamp(-1, 1)
        x_before = self.ant_x.clone() if self.task == "Ant" else self.qpos[:, 0].clone()
        self.ctrl.copy_(actions)
        wp.capture_launch(self.physics_graph, stream=self.stream)
        if hasattr(self.data, "overflow"):
            self.overflow_seen.logical_or_(wp.to_torch(self.data.overflow).ne(0).any())
        self.nonfinite_seen.logical_or_(~(torch.isfinite(self.qpos).all() & torch.isfinite(self.qvel).all()))
        terminal_obs = self.observation()
        state = torch.cat((self.qpos[:, 2:], self.qvel), dim=-1)
        healthy = ((state > -100) & (state < 100)).all(-1)
        healthy &= (self.qpos[:, 1] > .7) & (self.qpos[:, 2] > -.2) & (self.qpos[:, 2] < .2)
        if self.task == "Walker2d":
            healthy = (self.qpos[:,1] > .8) & (self.qpos[:,1] < 2.) & (self.qpos[:,2] > -1.) & (self.qpos[:,2] < 1.)
        elif self.task == "HalfCheetah":
            healthy = torch.ones(self.num_envs,device=self.device,dtype=torch.bool)
        elif self.task == "Ant":
            healthy = torch.isfinite(self.qpos).all(-1) & torch.isfinite(self.qvel).all(-1) & (self.qpos[:,2] >= .2) & (self.qpos[:,2] <= 1.)
        elif self.task == "Swimmer":
            healthy = torch.ones(self.num_envs,device=self.device,dtype=torch.bool)
        elif self.task == "Reacher":
            healthy = torch.ones(self.num_envs,device=self.device,dtype=torch.bool)
        terminated = ~healthy
        # v4 pays the healthy bonus on the terminal step when termination is enabled.
        x_after = self.xipos[:,self.torso_id,0] if self.task == "Ant" else self.qpos[:,0]
        self.ant_x.copy_(x_after)
        bonus = 0. if self.task in ["HalfCheetah", "Swimmer"] else 1.
        reward = (x_after - x_before) / self.dt + bonus - self.control_cost * actions.square().sum(-1)
        if self.task == "InvertedDoublePendulum":
            x,y=self.site_xpos[:,0,0],self.site_xpos[:,0,2]
            reward=10-.01*x.square()-(y-2).square()-.001*self.qvel[:,1].square()-.005*self.qvel[:,2].square()
            terminated=y<=1
        elif self.task == "Reacher":
            reward = reacher_reward
            # A separate tensor must survive the following masked autoreset.
            terminal_obs = terminal_obs.clone()
        self.lengths.add_(1)
        self.returns.add_(reward)
        truncated = self.lengths >= self.max_steps
        done = terminated | truncated
        info = {"terminal_observation": terminal_obs, "episode_done": done,
                "episode_return": self.returns.clone(), "episode_length": self.lengths.clone()}
        obs = self.reset(done)
        return obs, reward, terminated, truncated, info

    def check_capacity(self):
        if bool(self.overflow_seen):
            raise RuntimeError("MuJoCo Warp contact/constraint capacity overflow")
        if bool(self.nonfinite_seen):
            raise RuntimeError("Non-finite GPU physics state")
