"""Remote, resumable deterministic queue for 160 external PPO baselines."""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import statistics
import subprocess
import time
import traceback

TASKS=('Hopper','Walker2d','HalfCheetah','Ant','Swimmer')
METHODS=('critic_aware','gradient_ppo','reward_profiling','pae')
SEEDS=tuple(range(21,29))
STEPS=10027008
VERSIONS={'torch':'2.8.0','mujoco':'3.12.0','mujoco-warp':'3.12.0',
          'warp-lang':'1.17.0','gymnasium':'1.2.0','numpy':'1.26.4'}
GPU_MEMORY_ESTIMATE_MIB={'Ant':11000,'Walker2d':8000,'Hopper':5000,
                         'HalfCheetah':4500,'Swimmer':4500}


class AdoptedProcess:
    """Observe an already-running trainer after its scheduler is replaced."""
    def __init__(self,pid):self.pid=pid
    def poll(self):
        try:os.kill(self.pid,0)
        except ProcessLookupError:return 0
        return None


def write(path,value):
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
    temp.replace(path)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def gpu_free():
    raw=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free',
                                 '--format=csv,noheader,nounits'],text=True)
    return {int(line.split(',')[0]):int(line.split(',')[1]) for line in raw.strip().splitlines()}


def auc(path,budget):
    initial=json.loads((path/'initial_evaluation.json').read_text())
    evaluations=[json.loads(x) for x in (path/'evaluations.jsonl').read_text().splitlines()]
    points=[(0,float(initial['mean']))]+[(int(x['steps']),float(x['mean'])) for x in evaluations]
    assert points[-1][0]==budget and all(a[0]<b[0] for a,b in zip(points,points[1:]))
    return sum((b[0]-a[0])*(a[1]+b[1])/2 for a,b in zip(points,points[1:]))/budget


def verify(path,task,method,seed,short=False):
    config=json.loads((path/'config.json').read_text())
    summary=json.loads((path/'summary.json').read_text())
    budget=131072 if short else STEPS
    assert config['task']==task and config['method']==method and config['seed']==seed
    assert config['determinism']=={'torch':True,'warp':'run_to_run',
                                  'warp_max_records':8,'cublas_workspace_config':':4096:8'}
    assert summary['state']=='completed' and summary['reload_check']=='passed'
    assert summary['training_transitions']==budget
    assert (path/'latest.pt').stat().st_size>0
    progress=list(csv.DictReader((path/'progress.csv').open()))
    if not short:
        assert len(progress)==(204 if method=='pae' else 153)
    else:
        assert len(progress)>=2
    if method=='pae':
        assert config['force_pae_overlap'] and config['pae_prefix']==48
        assert config['pae_tail']==16
        assert all(row['overlap_active'].lower()=='true' for row in progress)
    elif method=='critic_aware':
        assert len((path/'lambda_decisions.jsonl').read_text().splitlines())==len(progress)
    elif method=='gradient_ppo':
        assert summary['optimizer_steps']['h']>0
    elif method=='reward_profiling':
        assert len((path/'profiling_decisions.jsonl').read_text().splitlines())==min(10,len(progress))
        assert summary['total_algorithm_transitions']>budget
    final=float(summary['final_eval']['mean'])
    area=float(auc(path,budget))
    assert math.isfinite(final) and math.isfinite(area)
    return {'final_return':final,'auc':area,
            'total_algorithm_transitions':int(summary['total_algorithm_transitions']),
            'elapsed_seconds':float(summary['elapsed_seconds'])}


def command(python,source,path,task,method,seed,gpu,steps):
    trainer='train_pae_baseline.py' if method=='pae' else 'train_external_baseline.py'
    result=[str(python),str(source/trainer),'--out',str(path),'--task',task,
            '--method',method,'--seed',str(seed),'--device',f'cuda:{gpu}',
            '--steps',str(steps),'--num-envs','1024','--rollout','64',
            '--batch-size','1024','--eval-envs','32','--eval-every','262144']
    if method=='pae':result.append('--force-pae-overlap')
    if method=='pae' and steps<STEPS:
        result.extend(['--overlap-start-steps','0','--overlap-stop-steps',str(steps)])
    return result


def check_environment(python,source,manifest):
    for name,expected in manifest.items():
        assert digest(source/name)==expected,name
    script='import importlib.metadata as m,json,torch; print(json.dumps({x:m.version(x) for x in '+repr(tuple(VERSIONS))+'}))'
    versions=json.loads(subprocess.check_output([str(python),'-c',script],text=True))
    for package,expected in VERSIONS.items():
        assert versions[package].split('+')[0]==expected,(package,versions[package],expected)
    return versions


def jobs(out):
    return [{'id':f'{task}__{method}__seed{seed}','task':task,'method':method,
             'seed':seed,'path':str(out/'runs'/f'{task}__{method}__seed{seed}'),
             'state':'pending'}
            for seed in SEEDS for task in TASKS for method in METHODS]


def status(out,state,all_jobs,active,started,**extra):
    count=sum(j['state'] in ('completed','preserved_verified','reused_verified') for j in all_jobs)
    write(out/'suite_status.json',{'state':state,'completed_count':count,'total':160,
          'active':{jid:{'pid':proc.pid,'gpu':job['gpu']} for jid,(proc,_,job) in active.items()},
          'jobs':all_jobs,'elapsed_seconds':time.time()-started,**extra})


def finalize(out,all_jobs,manifest,source):
    for name,expected in manifest.items():assert digest(source/name)==expected,name
    rows=[]
    for job in all_jobs:
        metrics=(job['metrics'] if job['state']=='reused_verified' else
                 verify(Path(job['path']),job['task'],job['method'],job['seed']))
        rows.append({'task':job['task'],'method':job['method'],'seed':job['seed'],
                     'path':job.get('original_path',job['path']),
                     'origin':job.get('origin','remote'),**metrics})
    assert len(rows)==160 and len({(r['task'],r['method'],r['seed']) for r in rows})==160
    summary={}
    for task in TASKS:
        summary[task]={}
        for method in METHODS:
            cell=[r for r in rows if r['task']==task and r['method']==method]
            assert len(cell)==8
            summary[task][method]={
                'final_mean':statistics.mean(r['final_return'] for r in cell),
                'final_sd':statistics.stdev(r['final_return'] for r in cell),
                'auc_mean':statistics.mean(r['auc'] for r in cell),
                'auc_sd':statistics.stdev(r['auc'] for r in cell),
                'mean_algorithm_transitions':statistics.mean(r['total_algorithm_transitions'] for r in cell),
                'mean_elapsed_seconds':statistics.mean(r['elapsed_seconds'] for r in cell)}
    result={'state':'completed','total':160,'tasks':TASKS,'methods':METHODS,
            'seeds':SEEDS,'rows':rows,'summary':summary,
            'scope':'Remote external matched-backbone baselines; all prespecified runs included'}
    write(out/'ANALYSIS.json',result)
    return result


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--resume',action='store_true')
    parser.add_argument('--max-per-gpu',type=int,default=3)
    parser.add_argument('--min-free-mib',type=int,default=7000)
    parser.add_argument('--reuse-manifest',type=Path)
    parser.add_argument('--adopt-status',type=Path)
    args=parser.parse_args()
    out=args.root.resolve()
    source=out/'source'
    python=out/'.venv/bin/python'
    manifest=json.loads((out/'source_hashes.json').read_text())
    versions=check_environment(python,source,manifest)
    write(out/'environment.json',{'versions':versions,'gpus':subprocess.check_output(
          ['nvidia-smi','--query-gpu=index,name,memory.total','--format=csv,noheader,nounits'],
          text=True).strip().splitlines()})
    all_jobs=jobs(out)
    archive=[]
    prior=json.loads(args.adopt_status.read_text()) if args.adopt_status else None
    prior_active=prior['active'] if prior else {}
    prior_jobs={job['id']:job for job in prior['jobs']} if prior else {}
    if prior:
        assert prior['state']=='running' and len(prior_active)<=8
        assert all(jid in prior_jobs and prior_jobs[jid]['state']=='running' for jid in prior_active)
    if args.reuse_manifest:
        reuse=json.loads(args.reuse_manifest.read_text())
        assert reuse['state']=='verified' and len(reuse['rows'])==48
        by_id={row['id']:row for row in reuse['rows']}
        assert len(by_id)==48
        for job in all_jobs:
            row=by_id.get(job['id'])
            if row is None:continue
            assert row['task']==job['task'] and row['method']==job['method'] and row['seed']==job['seed']
            assert not Path(job['path']).exists(),job['id']
            job.update(state='reused_verified',metrics=row['metrics'],origin='local_deterministic',
                       original_path=row['path'],source_hashes=row['source_hashes'],
                       artifact_hashes=row['artifact_hashes'])
    if args.resume:
        stamp=time.strftime('%Y%m%dT%H%M%S')
        for job in all_jobs:
            if job['state']=='reused_verified':continue
            if job['id'] in prior_active:
                old=prior_jobs[job['id']]
                assert Path(job['path']).exists() and os.path.exists('/proc/'+str(prior_active[job['id']]['pid']))
                job.update(state='running',gpu=old['gpu'],pid=old['pid'],log=old['log'])
                continue
            path=Path(job['path'])
            if not path.exists():continue
            try:
                job['metrics']=verify(path,job['task'],job['method'],job['seed'])
                job['state']='preserved_verified'
            except (FileNotFoundError,AssertionError,KeyError,json.JSONDecodeError):
                archived=path.with_name(path.name+'.interrupted_'+stamp)
                path.rename(archived)
                archive.append({'id':job['id'],'path':str(archived)})
    else:
        assert not (out/'suite_status.json').exists()
        for job in all_jobs:assert not Path(job['path']).exists()
    if not (out/'SMOKE_VERIFIED.json').exists():
        smoke=[('Hopper','critic_aware',91021,0),('Swimmer','pae',91022,1),
               ('Ant','reward_profiling',91023,0)]
        for task,method,seed,gpu in smoke:
            name=f'smoke__{task}__{method}'
            path=out/'runs'/name
            log_path=out/(name+'.log')
            if path.exists():
                try:
                    verify(path,task,method,seed,short=True)
                    continue
                except (FileNotFoundError,AssertionError,KeyError,json.JSONDecodeError):
                    archived=path.with_name(path.name+'.interrupted_'+time.strftime('%Y%m%dT%H%M%S'))
                    path.rename(archived)
                    archive.append({'id':name,'path':str(archived)})
            if log_path.exists():
                log_path.rename(log_path.with_name(log_path.stem+'.interrupted_'+
                    time.strftime('%Y%m%dT%H%M%S')+'.log'))
            status(out,'smoke_running',all_jobs,{},time.time(),smoke=name)
            with log_path.open('x') as handle:
                code=subprocess.call(command(python,source,path,task,method,seed,gpu,131072),
                         cwd=source,env={**os.environ,'PYTHONUNBUFFERED':'1',
                         'OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1',
                         'DPO_TORCH_DETERMINISTIC':'1','DPO_WARP_DETERMINISTIC':'run_to_run',
                         'DPO_WARP_DETERMINISTIC_MAX_RECORDS':'8','CUBLAS_WORKSPACE_CONFIG':':4096:8'},
                         stdout=handle,stderr=subprocess.STDOUT)
            assert code==0,(name,code,log_path)
            verify(path,task,method,seed,short=True)
        write(out/'SMOKE_VERIFIED.json',{'state':'passed','smokes':[x[:3] for x in smoke]})
    active={}
    for job in all_jobs:
        if job['id'] in prior_active:
            handle=open(job['log'],'a')
            active[job['id']]=(AdoptedProcess(job['pid']),handle,job)
    failure=None
    started=time.time()
    env={**os.environ,'PYTHONUNBUFFERED':'1','OMP_NUM_THREADS':'1',
         'MKL_NUM_THREADS':'1','DPO_TORCH_DETERMINISTIC':'1',
         'DPO_WARP_DETERMINISTIC':'run_to_run','DPO_WARP_DETERMINISTIC_MAX_RECORDS':'8',
         'CUBLAS_WORKSPACE_CONFIG':':4096:8'}
    while True:
        for jid,(proc,handle,job) in list(active.items()):
            code=proc.poll()
            if code is None:continue
            handle.close();del active[jid]
            if code:
                job.update(state='failed',exit_code=code)
                failure={'id':jid,'exit_code':code,'log':job['log']}
                continue
            try:
                job['metrics']=verify(Path(job['path']),job['task'],job['method'],job['seed'])
                job['state']='completed'
            except BaseException as exc:
                job['state']='failed'
                failure={'id':jid,'verification_error':repr(exc),'log':job['log']}
        done=sum(job['state'] in ('completed','preserved_verified','reused_verified') for job in all_jobs)
        if done==160 and not active and not failure:
            result=finalize(out,all_jobs,manifest,source)
            status(out,'completed',all_jobs,active,started,
                   analysis_path=str(out/'ANALYSIS.json'),summary=result['summary'],
                   archived_incomplete=archive)
            return
        if failure and not active:
            status(out,'failed',all_jobs,active,started,failure=failure,
                   archived_incomplete=archive)
            raise SystemExit(1)
        if not failure:
            free=gpu_free()
            counts={gpu:sum(job['gpu']==gpu for _,_,job in active.values()) for gpu in free}
            for gpu in sorted(free,key=free.get,reverse=True):
                if counts[gpu]>=args.max_per_gpu:continue
                job=next((x for x in all_jobs if x['state']=='pending' and
                          free[gpu]>=GPU_MEMORY_ESTIMATE_MIB[x['task']]+args.min_free_mib),None)
                if job is None:continue
                suffix='.resume_'+stamp if args.resume else ''
                log_path=out/(job['id']+suffix+'.log')
                handle=log_path.open('x')
                proc=subprocess.Popen(command(python,source,Path(job['path']),
                         job['task'],job['method'],job['seed'],gpu,STEPS),
                         cwd=source,env=env,stdout=handle,stderr=subprocess.STDOUT)
                job.update(state='running',gpu=gpu,pid=proc.pid,log=str(log_path))
                active[job['id']]=(proc,handle,job)
                break
        status(out,'attention_required' if failure else 'running',all_jobs,active,started,
               failure=failure,archived_incomplete=archive)
        time.sleep(30)


if __name__=='__main__':
    try:main()
    except BaseException as exc:
        parser=argparse.ArgumentParser(add_help=False)
        parser.add_argument('--root',type=Path)
        out=parser.parse_known_args()[0].root
        if out and out.is_dir():
            write(out/'launcher_failure.json',{'error':repr(exc),'traceback':traceback.format_exc()})
        raise
