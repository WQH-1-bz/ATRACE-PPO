"""Stdlib prospective existing-reference contract and fresh native immutable gate.
Never trains, copies checkpoints, evaluates, or inserts a reference job.
"""
import argparse
import json
from pathlib import Path
from bundle_contract import ROOT,PYTHON,GPU_UUIDS,FLAGS,DET,read,sha,check_manifest,require_runtime,validate_interpreter_provenance,gpu_snapshot
EVIDENCE_ROOT=Path('/ssd_2/wch/hopper_full_practical_adjustment_r1_8seed_20261007')
PREVIOUS_ROOT=Path('/ssd_2/wch/hopper_full_centered_ncs2_i2_binding_r2_8seed_20261007')
PREVIOUS_MANIFEST='6fcd2891e7dd799afc0076465a2ab8a10a08df3d1947f13fae671d526ac95911'
REFERENCE_PATH=PREVIOUS_ROOT/'runs/engineering_reference_I2_seed91103'
REFERENCE_KEYS=('train_pae_baseline.py','external_baseline_algorithms.py','locomotion_warp.py','train_noisy_warp.py','ant_contact_compat.py')

def validate_reuse_contract(ledger,manifest):
    assert ledger['state']=='prospectively_pinned_existing_original_I2_reference'
    assert ledger['reference_path']==str(REFERENCE_PATH) and ledger['previous_native_root']==str(PREVIOUS_ROOT)
    assert ledger['previous_manifest_sha256']==PREVIOUS_MANIFEST==manifest['preserved_previous_Full_manifest_sha256']
    assert ledger['seed']==91103 and ledger['gpu']==0 and ledger['device']=='cuda:0'
    assert ledger['physical_GPU0_UUID']==GPU_UUIDS[0]
    assert ledger['invocation_entrypoint']==str(PYTHON)==manifest['native_interpreter']
    assert ledger['actual_resolved_interpreter']==manifest['actual_native_interpreter']
    assert ledger['native_python'].startswith('3.11.15 ') and ledger['runtime_versions']==manifest['runtime_versions']
    assert ledger['determinism']==DET and ledger['xml_sha256']==manifest['xml_sha256'] and ledger['exact_flags']==FLAGS
    assert ledger['original_reference_source_hashes']==manifest['reference_i2_hashes'] and len(ledger['original_reference_source_hashes'])==18
    assert ledger['old_original_reference_source_native_hashes']=={str(PREVIOUS_ROOT/'reference_i2'/n):d for n,d in manifest['reference_i2_hashes'].items()}
    assert ledger['budget']==786432 and ledger['switch']==524288 and ledger['windows']==13 and ledger['shared_adam_calls']==7680
    assert ledger['new_reference_training_runs']==ledger['new_reference_training_transitions']==0
    assert ledger['reference_reused_not_new_job_or_output'] and ledger['actual_prior_training_required'] and ledger['fresh_resource_gated_native_reuse_check_before_shortA']
    assert manifest['reference_route']=='reused_completed_original_I2_engineering13window' and manifest['new_reference_runs_if_capture_missing']==0
    previous_binding=read(EVIDENCE_ROOT/'evidence/reference_reuse/training/PARENT_NATIVE_BINDINGS.json')
    assert previous_binding['state']=='verified' and previous_binding['manifest_sha256']==PREVIOUS_MANIFEST
    assert previous_binding['reference_i2_hashes']==ledger['original_reference_source_hashes']
    assert previous_binding['invocation_entrypoint']==ledger['invocation_entrypoint'] and previous_binding['actual_resolved_interpreter']==ledger['actual_resolved_interpreter']
    assert previous_binding['runtime_versions']==ledger['runtime_versions'] and previous_binding['original_caches']==ledger['original_caches'] and not previous_binding['CUDA_VISIBLE_DEVICES_present']
    execution=ledger['original_training_execution']
    assert execution['stage']=='reference_training' and execution['pid']>0 and execution['returncode']==0 and execution['gpu']==0 and execution['manifest_sha256']==PREVIOUS_MANIFEST
    assert execution['command']==[ledger['invocation_entrypoint'],str(PREVIOUS_ROOT/'reference_negative_control.py'),'--out',str(REFERENCE_PATH)]
    actual=read(EVIDENCE_ROOT/'evidence/reference_reuse/training/results/engineering_reference_I2_seed91103__reference_training__execution.json')
    assert actual==execution
    suite=read(EVIDENCE_ROOT/'evidence/reference_reuse/training/suite_status.json')
    ref=suite['reference_job'];assert suite['state']=='completed' and suite['completed_count']==8 and not suite['active'] and suite['failure'] is None
    assert ref['state']=='completed' and ref['path']==str(REFERENCE_PATH) and ref['process_history'][0]==execution and ref['returncode']==0
    assert ref['process_history'][1]['stage']=='reference' and ref['process_history'][1]['returncode']==0
    capture=ledger['capture_receipt']
    actual_capture=read(EVIDENCE_ROOT/'evidence/reference_reuse/training/runs/engineering_reference_I2_seed91103/REFERENCE_CAPTURE_VERIFIED.json')
    assert capture==actual_capture and capture['state']=='passed' and capture['source_hashes']==ledger['original_reference_source_hashes']
    assert capture['seed']==91103 and capture['gpu']==0 and capture['device']=='cuda:0'
    assert capture['training_transitions']==786432 and capture['stage_switch_steps']==524288 and capture['windows']==13 and capture['shared_adam_calls']==7680
    assert capture['original_source_unmodified'] and capture['f_locals_read_only'] and capture['captured_before_extra_auxiliary_warmups']
    assert capture['tracer_numerical_state_assignments']==capture['extra_model_optimizer_environment_calls']==0 and capture['capture_phases']==['pre','post']
    assert capture['runtime_versions']==ledger['runtime_versions'] and capture['actual_interpreter']==ledger['invocation_entrypoint']
    config=read(EVIDENCE_ROOT/'evidence/reference_reuse/training/runs/engineering_reference_I2_seed91103/config.json')
    assert config['source_sha256']=={k:ledger['original_reference_source_hashes'][k] for k in REFERENCE_KEYS}
    assert config['seed']==91103 and config['device']=='cuda:0' and config['effective_steps']==786432 and config['stage_switch_steps']==524288
    assert config['xml_sha256']==ledger['xml_sha256'] and config['determinism']==ledger['determinism']
    assert capture['config_sha256']==ledger['artifact_hashes']['config.json'] and capture['initial_evaluation_sha256']==ledger['artifact_hashes']['initial_evaluation.json']
    for phase,digest in capture['snapshots'].items():assert ledger['artifact_hashes']['first_window_'+phase+'.pt']==digest
    marker=read(EVIDENCE_ROOT/'evidence/reference_reuse/terminal15/PARENT_TERMINAL15_VERIFIED.json')
    assert marker['state']=='passed' and marker['fresh_native_helpers']==15 and marker['all_actual_returncodes_zero'] and marker['all_output_hashes_verified'] and marker['manifest_sha256']==PREVIOUS_MANIFEST
    assert sha(EVIDENCE_ROOT/'evidence/reference_reuse/terminal15/PARENT_TERMINAL15_VERIFIED.json')==ledger['previous_terminal15_marker_sha256']
    assert len(ledger['previous_actual_reference_and_direct_helpers'])==3
    assert {r['id'] for r in ledger['previous_actual_reference_and_direct_helpers']}=={'original_I2_reference','smoke_Full_a__compare_reference','smoke_Full_b__compare_reference'}
    for receipt in ledger['previous_actual_reference_and_direct_helpers']:
        ex=receipt['execution'];assert ex in marker['receipts'] and ex['actual_returncode']==0 and ex['gpu']==0 and ex['manifest_sha256']==PREVIOUS_MANIFEST
        assert ex['snapshot_before_launch']['cards']['0']['uuid']==GPU_UUIDS[0]
        assert ex['output_sha256']==receipt['report_sha256']
        ident=receipt['id'];assert ident in ('original_I2_reference','smoke_Full_a__compare_reference','smoke_Full_b__compare_reference')
        proof=EVIDENCE_ROOT/'evidence/reference_reuse/terminal15/parent_terminal_verification'
        assert read(proof/(ident+'__execution.json'))==ex and sha(proof/(ident+'.json'))==ex['output_sha256']
        report=read(proof/(ident+'.json'));assert report['state']=='passed' and report['manifest_sha256']==PREVIOUS_MANIFEST
        if ident=='original_I2_reference':assert report['path']==str(REFERENCE_PATH) and report['snapshots']==capture['snapshots']
        else:assert report['original_I2_used56_first_window_before_auxiliary_warmups_exact'] and report['same_seed91103_GPU0']
    parent=EVIDENCE_ROOT/'evidence/reference_reuse/PARENT_NATIVE_TERMINAL15_ACCEPTANCE.json'
    assert sha(parent)==ledger['parent_actual_terminal15_acceptance_sha256']
    proof=read(parent);assert proof['state']=='parent_direct_actual_terminal15_passed' and proof['all15_actual_child_returncodes_zero'] and proof['all15_output_hashes_match']
    return {'state':'passed','reference_path':str(REFERENCE_PATH),'actual_prior_training_returncode':execution['returncode'],'previous_Full_manifest_sha256':PREVIOUS_MANIFEST,'budget':786432,'switch':524288,'windows':13,'shared_adam_calls':7680,'fresh_native_check_required':True,'new_reference_training':0}

def load_reuse_contract(manifest):
    path=ROOT/'REFERENCE_REUSE_LEDGER.json'
    assert sha(path)==manifest['reference_reuse_ledger_sha256']
    ledger=read(path)
    for name,digest in ledger['cold_evidence_hashes'].items():assert sha(EVIDENCE_ROOT/name)==digest,('cold actual reference evidence changed',name)
    proof=validate_reuse_contract(ledger,manifest)
    return ledger,proof

def verify_existing_reference(path):
    manifest=require_runtime();ledger,proof=load_reuse_contract(manifest)
    assert Path(path)==REFERENCE_PATH and REFERENCE_PATH.is_dir(),('No replacement or new reference output',path)
    snapshot=gpu_snapshot();assert snapshot['cards'][0]['uuid']==ledger['physical_GPU0_UUID']
    oldmanifest=PREVIOUS_ROOT/'MANIFEST.json';assert sha(oldmanifest)==PREVIOUS_MANIFEST
    old=read(oldmanifest);assert old['reference_i2_hashes']==ledger['original_reference_source_hashes']
    for name,digest in ledger['old_original_reference_source_native_hashes'].items():assert sha(name)==digest,('Original reference source changed',name)
    for name,digest in ledger['old_native_metadata_hashes'].items():assert sha(name)==digest,('Prior actual reference provenance changed',name)
    for name,digest in ledger['artifact_hashes'].items():assert sha(REFERENCE_PATH/name)==digest,('Immutable original reference artifact changed',name)
    config=read(REFERENCE_PATH/'config.json');capture=read(REFERENCE_PATH/'REFERENCE_CAPTURE_VERIFIED.json')
    assert config==read(EVIDENCE_ROOT/'evidence/reference_reuse/training/runs/engineering_reference_I2_seed91103/config.json') and capture==ledger['capture_receipt']
    provenance=validate_interpreter_provenance(PYTHON,capture['actual_interpreter'],manifest['native_interpreter'],manifest['actual_native_interpreter'])
    assert provenance['actual_resolved_interpreter']==ledger['actual_resolved_interpreter']
    binding=read(ROOT/'PARENT_NATIVE_BINDINGS.json')
    assert binding['actual_resolved_interpreter']==ledger['actual_resolved_interpreter'] and binding['runtime_versions']==ledger['runtime_versions'] and binding['original_caches']==ledger['original_caches']
    proof.update({'native_immutable_old_metadata_pins_checked':len(ledger['old_native_metadata_hashes']),'native_original_source18_checked':18,'native_reference_artifact_pins_checked':len(ledger['artifact_hashes']),'GPU0_UUID':snapshot['cards'][0]['uuid'],'ledger_sha256':sha(ROOT/'REFERENCE_REUSE_LEDGER.json'),'read_only_runpy_capture_sha256':sha(REFERENCE_PATH/'REFERENCE_CAPTURE_VERIFIED.json'),'native_fresh_immutable_verification':'passed','new_training_or_evaluation':0})
    return proof

def main():
    p=argparse.ArgumentParser();p.add_argument('--check-contract-only',action='store_true');args=p.parse_args()
    if args.check_contract_only:
        manifest=check_manifest();_,proof=load_reuse_contract(manifest)
        proof.update({'scope':'cold prospective provenance contract only; not native admission','native_actions':0,'scientific_imports':0,'actual_manifest_sha256':sha(ROOT/'MANIFEST.json')})
    else:proof=verify_existing_reference(str(REFERENCE_PATH))
    print(json.dumps(proof,indent=2,allow_nan=False))
if __name__=='__main__':main()
