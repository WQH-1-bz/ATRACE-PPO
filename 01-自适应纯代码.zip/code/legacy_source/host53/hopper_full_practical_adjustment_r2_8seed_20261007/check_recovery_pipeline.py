"""One actual-main stdlib orchestration fixture plus real file-integrity negatives.
Scientific/native work is explicitly replaced by owned local metadata-only children.
"""
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import types
ROOT=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT))
import run_full
import short_a_reuse

def main():
    # Invoke the production artifact integrity guard on actual local files.
    with tempfile.TemporaryDirectory(prefix='hopper_recovery_integrity_') as temp:
        p=Path(temp);(p/'a').write_text('one');(p/'b').write_text('two')
        pins={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.iterdir()}
        short_a_reuse.check_artifacts(p,pins)
        for mutation in ('addition','change','missing'):
            if mutation=='addition':(p/'extra').write_text('extra')
            elif mutation=='change':(p/'a').write_text('changed')
            else:(p/'b').unlink()
            try:short_a_reuse.check_artifacts(p,pins)
            except (AssertionError,FileNotFoundError):pass
            else:raise AssertionError(mutation)
            if mutation=='addition':(p/'extra').unlink()
            elif mutation=='change':(p/'a').write_text('one')
            else:(p/'b').write_text('two')
    actual=run_full.read(ROOT/'SHORT_A_REUSE.json')
    with tempfile.TemporaryDirectory(prefix='hopper_recovery_actual_main_') as temp:
        fixture=Path(temp);(fixture/'MANIFEST.json').write_text('explicit_stdlib_fixture');digest=run_full.sha(fixture/'MANIFEST.json')
        source=actual['scientific_source_hashes'];manifest={'reference_route':'reused_completed_original_I2_engineering13window','new_reference_runs_if_capture_missing':0,'source_hashes':source}
        control=fixture/'old_original_I2';control.mkdir()
        data=copy.deepcopy(actual);data['prior_original_reference_job']['path']=str(control)
        original_reference=run_full.read(ROOT/'REFERENCE_REUSE_LEDGER.json');original_reference['reference_path']=str(control)
        run_full.write(fixture/'SHORT_A_REUSE.json',data);run_full.write(fixture/'REFERENCE_REUSE_LEDGER.json',original_reference)
        run_full.write(fixture/'REMOTE_PREPARED.json',{'state':'prepared','manifest_sha256':digest})
        run_full.write(fixture/'LUNA_MONITOR_ACTIVE.json',{'fresh_stage':'practical_strict_short_pipeline','goal_id':'owned_fixture_goal'})
        roots=['ROOT','require_launch','check_manifest','gpu_snapshot','child_env']
        saved={key:getattr(run_full,key) for key in roots};old_argv=sys.argv[:];old_popen=subprocess.Popen;old_sleep=time.sleep;old_verify=short_a_reuse.verify_reuse
        launched=[]
        def snapshot():return {'cards':{0:{'free_mib':100000,'total_mib':100000},1:{'free_mib':100000,'total_mib':100000}},'process_mib':{0:{},1:{}}}
        def fixture_popen(argv,**kwargs):
            if 'train_pae_baseline.py' in argv[1]:
                stage='training';output=Path(argv[argv.index('--out')+1]);assert output.name=='smoke_Full_b';payload={'operation':'training','path':str(output),'result':{'state':'completed','peak_torch_memory_bytes':0}}
            elif 'stress_checkpoint.py' in argv[1]:
                stage='stress';output=Path(argv[argv.index('--job-path')+1]);assert output.name=='smoke_Full_b';payload={'operation':'stress','path':str(output),'result':{'state':'passed','peak_torch_memory_reserved_bytes':0}}
            else:
                stage=argv[argv.index('--operation')+1]
                assert stage not in ('reference','saved-state'),'Prior completed verification must be reused'
                output=Path(argv[argv.index('--result')+1]);payload={'operation':stage,'path':str(output),'result':{'state':'passed','manifest_sha256':digest,'source_hashes':source,'peak_torch_memory_reserved_bytes':0}}
            program="import json,pathlib,sys; x=json.loads(sys.argv[1]); p=pathlib.Path(x['path']); op=x['operation']; p.mkdir(exist_ok=False) if op=='training' else None; dest=p/'summary.json' if op=='training' else p/'checkpoint_stress_result.json' if op=='stress' else p; dest.write_text(json.dumps(x['result'])+'\\n')"
            proc=old_popen([sys.executable,'-c',program,json.dumps(payload)],**kwargs);launched.append({'actual_pid':proc.pid,'stage':stage,'declared_argv':argv,'scope':'local_metadata_fixture_only'});return proc
        try:
            run_full.ROOT=fixture;run_full.require_launch=lambda:None;run_full.check_manifest=lambda:manifest;run_full.gpu_snapshot=snapshot;run_full.child_env=lambda:os.environ.copy()
            short_a_reuse.verify_reuse=lambda:{'state':'passed','prior_observed_peak_mib':6250,'new_training_transitions':0,'scope':'fixture admission stub; production integrity tested separately'}
            subprocess.Popen=fixture_popen;time.sleep=lambda _:old_sleep(.01)
            sys.argv=['run_full.py','--stage','short'];rc=run_full.main()
            status=run_full.read(fixture/'suite_status.json')
            assert rc==0 and status['state']=='short_completed_awaiting_parent_formal_admission' and status['formal_training_started_count']==0 and not status['active'] and status['failure'] is None
            assert sum(x['stage']=='training' for x in launched)==1 and sum(x['stage']=='stress' for x in launched)==1
            assert status['smoke_jobs'][0]['path']==actual['path'] and status['smoke_jobs'][0]['reused_completed_short']
            assert status['smoke_jobs'][0]['process_history'][:2]==[actual['training_execution'],actual['stress_execution']]
            assert len(launched)==9 and status['jobs']==run_full.plan()
            gate=run_full.read(fixture/'SMOKE_VERIFIED.json');assert gate['new_r2_short_training_transitions']==786432 and gate['reservation_mib']>=6506
            assert not (fixture/'FORMAL_STAGE_STARTED.json').exists()
        finally:
            for key,value in saved.items():setattr(run_full,key,value)
            subprocess.Popen=old_popen;time.sleep=old_sleep;short_a_reuse.verify_reuse=old_verify;sys.argv=old_argv
            sys.meta_path[:]=[x for x in sys.meta_path if not isinstance(x,run_full.NoScientificImports)]
    assert not any(x in sys.modules for x in ('torch','numpy','warp','mujoco'))
    print(json.dumps({'state':'passed','actual_main_returncode':rc,'strict_short_boundary_without_formal':True,'existing_A_training_and_stress_forbidden':True,'pending_B_only_training_and_stress':True,'original_reference_and_saved_checks_reused':True,'production_integrity_positive_and_add_change_missing_negatives':True,'owned_local_fixture_children':launched,'scientific_library_imports':0,'native_actions':0}))

if __name__=='__main__':main()
