"""Cold stdlib runtime, source and preserved-record contracts."""
import csv
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
NATIVE_ROOT=Path('/ssd_2/wch/hopper_full_practical_adjustment_r2_8seed_20261007')
OLD_ROOT=Path('/ssd_2/wch/hopper_innovation12_transfer2_records_r1_8seed_20261006')
PYTHON=OLD_ROOT/'.venv/bin/python'
CENTERED_ROOT=Path('/ssd_2/wch/hopper_centered_ncs2_i1_scheduler_r2_8seed_20261006')
GPU_UUIDS={0:'GPU-32b8892b-0703-3c74-56fe-cf278c1fa4cc',1:'GPU-694f7a96-5e77-2a24-2a88-87c554d001bf'}
UNIT='dpo-hopper-full-practical-adjustment-r2-8seed-20261007.service'
FLAGS={'PYTHONUNBUFFERED':'1','PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','DPO_TORCH_DETERMINISTIC':'1','DPO_WARP_DETERMINISTIC':'run_to_run','DPO_WARP_DETERMINISTIC_MAX_RECORDS':'8','CUBLAS_WORKSPACE_CONFIG':':4096:8','DPO_PPO_GRAPH':'0'}
DET={'torch':True,'warp':'run_to_run','warp_max_records':8,'cublas_workspace_config':':4096:8'}
STRESS=(('none',0.),('gaussian',.1),('gaussian',.15),('gaussian',.3),('multiplicative',.2),('multiplicative',.3))
DISK_FLOOR=10*1024**3
def read(p):
    def invalid(v):raise ValueError('Nonfinite JSON: '+v)
    return json.loads(Path(p).read_text(),parse_constant=invalid)
def write(p,x):
    p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n');tmp.replace(p)
def write_new(p,x):
    p=Path(p);assert not p.exists(),('no overwrite',p)
    with p.open('x') as s:s.write(json.dumps(x,indent=2,allow_nan=False)+'\n')
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as s:
        for b in iter(lambda:s.read(1048576),b''):h.update(b)
    return h.hexdigest()
def child_env():
    assert 'CUDA_VISIBLE_DEVICES' not in os.environ
    env={**os.environ,**FLAGS}
    for key,sub in [('XDG_CACHE_HOME','cache'),('WARP_CACHE_PATH','cache/warp'),('CUDA_CACHE_PATH','cache/cuda'),('TORCH_HOME','cache/torch'),('TMPDIR','tmp')]:env[key]=str(OLD_ROOT/sub)
    return env
def validate_interpreter_provenance(invocation,actual,expected_invocation,expected_actual):
    """Invocation spelling and resolved executable identity have distinct scopes."""
    assert str(invocation)==str(expected_invocation),('invocation entrypoint changed',invocation)
    actual_resolved=str(Path(actual).resolve());expected_resolved=str(Path(expected_actual).resolve())
    assert actual_resolved==expected_resolved,('actual interpreter differs from original runtime binding',actual)
    return {'invocation_entrypoint':str(invocation),'actual_resolved_interpreter':actual_resolved,'expected_actual_interpreter':str(expected_actual)}
def check_manifest():
    m=read(ROOT/'MANIFEST.json');assert sha(ROOT/'MANIFEST.json')==(ROOT/'MANIFEST.sha256').read_text().strip()
    assert m['state']=='READY_source_only' and m['formal_total']==8
    for name,digest in m['bundle_hashes'].items():
        p=ROOT/name;assert p.is_file() and sha(p)==digest,('frozen bundle changed',name)
        assert not p.stat().st_mode&0o222,('frozen file writable',name)
    for sub,key in [('source_full','source_hashes'),('reference_i2','reference_i2_hashes')]:assert {p.name for p in (ROOT/sub).iterdir() if p.is_file()}==set(m[key])
    return m
def gpu_snapshot():
    rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,memory.free,memory.total','--format=csv,noheader,nounits'],text=True,timeout=20).splitlines();cards={}
    for line in rows:
        index,uuid,free,total=[x.strip() for x in line.split(',')];cards[int(index)]={'uuid':uuid,'free_mib':int(free),'total_mib':int(total)}
    for index,uuid in GPU_UUIDS.items():assert cards[index]['uuid']==uuid,('physical GPU UUID',index,cards)
    memory={0:{},1:{}}
    for line in subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_gpu_memory','--format=csv,noheader,nounits'],text=True,timeout=20).splitlines():
        pid,uuid,used=[x.strip() for x in line.split(',')]
        if uuid in GPU_UUIDS.values():
            card=next(i for i,u in GPU_UUIDS.items() if u==uuid);memory[card][int(pid)]=int(used)
    return {'cards':cards,'process_mib':memory}
def require_runtime():
    assert ROOT==NATIVE_ROOT,('native execution only',ROOT)
    assert 'CUDA_VISIBLE_DEVICES' not in os.environ
    m=check_manifest();assert sys.version.startswith('3.11.15 '),(sys.version,'existing native Python3.11.15 required')
    validate_interpreter_provenance(PYTHON,sys.executable,m['native_interpreter'],m['actual_native_interpreter'])
    for name,version in m['runtime_versions'].items():assert importlib.metadata.version(name)==version,(name,version)
    for key,value in FLAGS.items():assert os.environ.get(key)==value,(key,os.environ.get(key))
    for key,value in child_env().items():
        if key in ('XDG_CACHE_HOME','WARP_CACHE_PATH','CUDA_CACHE_PATH','TORCH_HOME','TMPDIR'):assert os.environ.get(key)==value,(key,'original caches required')
    review=read(ROOT/'PARENT_REVIEW_ADMISSION.json');assert review['state']=='passed' and review['independent_source_review_passed']
    assert review['manifest_sha256']==sha(ROOT/'MANIFEST.json')
    assert review['practical_td_persistence_candidate_approved'] and review['user_broader_code_changes_authorized']
    assert review['oracle_float_type_recovery_approved'] and review['completed_short_A_reuse_approved']
    binding=read(ROOT/'PARENT_NATIVE_BINDINGS.json');assert binding['state']=='verified' and binding['manifest_sha256']==sha(ROOT/'MANIFEST.json') and binding['source_hashes']==m['source_hashes'] and binding['reference_i2_hashes']==m['reference_i2_hashes']
    monitor=read(ROOT/'LUNA_MONITOR_ACTIVE.json');assert monitor['state']=='ACTIVE' and monitor['manifest_sha256']==sha(ROOT/'MANIFEST.json')
    for label in ('actual_goal_receipt','initial_snapshot'):
        path=Path(monitor[label+'_path']);assert sha(path)==monitor[label+'_sha256']
    goal=read(monitor['actual_goal_receipt_path'])['goal'];assert goal['status']=='active' and goal['threadId']==monitor['goal_id']
    assert monitor['initial_snapshot_recorded'] and monitor['fresh_stage'] in ('practical_strict_short_pipeline','formal_training','terminal_verification')
    return m
def require_launch():
    require_runtime();assert shutil.disk_usage(ROOT).free>=DISK_FLOOR
    return gpu_snapshot()
def controls():
    from contracts import SEEDS,REPORT_METHODS
    rows=read(ROOT/'COMPARISON_REFERENCE.json')['rows'];assert len(rows)==88
    assert {(r['method'],r['seed']) for r in rows}=={(m,s) for m in REPORT_METHODS for s in SEEDS}
    return rows
def reintegrate(p,budget):
    p=Path(p);initial=read(p/'initial_evaluation.json');ev=[json.loads(v) for v in (p/'evaluations.jsonl').read_text().splitlines() if v.strip()]
    for e in [initial,*ev]:
        assert len(e['returns'])==len(e['lengths'])==32 and all(math.isfinite(v) for v in e['returns'])
        assert all(type(v) is int and 1<=v<=1000 for v in e['lengths'])
    pts=[(0,initial['mean'])]+[(e['steps'],e['mean']) for e in ev]
    assert pts[-1][0]==budget and len(ev)==39 and all(a[0]<b[0] for a,b in zip(pts,pts[1:]))
    return sum((b[0]-a[0])*(a[1]+b[1])/2 for a,b in zip(pts,pts[1:]))/budget,initial,ev
def verify_historical():
    m=read(ROOT/'MANIFEST.json');count=0
    for name,digest in read(ROOT/'PRESERVED_NATIVE_FILES.json').items():assert sha(name)==digest,('protected source changed',name);count+=1
    reports=[];history=read(Path('/ssd_2/wch/hopper_full_practical_adjustment_r1_8seed_20261007/evidence/HISTORICAL_EXECUTION_EXPECTATIONS.json'))['rows']
    for row in controls():
        p=Path(row['path'])
        for name,digest in row['artifact_hashes'].items():assert sha(p/name)==digest,('protected result changed',p/name);count+=1
        c=read(p/'config.json');s=read(p/'summary.json');status=read(p/'status.json')
        assert c['task'].startswith('Hopper') and c['seed']==row['seed'] and c.get('effective_steps',c['steps'])==10027008
        assert c['xml_sha256']==m['xml_sha256'] and s['state']==status['state']=='completed' and s['reload_check']=='passed' and s['steps']==10027008
        for key,value in [('num_envs',1024),('rollout',64),('batch_size',1024),('eval_envs',32),('eval_every',262144)]:assert c[key]==value
        if row['method'] in ('fixed90','fixed95','fixed99','linear','critic_aware','gradient_ppo','reward_profiling','pae'):
            expected=history[row['method']+'__seed'+str(row['seed'])]
            assert sha(p/'config.json')==expected['config_sha256'] and c['determinism']==expected['determinism']
        area,initial,ev=reintegrate(p,10027008)
        assert area==row['auc'] and s['final_eval']['mean']==row['final_return'],('historical score changed',row['method'],row['seed'])
        assert s.get('total_algorithm_transitions',10027008)==row.get('total_algorithm_transitions',10027008)
        reports.append({'method':row['method'],'seed':row['seed'],'path':str(p),'final_return':row['final_return'],'auc':area,'scientific_version':row['scientific_version']})
    # Recheck the original scope inventories exactly, without broadening their membership.
    scopes=[]
    for spec in m['original_inventory_scopes']:
        inventory=read(spec['path']);assert sha(spec['path'])==spec['sha256']
        for name,digest in inventory['files'].items():assert sha(name)==digest,('original inventory changed',name)
        scopes.append({'path':spec['path'],'files':len(inventory['files'])})
    from short_a_reuse import verify_reuse
    reuse=verify_reuse()
    return {'state':'passed','reused_short_A_preserved':reuse,'scoped_protected_files':count,'comparison_rows':88,'reintegrated_original_rows':reports,'original_inventory_scopes':scopes,'new_training_or_evaluation':0,'Swimmer_mutations':0}
