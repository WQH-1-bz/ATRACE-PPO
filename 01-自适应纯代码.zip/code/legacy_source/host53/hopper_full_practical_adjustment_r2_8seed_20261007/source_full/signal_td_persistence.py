"""Signed lag-one TD correlation on fresh consumed rows; no critic-truth claim."""
import math


def persistence_from_moments(count, mean_left, mean_right, variance_left, variance_right, covariance):
    if type(count) is not int or count < 0:
        raise ValueError('Invalid TD pair count')
    if not all(math.isfinite(v) for v in (mean_left,mean_right,variance_left,variance_right,covariance)):
        raise ValueError('Nonfinite TD pair moments')
    if min(variance_left,variance_right)<0:
        raise ValueError('Negative TD pair variance')
    valid = count >= 2 and variance_left > 0. and variance_right > 0.
    persistence = max(-1., min(1., covariance/math.sqrt(variance_left*variance_right))) if valid else 0.
    return {'persistence':persistence,'td_pair_count':count,'td_pair_signal_valid':valid,
            'td_pair_mean_left':mean_left,'td_pair_mean_right':mean_right,
            'td_pair_variance_left':variance_left,'td_pair_variance_right':variance_right,
            'td_pair_covariance':covariance}


def td_persistence(rewards, values, next_values, terminated, done, incoming, used, gamma=.99):
    import torch
    tensors=(rewards,values,next_values,terminated,done)
    if rewards.ndim!=2 or not all(t.shape==rewards.shape and t.device==rewards.device for t in tensors):
        raise ValueError('Matching time-by-world tensors required')
    if not all(t.dtype==torch.float32 for t in tensors[:3]) or terminated.dtype!=torch.bool or done.dtype!=torch.bool:
        raise ValueError('TD input dtype mismatch')
    if type(incoming) is not int or type(used) is not int or not 0 <= incoming < used <= rewards.shape[0]:
        raise ValueError('Invalid fresh consumed domain')
    if bool((terminated & ~done).any()) or not all(bool(torch.isfinite(t).all()) for t in tensors[:3]):
        raise ValueError('Invalid TD masks or nonfinite input')
    # Match primary trace TD arithmetic, then reduce centered moments in FP64.
    td=(rewards+gamma*(~terminated).float()*next_values-values)[incoming:used].double()
    mask=~done[incoming:used-1]
    left,right=td[:-1][mask],td[1:][mask]
    count=left.numel()
    if count:
        mean_left,mean_right=left.mean(),right.mean()
        centered_left,centered_right=left-mean_left,right-mean_right
        moments=tuple(map(float,(mean_left,mean_right,centered_left.square().mean(),centered_right.square().mean(),(centered_left*centered_right).mean())))
    else:
        moments=(0.,0.,0.,0.,0.)
    result=persistence_from_moments(count,*moments)
    result.update(td_fresh_consumed_rows=used-incoming,td_fresh_mean=float(td.mean()),td_fresh_variance=float(td.var(unbiased=False)),td_fresh_mse=float(td.square().mean()))
    return result
