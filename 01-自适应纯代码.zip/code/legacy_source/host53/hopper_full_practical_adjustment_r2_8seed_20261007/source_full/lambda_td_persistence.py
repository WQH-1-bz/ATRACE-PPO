"""Causal TD-persistence controller: slow target, bounded actor trace tracking."""
import math
from dataclasses import asdict, dataclass

@dataclass
class TDPersistence:
    value: float = .95
    target: float = .95
    observations: int = 0
    block_sum: float = 0.
    last_persistence: float = 0.
    last_block_mean: float = 0.
    slow_persistence: float = 0.
    slow_initialized: bool = False

    def observe(self, persistence):
        if not math.isfinite(persistence) or not -1. <= persistence <= 1.:
            raise ValueError('TD persistence must be finite in [-1,1]')
        self.last_persistence = persistence
        self.observations += 1
        self.block_sum += persistence
        if self.observations % 4 == 0:
            self.last_block_mean = self.block_sum / 4.
            if not self.slow_initialized:
                self.slow_persistence = self.last_block_mean
                self.slow_initialized = True
            else:
                self.slow_persistence = .9*self.slow_persistence + .1*self.last_block_mean
            self.target = min(.99, max(.90, .95 + .04*math.tanh(2.*self.slow_persistence)))
            self.block_sum = 0.

    def step(self, update):
        if type(update) is not int or update != self.observations + 1:
            raise ValueError('Controller requires consecutive chronological windows')
        old = self.value
        if update > 4:
            self.value = min(.99, max(.90,
                old + max(-.001, min(.001, .1*(self.target-old)))))
        return self.value-old

    def state_dict(self):
        return asdict(self)
