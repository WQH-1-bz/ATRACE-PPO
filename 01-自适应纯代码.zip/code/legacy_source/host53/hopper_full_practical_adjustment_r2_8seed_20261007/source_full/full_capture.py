"""Capture actual frozen Full targets and first-window states; no forward/step calls."""
import torch

def physics_state(env,evaluation_env):
    """Read existing tensors and generators only; no simulation/model/optimizer calls."""
    names=('qpos','qvel','ctrl','xipos','site_xpos','constraint_force','ant_x',
           'qpos0','reset_mask','lengths','returns','overflow_seen','nonfinite_seen')
    def one(value):
        return {**{name:getattr(value,name).detach().cpu().clone() for name in names},
                'rng':value.rng.get_state().detach().cpu().clone()}
    return {'training':one(env),'evaluation':one(evaluation_env),
            'torch_cpu_rng':torch.get_rng_state().clone(),
            'torch_cuda_rng':torch.cuda.get_rng_state(env.device).cpu().clone()}

def snapshot_state(path,model,optimizers,normal,rnormal,metadata):
    def cpu(x):
        if isinstance(x,torch.Tensor):return x.detach().cpu().clone()
        if isinstance(x,dict):return {k:cpu(v) for k,v in x.items()}
        if isinstance(x,list):return [cpu(v) for v in x]
        if isinstance(x,tuple):return tuple(cpu(v) for v in x)
        return x
    torch.save(cpu({'model':model.state_dict(),'optimizers':{k:o.state_dict() for k,o in optimizers.items()},'obs_stats':normal.state_dict(),'reward_stats':rnormal.state_dict(),**metadata}),path)

def capture_window(path,inputs,actor,critic95,fixed95_actor,metrics,metadata):
    # Store complete recurrence domain, plus the exact flattened PPO-consumed labels.
    record={k:v.detach().cpu().clone() for k,v in inputs.items()}
    record.update(actor_advantage=actor.detach().cpu().clone(),consumed_critic_return=critic95.detach().cpu().clone(),fixed95_actor_advantage=fixed95_actor.detach().cpu().clone(),**metrics,**metadata)
    torch.save(record,path)
