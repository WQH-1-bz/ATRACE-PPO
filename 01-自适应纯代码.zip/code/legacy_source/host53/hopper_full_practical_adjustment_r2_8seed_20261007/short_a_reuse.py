"""Immutable r1 shortA reuse; native stdlib only, never trains/stresses/copies tensors."""
import copy
from pathlib import Path
from bundle_contract import ROOT,read,sha
R1_ROOT=Path('/ssd_2/wch/hopper_full_practical_adjustment_r1_8seed_20261007')
A_PATH=R1_ROOT/'runs/smoke_Full_a'
R1_MANIFEST='221a932c4abaa4f6b418c1804673c6616cfac53ffe949e6415d1cfa5493d6d16'

def reuse_job():
    ledger=read(ROOT/'SHORT_A_REUSE.json')
    assert ledger['state']=='prospectively_pinned_completed_short_A' and ledger['path']==str(A_PATH)
    return {'id':'smoke_Full_a','seed':91103,'gpu':0,'smoke':True,'path':str(A_PATH),
            'state':'verify_pending','reused_completed_short':True,'read_only_training_and_stress':True,
            'prior_training_pid':ledger['training_execution']['pid'],
            'process_history':copy.deepcopy([ledger['training_execution'],ledger['stress_execution']]),
            'prior_failed_verify_preserved_in_ledger':True,'new_training_transitions':0}

def check_artifacts(path,pins):
    files=[p for p in path.rglob('*') if p.is_file()]
    assert all(not p.is_symlink() for p in files)
    assert {str(p.relative_to(path)) for p in files}==set(pins),'Completed A output membership changed'
    for name,digest in pins.items():assert sha(path/name)==digest,('completed shortA changed',name)


def verify_reuse():
    ledger=read(ROOT/'SHORT_A_REUSE.json');manifest=read(ROOT/'MANIFEST.json')
    assert ledger['state']=='prospectively_pinned_completed_short_A' and ledger['path']==str(A_PATH)
    assert ledger['r1_manifest_sha256']==sha(R1_ROOT/'MANIFEST.json')==R1_MANIFEST
    old=read(R1_ROOT/'MANIFEST.json')
    assert old['source_hashes']==manifest['source_hashes']==ledger['scientific_source_hashes']
    assert old['reference_i2_hashes']==manifest['reference_i2_hashes']
    for name,digest in old['bundle_hashes'].items():assert sha(R1_ROOT/name)==digest,('preserved frozen r1 source',name)
    for name,digest in ledger['native_metadata_hashes'].items():assert sha(name)==digest,('r1 actual failure/provenance changed',name)
    check_artifacts(A_PATH,ledger['artifact_hashes'])
    actual=read(ROOT/'R1_FAILURE_RECEIPT.json')
    assert sha(ROOT/'R1_FAILURE_RECEIPT.json')==ledger['root_actual_failure_receipt_sha256']
    assert sha(ROOT/'R1_FAILURE_CAPTURE_EXECUTION.json')==ledger['root_actual_failure_capture_execution_sha256']
    suite=read(R1_ROOT/'suite_status.json')
    assert suite==actual['status']
    assert sha(R1_ROOT/'logs/smoke_Full_a__verify.log')==actual['verify_log_sha256']
    assert suite['state']=='failed' and not suite['active'] and suite['formal_training_started_count']==0
    assert suite['failure']['id']=='smoke_Full_a' and suite['failure']['stage']=='verify' and suite['failure']['returncode']==1
    a,b=suite['smoke_jobs'];assert a['path']==str(A_PATH) and a['state']=='failed' and b['state']=='pending' and 'training_pid' not in b
    assert not (R1_ROOT/'runs/smoke_Full_b').exists()
    training,stress,failed_verify=ledger['training_execution'],ledger['stress_execution'],ledger['failed_verify_execution']
    assert training in a['process_history'] and stress in a['process_history'] and failed_verify in a['process_history']
    assert (training['stage'],training['pid'],training['returncode'])==('training',3909186,0)
    assert (stress['stage'],stress['pid'],stress['returncode'])==('stress',3929317,0)
    assert (failed_verify['stage'],failed_verify['pid'],failed_verify['returncode'])==('verify',3934563,1)
    config=read(A_PATH/'config.json');summary=read(A_PATH/'summary.json');side=read(A_PATH/'checkpoint_stress_result.json')
    assert config['source_sha256']==manifest['source_hashes'] and config['seed']==91103 and config['device']=='cuda:0'
    assert config['effective_steps']==config['steps']==summary['steps']==786432 and config['stage_switch_steps']==524288
    assert summary==read(A_PATH/'status.json') and summary['state']=='completed' and summary['reload_check']=='passed'
    assert summary['optimizer_steps']=={'actor':7680,'critic':7680,'h':0}
    assert side['state']=='passed' and side['source_hashes']==manifest['source_hashes']
    assert side['training_transitions']==side['optimizer_steps']==0 and side['training_files_unchanged'] and side['model_unchanged'] and side['normalizer_unchanged']
    assert side['protected_training_artifacts']==ledger['pre_stress_artifact_hashes']
    return {'state':'passed','path':str(A_PATH),'r1_manifest_sha256':R1_MANIFEST,
            'prior_actual_training_pid':training['pid'],'prior_actual_training_returncode':0,
            'prior_actual_stress_pid':stress['pid'],'prior_actual_stress_returncode':0,
            'prior_failed_verify_pid':failed_verify['pid'],'prior_failed_verify_returncode':1,
            'preserved_artifacts':len(ledger['artifact_hashes']),'prior_observed_peak_mib':ledger['prior_observed_peak_mib'],
            'new_training_transitions':0,'new_stress_evaluation_calls':0,'tensor_payload_copies':0}
