"""Fresh-process exact TD-persistence Full replay; GPU imports never reach coordinator."""
import argparse,ast,copy,csv,hashlib,importlib.util,json,math,os,struct,sys,types
from pathlib import Path
from contracts import BUDGET,SHORT,SWITCH,SHORT_SWITCH,ledger
from controller_oracle import replay as controller_oracle
from bundle_contract import ROOT,DET,STRESS,check_manifest,require_runtime,validate_interpreter_provenance
sys.dont_write_bytecode=True
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import torch
BASEFILES=('config.json','summary.json','status.json','progress.csv','initial_evaluation.json','evaluations.jsonl','latest.pt','stress_evaluation.json','checkpoint_stress_result.json','retained_tail_diagnostics.jsonl','td_persistence_decisions.jsonl','first_window_pre.pt','first_window_post.pt','final_scientific_state.pt')
def read(p):
    def invalid(value):raise ValueError('Nonfinite JSON constant: '+value)
    return json.loads(Path(p).read_text(),parse_constant=invalid)

def write(p,x):
    p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n');tmp.replace(p)

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def jsonl(p):return [json.loads(x) for x in Path(p).read_text().splitlines() if x.strip()]

def exact(a,b):assert type(a)==type(b) and (struct.pack('!d',a)==struct.pack('!d',b) if isinstance(a,float) else a==b),(a,b)

def differences(a,b,path=''):
    if isinstance(a,torch.Tensor):
        if not isinstance(b,torch.Tensor) or a.dtype!=b.dtype or a.shape!=b.shape:return [path]
        return [] if torch.equal(a.detach().cpu().contiguous().reshape(-1).view(torch.uint8),b.detach().cpu().contiguous().reshape(-1).view(torch.uint8)) else [path]
    if isinstance(a,dict):
        if not isinstance(b,dict) or a.keys()!=b.keys():return [path+'.keys']
        return [v for k in a for v in differences(a[k],b[k],path+'.'+str(k))]
    if isinstance(a,(list,tuple)):
        if type(a)!=type(b) or len(a)!=len(b):return [path+'.len']
        return [v for i,(x,y) in enumerate(zip(a,b)) for v in differences(x,y,path+'.'+str(i))]
    if type(a)!=type(b):return [path+'.type']
    return [] if (struct.pack('!d',a)==struct.pack('!d',b) if isinstance(a,float) else a==b) else [path]

def batch(e,device=None):
    assert len(e['returns'])==len(e['lengths'])==32 and all(math.isfinite(v) for v in e['returns'])
    assert all(type(v) is int and 1<=v<=1000 for v in e['lengths'])
    assert math.isfinite(e['mean']) and math.isfinite(e['std'])
    if device:
        v=torch.tensor(e['returns'],dtype=torch.float32,device=device);exact(float(v.mean()),e['mean']);exact(float(v.std(unbiased=False)),e['std'])

def auc(p,budget):
    initial=read(p/'initial_evaluation.json');ev=jsonl(p/'evaluations.jsonl')
    for e in [initial,*ev]:batch(e)
    pts=[(0,initial['mean'])]+[(e['steps'],e['mean']) for e in ev]
    assert pts[-1][0]==budget and all(a[0]<b[0] for a,b in zip(pts,pts[1:]))
    return sum((b[0]-a[0])*(a[1]+b[1])/2 for a,b in zip(pts,pts[1:]))/budget,initial,ev

def controller_class():
    name='full_td_controller'
    if name not in sys.modules:
        spec=importlib.util.spec_from_file_location(name,ROOT/'source_full/lambda_td_persistence.py');module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return sys.modules[name].TDPersistence

def signal_reducer():
    name='full_td_signal'
    if name not in sys.modules:
        spec=importlib.util.spec_from_file_location(name,ROOT/'source_full/signal_td_persistence.py');module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return sys.modules[name].td_persistence

def primitive(function_name,reference=False):
    name='full_replay_'+function_name+('_reference' if reference else '')
    if name not in sys.modules:
        source=ROOT/('reference_i2' if reference else 'source_full')/'train_pae_baseline.py'
        nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==function_name];assert len(nodes)==1
        module=types.ModuleType(name);module.torch=torch;sys.modules[name]=module
        exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(source),'exec'),module.__dict__)
    return getattr(sys.modules[name],function_name)

def scientific_names(short=False):return [f'full_scientific_states/update_{x["update"]:03d}.pt' for x in ledger(short)]

def assert_scientific_capture(x,expected_adam):
    def finite_cpu(value):
        if isinstance(value,torch.Tensor):
            assert value.device.type=='cpu' and not value.requires_grad and bool(torch.isfinite(value).all())
        elif isinstance(value,dict):
            for child in value.values():finite_cpu(child)
        elif isinstance(value,(list,tuple)):
            for child in value:finite_cpu(child)
        elif isinstance(value,float):assert math.isfinite(value)
    finite_cpu(x)
    assert set(x)=={'model','optimizers','obs_stats','reward_stats','update','steps','physics','controller','actor_lambda','critic_lambda'}
    modelkeys={'log_std'}|{f'{scope}.{layer}.{field}' for scope in ('actor','critic') for layer in (0,2,4) for field in ('weight','bias')}
    assert set(x['model'])==modelkeys and set(x['optimizers'])=={'ppo'}
    for scope in ('obs_stats','reward_stats'):assert set(x[scope])=={'mean','var','count'}
    optimizer=x['optimizers']['ppo'];assert set(optimizer)=={'state','param_groups'} and len(optimizer['param_groups'])==1
    parameters=optimizer['param_groups'][0]['params'];assert len(parameters)==len(modelkeys) and set(optimizer['state'])==set(parameters)
    for value in optimizer['state'].values():
        assert set(value)=={'step','exp_avg','exp_avg_sq'} and float(value['step'])==expected_adam
        assert value['exp_avg'].shape==value['exp_avg_sq'].shape
    for name in ('torch_cpu_rng','torch_cuda_rng'):
        tensor=x['physics'][name];assert tensor.dtype==torch.uint8 and tensor.device.type=='cpu' and tensor.ndim==1 and tensor.numel()>0
    for scope in ('training','evaluation'):
        tensor=x['physics'][scope]['rng'];assert tensor.dtype==torch.uint8 and tensor.device.type=='cpu' and tensor.ndim==1 and tensor.numel()>0

def window_names(short=False):return [f'full_window_audits/update_{x["update"]:03d}.pt' for x in ledger(short)]

def legacy_audit_names(short=False):return [f'split_trace_audit_{u:03d}.pt' for u in (3,8 if short else 86,13 if short else 164)]

def checkpoint(path,expected,config):
    x=torch.load(path/'latest.pt',map_location='cpu',weights_only=False);assert x['config']==config and x['steps']==(expected//10*1024)
    assert x['optimizer_steps']=={'actor':expected,'critic':expected,'h':0} and set(x['optimizers'])=={'ppo'}
    opt=x['optimizers']['ppo'];assert opt['state'] and len(opt['state'])==len(x['model'])
    for d in opt['state'].values():
        assert float(d['step'])==expected
        for k in ('exp_avg','exp_avg_sq'):assert bool(torch.isfinite(d[k]).all())
    assert all(bool(torch.isfinite(v).all()) for v in x['model'].values());return x

def replay_window(x,l,device,actual_target_audit):
    for key,value in l.items():exact(x[key],value)
    assert x['target_device']==device and x['gamma']==.99 and x['critic_lambda']==.95
    end,used,incoming=l['end_per_world'],l['used_per_world'],l['incoming_retained_per_world']
    keys=('normalized_reward','values','next_values','terminated','done','raw_rhos','capped_cs')
    for key in (*keys,'trace_logratios'):
        t=x[key];assert isinstance(t,torch.Tensor) and t.shape==(end,1024) and t.device.type=='cpu' and not t.requires_grad
        assert t.dtype==(torch.bool if key in ('terminated','done') else torch.float32) and bool(torch.isfinite(t).all())
    for key in ('actor_advantage','consumed_critic_return','fixed95_actor_advantage'):
        t=x[key];assert t.shape==(used*1024,) and t.dtype==torch.float32 and t.device.type=='cpu' and not t.requires_grad and bool(torch.isfinite(t).all())
    assert not bool((x['terminated']&~x['done']).any())
    logs=x['trace_logratios'].to(device);rho=logs.exp();c=logs.clamp(max=0).exp()
    assert torch.equal(rho,x['raw_rhos'].to(device)) and torch.equal(c,x['capped_cs'].to(device))
    assert torch.equal(rho[incoming:],torch.ones_like(rho[incoming:])) and torch.equal(c[incoming:],torch.ones_like(c[incoming:]))
    xs=[x[k].to(device) for k in keys];primary=primitive('split_tail_trace');actor=primitive('actor_split_tail_trace')
    with torch.no_grad():
        if actual_target_audit:
            for _ in range(3):primary(*xs,.99,.95)
            a95,r95=primary(*xs,.99,.95)
            assert torch.equal(a95[:used].flatten(),x['fixed95_actor_advantage'].to(device)) and torch.equal(r95[:used].flatten(),x['consumed_critic_return'].to(device)),('primary95 consumed replay',l['update'])
        if x['actor_lambda']!=.95:
            for _ in range(3):actor(*xs,.99,.95)
            a,_=actor(*xs,.99,x['actor_lambda'])
            assert torch.equal(a[:used].flatten(),x['actor_advantage'].to(device)),('actual adaptive actor replay',l['update'])
        elif actual_target_audit:
            assert torch.equal(a95[:used].flatten(),x['actor_advantage'].to(device)),('shared actual actor95 replay',l['update'])
        metrics=signal_reducer()(*xs[:5],incoming,used,.99)
    for key,value in metrics.items():exact(value,x[key])
    return metrics,not torch.equal(x['actor_advantage'],x['fixed95_actor_advantage'])

def verify(j):
    p=Path(j['path']);short=bool(j.get('smoke'));budget=SHORT if short else BUDGET;ls=ledger(short);device=f"cuda:{j['gpu']}";torch.cuda.set_device(device)
    c=read(p/'config.json');summary=read(p/'summary.json');assert summary==read(p/'status.json') and summary['state']=='completed' and summary['reload_check']=='passed'
    assert c['task']=='Hopper' and summary['physics_device']==summary['device']==device
    assert c['algorithm_version']=='hopper_full_td_persistence_accepted_i2_v1' and c['source_sha256']==read(ROOT/'MANIFEST.json')['source_hashes']
    assert c['versions']==read(ROOT/'MANIFEST.json')['runtime_versions'] and c['xml_sha256']==read(ROOT/'MANIFEST.json')['xml_sha256']
    assert c['seed']==j['seed'] and c['device']==device and c['determinism']==DET and c['effective_steps']==c['steps']==summary['steps']==budget
    assert c['stage_switch_steps']==(SHORT_SWITCH if short else SWITCH) and c['retained_tail_steps']==8 and c['fixed_critic_lambda']==.95
    assert c['staged_full'] and c['retained_tail_diagnostics'] and c['retained_tail_correction'] and c['retained_td_unclipped'] and c['save_split_trace_audit']
    assert not(c['adaptive_kl'] or c['readiness_boost'] or c['adaptive_overlap'] or c['force_pae_overlap'])
    for key,value in [('num_envs',1024),('rollout',64),('batch_size',1024),('epochs',10),('eval_envs',32),('eval_every',262144)]:assert c[key]==value
    assert summary['training_transitions']==summary['total_algorithm_transitions']==budget and summary['optimizer_steps']=={'actor':budget//1024*10,'critic':budget//1024*10,'h':0}
    assert c['signal_files']==window_names(short)
    assert {str(v.relative_to(p)) for v in (p/'full_window_audits').glob('*.pt')}==set(window_names(short))
    assert {v.name for v in p.glob('split_trace_audit_*.pt')}==set(legacy_audit_names(short))
    rows=list(csv.DictReader((p/'progress.csv').open()));decisions=jsonl(p/'td_persistence_decisions.jsonl');diagnostics=jsonl(p/'retained_tail_diagnostics.jsonl');assert len(rows)==len(decisions)==len(diagnostics)==len(ls)
    control=controller_class()();history=[];oracle=controller_oracle(history);values=[];reports=[];separated=0;adam_count=0
    assert {str(v.relative_to(p)) for v in (p/'full_scientific_states').glob('*.pt')}==set(scientific_names(short))
    for l,row,d,diag in zip(ls,rows,decisions,diagnostics):
        u=l['update'];assert d['update']==diag['update']==u and d['steps']==int(row['steps'])==l['steps']
        for key in ('fresh_per_world','used_per_world','retained_per_world'):assert int(row[key])==l[key]
        assert row['overlap_active']==str(l['overlap_active']) and row['stage_boundary_flush']==str(l['stage_boundary_flush'])
        assert float(row['gae_lambda_used'])==float(row['gae_lambda_next'])==.95,'Legacy columns describe primary95'
        x=torch.load(p/window_names(short)[u-1],map_location='cpu',weights_only=False)
        assert not differences(x['controller_before_step'],control.state_dict())
        assert not differences(control.state_dict(),oracle)
        prior_value=oracle['value'];oracle=controller_oracle(history,before_window=True);oracle_delta=oracle['value']-prior_value;delta=control.step(u)
        exact(delta,oracle_delta);assert not differences(control.state_dict(),oracle)
        assert not differences(x['controller_before_observe'],control.state_dict());exact(control.value,x['actor_lambda']);exact(control.value,d['actor_lambda']);exact(delta,d['lambda_delta']);exact(.95,d['critic_lambda'])
        actual_target_audit=u in ([3,4,5,9,10,13] if short else [3,4,5,87,88,164])
        metrics,effect=replay_window(x,l,device,actual_target_audit);separated+=int(effect)
        for key,value in metrics.items():exact(value,d[key])
        history.append(metrics['persistence'])
        oracle=controller_oracle(history)
        control.observe(metrics['persistence'])
        assert not differences(control.state_dict(),oracle),('independent chronological block/slow-target oracle',u)
        adam_count+=l['used_per_world']*10
        scientific=torch.load(p/scientific_names(short)[u-1],map_location='cpu',weights_only=False)
        assert_scientific_capture(scientific,adam_count)
        assert not differences(scientific['controller'],control.state_dict())
        assert scientific['update']==u and scientific['steps']==l['steps'] and scientific['actor_lambda']==x['actor_lambda'] and scientific['critic_lambda']==.95
        assert all(float(v['step'])==adam_count for v in scientific['optimizers']['ppo']['state'].values())
        assert set(scientific['physics'])=={'training','evaluation','torch_cpu_rng','torch_cuda_rng'}
        for scope in ('training','evaluation'):
            tensors=scientific['physics'][scope]
            assert set(tensors)=={'qpos','qvel','ctrl','xipos','site_xpos','constraint_force','ant_x','qpos0','reset_mask','lengths','returns','overflow_seen','nonfinite_seen','rng'}
            assert all(isinstance(v,torch.Tensor) and v.device.type=='cpu' and not v.requires_grad and bool(torch.isfinite(v).all()) for v in tensors.values())
        if u<=4:assert x['actor_lambda']==.95 and not effect
        if short and u==5:
            assert x['actor_lambda']!=.95 and effect,'inactive short window5 adaptive actor; no retry or waiver'
        if short and u==9:
            assert l['incoming_retained_per_world']==8 and l['stage_boundary_flush'] and l['used_per_world']==l['end_per_world']==64
        assert control.observations==u
        for key,value in control.state_dict().items():exact(value,d[key])
        for key in ('value_loss','policy_loss','approx_kl','explained_variance'):assert math.isfinite(float(row[key]))
        assert diag['fresh_actor_correction_nonzero_count']==diag['fresh_critic_correction_nonzero_count']==0
        values.append(control.value);reports.append({'update':u,'actor_lambda':control.value,'critic_lambda':.95,'actual_actor_labels_separated':effect,'primary_actual_target_audit':actual_target_audit,'early_cold_primary_targets_not_warmed_retroactively':u in (1,2),'slow_persistence':control.slow_persistence,'slow_initialized':control.slow_initialized,**metrics})
    assert values[:4]==[.95]*4 and max(abs(v-.95) for v in values)>1e-12 and separated>0
    saved=checkpoint(p,budget//1024*10,c);assert saved['td_persistence_feedback']==control.state_dict()
    final_scientific=torch.load(p/'final_scientific_state.pt',map_location='cpu',weights_only=False);assert_scientific_capture(final_scientific,budget//1024*10)
    assert not differences(final_scientific['controller'],control.state_dict())
    for key in ('model','optimizers','obs_stats','reward_stats'):assert not differences(final_scientific[key],saved[key])
    area,initial,ev=auc(p,budget);assert len(ev)==(3 if short else 39)
    threshold=262144;expected=[]
    for l in ls:
        if l['steps']>=threshold or l['steps']==budget:expected.append(l['steps']);threshold=(l['steps']//262144+1)*262144
    assert [e['steps'] for e in ev]==expected
    for e in [initial,*ev,summary['final_eval']]:batch(e,device)
    exact(ev[-1]['mean'],summary['final_eval']['mean'])
    # Accepted I2 stores np.trapz AUC; recomputation uses the original evaluation grid.
    assert math.isclose(area,summary['normalized_return_auc'],rel_tol=0.,abs_tol=1e-12)
    stress=read(p/'stress_evaluation.json');assert [(x['mode'],x['scale']) for x in stress]==list(STRESS)
    for e in stress:batch(e,device)
    side=read(p/'checkpoint_stress_result.json');assert side['state']=='passed' and side['training_transitions']==side['optimizer_steps']==0 and side['model_unchanged'] and side['normalizer_unchanged']
    names=[*BASEFILES,*window_names(short),*scientific_names(short),*legacy_audit_names(short)];assert all((p/name).is_file() for name in names)
    return {'seed':j['seed'],'path':str(p),'final_return':summary['final_eval']['mean'],'auc':area,'initial_return':initial['mean'],'updates':len(ls),'steps':budget,'actor_adam_steps':budget//1024*10,'critic_adam_steps':budget//1024*10,'auxiliary_adam_steps':0,'lambda_min':min(values),'lambda_max':max(values),'maximum_lambda_deviation':max(abs(v-.95) for v in values),'controller_replay':'passed','declared_native_replays':'passed','all_window_signal_controller_replay':'passed','primary_actual_target_audit_updates':[3,4,5,9,10,13] if short else [3,4,5,87,88,164],'first2_primary_targets_scope':'captured finite native payloads; firstwindow direct I2negativecontrol; no warmedretroactive equality claim','actual_labels_separated_windows':separated,'window_reports':reports,'stress_verified':True,'artifact_hashes':{name:sha(p/name) for name in names}}

def exact_pair(first,second):
    ps=[Path(first),Path(second)];delta=[]
    xs=[torch.load(p/'latest.pt',map_location='cpu',weights_only=False) for p in ps]
    for x in xs:x['config'].pop('out')
    delta+=differences(*xs,path='latest.pt')
    for name in [*window_names(True),*scientific_names(True),*legacy_audit_names(True),'first_window_pre.pt','first_window_post.pt','final_scientific_state.pt']:
        delta+=differences(*(torch.load(p/name,map_location='cpu',weights_only=False) for p in ps),path=name)
    for name in ('initial_evaluation.json','evaluations.jsonl','td_persistence_decisions.jsonl','retained_tail_diagnostics.jsonl','stress_evaluation.json'):
        if (ps[0]/name).read_bytes()!=(ps[1]/name).read_bytes():delta.append(name)
    for name in ('config.json','summary.json','status.json'):
        xs=[read(p/name) for p in ps]
        for x in xs:
            for key in ('out','pid','elapsed_seconds','steps_per_second','peak_torch_memory_bytes'):x.pop(key,None)
        delta+=differences(*xs,path=name)
    rows=[list(csv.DictReader((p/'progress.csv').open())) for p in ps]
    assert len(rows[0])==len(rows[1])==13
    for u,(x,y) in enumerate(zip(*rows),1):delta+=[f'progress.{u}.{k}' for k in x if k not in ('elapsed_seconds','steps_per_second') and x[k]!=y[k]]
    assert not delta,delta
    return {'state':'passed','seed':91103,'gpu':0,'short_windows':13,'model_Adam_normalizers_all_scientific_signal_controller_targets_bytes_exact':True,'scientific_non_timing_logs_exact':True,'named_config_summary_status_operational_exclusions':['out','pid','elapsed_seconds','steps_per_second','peak_torch_memory_bytes'],'named_progress_timing_exclusions':['elapsed_seconds','steps_per_second'],'both_allocator_peaks_preserved_max_used_for_memory':True,'no_tolerance_or_retry':True}

def compare_reference(reference,candidate):
    ps=[Path(reference),Path(candidate)]
    for phase in ('pre','post'):
        xs=[torch.load(p/f'first_window_{phase}.pt',map_location='cpu',weights_only=False) for p in ps]
        assert not differences(*xs,path=phase),('original I2 first-window fixed95 control',phase)
    assert (ps[0]/'initial_evaluation.json').read_bytes()==(ps[1]/'initial_evaluation.json').read_bytes()
    return {'state':'passed','original_I2_used56_first_window_before_auxiliary_warmups_exact':True,'pre_targets_inputs_model_Adam_normalizers_exact':True,'post_PPO_model_Adam_normalizers_exact':True,'same_seed91103_GPU0':True}

def verify_reference_provenance(config,receipt,reference_hashes):
    # The unchanged original trainer records five imported implementation files;
    # the read-only capture receipt independently records all eighteen package files.
    keys=('train_pae_baseline.py','external_baseline_algorithms.py','locomotion_warp.py',
          'train_noisy_warp.py','ant_contact_compat.py')
    assert len(reference_hashes)==18 and all(key in reference_hashes for key in keys)
    assert set(config['source_sha256'])==set(keys)
    assert config['source_sha256']=={key:reference_hashes[key] for key in keys}
    assert receipt['state']=='passed' and receipt['source_hashes']==reference_hashes
    return True

def verify_reference(path):
    from reference_reuse import verify_existing_reference
    reused=verify_existing_reference(path)
    p=Path(path);c=read(p/'config.json');summary=read(p/'summary.json')
    assert c['task']=='Hopper' and c['seed']==91103 and c['device']=='cuda:0'
    assert c['effective_steps']==summary['steps']==SHORT and summary['state']=='completed'
    reference_hashes=read(ROOT/'MANIFEST.json')['reference_i2_hashes']
    verify_reference_provenance(c,read(p/'REFERENCE_CAPTURE_VERIFIED.json'),reference_hashes)
    assert c['determinism']==DET and summary['reload_check']=='passed'
    assert c['stage_switch_steps']==SHORT_SWITCH and c['xml_sha256']==read(ROOT/'MANIFEST.json')['xml_sha256']
    for key,value in [('num_envs',1024),('rollout',64),('batch_size',1024),('epochs',10),('eval_envs',32),('eval_every',262144)]:assert c[key]==value
    assert c['method']=='pae' and c['staged_full'] and c['retained_tail_steps']==8 and c['retained_tail_correction'] and c['retained_td_unclipped'] and c['save_split_trace_audit']
    assert not any(c[k] for k in ('adaptive_kl','readiness_boost','adaptive_overlap','force_pae_overlap'))
    assert summary['optimizer_steps']=={'actor':7680,'critic':7680,'h':0}
    progress=list(csv.DictReader((p/'progress.csv').open()));assert len(progress)==13
    for row,l in zip(progress,ledger(True)):
        assert int(row['steps'])==l['steps'] and int(row['used_per_world'])==l['used_per_world'] and int(row['fresh_per_world'])==l['fresh_per_world'] and int(row['retained_per_world'])==l['retained_per_world']
        assert row['overlap_active']==str(l['overlap_active']) and row['stage_boundary_flush']==str(l['stage_boundary_flush'])
        assert float(row['gae_lambda_used'])==float(row['gae_lambda_next'])==.95
    saved=torch.load(p/'latest.pt',map_location='cpu',weights_only=False)
    assert {float(v['step']) for v in saved['optimizers']['ppo']['state'].values()}=={7680.}
    receipt=read(p/'REFERENCE_CAPTURE_VERIFIED.json')
    assert receipt['state']=='passed' and receipt['source_hashes']==reference_hashes
    assert receipt['original_source_unmodified'] and receipt['f_locals_read_only']
    assert receipt['seed']==91103 and receipt['gpu']==0 and receipt['device']=='cuda:0' and receipt['training_transitions']==SHORT and receipt['stage_switch_steps']==SHORT_SWITCH
    assert receipt['windows']==13 and receipt['shared_adam_calls']==7680 and receipt['runtime_versions']==read(ROOT/'MANIFEST.json')['runtime_versions']
    manifest=read(ROOT/'MANIFEST.json');binding=read(ROOT/'PARENT_NATIVE_BINDINGS.json')
    assert receipt['native_python'].startswith('3.11.15 ')
    provenance=validate_interpreter_provenance(binding['invocation_entrypoint'],receipt['actual_interpreter'],manifest['native_interpreter'],manifest['actual_native_interpreter'])
    assert provenance['actual_resolved_interpreter']==binding['actual_resolved_interpreter']
    assert receipt['config_sha256']==sha(p/'config.json') and receipt['initial_evaluation_sha256']==sha(p/'initial_evaluation.json')
    assert receipt['tracer_numerical_state_assignments']==receipt['extra_model_optimizer_environment_calls']==0
    for phase,digest in receipt['snapshots'].items():assert sha(p/f'first_window_{phase}.pt')==digest
    return {'state':'passed','seed':91103,'gpu':0,'path':str(p),'snapshots':receipt['snapshots'],'primary_analysis_excluded':True,'reference_reused':True,'new_reference_training':0,'reuse_verification':reused}


def verify_saved_signal(device):
    """Read32 immutable actual old-Full windows; never selects a target or sees returns."""
    original=Path('/ssd_2/wch/hopper_full_slow_reference_staging_r2_8seed_20261007')
    pins=read(ROOT/'PRESERVED_NATIVE_FILES.json');rows=[]
    for seed in range(21,29):
        for update in (9,87,88,164):
            path=original/'runs'/('Hopper__Full_slow_reference__seed'+str(seed))/'full_window_audits'/f'update_{update:03d}.pt'
            assert sha(path)==pins[str(path)]
            x=torch.load(path,map_location='cpu',weights_only=False)
            keys=('normalized_reward','values','next_values','terminated','done')
            xs=[x[k].to(device) for k in keys]
            metrics=signal_reducer()(*xs,x['incoming_retained_per_world'],x['used_per_world'],.99)
            # Independent mask construction and FP64 pair reduction on native tensors.
            first,last=x['incoming_retained_per_world'],x['used_per_world']
            td=(xs[0]+.99*(~xs[3]).float()*xs[2]-xs[1]).double()
            times=torch.arange(first,last-1,device=device)[:,None].expand(last-first-1,1024)
            worlds=torch.arange(1024,device=device)[None,:].expand(last-first-1,1024)
            valid=~xs[4][times,worlds]
            a,b=td[times[valid],worlds[valid]],td[times[valid]+1,worlds[valid]]
            assert metrics['td_pair_count']==a.numel() and metrics['td_fresh_consumed_rows']==last-first
            if a.numel()>1 and float(a.var(unbiased=False))>0 and float(b.var(unbiased=False))>0:
                expected=float(((a-a.mean())*(b-b.mean())).mean()/torch.sqrt(a.var(unbiased=False)*b.var(unbiased=False)))
                assert math.isclose(metrics['persistence'],max(-1.,min(1.,expected)),rel_tol=0,abs_tol=1e-14)
            assert sha(path)==pins[str(path)]
            rows.append({'seed':seed,'update':update,'input_sha256':pins[str(path)],**metrics})
    return {'state':'passed','rows':rows,'all32_saved_windows':True,'signal_domain_independently_indexed':True,'no_parameter_or_polarity_selection':True,'training_or_evaluation_calls':0}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--operation',choices=['verify','pair','reference','compare-reference','protected','saved-state'],required=True)
    parser.add_argument('--job-json',type=Path);parser.add_argument('--paths',nargs='+');parser.add_argument('--result',type=Path,required=True)
    parser.add_argument('--gpu',type=int,choices=[0,1],default=0)
    args=parser.parse_args();manifest=require_runtime();torch.set_num_threads(1);torch.use_deterministic_algorithms(True);torch.cuda.set_device('cuda:'+str(args.gpu))
    if args.operation=='verify':
        job=read(args.job_json);assert job['gpu']==args.gpu;result=verify(job)
    elif args.operation=='saved-state':result=verify_saved_signal('cuda:'+str(args.gpu))
    elif args.operation=='pair':result=exact_pair(*args.paths)
    elif args.operation=='reference':result=verify_reference(args.paths[0])
    elif args.operation=='compare-reference':result=compare_reference(*args.paths)
    else:
        from bundle_contract import verify_historical
        result=verify_historical()
    result['peak_torch_memory_reserved_bytes']=torch.cuda.max_memory_reserved('cuda:'+str(args.gpu))
    result['state']='passed';result['manifest_sha256']=sha(ROOT/'MANIFEST.json');result['operation']=args.operation;result['source_hashes']=manifest['source_hashes']
    assert not args.result.exists();write(args.result,result)
    print(json.dumps({'state':'passed','operation':args.operation,'result':str(args.result)}))

if __name__=='__main__':main()
