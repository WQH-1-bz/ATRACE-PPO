"""Parent-invoked cold native source binding; no scientific imports/GPU calls."""
import importlib.metadata
import os
from pathlib import Path
import sys
from bundle_contract import ROOT,NATIVE_ROOT,PYTHON,FLAGS,read,sha,write_new,check_manifest,child_env,validate_interpreter_provenance
def main():
    assert ROOT==NATIVE_ROOT and 'CUDA_VISIBLE_DEVICES' not in os.environ
    m=check_manifest();assert sys.version.startswith('3.11.15 ')
    provenance=validate_interpreter_provenance(PYTHON,sys.executable,m['native_interpreter'],m['actual_native_interpreter'])
    actual_interpreter=provenance['actual_resolved_interpreter']
    for name,version in m['runtime_versions'].items():assert importlib.metadata.version(name)==version
    assert all(os.environ.get(k)==v for k,v in FLAGS.items())
    review=read(ROOT/'PARENT_REVIEW_ADMISSION.json');assert review['state']=='passed' and review['manifest_sha256']==sha(ROOT/'MANIFEST.json') and review['independent_source_review_passed']
    assert review['practical_td_persistence_candidate_approved'] and review['user_broader_code_changes_authorized']
    assert review['oracle_float_type_recovery_approved'] and review['completed_short_A_reuse_approved']
    for path,digest in read(ROOT/'PRESERVED_NATIVE_FILES.json').items():assert sha(path)==digest
    from short_a_reuse import verify_reuse
    reuse=verify_reuse()
    source={p.name:sha(p) for p in (ROOT/'source_full').iterdir() if p.is_file()}
    reference={p.name:sha(p) for p in (ROOT/'reference_i2').iterdir() if p.is_file()}
    assert source==m['source_hashes'] and reference==m['reference_i2_hashes']
    write_new(ROOT/'PARENT_NATIVE_BINDINGS.json',{'state':'verified','completed_short_A_reuse':reuse,'manifest_sha256':sha(ROOT/'MANIFEST.json'),'source_hashes':source,'reference_i2_hashes':reference,'runtime_python':sys.version,'actual_interpreter':sys.executable,'actual_resolved_interpreter':actual_interpreter,'expected_actual_interpreter':m['actual_native_interpreter'],'invocation_entrypoint':str(PYTHON),'runtime_versions':{p:importlib.metadata.version(p) for p in m['runtime_versions']},'CUDA_VISIBLE_DEVICES_present':False,'original_caches':{k:v for k,v in child_env().items() if k in ('XDG_CACHE_HOME','WARP_CACHE_PATH','CUDA_CACHE_PATH','TORCH_HOME','TMPDIR')},'scientific_imports':0,'new_training_or_evaluation':0})
if __name__=='__main__':main()
