"""Independent scalar contract replay from the full chronological observation list."""
import math


def replay(history, before_window=False):
    value=target=.95
    slow=0.
    initialized=False
    states=[]
    for index, observation in enumerate(history,1):
        if not math.isfinite(observation) or not -1 <= observation <= 1:
            raise ValueError('Invalid chronological TD persistence')
        if index>4:
            change=max(-.001,min(.001,.1*(target-value)))
            value=min(.99,max(.90,value+change))
        if index%4==0:
            block=sum(history[index-4:index])/4.
            slow=block if not initialized else .9*slow+.1*block
            initialized=True
            target=min(.99,max(.90,.95+.04*math.tanh(2.*slow)))
        states.append({'value':value,'target':target,'observations':index,'block_sum':sum(history[index-index%4:index],0.),'last_persistence':observation,'last_block_mean':sum(history[index-index%4-4:index-index%4])/4. if index>=4 else 0.,'slow_persistence':slow,'slow_initialized':initialized})
    state=states[-1] if states else {'value':.95,'target':.95,'observations':0,'block_sum':0.,'last_persistence':0.,'last_block_mean':0.,'slow_persistence':0.,'slow_initialized':False}
    if before_window:
        state=dict(state)
        if len(history)+1>4:
            state['value']=min(.99,max(.90,state['value']+max(-.001,min(.001,.1*(state['target']-state['value'])))))
    return state
