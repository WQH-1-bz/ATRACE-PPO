"""Bounded stdlib source checks; no real Torch/NumPy/SSH/GPU imports or native run."""
import ast
import copy
import importlib.util
import json
import math
import struct
import subprocess
import sys
import types
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'source_full'))
from lambda_td_persistence import TDPersistence
from signal_td_persistence import persistence_from_moments,td_persistence
from controller_oracle import replay
from contracts import ledger,split_reference
import run_full

def expect_failure(call):
    try:call()
    except (ValueError,AssertionError,KeyError,FileNotFoundError):return
    raise AssertionError('Required negative control passed')

# Small generic tensor arithmetic adapter, solely to exercise the real domain selector.
# It emulates FP32 element arithmetic and FP64 moments without loading a tensor library.
class Array:
    def __init__(self,data,dtype='float32',shape=None):
        self.data=data;self.dtype=dtype;self.shape=shape or ((len(data),len(data[0])) if data and isinstance(data[0],list) else (len(data),));self.ndim=len(self.shape);self.device='test_cpu'
    def flat(self):return [v for row in self.data for v in row] if self.ndim==2 else list(self.data)
    def apply(self,other,fn,dtype=None):
        data=self.flat();rhs=other.flat() if isinstance(other,Array) else [other]*len(data)
        dt=dtype or self.dtype
        def cast(x):return bool(x) if dt=='bool' else struct.unpack('f',struct.pack('f',x))[0] if dt=='float32' else float(x)
        vals=[cast(fn(a,cast(b))) for a,b in zip(data,rhs)]
        if self.ndim==2:vals=[vals[i:i+self.shape[1]] for i in range(0,len(vals),self.shape[1])]
        return Array(vals,dt,self.shape)
    def __add__(self,x):return self.apply(x,lambda a,b:a+b)
    def __sub__(self,x):return self.apply(x,lambda a,b:a-b)
    def __mul__(self,x):return self.apply(x,lambda a,b:a*b)
    __rmul__=__mul__
    def __and__(self,x):return self.apply(x,lambda a,b:a and b,'bool')
    def __invert__(self):return self.apply(0,lambda a,b:not a,'bool')
    def __getitem__(self,key):
        if isinstance(key,slice):return Array(self.data[key],self.dtype)
        if isinstance(key,Array):return Array([v for v,m in zip(self.flat(),key.flat()) if m],self.dtype)
        raise TypeError(key)
    def all(self):return all(self.flat())
    def any(self):return any(self.flat())
    def float(self):return Array([[float(v) for v in row] for row in self.data] if self.ndim==2 else list(map(float,self.data)),'float32',self.shape)
    def double(self):return Array(self.data,'float64',self.shape)
    def numel(self):return len(self.flat())
    def mean(self):return sum(self.flat())/self.numel()
    def var(self,unbiased=False):
        assert unbiased is False;m=self.mean();return sum((v-m)**2 for v in self.flat())/self.numel()
    def square(self):return self.apply(self,lambda a,b:a*b)

class FakeTorch(types.ModuleType):
    float32='float32';bool='bool'
    @staticmethod
    def isfinite(x):return x.apply(0,lambda a,b:math.isfinite(a),'bool')

def main():
    checked=[]
    files=list(ROOT.rglob('*.py'))
    for path in files:compile(path.read_text(),str(path),'exec')
    checked.append('all_python_compile')
    old=Path('/home/mumu08/ssd_2/wch/dpo/runs/hopper_full_slow_reference_staging_r2_8seed_20261007/source_full/train_pae_baseline.py')
    a,b=ast.parse(old.read_text()),ast.parse((ROOT/'source_full/train_pae_baseline.py').read_text())
    for name in ('capped_tail_trace','split_tail_trace','actor_split_tail_trace'):
        nodes=[next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name==name) for tree in (a,b)]
        assert ast.dump(nodes[0],include_attributes=False)==ast.dump(nodes[1],include_attributes=False)
    # Compare the complete optimizer epoch body, not only the recurrence text.
    def epoch(tree):return next(n for n in ast.walk(tree) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='epoch')
    assert ast.dump(epoch(a),include_attributes=False)==ast.dump(epoch(b),include_attributes=False)
    def calls(tree):return [ast.dump(n.func,include_attributes=False) for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id in ('model','env','optimizers','optimizer')]
    assert calls(a)==calls(b)
    checked.append('primary95_actor_trace_PPO_and_model_environment_call_AST_preserved')
    for short in (False,True):
        rows=ledger(short);assert rows[4]['incoming_retained_per_world']==8
        assert rows[8 if short else 86]['stage_boundary_flush']
    jobs=run_full.plan();assert len(jobs)==8 and [j['seed'] for j in jobs]==list(range(21,29))
    commands=[run_full.command(j) for j in jobs]
    stripped=[[v for i,v in enumerate(cmd) if i==0 or cmd[i-1] not in ('--seed','--out','--device')] for cmd in commands]
    assert all(x==stripped[0] for x in stripped)
    short_jobs=run_full.plan(True);assert short_jobs[0]['reused_completed_short'] and short_jobs[0]['state']=='verify_pending' and short_jobs[1]['state']=='pending'
    checked.append('exact_fresh_transition_optimizer_stage_ledger_shared8seed_plan')
    for signal in (1.,-1.,0.):
        history=[];control=TDPersistence()
        for update in range(1,165):
            before=control.state_dict();delta=control.step(update)
            assert abs(delta)<=.001+1e-15 and .90<=control.value<=.99
            assert control.state_dict()==replay(history,before_window=True)
            if update<=4:assert control.value==.95
            if update==5:assert (control.value>.95 if signal>0 else control.value<.95 if signal<0 else control.value==.95)
            history.append(signal);control.observe(signal);assert control.state_dict()==replay(history)
        expect_failure(lambda:control.step(2))
    mixed=[1.]*4+[-1.]*8+[.25]*12
    control=TDPersistence();history=[]
    for update,v in enumerate(mixed,1):
        control.step(update);history.append(v);control.observe(v);assert control.state_dict()==replay(history)
    for v in (float('nan'),float('inf'),1.01,-1.01):expect_failure(lambda v=v:TDPersistence().observe(v))
    checked.append('chronological_hold4_actor5_slow_block_signed_bounded_controller')
    for variance,covariance,expected in ((1.,1.,1.),(1.,-1.,-1.),(1.,0.,0.),(1e-90,1e-90,1.)):
        out=persistence_from_moments(3,4.,9.,variance,variance,covariance);assert out['persistence']==expected
    assert persistence_from_moments(3,0.,0.,0.,1.,0.)['persistence']==0.
    assert not persistence_from_moments(1,0.,0.,1.,1.,0.)['td_pair_signal_valid']
    expect_failure(lambda:persistence_from_moments(3,0.,0.,-1.,1.,0.))
    expect_failure(lambda:persistence_from_moments(3,0.,0.,1.,1.,float('nan')))
    checked.append('affine_sign_scale_tiny_positive_variance_and_degenerate_moments')
    assert 'torch' not in sys.modules
    sys.modules['torch']=FakeTorch('torch')
    try:
        rewards=Array([[900.,-700.],[1.,2.],[3.,4.],[5.,6.],[-800.,1000.]])
        zero=Array([[0.,0.]]*5);term=Array([[False,False]]*5,'bool')
        done=Array([[False,False],[False,False],[False,True],[False,False],[False,False]],'bool')
        out=td_persistence(rewards,zero,zero,term,done,1,4)
        left,right=[1.,2.,3.],[3.,4.,5.]
        assert out['td_pair_count']==3 and out['td_fresh_consumed_rows']==3 and out['persistence']==1.
        assert out['td_pair_mean_left']==sum(left)/3 and out['td_pair_mean_right']==sum(right)/3
        crossed=td_persistence(rewards,zero,zero,term,Array([[True,True]]*5,'bool'),1,4)
        assert crossed['td_pair_count']==0 and crossed['persistence']==0.
        invalid=Array([[True,False]]+[[False,False]]*4,'bool')
        expect_failure(lambda:td_persistence(rewards,zero,zero,invalid,done,1,4))
    finally:del sys.modules['torch']
    checked.append('actual_signal_selector_excludes_retained_context_and_episode_crossing')
    # Real owned local exit7 must stop admission before any GPU query or next Popen.
    child=subprocess.Popen([sys.executable,'-c','raise SystemExit(7)']);child.wait()
    failures=[];active={'owned':{'process':child,'stream':types.SimpleNamespace(close=lambda:None)}}
    def finished(i,v):raise AssertionError(v['returncode'])
    def failed(i,v,e,tb):failures.append((i,v['returncode']))
    queries=[]
    snap=run_full.admission_snapshot(lambda:run_full.drain_completions(active,finished,failed),lambda:bool(failures),lambda:queries.append(True),lambda x:True)
    assert snap is None and failures==[('owned',7)] and not queries and not active
    snapshot={'cards':{0:{'free_mib':4000}},'process_mib':{0:{}}}
    active={'init':{'job':{'gpu':0},'reservation':3500,'process':types.SimpleNamespace(pid=123)}}
    assert not run_full.fits(snapshot,active,3500,0)
    checked.append('actual_owned_child_exit7_failstop_and_initializing_worker_reservation')
    # Execute production formal admission with exact positive/negative marker shapes.
    data={'MANIFEST.json':'manifest','SMOKE_VERIFIED.json':{'state':'passed','manifest_sha256':'m','short_monitor_goal_id':'old','actual_u5_adaptation_and_target_separation_verified':True,'first4_actor95':True},'PARENT_SHORT_ADMISSION.json':{'state':'passed','manifest_sha256':'m','independent_actual_short_pass_verified':True,'smoke_verified_sha256':'s'},'LUNA_MONITOR_ACTIVE.json':{'fresh_stage':'formal_training','goal_id':'new'},'SHORT_STAGE_STATUS.json':{'state':'short_completed_awaiting_parent_formal_admission','formal_training_started_count':0,'active':{},'failure':None,'smoke_jobs':[{'state':'completed'}]*2,'saved_signal_job':{'state':'completed'},'reference_job':{'state':'completed'},'pair_job':{'state':'completed'}}}
    old_read,old_sha=run_full.read,run_full.sha
    run_full.read=lambda p:copy.deepcopy(data[Path(p).name]);run_full.sha=lambda p:'m' if Path(p).name=='MANIFEST.json' else 's'
    try:
        assert run_full.formal_admission()[1]['state']=='passed'
        for file,key,bad in [('PARENT_SHORT_ADMISSION.json','independent_actual_short_pass_verified',False),('LUNA_MONITOR_ACTIVE.json','goal_id','old'),('SHORT_STAGE_STATUS.json','active',{'worker':1}),('SMOKE_VERIFIED.json','actual_u5_adaptation_and_target_separation_verified',False)]:
            prior=data[file][key];data[file][key]=bad;expect_failure(run_full.formal_admission);data[file][key]=prior
    finally:run_full.read,run_full.sha=old_read,old_sha
    checked.append('production_formal_gate_short_pass_fresh_monitor_activity_and_inactive_workers')
    assert not any(n in sys.modules for n in ('torch','numpy','warp','mujoco'))
    print(json.dumps({'state':'passed','checks':checked,'count':len(checked),'compiled_python_files':len(files),'owned_child_pid':child.pid,'owned_child_returncode':child.returncode,'native_actions':0,'scientific_library_imports':0},allow_nan=False))

if __name__=='__main__':main()
