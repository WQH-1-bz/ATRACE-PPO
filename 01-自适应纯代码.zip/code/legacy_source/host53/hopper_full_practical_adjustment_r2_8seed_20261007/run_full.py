"""Stdlib coordinator; all native scientific work runs in fresh subprocesses."""
import argparse
import importlib.abc
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback
from contracts import BUDGET,SHORT,SWITCH,SHORT_SWITCH,SEEDS
from bundle_contract import ROOT,PYTHON,DISK_FLOOR,read,write,write_new,sha,child_env,check_manifest,require_launch,gpu_snapshot,verify_historical
from analysis_full import analyze

class NoScientificImports(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in ('torch','warp','mujoco','mujoco_warp','numpy','scipy','gymnasium'):raise ImportError('Scientific import forbidden in stdlib coordinator: '+fullname)

def reap_all(active):
    finished=[]
    for ident,value in list(active.items()):
        code=value['process'].poll()
        if code is not None:value['returncode']=code;finished.append((ident,value))
    for ident,value in finished:value['stream'].close();del active[ident]
    return finished

def drain_completions(active,finished,failed):
    completions=reap_all(active)
    for ident,value in completions:
        try:finished(ident,value)
        except BaseException as exc:failed(ident,value,exc,traceback.format_exc())
    return len(completions)

def admission_snapshot(drain,has_failure,snapshot,capacity,current=None):
    changed=drain()
    if has_failure():return None
    if current is None or changed:
        while True:
            current=snapshot();changed=drain()
            if has_failure():return None
            if not changed:break
    return current if capacity(current) else None

def command(job):
    short=bool(job.get('smoke'));budget=SHORT if short else BUDGET;cut=SHORT_SWITCH if short else SWITCH
    assert job['gpu'] in (0,1)
    return [str(PYTHON),str(ROOT/'source_full/train_pae_baseline.py'),'--out',job['path'],'--method','pae','--task','Hopper','--seed',str(job['seed']),'--device','cuda:'+str(job['gpu']),'--steps',str(budget),'--num-envs','1024','--rollout','64','--batch-size','1024','--eval-envs','32','--eval-every','262144','--staged-full','--stage-switch-steps',str(cut),'--retained-tail-steps','8','--retained-tail-diagnostics','--retained-tail-correction','--retained-td-unclipped','--save-split-trace-audit','--overlap-start-steps','0','--overlap-stop-steps',str(budget)]

def new_job(ident,seed,gpu,smoke=False):
    return {'id':ident,'seed':seed,'gpu':gpu,'smoke':smoke,'path':str(ROOT/'runs'/ident),'state':'pending'}

def plan(short=False):
    if short:
        from short_a_reuse import reuse_job
        return [reuse_job(),new_job('smoke_Full_b',91103,0,True)]
    return [new_job('Hopper__Full_td_persistence__seed'+str(s),s,(s-21)%2) for s in SEEDS]

def reservation_for_peak(peak):return max(3500,math.ceil(peak)+256)

def fits(snapshot,active,reservation,gpu):
    workers=[v for v in active.values() if v['job']['gpu']==gpu];memory=snapshot['process_mib'][gpu]
    initializing=sum(max(0,max(reservation,v['reservation'])-memory.get(v['process'].pid,0)) for v in workers)
    return len(workers)<4 and snapshot['cards'][gpu]['free_mib']-initializing>=reservation+512

def formal_admission():
    admission=read(ROOT/'PARENT_SHORT_ADMISSION.json');monitor=read(ROOT/'LUNA_MONITOR_ACTIVE.json')
    assert admission['state']=='passed' and admission['manifest_sha256']==sha(ROOT/'MANIFEST.json')
    assert admission['independent_actual_short_pass_verified'] and admission['smoke_verified_sha256']==sha(ROOT/'SMOKE_VERIFIED.json')
    previous=read(ROOT/'SHORT_STAGE_STATUS.json');assert previous['state']=='short_completed_awaiting_parent_formal_admission' and previous['formal_training_started_count']==0 and not previous['active'] and previous['failure'] is None
    gate=read(ROOT/'SMOKE_VERIFIED.json')
    assert gate['state']=='passed' and gate['manifest_sha256']==sha(ROOT/'MANIFEST.json')
    assert monitor['fresh_stage']=='formal_training' and monitor['goal_id']!=gate['short_monitor_goal_id']
    assert len(previous['smoke_jobs'])==2 and all(j['state']=='completed' for j in previous['smoke_jobs'])
    assert previous['saved_signal_job']['state']==previous['reference_job']['state']==previous['pair_job']['state']=='completed'
    assert gate['actual_u5_adaptation_and_target_separation_verified'] and gate['first4_actor95']
    return previous,gate,monitor


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--prepare-only',action='store_true');parser.add_argument('--stage',choices=['short','formal'],required=True);args=parser.parse_args()
    sys.meta_path.insert(0,NoScientificImports());require_launch();manifest=check_manifest()
    assert not any(n.split('.')[0] in ('torch','warp','numpy','mujoco','scipy') for n in sys.modules)
    if args.prepare_only:
        write_new(ROOT/'PREPARE_PASSED.json',{'state':'passed','manifest_sha256':sha(ROOT/'MANIFEST.json'),'protected':verify_historical(),'training_started':False});return 0
    if args.stage=='short':assert not (ROOT/'suite_status.json').exists(),'No short restart/retry'
    else:assert not (ROOT/'FORMAL_STAGE_STARTED.json').exists(),'No formal restart/retry'
    prepared=read(ROOT/'REMOTE_PREPARED.json');assert prepared['state']=='prepared' and prepared['manifest_sha256']==sha(ROOT/'MANIFEST.json')
    for sub in ('runs','results','logs'):(ROOT/sub).mkdir(exist_ok=True)
    jobs=plan();smokes=plan(True)
    # Existing immutable control is a verification input, never a new training job.
    reuse=read(ROOT/'REFERENCE_REUSE_LEDGER.json')
    assert manifest['reference_route']=='reused_completed_original_I2_engineering13window' and manifest['new_reference_runs_if_capture_missing']==0
    reference={'id':'reused_original_I2_seed91103','seed':91103,'gpu':0,'smoke':True,'path':reuse['reference_path'],'state':'reference_pending','reference':True,'reused':True,'prior_execution_ledger_sha256':sha(ROOT/'REFERENCE_REUSE_LEDGER.json'),'new_training_transitions':0}
    protected=[{'id':'PROTECTED_'+phase,'gpu':0,'state':'protected_pending'} for phase in ('before','after_shorts','terminal')]
    completed_r1=read(ROOT/'SHORT_A_REUSE.json')
    saved=completed_r1['prior_saved_signal_job'];reference=completed_r1['prior_original_reference_job']
    assert saved['state']==reference['state']=='completed'
    saved['reused_prior_completed_verification']=True;reference['reused_prior_completed_verification']=True
    pair={'id':'SHORT_PAIR','gpu':0,'state':'pair_pending'}
    assert Path(reference['path']).is_dir(), 'Reused original reference must already exist; never train another'
    assert all(not Path(j['path']).exists() for j in (smokes if args.stage=='short' else jobs) if not j.get('reused_completed_short'))
    from short_a_reuse import verify_reuse
    reused_A=verify_reuse()
    active={};failures=[];gate=None;reservation=reservation_for_peak(reused_A['prior_observed_peak_mib']);worker_peak=reused_A['prior_observed_peak_mib'];all_peak=worker_peak;card_peak={0:0,1:0};latest=None;start=time.time()
    if args.stage=='formal':
        previous,gate,monitor=formal_admission()
        smokes=previous['smoke_jobs'];reference=previous['reference_job'];protected=previous['protected_jobs'];pair=previous['pair_job'];saved=previous['saved_signal_job']
        reservation=gate['reservation_mib']
        write_new(ROOT/'FORMAL_STAGE_STARTED.json',{'manifest_sha256':sha(ROOT/'MANIFEST.json'),'short_admission_sha256':sha(ROOT/'PARENT_SHORT_ADMISSION.json'),'fresh_formal_monitor_goal_id':monitor['goal_id'],'all8_shared_configuration':True})
    else:
        assert read(ROOT/'LUNA_MONITOR_ACTIVE.json')['fresh_stage']=='practical_strict_short_pipeline'
    def has_failure():return bool(failures)
    def status(state):
        write(ROOT/'suite_status.json',{'state':state,'task':'Hopper','round':'Full_TD_persistence','total':8,'completed_count':sum(j['state']=='completed' for j in jobs),'formal_training_started_count':sum('training_pid' in j for j in jobs),'jobs':jobs,'smoke_jobs':smokes,'reference_job':reference,'protected_jobs':protected,'pair_job':pair,'saved_signal_job':saved,'engineering_gate':gate,'active':{k:{'pid':v['process'].pid,'gpu':v['job']['gpu'],'stage':v['stage'],'command':v['command'],'sampled_peak_mib':v['peak'],'reservation_mib':v['reservation']} for k,v in active.items()},'failure':failures[0] if failures else None,'failures':failures,'reservation_mib':reservation,'initializing_workers_charged':True,'headroom_mib':512,'max_per_gpu':4,'worker_sampled_or_allocator_peak_mib':worker_peak,'all_children_sampled_or_allocator_peak_mib':all_peak,'card_all_process_sampled_peak_mib':card_peak,'latest_gpu_snapshot':latest,'peak_scope':'Sampled NVML process/card usage and separately reported Torch allocator peaks; no instantaneous physical maximum claim','coordinator_pid':os.getpid(),'coordinator_cuda_imported':False,'elapsed_seconds':time.time()-start,'automatic_restart':False,'automatic_retry':False,'Swimmer_mutations':0})
    def failed(ident,value,exc,tb):
        value['job']['state']='failed';value['job']['returncode']=value['returncode']
        failures.append({'id':ident,'stage':value['stage'],'returncode':value['returncode'],'error':repr(exc),'traceback':tb})
    def finished(ident,value):
        nonlocal reservation,worker_peak,all_peak
        job=value['job'];stage=value['stage'];code=value['returncode'];allocator=0
        receipt={'stage':stage,'pid':value['process'].pid,'gpu':job['gpu'],'command':value['command'],'returncode':code,'sampled_peak_mib':value['peak'],'manifest_sha256':sha(ROOT/'MANIFEST.json')}
        receipt_path=ROOT/'results'/(ident+'__'+stage+'__execution.json')
        write_new(receipt_path,receipt);job.setdefault('process_history',[]).append(receipt);job['returncode']=code
        if code==0 and stage in ('training','reference_training'):
            summary=read(Path(job['path'])/'summary.json');assert summary['state']=='completed'
            allocator=math.ceil(summary.get('peak_torch_memory_bytes',0)/1048576);worker_peak=max(worker_peak,value['peak'],allocator)
            job['state']='reference_pending' if stage=='reference_training' else 'stress_pending'
        elif code==0 and stage=='stress':
            report=read(Path(job['path'])/'checkpoint_stress_result.json');assert report['state']=='passed'
            allocator=math.ceil(report['peak_torch_memory_reserved_bytes']/1048576);job['state']='verify_pending'
            receipt['result_sha256']=sha(Path(job['path'])/'checkpoint_stress_result.json')
        elif code==0:
            report=read(value['result']);assert report['state']=='passed' and report['manifest_sha256']==sha(ROOT/'MANIFEST.json') and report['source_hashes']==manifest['source_hashes']
            allocator=math.ceil(report['peak_torch_memory_reserved_bytes']/1048576);receipt['result_sha256']=sha(value['result'])
            if stage=='verify':job['metrics']=report;job['state']='compare-reference_pending' if job.get('smoke') else 'completed'
            elif stage=='compare-reference':job['reference_comparison']=report;job['state']='completed'
            else:job['metrics']=report;job['state']='completed'
        receipt['torch_allocator_peak_mib']=allocator
        write(receipt_path,receipt)
        if code!=0:raise RuntimeError('Actual child nonzero exit: '+ident+' '+stage+' '+str(code))
        all_peak=max(all_peak,value['peak'],allocator);reservation=reservation_for_peak(all_peak)
    def drain():return drain_completions(active,finished,failed)
    def spawn(job,stage):
        nonlocal latest
        if has_failure():return False
        assert not (job.get('reused_completed_short') and stage in ('training','stress')),'Completed shortA training/stress is immutable; never rerun'
        result=ROOT/'results'/(job['id']+'__'+stage+'.json');assert not result.exists()
        input_file=None
        if stage=='training':argv=command(job)
        elif stage=='reference_training':raise AssertionError('Original-reference training forbidden; immutable reuse only')
        elif stage=='stress':argv=[str(PYTHON),str(ROOT/'stress_checkpoint.py'),'--job-path',job['path'],'--device','cuda:'+str(job['gpu'])]
        else:
            argv=[str(PYTHON),str(ROOT/'replay_helper.py'),'--operation',stage,'--gpu',str(job['gpu']),'--result',str(result)]
            if stage=='verify':
                input_file=ROOT/'results'/(job['id']+'__input.json');argv+=['--job-json',str(input_file)]
            elif stage=='reference':argv+=['--paths',reference['path']]
            elif stage=='compare-reference':argv+=['--paths',reference['path'],job['path']]
            elif stage=='pair':argv+=['--paths',*[j['path'] for j in smokes]]
        log=ROOT/'logs'/(job['id']+'__'+stage+'.log');stream=None
        helper_deadline=job.setdefault('helper_admission_deadline_'+stage,time.monotonic()+300) if stage!='training' else None
        while True:
            latest=admission_snapshot(drain,has_failure,gpu_snapshot,lambda s:fits(s,active,reservation,job['gpu']))
            if latest is None:
                if stream is not None:stream.close()
                if not has_failure() and helper_deadline is not None and time.monotonic()>=helper_deadline:
                    raise RuntimeError('Pre-short/helper memory admission timeout300s; no helper launched or retried')
                return False
            assert shutil.disk_usage(ROOT).free>=DISK_FLOOR,'10GiB disk reserve required'
            # Recheck all observed exits immediately before the launch transaction.
            # Any changed completion invalidates admission BEFORE write-once files.
            changed=drain()
            if has_failure():return False
            if changed:continue
            if input_file is not None:write_new(input_file,job)
            stream=log.open('x')
            try:process=subprocess.Popen(argv,cwd=ROOT,env=child_env(),stdout=stream,stderr=subprocess.STDOUT)
            except BaseException as error:
                stream.close()
                write_new(ROOT/'results'/(job['id']+'__'+stage+'__launch_failure.json'),
                          {'state':'actual_Popen_exception_no_child','id':job['id'],'stage':stage,
                           'command':argv,'error':repr(error),'manifest_sha256':sha(ROOT/'MANIFEST.json'),
                           'actual_child_pid':None,'actual_child_returncode':None,
                           'input_sha256':sha(input_file) if input_file is not None else None,
                           'log_path':str(log),'launched_children':0,'automatic_retry':False})
                raise
            break
        active[job['id']]={'process':process,'stream':stream,'job':job,'stage':stage,'result':result,'command':argv,'peak':0,'reservation':reservation}
        job.update(state=stage+'_running',command=argv,pid=process.pid)
        if stage=='training':job['training_pid']=process.pid
        return True
    try:
        status('engineering_pending')
        while True:
            drain();latest=gpu_snapshot();drain()
            for card in (0,1):card_peak[card]=max(card_peak[card],latest['cards'][card]['total_mib']-latest['cards'][card]['free_mib'])
            for v in active.values():v['peak']=max(v['peak'],latest['process_mib'][v['job']['gpu']].get(v['process'].pid,0))
            if failures:
                status('failure_active_workers_preserved' if active else 'failed')
                if not active:return 1
            elif gate is None:
                if not active:
                    if protected[0]['state']!='completed':spawn(protected[0],'protected')
                    elif saved['state']!='completed':spawn(saved,'saved-state')
                    elif reference['state']!='completed':spawn(reference,'reference')
                    else:
                        pending=next((j for j in smokes if j['state']!='completed'),None)
                        if pending:spawn(pending,'training' if pending['state']=='pending' else pending['state'].removesuffix('_pending'))
                        elif pair['state']!='completed':spawn(pair,'pair')
                        elif protected[1]['state']!='completed':spawn(protected[1],'protected')
                        else:
                            check_manifest();gate={'state':'passed','manifest_sha256':sha(ROOT/'MANIFEST.json'),'pair':pair['metrics'],'original_I2_control':reference['metrics'],'saved32_TD_signal_check':saved['metrics'],'original_firstwindow_comparisons':[j['reference_comparison'] for j in smokes],'new_original_I2_engineering_runs':0,'new_original_I2_engineering_transitions':0,'reused_original_I2_path':reference['path'],'reuse_ledger_sha256':sha(ROOT/'REFERENCE_REUSE_LEDGER.json'),'short_pair_transitions':2*SHORT,'new_r2_short_training_transitions':SHORT,'reused_completed_short_A_path':smokes[0]['path'],'reused_A_prior_actual_training_and_stress':reused_A,'same_physical_GPU0_sequential':True,'first4_actor95':True,'actual_u5_adaptation_and_target_separation_verified':True,'u9_retained8_full64_flush_verified':True,'all13_TD_signal_controller_and_adaptive_actor_replays':'passed','short_primary_audit_updates':[3,4,5,9,10,13],'cold_primary1_2_not_retroactively_warmed':True,'reservation_mib':reservation,'both_short_observed_peaks':[j['process_history'][0] for j in smokes],'short_monitor_goal_id':read(ROOT/'LUNA_MONITOR_ACTIVE.json')['goal_id']}
                            write_new(ROOT/'SMOKE_VERIFIED.json',gate)
                            status('short_completed_awaiting_parent_formal_admission');write_new(ROOT/'SHORT_STAGE_STATUS.json',read(ROOT/'suite_status.json'));return 0
                status('engineering_running' if active else 'engineering_waiting_for_gpu_memory')
            elif all(j['state']=='completed' for j in jobs):
                if not active and protected[2]['state']!='completed':spawn(protected[2],'protected')
                elif protected[2]['state']=='completed':
                    check_manifest();write_new(ROOT/'ANALYSIS.json',analyze(jobs));write_new(ROOT/'ENGINEERING_ACCOUNTING.json',{'new_reference_runs':0,'new_reference_transitions':0,'reference_reused':True,'reused_reference_path':reference['path'],'short_pair_transitions':2*SHORT,'new_r2_short_training_transitions':SHORT,'reused_completed_short_A_path':smokes[0]['path'],'reused_A_prior_actual_training_and_stress':reused_A,'outside_primary_comparisons':True});status('completed');return 0
                status('terminal_protection')
            else:
                # All eight are already queued with one shared recipe, four/card at most.
                for job in jobs:
                    if job['id'] in active or job['state']=='completed':continue
                    stage='training' if job['state']=='pending' else job['state'].removesuffix('_pending')
                    spawn(job,stage)
                    if has_failure():break
                status('running' if active else 'waiting_for_gpu_memory')
            time.sleep(2)
    except BaseException as exc:
        failures.append({'id':'coordinator','error':repr(exc),'traceback':traceback.format_exc()});status('failed_active_workers_preserved' if active else 'failed');raise

if __name__=='__main__':sys.exit(main())
