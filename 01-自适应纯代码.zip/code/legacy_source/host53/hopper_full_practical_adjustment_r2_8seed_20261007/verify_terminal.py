"""One-shot serial terminal helpers with the coordinator's exact admission guards."""
import math
import shutil
import subprocess
import time
from pathlib import Path
from bundle_contract import ROOT,PYTHON,DISK_FLOOR,read,sha,write_new,require_runtime,check_manifest,child_env,gpu_snapshot
from analysis_full import analyze
from run_full import drain_completions,admission_snapshot,fits,reservation_for_peak

def guarded_launch(active,job,argv,stream,drain,has_failure,reservation,timeout_seconds=300):
    """Capacity waiting is bounded; the helper is launched at most once."""
    deadline=time.monotonic()+timeout_seconds
    while True:
        snapshot=admission_snapshot(drain,has_failure,gpu_snapshot,
                                    lambda value:fits(value,active,reservation(),job['gpu']))
        if has_failure():return None
        if snapshot is None:
            if time.monotonic()>=deadline:raise RuntimeError('Terminal helper memory admission timeout; no launch or retry')
            time.sleep(2);continue
        assert shutil.disk_usage(ROOT).free>=DISK_FLOOR,'10GiB disk reserve required before terminal helper'
        # This is the same final observed-exit/error boundary used by run_full.
        changed=drain()
        if has_failure():return None
        if changed:continue
        process=subprocess.Popen(argv,cwd=ROOT,env=child_env(),stdout=stream,stderr=subprocess.STDOUT)
        active[job['id']]={'process':process,'stream':stream,'job':job,'reservation':reservation(),
                           'peak':0,'snapshot_before_launch':snapshot,'command':argv}
        return process

def main():
    require_runtime();m=check_manifest();suite=read(ROOT/'suite_status.json')
    assert suite['state']=='completed' and suite['completed_count']==8 and suite['failure'] is None and not suite['active']
    assert suite['engineering_gate']['state']=='passed' and analyze(suite['jobs'])==read(ROOT/'ANALYSIS.json')
    proofdir=ROOT/'parent_terminal_verification';proofdir.mkdir(exist_ok=False)
    reference=suite['reference_job'];smokes=suite['smoke_jobs'];checks=[]
    for job in [*smokes,*suite['jobs']]:
        input_file=proofdir/(job['id']+'__input.json');write_new(input_file,job)
        checks.append((job['id']+'__verify',job['gpu'],['--operation','verify','--job-json',str(input_file)],job['metrics']))
    checks.extend([('original_I2_reference',0,['--operation','reference','--paths',reference['path']],reference['metrics']),('short_pair',0,['--operation','pair','--paths',*[j['path'] for j in smokes]],suite['pair_job']['metrics']),('protected88',0,['--operation','protected'],suite['protected_jobs'][2]['metrics'])])
    for job in smokes:checks.append((job['id']+'__compare_reference',0,['--operation','compare-reference','--paths',reference['path'],job['path']],job['reference_comparison']))
    assert len(checks)==15
    receipts=[];active={};failures=[]
    reservation=max(suite['reservation_mib'],reservation_for_peak(suite['all_children_sampled_or_allocator_peak_mib']))
    def has_failure():return bool(failures)
    def finished(ident,value):
        nonlocal reservation
        job=value['job'];result=job['result'];code=value['returncode'];allocator=0
        receipt={'id':ident,'command':value['command'],'pid':value['process'].pid,'actual_returncode':code,
                 'gpu':job['gpu'],'output_sha256':sha(result) if result.is_file() else None,
                 'sampled_peak_mib':value['peak'],'reservation_mib':value['reservation'],
                 'snapshot_before_launch':value['snapshot_before_launch'],'manifest_sha256':sha(ROOT/'MANIFEST.json')}
        write_new(proofdir/(ident+'__execution.json'),receipt);receipts.append(receipt)
        assert code==0 and result.is_file(),('fresh parent helper failed',ident,code)
        report=read(result);assert report['state']=='passed' and report['manifest_sha256']==sha(ROOT/'MANIFEST.json') and report['source_hashes']==m['source_hashes']
        assert {k:v for k,v in report.items() if k!='peak_torch_memory_reserved_bytes'}=={k:v for k,v in job['expected'].items() if k!='peak_torch_memory_reserved_bytes'},('fresh actual native report differs from training gate',ident)
        allocator=math.ceil(report['peak_torch_memory_reserved_bytes']/1048576)
        reservation=max(reservation,reservation_for_peak(max(allocator,value['peak'])))
    def failed(ident,value,error,tb):
        failure={'id':ident,'actual_returncode':value['returncode'],'error':repr(error),'traceback':tb}
        failures.append(failure);write_new(proofdir/(ident+'__failure.json'),failure)
    def drain():return drain_completions(active,finished,failed)
    for ident,gpu,flags,expected in checks:
        result=proofdir/(ident+'.json');argv=[str(PYTHON),str(ROOT/'replay_helper.py'),*flags,'--gpu',str(gpu),'--result',str(result)]
        job={'id':ident,'gpu':gpu,'result':result,'expected':expected};stream=(proofdir/(ident+'.log')).open('x')
        try:child=guarded_launch(active,job,argv,stream,drain,has_failure,lambda:reservation)
        except BaseException:stream.close();raise
        if child is None:stream.close();raise RuntimeError('Prior terminal helper failure blocks new admissions')
        while active:
            drain()
            if not active:break
            snapshot=gpu_snapshot();drain()
            for value in active.values():
                value['peak']=max(value['peak'],snapshot['process_mib'][value['job']['gpu']].get(value['process'].pid,0))
            if active:time.sleep(2)
        assert not failures,('Terminal verification fail-stop; no retry',failures)
    assert not active and len(receipts)==15 and not failures
    assert analyze(suite['jobs'])==read(ROOT/'ANALYSIS.json')
    write_new(ROOT/'PARENT_TERMINAL15_VERIFIED.json',{'state':'passed','fresh_native_helpers':15,'all_actual_returncodes_zero':True,'all_output_hashes_verified':True,'manifest_sha256':sha(ROOT/'MANIFEST.json'),'analysis_exactly_reproduced':True,'protected88_preserved':True,'receipts':receipts,'new_training_or_evaluation':0,'shared_coordinator_admission_functions':True,'final_reservation_mib':reservation,'headroom_mib':512,'disk_floor_bytes':DISK_FLOOR,'capacity_wait_bound_seconds_per_helper':300,'automatic_retry':False,'active_workers_preserved_on_failure':True})
if __name__=='__main__':main()
