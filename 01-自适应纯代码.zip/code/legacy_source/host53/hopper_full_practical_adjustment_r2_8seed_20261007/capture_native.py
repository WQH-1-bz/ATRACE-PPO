"""Bounded native metadata export for independent parent raw reconstruction."""
import argparse
import io
import json
from pathlib import Path
import tarfile
from bundle_contract import ROOT,check_manifest,read,sha,write_new,require_runtime
def main():
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=['startup','short','terminal','failure'],required=True);p.add_argument('--archive',type=Path,required=True);args=p.parse_args()
    require_runtime();m=check_manifest();suite=read(ROOT/'suite_status.json')
    if args.phase=='short':assert suite['state']=='short_completed_awaiting_parent_formal_admission' and suite['formal_training_started_count']==0 and not suite['active'] and suite['failure'] is None
    if args.phase=='terminal':assert suite['state']=='completed' and suite['completed_count']==8 and not suite['active'] and suite['failure'] is None
    assert not args.archive.exists() and args.archive.parent.resolve()==ROOT
    top=['MANIFEST.json','MANIFEST.sha256','COMPARISON_REFERENCE.json','PARENT_REVIEW_ADMISSION.json','PARENT_NATIVE_BINDINGS.json','LUNA_MONITOR_ACTIVE.json','REMOTE_PREPARED.json','suite_status.json','SMOKE_VERIFIED.json','ENGINEERING_ACCOUNTING.json','ANALYSIS.json','PARENT_TERMINAL15_VERIFIED.json','SHORT_STAGE_STATUS.json','PARENT_SHORT_ADMISSION.json','FORMAL_STAGE_STARTED.json','SHORT_A_REUSE.json','R1_FAILURE_RECEIPT.json','PARENT_ACTUAL_SCALAR_DEFECT_VERIFICATION.json']
    paths=[ROOT/name for name in top if (ROOT/name).is_file()]
    paths.extend(sorted((ROOT/'results').glob('*.json')))
    paths.extend(sorted((ROOT/'parent_receipts').glob('*.json')))
    paths.extend(sorted((ROOT/'parent_terminal_verification').glob('*.json')))
    for job in [*suite['smoke_jobs'],*suite['jobs']]:
        path=Path(job['path'])
        if path.is_dir() and path.parent==ROOT/'runs':paths.extend(sorted(v for v in path.iterdir() if v.is_file() and v.suffix in ('.json','.jsonl','.csv')))
    reused=Path(suite['reference_job']['path'])
    assert reused==Path(m['reused_original_reference_path']) and reused.is_dir()
    external=[v for v in reused.iterdir() if v.is_file() and v.suffix in ('.json','.jsonl','.csv')]
    reused_A=Path(suite['smoke_jobs'][0]['path'])
    assert reused_A==Path(read(ROOT/'SHORT_A_REUSE.json')['path'])
    external_A=[v for v in reused_A.iterdir() if v.is_file() and v.suffix in ('.json','.jsonl','.csv')]
    inventory={str(v.relative_to(ROOT)):sha(v) for v in paths}
    inventory.update({'reused_short_A_metadata/'+v.name:sha(v) for v in external_A})
    inventory.update({'reused_reference_metadata/'+v.name:sha(v) for v in external})
    record={'state':'verified_capture','phase':args.phase,'manifest_sha256':sha(ROOT/'MANIFEST.json'),'source_hashes':m['source_hashes'],'reference_i2_hashes':m['reference_i2_hashes'],'files':inventory,'raw_training_tensor_pins':'all-window binary hashes in actual native verify receipts; binaries retained native','new_training_or_evaluation':0}
    with tarfile.open(args.archive,'x') as t:
        for path in paths:
            data=path.read_bytes();name=str(path.relative_to(ROOT));info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o444;t.addfile(info,io.BytesIO(data))
        for path in external:
            data=path.read_bytes();info=tarfile.TarInfo('reused_reference_metadata/'+path.name);info.size=len(data);info.mode=0o444;t.addfile(info,io.BytesIO(data))
        for path in external_A:
            data=path.read_bytes();info=tarfile.TarInfo('reused_short_A_metadata/'+path.name);info.size=len(data);info.mode=0o444;t.addfile(info,io.BytesIO(data))
        data=(json.dumps(record,indent=2,allow_nan=False)+'\n').encode();info=tarfile.TarInfo('CAPTURE_INVENTORY.json');info.size=len(data);info.mode=0o444;t.addfile(info,io.BytesIO(data))
    write_new(ROOT/(args.phase+'_CAPTURE_RECEIPT.json'),{'state':'passed','archive':str(args.archive),'archive_sha256':sha(args.archive),'manifest_sha256':record['manifest_sha256'],'captured_files':len(paths)+len(external)+len(external_A),'reused_short_A_actual_path':str(reused_A),'reused_reference_actual_path':str(reused),'phase':args.phase,'read_only':True})
if __name__=='__main__':main()
