"""Type/bit-exact full-state regression using actual native helper comparison code."""
import ast
import importlib.util
import json
import struct
import sys
import types
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'source_full'))
from lambda_td_persistence import TDPersistence

def import_oracle(path,name):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def main():
    prior=Path('/home/mumu08/ssd_2/wch/dpo/runs/hopper_full_practical_adjustment_r1_8seed_20261007')
    original=(prior/'controller_oracle.py').read_text();corrected=(ROOT/'controller_oracle.py').read_text()
    assert corrected==original.replace("'block_sum':sum(history[index-index%4:index])","'block_sum':sum(history[index-index%4:index],0.)")
    tree=ast.parse((ROOT/'replay_helper.py').read_text());comparison=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='differences')
    ns={'torch':types.SimpleNamespace(Tensor=type('UnusedTensor',(object,),{})),'struct':struct}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[comparison],type_ignores=[])),'actual_production_differences','exec'),ns)
    diff=ns['differences'];old=import_oracle(prior/'controller_oracle.py','old_oracle');new=import_oracle(ROOT/'controller_oracle.py','new_oracle')
    rows=[]
    histories={'positive':[.25]*13,'negative':[-.5]*13,'neutral':[0.]*13,'mixed':[.2,-.1,.4,.3,-.8,.5,.2,-.2,.7,-.4,0.,.1,.25]}
    actual=json.loads((ROOT/'SHORT_A_REUSE.json').read_text())
    histories['actual_completed_A']=[r['persistence'] for r in actual['actual_scalar_decisions']]
    for label,values in histories.items():
        controller=TDPersistence();history=[]
        assert not diff(controller.state_dict(),new.replay([])),('empty history',label)
        for update,signal in enumerate(values,1):
            assert not diff(controller.state_dict(),new.replay(history)),('before step',label,update)
            delta=controller.step(update)
            assert not diff(controller.state_dict(),new.replay(history,True)),('before observe',label,update)
            history.append(signal);controller.observe(signal)
            assert not diff(controller.state_dict(),new.replay(history)),('after observe',label,update)
            olddiff=diff(controller.state_dict(),old.replay(history))
            if update in (4,8,12):
                assert olddiff==['.block_sum.type'],(label,update,olddiff)
                assert type(controller.block_sum) is float and type(new.replay(history)['block_sum']) is float
                rows.append({'history':label,'window':update,'old_exact_failure':olddiff,'new_full_state_exact':True})
            if label=='actual_completed_A':
                expected=actual['actual_scalar_decisions'][update-1]
                assert not diff(controller.state_dict(),{key:expected[key] for key in controller.state_dict()}),('actual scalar controller state',update)
                assert struct.pack('!d',delta)==struct.pack('!d',expected['lambda_delta'])
    assert len(rows)==15
    print(json.dumps({'state':'passed','comparison_function':'actual replay_helper.differences AST','empty_history_full_state_exact':True,'positive_negative_neutral_mixed_actual_A_histories':True,'rows':rows,'native_actions':0,'scientific_imports':0}))

if __name__=='__main__':main()
