"""Parent-native preparation only: create new run/results/logs, preserve old caches."""
from bundle_contract import ROOT,OLD_ROOT,require_runtime,check_manifest,verify_historical,write_new,sha
def main():
    require_runtime();manifest=check_manifest();proof=verify_historical()
    assert not (ROOT/'suite_status.json').exists() and not (ROOT/'REMOTE_PREPARED.json').exists()
    for name in ('cache','cache/warp','cache/cuda','cache/torch','tmp'):assert (OLD_ROOT/name).is_dir(),('existing original cache missing',name)
    for name in ('runs','results','logs'):(ROOT/name).mkdir(exist_ok=True)
    write_new(ROOT/'REMOTE_PREPARED.json',{'state':'prepared','manifest_sha256':sha(ROOT/'MANIFEST.json'),'protected':proof,'new_training_transitions':0,'installations':0,'original_caches_reused':True})

if __name__=='__main__':main()
