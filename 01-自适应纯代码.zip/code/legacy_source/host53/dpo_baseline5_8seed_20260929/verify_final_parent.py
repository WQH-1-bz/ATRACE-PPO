"""Read-only experiment audit; writes only a separate acceptance artifact."""
import argparse
import collections
import csv
import datetime
import hashlib
import itertools
import json
import math
import statistics
from pathlib import Path

BUDGET = 10027008
TASKS = ('Hopper', 'Walker2d', 'HalfCheetah', 'Ant', 'Swimmer')
METHODS = ('fixed95', 'fixed90', 'fixed99', 'linear', 'critic_aware')
DET = {'torch': True, 'warp': 'run_to_run', 'warp_max_records': 8,
       'cublas_workspace_config': ':4096:8'}


def read(p):
    return json.loads(p.read_text())


def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()


def same(x, y):
    assert math.isclose(float(x), float(y), rel_tol=1e-12, abs_tol=1e-9), (x, y)


def eval_batch(e):
    assert len(e['returns']) == len(e['lengths']) == 32
    assert all(math.isfinite(x) for x in e['returns'])
    assert all(1 <= x <= 1000 for x in e['lengths'])
    assert math.isclose(statistics.mean(e['returns']), e['mean'], rel_tol=1e-6, abs_tol=1e-3)


def verify_row(row, reuse, original_hashes):
    p = Path(row['path'])
    required = ['config.json', 'summary.json', 'status.json', 'latest.pt',
                'initial_evaluation.json', 'evaluations.jsonl', 'progress.csv']
    if row['method'] == 'critic_aware':
        required.append('lambda_decisions.jsonl')
    else:
        required.append('stress_evaluation.json')
    assert all((p / n).is_file() and (p / n).stat().st_size > 0 for n in required)
    c, s, status = (read(p / n) for n in ('config.json', 'summary.json', 'status.json'))
    assert c['seed'] == row['seed'] and c['task'].split('-v4')[0] == row['task']
    assert c['effective_steps'] == c['steps'] == BUDGET
    assert c['num_envs'] == 1024 and c['rollout'] == 64 and c['batch_size'] == 1024
    assert c['epochs'] == 10 and c['eval_envs'] == 32 and c['eval_every'] == 262144
    records = 4 if row['execution_backend'] == 'hopper_graph4_v1' else 8
    assert c['determinism'] == {**DET, 'warp_max_records': records}
    if records == 4:
        assert row['task'] == 'Hopper' and row['origin'] == 'remote_new'
    assert s['state'] == status['state'] == 'completed'
    assert s['steps'] == status['steps'] == BUDGET and s['reload_check'] == 'passed'
    same(status['final_eval']['mean'], s['final_eval']['mean'])
    progress = list(csv.DictReader((p / 'progress.csv').open()))
    assert len(progress) == 153
    assert [int(x['steps']) for x in progress] == [65536 * i for i in range(1, 154)]
    if row['method'] == 'critic_aware':
        assert c['method'] == 'critic_aware' and c['anneal_lr']
        assert s['training_transitions'] == s['total_algorithm_transitions'] == BUDGET
        assert s['optimizer_steps'] == {'actor': 48960, 'critic': 97920, 'h': 0}
        assert s['profiling_extra_transitions'] == 0
        for n, digest in c['source_sha256'].items():
            assert digest == original_hashes[n], n
        decisions = [json.loads(x) for x in (p / 'lambda_decisions.jsonl').read_text().splitlines()]
        assert len(decisions) == 153
        value, previous_loss = .95, math.inf
        for i, (d, pr) in enumerate(zip(decisions, progress), 1):
            assert d['update'] == i
            same(d['used'], value)
            same(pr['gae_lambda_used'], value)
            if i == 1:
                assert d['previous_loss'] is None
            else:
                same(d['previous_loss'], previous_loss)
            loss = d['last_minibatch_value_loss']
            assert math.isfinite(loss)
            step = .090 - .085 * i / 153
            if loss < previous_loss:
                value = max(.7, value - step)
            elif loss > previous_loss:
                value = min(.99, value + step)
            same(d['next'], value)
            same(pr['gae_lambda_next'], value)
            previous_loss = loss
        lambdas = [float(x['gae_lambda_used']) for x in progress]
    else:
        assert c['noise_mode'] == 'none' and c['noise_scale'] == 0
        lambdas = [float(x['gae_lambda']) for x in progress]
        if row['method'] == 'linear':
            assert c['lambda_mode'] == 'linear'
            for i, value in enumerate(lambdas):
                same(value, .90 + .09 * i / 152)
        else:
            value = {'fixed90': .90, 'fixed95': .95, 'fixed99': .99}[row['method']]
            assert c['lambda_mode'] == 'fixed' and c['fixed_lambda'] == value
            for x in lambdas:
                same(x, value)
        read(p / 'stress_evaluation.json')
    initial = read(p / 'initial_evaluation.json')
    evaluations = [json.loads(x) for x in (p / 'evaluations.jsonl').read_text().splitlines()]
    assert [e['steps'] for e in evaluations] == [262144 * i for i in range(1, 39)] + [BUDGET]
    for e in [initial, s['final_eval'], *evaluations]:
        eval_batch(e)
    same(evaluations[-1]['mean'], s['final_eval']['mean'])
    points = [(0, initial['mean'])] + [(x['steps'], x['mean']) for x in evaluations]
    auc = sum((b[0]-a[0]) * (a[1]+b[1])/2 for a,b in zip(points, points[1:])) / BUDGET
    same(auc, row['auc'])
    same(s['final_eval']['mean'], row['final_return'])
    if 'normalized_return_auc' in s:
        same(auc, s['normalized_return_auc'])
    if row['origin'] != 'remote_new':
        old = reuse[(row['task'], row['method'], row['seed'])]
        assert old['path'] == row['path'] and old['origin'] == row['origin']
        same(old['auc'], auc)
        same(old['final_return'], row['final_return'])
        for n, digest in old.get('artifact_hashes', {}).items():
            assert sha(p / n) == digest, (row['path'], n)
    return {**row, 'verified': True, 'updates': 153, 'steps': BUDGET,
            'initial_return': initial['mean'], 'lambda_min': min(lambdas),
            'lambda_max': max(lambdas), 'xml_sha256': c['xml_sha256'],
            'artifact_hashes': {n: sha(p / n) for n in required}}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', type=Path, required=True)
    ap.add_argument('--shard', choices=['local', 'remote'], required=True)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--fast-source', type=Path)
    args = ap.parse_args()
    root = args.root
    a, status, manifest = (read(root / n) for n in ('ANALYSIS.json', 'suite_status.json', 'reuse52_manifest.json'))
    assert a['state'] == status['state'] == 'completed'
    assert status['total'] == status['completed_count'] == a['total'] == 200
    assert status['failure'] is None and not status['active']
    assert set((x['task'], x['method'], x['seed']) for x in a['rows']) == set(itertools.product(TASKS, METHODS, range(21,29)))
    assert len(a['rows']) == len(status['jobs']) == 200
    assert collections.Counter(x['origin'] for x in a['rows']) == {'remote_new':148, 'preserved_internal_base':12, 'preserved_external_matrix':40}
    assert collections.Counter(x['execution_backend'] for x in a['rows']) == {'original_eager8':180, 'hopper_graph4_v1':20}
    assert manifest['state'] == 'verified' and len(manifest['rows']) == 52
    reuse = {(x['task'],x['method'],x['seed']):x for x in manifest['rows']}
    assert len(reuse) == 52
    jobs = {(x['task'],x['method'],x['seed']):x for x in status['jobs']}
    for row in a['rows']:
        j = jobs[(row['task'],row['method'],row['seed'])]
        assert j['state'] == 'completed' and j['origin'] == row['origin']
        assert j.get('original_path',j['path']) == row['path']
        same(j['metrics']['final_return'],row['final_return'])
        same(j['metrics']['auc'],row['auc'])
    original_hashes = read(root / 'source_hashes.json')
    assert len(original_hashes) == 17
    for n,digest in original_hashes.items():
        assert sha(root/'source'/n) == digest, n
    fast_hashes = None
    if args.fast_source:
        fast_hashes = read(args.fast_source.parent/'source_v1_hashes.json')
        assert len(fast_hashes) == 18
        for n,digest in fast_hashes.items():
            assert sha(args.fast_source/n) == digest,n
    rows = [r for r in a['rows'] if Path(r['path']).exists()]
    assert len(rows) == (24 if args.shard == 'local' else 176), len(rows)
    verified = [verify_row(r,reuse,original_hashes) for r in rows]
    for task in TASKS:
        for method in METHODS:
            rs = [r for r in a['rows'] if r['task']==task and r['method']==method]
            assert len(rs)==8
            for key,field,func in [('final_mean','final_return',statistics.mean),('final_sd','final_return',statistics.stdev),('auc_mean','auc',statistics.mean),('auc_sd','auc',statistics.stdev)]:
                same(func(r[field] for r in rs),a['summary'][task][method][key])
    result={'state':'passed','timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'shard':args.shard,'completed_verified':len(verified),'formal_budget':BUDGET,
            'analysis_sha256':sha(root/'ANALYSIS.json'),'source_hashes':original_hashes,
            'fast_source_hashes':fast_hashes,'rows':verified,'summary':a['summary'],
            'scope':'Artifact, metric, controller and provenance verification; no new training.'}
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'state':'passed','shard':args.shard,'completed_verified':len(verified),'analysis_sha256':result['analysis_sha256']}))


if __name__ == '__main__':
    main()
