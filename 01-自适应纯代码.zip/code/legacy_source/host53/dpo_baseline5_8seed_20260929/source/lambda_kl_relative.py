"""KLF2: replace fixed KL scale with a causal slow reference; experimental."""
import math
from dataclasses import dataclass,asdict
@dataclass
class KLFeedback:
    value:float=.95
    ema:float=0.
    reference:float=0.
    target:float=.95
    observations:int=0
    fast_alpha:float=.1
    slow_alpha:float=.01
    lower_bound:float=.90
    upper_bound:float=.99
    def observe(self,kl):
        if not math.isfinite(kl) or kl < -1e-7:raise ValueError('Invalid KL')
        kl=max(0.,kl)
        self.observations+=1
        if self.observations==1:self.ema=kl;self.reference=kl
        else:
            self.ema=(1-self.fast_alpha)*self.ema+self.fast_alpha*kl
            self.reference=(1-self.slow_alpha)*self.reference+self.slow_alpha*kl
        if self.observations>=4 and self.observations%4==0:
            self.target=min(self.upper_bound,max(self.lower_bound,.95+.04*math.tanh(math.log(max(self.reference,1e-8)/max(self.ema,1e-8)))))
    def step(self,update):
        old=self.value
        if update>4:self.value=min(self.upper_bound,max(self.lower_bound,old+max(-.001,min(.001,.1*(self.target-old)))))
        return self.value-old
    def state_dict(self):return asdict(self)
