"""Frozen five-task, five-baseline, eight-seed queue; no ours runs."""
import argparse,csv,hashlib,json,math,os,statistics,subprocess,time,traceback
from pathlib import Path
TASKS=('Hopper','Walker2d','HalfCheetah','Ant','Swimmer')
METHODS=('fixed95','fixed90','fixed99','linear','critic_aware')
SEEDS=tuple(range(21,29));STEPS=10027008;SHORT=524288
FAST_SOURCE=None
class AdoptedProcess:
 def __init__(self,j):self.pid=j["pid"];self.job=j
 def poll(self):
  try:
   state=Path(f"/proc/{self.pid}/stat").read_text().rsplit(")",1)[1].split()[0]
   if state not in ["Z","X"]:return None
  except FileNotFoundError:pass
  try:verify(self.job);return 0
  except Exception:return 1
DET={'torch':True,'warp':'run_to_run','warp_max_records':8,'cublas_workspace_config':':4096:8'}
def write(p,x):
 t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n');t.replace(p)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot():
 raw=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'],text=True)
 free={int(x.split(',')[0]):int(x.split(',')[1]) for x in raw.strip().splitlines()}
 raw=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,used_gpu_memory','--format=csv,noheader,nounits'],text=True)
 used={int(x.split(',')[0]):int(x.split(',')[1]) for x in raw.strip().splitlines() if x.strip()}
 return free,used
def command(root,j,gpu,short=False):
 assert j['method']!='critic_aware','critic-aware already completed; no external reruns'
 src=FAST_SOURCE if j.get('execution_backend')=='hopper_graph4_v1' else root/'source'
 cmd=[str(root/'.venv/bin/python'),str(src/'train_internal_base.py'),'--out',j['path'],'--task',j['task'],'--seed',str(j['seed']),'--device',f'cuda:{gpu}','--steps',str(SHORT if short else STEPS),'--num-envs','1024','--rollout','64','--batch-size','1024','--epochs','10','--eval-envs','32','--eval-every','262144']
 if j['method']=='linear':cmd+=['--lambda-mode','linear']
 else:cmd+=['--lambda-mode','fixed','--fixed-lambda',str({'fixed90':.90,'fixed95':.95,'fixed99':.99}[j['method']])]
 return cmd
def verify(j,short=False):
 p=Path(j['path']);budget=SHORT if short else STEPS
 c=json.loads((p/'config.json').read_text());s=json.loads((p/'summary.json').read_text())
 assert c['task'].startswith(j['task']+'-v4') and c['seed']==j['seed'] and c['determinism']=={**DET,'warp_max_records':4 if j.get('execution_backend')=='hopper_graph4_v1' else 8}
 assert c['noise_mode']=='none' and c['noise_scale']==0 and c['effective_steps']==budget
 assert s['state']=='completed' and s['reload_check']=='passed' and s['steps']==budget
 assert len(s['final_eval']['returns'])==32 and (p/'latest.pt').stat().st_size>0
 rs=list(csv.DictReader((p/'progress.csv').open()));assert len(rs)==(8 if short else 153)
 ls=[float(x['gae_lambda']) for x in rs]
 if j['method']=='linear':
  assert c['lambda_mode']=='linear';assert all(abs(x-(.90+.09*i/(len(ls)-1)))<1e-10 for i,x in enumerate(ls))
 else:
  v={'fixed90':.90,'fixed95':.95,'fixed99':.99}[j['method']]
  assert c['lambda_mode']=='fixed' and c['fixed_lambda']==v and all(abs(x-v)<1e-12 for x in ls)
 init=json.loads((p/'initial_evaluation.json').read_text());ev=[json.loads(x) for x in (p/'evaluations.jsonl').read_text().splitlines()]
 pts=[(0,init['mean'])]+[(x['steps'],x['mean']) for x in ev]
 assert pts[-1][0]==budget and all(a[0]<b[0] for a,b in zip(pts,pts[1:]))
 auc=sum((b[0]-a[0])*(a[1]+b[1])/2 for a,b in zip(pts,pts[1:]))/budget
 final=s['final_eval']['mean'];assert math.isfinite(auc) and math.isfinite(final)
 return {'final_return':final,'auc':auc,'initial_return':init['mean'],'updates':len(ls),'lambda_min':min(ls),'lambda_max':max(ls),'lambda_check':'passed'}
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--max-per-gpu',type=int,default=5);p.add_argument('--resume',action='store_true');p.add_argument('--adopt-status',type=Path,required=True);p.add_argument('--fast-source',type=Path,required=True);p.add_argument('--prepare-only',action='store_true');a=p.parse_args();root=a.root.resolve()
 global FAST_SOURCE
 FAST_SOURCE=a.fast_source.resolve();fast_hashes=json.loads((FAST_SOURCE.parent/'source_v1_hashes.json').read_text());prior=json.loads(a.adopt_status.read_text());prior_jobs={j['id']:j for j in prior['jobs']};assert len(prior_jobs)==200
 hashes=json.loads((root/'source_hashes.json').read_text())
 def check():
  for n,h in hashes.items():assert sha(root/'source'/n)==h,n
  for n,h in fast_hashes.items():assert sha(FAST_SOURCE/n)==h,n
 check();assert a.resume or not (root/'suite_status.json').exists()
 reuse=json.loads((root/'reuse52_manifest.json').read_text());assert reuse['state']=='verified' and len(reuse['rows'])==52
 jobs=[];old={x['id']:x for x in reuse['rows']}
 for seed in SEEDS:
  for task in TASKS:
   for method in METHODS:
    jid=f'{task}__{method}__seed{seed}';j={'id':jid,'task':task,'method':method,'seed':seed,'path':str(root/'runs'/jid),'state':'pending'}
    if jid in old:j.update(state='completed',metrics={k:old[jid][k] for k in ['final_return','auc']},origin=old[jid]['origin'],original_path=old[jid]['path'])
    elif jid in prior_jobs:
     prev=prior_jobs[jid];assert (prev['task'],prev['method'],prev['seed'])==(task,method,seed)
     j.update(prev)
     if j['state']=='completed':verify(j)
     elif j['state']=='running':
      assert j['pid']==prior['active'][jid]['pid']
      try:
       state=Path(f"/proc/{j['pid']}/stat").read_text().rsplit(')',1)[1].split()[0]
       if state not in ['Z','X']:assert j['path'].encode() in Path(f"/proc/{j['pid']}/cmdline").read_bytes(),jid
      except FileNotFoundError:verify(j)
     else:assert j['state']=='pending' and not Path(j['path']).exists()
    elif a.resume and Path(j['path']).exists():
     try:j.update(state='completed',metrics=verify(j),origin='remote_prior_session')
     except Exception:Path(j['path']).rename(Path(j['path']+'.interrupted_'+time.strftime('%Y%m%dT%H%M%S')))
    jobs.append(j)
 assert len(jobs)==200 and all(j['state']=='completed' for j in jobs if j['method']=='critic_aware')
 if a.prepare_only:
  print(json.dumps({'state':'handoff_preflight_passed','total':len(jobs),'completed':sum(j['state']=='completed' for j in jobs),'adopted':[j['id'] for j in jobs if j['state']=='running'],'future_fast':[j['id'] for j in jobs if j['state']=='pending' and j['task']=='Hopper']}));return
 started=time.time();active={};failure=None
 for j in jobs:
  if j['state']=='running':active[j['id']]=(AdoptedProcess(j),Path(j['log']).open('a'),j)
 env={**os.environ,'PYTHONUNBUFFERED':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','DPO_TORCH_DETERMINISTIC':'1','DPO_WARP_DETERMINISTIC':'run_to_run','DPO_WARP_DETERMINISTIC_MAX_RECORDS':'8','CUBLAS_WORKSPACE_CONFIG':':4096:8'}
 def status(state,**extra):write(root/'suite_status.json',{'state':state,'total':200,'completed_count':sum(j['state']=='completed' for j in jobs),'reused_count':52,'active':{k:{'pid':v[0].pid,'gpu':v[2]['gpu'],'task':v[2]['task']} for k,v in active.items()},'jobs':jobs,'failure':failure,'elapsed_seconds':time.time()-started,'scheduler_version':'hopper_graph4_v1','coordinator_pid':os.getpid(),**extra})
 peaks={};smoke_metrics={}
 if (root/'SMOKE_VERIFIED.json').exists():
  smoke=json.loads((root/'SMOKE_VERIFIED.json').read_text());assert smoke['state']=='passed';peaks=smoke['peaks_mib']
 else:
  pending=list(TASKS);smokes={}
  while pending or smokes:
   for task,(proc,h,j) in list(smokes.items()):
    code=proc.poll()
    if code is None:continue
    h.close();assert code==0,(task,code);smoke_metrics[task]=verify(j,True);del smokes[task]
   free,used=snapshot()
   for task,(proc,_,_) in smokes.items():peaks[task]=max(peaks.get(task,0),used.get(proc.pid,0))
   occupied={x[2]['gpu'] for x in smokes.values()}
   for gpu in free:
    if pending and gpu not in occupied:
     task=pending.pop(0);j={'task':task,'method':'fixed95','seed':91061+TASKS.index(task),'path':str(root/'runs'/('smoke__'+task)),'gpu':gpu}
     h=(root/('smoke__'+task+'.log')).open('w');proc=subprocess.Popen(command(root,j,gpu,True),cwd=root/'source',env=env,stdout=h,stderr=subprocess.STDOUT);smokes[task]=(proc,h,j)
   status('smoke_running',smoke_active={k:{'pid':x[0].pid,'gpu':x[2]['gpu']} for k,x in smokes.items()},smoke_completed=list(smoke_metrics));time.sleep(5)
  assert all(peaks[t]>0 for t in TASKS)
  write(root/'SMOKE_VERIFIED.json',{'state':'passed','peaks_mib':peaks,'metrics':smoke_metrics})
 estimates={task:peaks[task]+64 for task in TASKS}
 while True:
  for jid,(proc,h,j) in list(active.items()):
   code=proc.poll()
   if code is None:continue
   h.close();del active[jid]
   try:assert code==0,code;j.update(state='completed',metrics=verify(j),origin='remote_new')
   except Exception as e:j['state']='failed';failure={'id':jid,'error':repr(e),'log':j['log']}
  if all(j['state']=='completed' for j in jobs):
   check();rows=[{'task':j['task'],'method':j['method'],'seed':j['seed'],'path':j.get('original_path',j['path']),'origin':j['origin'],'execution_backend':j.get('execution_backend','original_eager8'),**j['metrics']} for j in jobs];summary={}
   assert len({(r['task'],r['method'],r['seed']) for r in rows})==200
   for task in TASKS:
    summary[task]={}
    for method in METHODS:
     ms=[r for r in rows if r['task']==task and r['method']==method];assert len(ms)==8
     summary[task][method]={k:fn(x[field] for x in ms) for k,field,fn in [('final_mean','final_return',statistics.mean),('final_sd','final_return',statistics.stdev),('auc_mean','auc',statistics.mean),('auc_sd','auc',statistics.stdev)]}
   write(root/'ANALYSIS.json',{'state':'completed','total':200,'tasks':TASKS,'methods':METHODS,'seeds':SEEDS,'rows':rows,'summary':summary});status('completed');return
  if failure and not active:status('failed');raise SystemExit(1)
  if not failure:
   free,used=snapshot()
   for gpu in sorted(free,key=free.get,reverse=True):
    if sum(x[2]['gpu']==gpu for x in active.values())>=a.max_per_gpu:continue
    reserve=sum(max(0,estimates[x[2]['task']]-used.get(x[0].pid,0)) for x in active.values() if x[2]['gpu']==gpu)
    j=next((j for j in jobs if j['state']=='pending' and free[gpu]-reserve>=estimates[j['task']]+512),None)
    if j is None:continue
    log=root/(j['id']+('.retry_'+time.strftime('%Y%m%dT%H%M%S') if a.resume else '')+'.log');h=log.open('x');j['execution_backend']='hopper_graph4_v1' if j['task']=='Hopper' else 'original_eager8';job_env={**env,'DPO_PPO_GRAPH':'1' if j['task']=='Hopper' else '0','DPO_WARP_DETERMINISTIC_MAX_RECORDS':'4' if j['task']=='Hopper' else '8'};proc=subprocess.Popen(command(root,j,gpu),cwd=root/'source',env=job_env,stdout=h,stderr=subprocess.STDOUT);j.update(state='running',gpu=gpu,pid=proc.pid,log=str(log));active[j['id']]=(proc,h,j);break
  status('attention_required' if failure else 'running',admission_estimates_mib=estimates);time.sleep(5)
if __name__=='__main__':
 try:main()
 except BaseException:traceback.print_exc();raise
