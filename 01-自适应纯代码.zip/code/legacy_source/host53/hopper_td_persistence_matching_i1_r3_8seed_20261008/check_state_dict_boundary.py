"""Pure stdlib checks of three named representation boundaries; no Torch imports."""
import ast
import copy
from collections import OrderedDict,UserDict
import hashlib
import json
from pathlib import Path
import struct
import sys
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parent
R2=ROOT.parent/'hopper_td_persistence_matching_i1_r2_8seed_20261007'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n):return ast.dump(n,include_attributes=False)
def named(t,name):return next(n for n in t.body if getattr(n,'name',None)==name)
def main():
    old=ast.parse((R2/'replay_helper.py').read_text());new=ast.parse((ROOT/'replay_helper.py').read_text())
    assert dump(named(old,'equal'))==dump(named(new,'equal'))
    expected=copy.deepcopy(new)
    boundary=named(expected,'compare_final_checkpoint_state_dicts');expected.body.remove(boundary)
    added=[n for n in expected.body if isinstance(n,ast.ImportFrom) and n.module=='collections']
    assert len(added)==1 and [a.name for a in added[0].names]==['OrderedDict'];expected.body.remove(added[0])
    old_verify=named(old,'verify');new_verify=named(expected,'verify')
    old_for=[n for n in old_verify.body if isinstance(n,ast.For) and isinstance(n.iter,ast.Tuple) and [v.value for v in n.iter.elts]==['model','obs_stats','reward_stats']]
    replacement=[n for n in new_verify.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='compare_final_checkpoint_state_dicts']
    assert len(old_for)==len(replacement)==1
    index=new_verify.body.index(replacement[0]);new_verify.body[index]=copy.deepcopy(old_for[0])
    assert dump(expected)==dump(old),'Replay changed outside exact named boundary/import'
    assert (ROOT/'stress_checkpoint.py').read_bytes()==(R2/'stress_checkpoint.py').read_bytes()
    original=json.loads((R2/'MANIFEST.json').read_text())
    for name,digest in original['source_hashes'].items():assert sha(ROOT/'source_i1'/name)==digest
    assert len(original['source_hashes'])==7
    # Execute only the extracted generic comparator and named boundary with scalars.
    # Torch's unchanged native tensor branch is not executed or claimed verified here.
    class UnusedTensor:pass
    namespace={'torch':SimpleNamespace(Tensor=UnusedTensor),'struct':struct,'OrderedDict':OrderedDict}
    defs=ast.Module(body=[copy.deepcopy(named(new,'equal')),copy.deepcopy(named(new,'compare_final_checkpoint_state_dicts'))],type_ignores=[])
    exec(compile(ast.fix_missing_locations(defs),'extracted_named_boundary','exec'),namespace)
    compare=namespace['compare_final_checkpoint_state_dicts']
    model_names=('log_std',)+tuple(f'{net}.{layer}.{part}' for net in ('actor','critic') for layer in (0,2,4) for part in ('weight','bias'))
    names={'model':model_names,'obs_stats':('mean','var','count'),'reward_stats':('mean','var','count')}
    def records():
        saved={k:OrderedDict((name,float(i)) for i,name in enumerate(keys)) for k,keys in names.items()}
        final={k:dict(v) for k,v in saved.items()};return final,saved
    def reject(fn,label):
        try:fn()
        except AssertionError:return
        raise AssertionError('Negative case accepted: '+label)
    report={}
    for field,keys in names.items():
        final,saved=records();saved[field]._metadata={'module_load_only':'outside_parameter_mapping'}
        before=list(saved[field].items());compare(final,saved);assert list(saved[field].items())==before
        cases=[]
        for variant in ('reordered','missing','extra','snapshot_OrderedDict','checkpoint_plain_dict','unsupported_UserDict','modified_scalar','opposite_signed_zero','scalar_type_change'):
            final,saved=records()
            if variant=='reordered':
                final[field]=dict(reversed(list(final[field].items())));saved[field]=OrderedDict(reversed(list(saved[field].items())))
            elif variant=='missing':final[field].pop(keys[-1]);saved[field].pop(keys[-1])
            elif variant=='extra':final[field]['undeclared']=1.;saved[field]['undeclared']=1.
            elif variant=='snapshot_OrderedDict':final[field]=OrderedDict(final[field])
            elif variant=='checkpoint_plain_dict':saved[field]=dict(saved[field])
            elif variant=='unsupported_UserDict':saved[field]=UserDict(saved[field])
            elif variant=='modified_scalar':saved[field][keys[0]]=.5
            elif variant=='opposite_signed_zero':saved[field][keys[0]]=-0.
            elif variant=='scalar_type_change':saved[field][keys[0]]=0
            reject(lambda:compare(final,saved),field+'/'+variant);cases.append(variant)
        report[field]={'declared_ordered_names':list(keys),'intended_dict_OrderedDict_same_content_passed':True,'negative_cases_rejected':cases}
    # Source consistency: all three saved fields originate in the same Module.state_dict API.
    trainer=ast.parse((ROOT/'source_i1/train_kl_relative.py').read_text())
    stats=named(trainer,'RunningStats');actor=named(trainer,'ActorCritic')
    assert all(not any(isinstance(n,ast.FunctionDef) and n.name=='state_dict' for n in cls.body) for cls in (stats,actor))
    buffers=[n.args[0].value for n in ast.walk(named(ast.Module(body=stats.body,type_ignores=[]),'__init__')) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='register_buffer']
    assert buffers==['mean','var','count']
    checkpoints=[n.value for n in ast.walk(trainer) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='checkpoint' for t in n.targets)]
    assert len(checkpoints)==1
    fields={k.value:v for k,v in zip(checkpoints[0].keys,checkpoints[0].values) if isinstance(k,ast.Constant)}
    for field in names:
        assert isinstance(fields[field],ast.Call) and isinstance(fields[field].func,ast.Attribute) and fields[field].func.attr=='state_dict'
    capture=ast.parse((ROOT/'source_i1/full_capture.py').read_text());snapshot=named(capture,'snapshot_state')
    cpu=next(n for n in snapshot.body if isinstance(n,ast.FunctionDef) and n.name=='cpu')
    dict_branches=[n for n in cpu.body if isinstance(n,ast.If) and isinstance(n.test,ast.Call) and isinstance(n.test.func,ast.Name) and n.test.func.id=='isinstance' and isinstance(n.test.args[1],ast.Name) and n.test.args[1].id=='dict']
    assert len(dict_branches)==1 and isinstance(dict_branches[0].body[0].value,ast.DictComp)
    assert (ROOT/'run_matching_i1.py').read_bytes()==(R2/'run_matching_i1.py').read_bytes()
    assert not any(n.split('.')[0] in ('torch','numpy','warp','gymnasium','mujoco') for n in sys.modules)
    print(json.dumps({'state':'passed','stdlib_AST_only':True,'generic_equal_AST_unchanged':True,
      'replay_AST_unchanged_outside_three_named_boundary_and_import':True,'science7_and_stress_byte_identical_to_r2':True,
      'optimizer_RNG_physics_coldGAE_signal_controller_primary_AB_checks_unchanged':True,
      'three_final_state_dict_fields_source_consistent':True,'scheduler_deadlines_reaping_resource_and_formal_gates_byte_unchanged':True,
      'named_boundaries':report,'native_Torch_tensor_comparison_unexecuted':True,'native_actions':0},indent=2,sort_keys=True))
if __name__=='__main__':main()
