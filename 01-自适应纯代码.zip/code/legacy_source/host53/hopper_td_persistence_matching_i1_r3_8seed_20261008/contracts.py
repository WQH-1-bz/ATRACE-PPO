"""Pure stdlib clocks and independent scalar contracts."""
import math
SEEDS=tuple(range(21,29))
BUDGET,SHORT=10027008,786432
CONTROL_METHODS=('fixed90','fixed95','fixed99','linear','critic_aware','gradient_ppo','reward_profiling','pae')
REPORT_METHODS=(*CONTROL_METHODS,'innovation1','innovation2','original_failed_NCS1')
def ledger(short=False):
    budget=SHORT if short else BUDGET
    rows=[dict(update=u,steps=u*65536,prior_collected_steps=(u-1)*65536,
      fresh_per_world=64,incoming_retained_per_world=0,end_per_world=64,used_per_world=64,
      retained_per_world=0,overlap_active=False,stage_boundary_flush=False) for u in range(1,budget//65536+1)]
    assert len(rows)==(12 if short else 153)
    assert sum(r['used_per_world']*1024 for r in rows)==budget
    assert sum(r['used_per_world']*10 for r in rows)==(7680 if short else 97920)
    return rows
def evaluation_grid(short=False):
    budget=SHORT if short else BUDGET
    return [*range(262144,budget,262144),budget]
def ordinary_reference(reward,value,next_value,terminated,done,lam):
    n=len(reward)
    assert all(len(x)==n for x in (value,next_value,terminated,done))
    # Expanded future sum independently of production carry loop.
    td=[r+.99*(not t)*nv-v for r,t,nv,v in zip(reward,terminated,next_value,value)]
    result=[]
    for t in range(n):
        weight,total=1.,0.
        for k in range(t,n):
            total+=weight*td[k];weight*=.99*lam*(not done[k])
        result.append(total)
    return result,[a+v for a,v in zip(result,value)]
