"""Root-admitted bounded metadata archive; tensors remain on native host53."""
import argparse
import io
from pathlib import Path
import tarfile
from bundle_contract import ROOT,read,sha,write_new,require_runtime
def main():
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=('startup','short','terminal','failure'),required=True)
    p.add_argument('--archive',type=Path,required=True);a=p.parse_args();require_runtime()
    assert a.archive.parent.resolve()==ROOT and not a.archive.exists()
    suite=read(ROOT/'suite_status.json')
    if a.phase=='short':assert suite['state']=='short_completed_awaiting_root_formal_admission' and suite['formal_training_started_count']==0 and not suite['active'] and not suite['failures']
    if a.phase=='terminal':assert suite['state']=='completed' and suite['completed_count']==8 and not suite['active'] and not suite['failures']
    names=['MANIFEST.json','MANIFEST.sha256','PARENT_REVIEW_ADMISSION.json','PARENT_NATIVE_BINDINGS.json','LUNA_MONITOR_ACTIVE.json',
      'suite_status.json','SHORT_VERIFIED.json','SHORT_STAGE_STATUS.json','PARENT_SHORT_ADMISSION.json','PARENT_RESOURCE_ADMISSION.json',
      'SHORT_STAGE_STARTED.json','FORMAL_STAGE_STARTED.json','ANALYSIS.json']
    paths=[ROOT/n for n in names if (ROOT/n).is_file()]+sorted((ROOT/'results').glob('*.json'))
    for j in [*suite['short_jobs'],*suite['jobs']]:
        d=Path(j['path']);assert d.parent==ROOT/'runs'
        if d.is_dir():paths.extend(sorted(v for v in d.iterdir() if v.is_file() and v.suffix in ('.json','.jsonl','.csv')))
    assert len(paths)<150 and sum(v.stat().st_size for v in paths)<50*1024**2,'bounded capture only'
    inventory={str(v.relative_to(ROOT)):sha(v) for v in paths}
    with tarfile.open(a.archive,'x') as t:
        for v in paths:
            data=v.read_bytes();entry=tarfile.TarInfo(str(v.relative_to(ROOT)));entry.size=len(data);entry.mode=0o444;t.addfile(entry,io.BytesIO(data))
    write_new(ROOT/(a.phase+'_CAPTURE_RECEIPT.json'),{'state':'passed','phase':a.phase,'archive_sha256':sha(a.archive),
      'manifest_sha256':sha(ROOT/'MANIFEST.json'),'files':inventory,'raw_binary_tensors_remain_native':True,
      'new_training_or_evaluation':0,'scientific_imports':0})
if __name__=='__main__':main()
