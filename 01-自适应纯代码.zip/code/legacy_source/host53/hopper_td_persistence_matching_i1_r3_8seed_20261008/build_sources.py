"""Pure stdlib identity proof for execution-only r3; no scientific imports."""
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
R2=ROOT.parent/'hopper_td_persistence_matching_i1_r2_8seed_20261007'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert sha(R2/'MANIFEST.json')=='c1ce43849b7cf18501b98266d67f5daefe96170b9c338ab327f785f68a54bcbe'
    m=json.loads((R2/'MANIFEST.json').read_text())
    assert len(m['source_hashes'])==7
    for name,digest in m['source_hashes'].items():assert sha(R2/'source_i1'/name)==sha(ROOT/'source_i1'/name)==digest
    assert {p.name for p in (ROOT/'source_i1').iterdir()}==set(m['source_hashes'])
    assert sha(ROOT/'stress_checkpoint.py')==sha(R2/'stress_checkpoint.py')
    print(json.dumps({'state':'passed','scientific_files_byte_identical_to_r2':7,'corrected_stress_helper_byte_identical_to_r2':True,'scientific_changes':0,'stdlib_only':True,'native_actions':0}))
if __name__=='__main__':main()
