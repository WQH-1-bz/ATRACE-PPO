"""All8 descriptive matching-component comparison; no selected-subset p values."""
import itertools
import statistics
from contracts import SEEDS,REPORT_METHODS
from bundle_contract import read,ROOT,controls
ENDPOINTS=('final_return','auc')
EXTERNAL=('critic_aware','gradient_ppo','reward_profiling','pae')
def analyze(jobs):
    ours={j['seed']:j['metrics'] for j in jobs};assert sorted(ours)==list(SEEDS)
    old=controls();full=read(ROOT/'FULL_REFERENCE.json')['rows']
    methods={m:{r['seed']:r for r in old if r['method']==m} for m in REPORT_METHODS}
    methods['Full']={r['seed']:r for r in full};methods['matching_TDp_I1']=ours
    summaries={m:{e:{'n':8,'mean':statistics.mean(rows[s][e] for s in SEEDS),
        'sd':statistics.stdev(rows[s][e] for s in SEEDS),'sd_definition':'sample n-1'} for e in ENDPOINTS} for m,rows in methods.items()}
    pairs={m:{e:{'differences_matching_I1_minus_comparator':[ours[s][e]-rows[s][e] for s in SEEDS],
        'mean_difference':statistics.mean(ours[s][e]-rows[s][e] for s in SEEDS)} for e in ENDPOINTS} for m,rows in methods.items() if m!='matching_TDp_I1'}
    reports={}
    for n in (3,5):
        out=[]
        for seeds in itertools.combinations(SEEDS,n):
            means={m:{e:statistics.mean(rows[s][e] for s in seeds) for e in ENDPOINTS} for m,rows in methods.items()}
            gate={e:means['fixed95'][e]<means['matching_TDp_I1'][e]<means['Full'][e]
                 and means['fixed95'][e]<means['innovation2'][e]<means['Full'][e]
                 and all(means['Full'][e]>means[m][e] for m in EXTERNAL) for e in ENDPOINTS}
            out.append({'seeds':list(seeds),'means':means,'passed_by_endpoint':gate,'passed':all(gate.values())})
        assert len(out)==56;reports[str(n)]=out
    return {'state':'completed','rows':[ours[s] for s in SEEDS],'all8_seeds':list(SEEDS),
      'all8_summary':summaries,'every_paired_outcome':pairs,'all_common_subset_reports':reports,
      'qualifying_common_subsets':{n:[r['seeds'] for r in rows if r['passed']] for n,rows in reports.items()},
      'all88_controls_and_existing_Full_preserved':True,'historical_NCS2_I1_remains_named_historical_comparator':True,
      'matching_component_scope':'Full retained-tail/split-trace/staged windows and interactions; ordinary64 vs Full164 different controller observation clock',
      'selected_common_triple26_27_28_is_developmental_evidence':True,
      'selected_subset_significance_computed':False,'independent_confirmation_claim':False,
      'additional_internal_comparisons':['fixed90','fixed99','linear'],
      'existing_Full_caveat':'Eight-seed Full means below fixed95; selected26/27/28 Full final below fixed90 despite higher AUC.',
      'new_Base_I2_Full_or_external_training':0}
