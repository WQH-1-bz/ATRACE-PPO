"""Focused stdlib scheduler contracts; no native subprocess or GPU query."""
import io
import json
from run_matching_i1 import reap_all,admission_snapshot,fits,check_deadline,plan,command
class Process:
    def __init__(self,pid,code):self.pid,self.code=pid,code
    def poll(self):return self.code
def main():
    active={'finished':{'process':Process(1,0),'stream':io.StringIO()},'live':{'process':Process(2,None),'stream':io.StringIO()}}
    ended=reap_all(active);assert len(ended)==1 and set(active)=={'live'} and ended[0][1]['returncode']==0 and ended[0][1]['stream'].closed
    events=[];calls=iter((1,0,0))
    def drain():events.append('drain');return next(calls)
    def snapshot():events.append('snapshot');return {'available':True}
    assert admission_snapshot(drain,lambda:False,snapshot,lambda s:s['available'])=={'available':True}
    assert events==['drain','snapshot','drain']
    # Capacity is now available, but elapsed deadline equality and overrun both reject.
    for now in (300.,300.001):
        try:check_deadline(300.,now)
        except TimeoutError:pass
        else:raise AssertionError('late capacity admission')
    check_deadline(300.,299.999)
    workers={'init':{'job':{'gpu':0},'process':Process(55,None),'reservation':6506,'cpu_reservation':2048,'rss_bytes':0,'disk_reservation':1024}}
    state={'cards':{0:{'free_mib':13524},1:{'free_mib':20000}},'process_mib':{0:{},1:{}},'cpu_available_bytes':3*1024**3,'disk_free_bytes':11*1024**3}
    assert fits(state,workers,6506,2048,1024,0)
    state['cards'][0]['free_mib']-=1;assert not fits(state,workers,6506,2048,1024,0)
    state['cards'][0]['free_mib']=20000;state['cpu_available_bytes']=2*1024**3;assert not fits(state,workers,6506,2048,1024,0)
    state['cpu_available_bytes']=3*1024**3;state['disk_free_bytes']=10*1024**3;assert not fits(state,workers,6506,2048,1024,0)
    assert [j['seed'] for j in plan()]==list(range(21,29)) and all(j['gpu'] in (0,1) for j in plan())
    assert all(j['gpu']==0 and j['seed']==91103 and j['short'] for j in plan(True))
    for j in plan():assert command(j)[1].endswith('source_i1/train_kl_relative.py') and '--steps' in command(j)
    print(json.dumps({'state':'passed','stdlib_only':True,'reaped_exits_release_reservations_before_admission':True,
       'initializing_GPU_CPU_and_pending_disk_charged':True,'deadline_equality_and_new_capacity_overrun_rejected':True,
       'all8_one_recipe_physical_GPU0_1_only':True,'shortA_B_sequential_sameGPU0_plan':True,'native_Popen_calls':0,'GPU_queries':0},indent=2))
if __name__=='__main__':main()
