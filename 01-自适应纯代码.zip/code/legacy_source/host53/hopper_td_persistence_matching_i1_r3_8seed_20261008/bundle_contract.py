"""Cold stdlib bundle, native admission and protection contracts."""
import csv
import importlib.metadata
import json
import hashlib
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
NATIVE_ROOT=Path('/ssd_2/wch/hopper_td_persistence_matching_i1_r3_8seed_20261008')
OLD_ROOT=Path('/ssd_2/wch/hopper_innovation12_transfer2_records_r1_8seed_20261006')
PYTHON=OLD_ROOT/'.venv/bin/python'
GPU_UUIDS={0:'GPU-32b8892b-0703-3c74-56fe-cf278c1fa4cc',1:'GPU-694f7a96-5e77-2a24-2a88-87c554d001bf'}
FLAGS={'PYTHONUNBUFFERED':'1','PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','DPO_TORCH_DETERMINISTIC':'1','DPO_WARP_DETERMINISTIC':'run_to_run','DPO_WARP_DETERMINISTIC_MAX_RECORDS':'8','CUBLAS_WORKSPACE_CONFIG':':4096:8','DPO_PPO_GRAPH':'0'}
DET={'torch':True,'warp':'run_to_run','warp_max_records':8,'cublas_workspace_config':':4096:8'}
DISK_FLOOR=10*1024**3
def read(p):
    def invalid(v):raise ValueError('Nonfinite JSON: '+v)
    return json.loads(Path(p).read_text(),parse_constant=invalid)
def write(p,x):
    p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n');tmp.replace(p)
def write_new(p,x):
    with Path(p).open('x') as f:f.write(json.dumps(x,indent=2,allow_nan=False)+'\n')
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as s:
        for b in iter(lambda:s.read(1048576),b''):h.update(b)
    return h.hexdigest()
def child_env():
    assert 'CUDA_VISIBLE_DEVICES' not in os.environ
    env={**os.environ,**FLAGS}
    for key,sub in [('XDG_CACHE_HOME','cache'),('WARP_CACHE_PATH','cache/warp'),('CUDA_CACHE_PATH','cache/cuda'),('TORCH_HOME','cache/torch'),('TMPDIR','tmp')]:env[key]=str(OLD_ROOT/sub)
    return env
def check_manifest():
    m=read(ROOT/'MANIFEST.json');assert sha(ROOT/'MANIFEST.json')==(ROOT/'MANIFEST.sha256').read_text().strip()
    assert m['state']=='READY_source_only' and m['formal_total']==8 and m['native_root']==str(NATIVE_ROOT)
    for name,digest in m['bundle_hashes'].items():
        p=ROOT/name;assert p.is_file() and sha(p)==digest and not p.stat().st_mode&0o222,('frozen bundle changed',name)
    assert {p.name for p in (ROOT/'source_i1').iterdir() if p.is_file()}==set(m['source_hashes'])
    return m
def require_review():
    assert ROOT==NATIVE_ROOT and 'CUDA_VISIBLE_DEVICES' not in os.environ
    m=check_manifest();assert sys.version.startswith('3.11.15 ')
    assert str(Path(sys.executable).resolve())==str(Path(m['actual_native_interpreter']).resolve())
    for name,version in m['runtime_versions'].items():assert importlib.metadata.version(name)==version
    for key,value in FLAGS.items():assert os.environ.get(key)==value
    for key in ('XDG_CACHE_HOME','WARP_CACHE_PATH','CUDA_CACHE_PATH','TORCH_HOME','TMPDIR'):assert os.environ.get(key)==child_env()[key]
    review=read(ROOT/'PARENT_REVIEW_ADMISSION.json')
    assert review['state']=='passed' and review['manifest_sha256']==sha(ROOT/'MANIFEST.json')
    assert review['independent_exact_source_review_passed'] and review['matching_TD_persistence_I1_approved']
    monitor=read(ROOT/'LUNA_MONITOR_ACTIVE.json')
    assert monitor['state']=='ACTIVE' and monitor['manifest_sha256']==sha(ROOT/'MANIFEST.json')
    assert monitor['fresh_stage'] in ('matching_i1_saved_strict_short','formal_training','terminal_verification')
    for label in ('actual_goal_receipt','initial_snapshot'):
        assert sha(monitor[label+'_path'])==monitor[label+'_sha256']
    goal=read(monitor['actual_goal_receipt_path'])['goal']
    assert goal['status']=='active' and goal['threadId']==monitor['goal_id'] and monitor['initial_snapshot_recorded']
    return m
def require_runtime():
    m=require_review();binding=read(ROOT/'PARENT_NATIVE_BINDINGS.json')
    assert binding['state']=='verified' and binding['manifest_sha256']==sha(ROOT/'MANIFEST.json')
    assert binding['source_hashes']==m['source_hashes']
    return m
def gpu_snapshot():
    assert ROOT==NATIVE_ROOT,'GPU access forbidden during local source preparation'
    rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,memory.free,memory.total','--format=csv,noheader,nounits'],text=True,timeout=20).splitlines()
    cards={}
    for line in rows:
        index,uuid,free,total=[x.strip() for x in line.split(',')];cards[int(index)]={'uuid':uuid,'free_mib':int(free),'total_mib':int(total)}
    assert set(cards)=={0,1}
    for index,uuid in GPU_UUIDS.items():assert cards[index]['uuid']==uuid
    memory={0:{},1:{}}
    for line in subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_gpu_memory','--format=csv,noheader,nounits'],text=True,timeout=20).splitlines():
        pid,uuid,used=[x.strip() for x in line.split(',')]
        assert uuid in GPU_UUIDS.values()
        card=next(i for i,u in GPU_UUIDS.items() if u==uuid);memory[card][int(pid)]=int(used)
    mem={line.split(':')[0]:int(line.split()[1])*1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith(('MemAvailable:','MemTotal:'))}
    return {'cards':cards,'process_mib':memory,'cpu_available_bytes':mem['MemAvailable'],'disk_free_bytes':shutil.disk_usage(ROOT).free}
def controls():
    from contracts import REPORT_METHODS,SEEDS
    rows=read(ROOT/'COMPARISON_REFERENCE.json')['rows'];assert len(rows)==88
    assert {(r['method'],r['seed']) for r in rows}=={(m,s) for m in REPORT_METHODS for s in SEEDS}
    return rows
def reintegrate(p,budget,strict_grid=True):
    from contracts import evaluation_grid,SHORT
    p=Path(p);initial=read(p/'initial_evaluation.json');ev=[json.loads(v) for v in (p/'evaluations.jsonl').read_text().splitlines() if v.strip()]
    if strict_grid:assert [x['steps'] for x in ev]==evaluation_grid(budget==SHORT)
    else:
        # Preserved staged/retained historical arms cross thresholds at their own window end.
        assert len(ev)==39 and ev[-1]['steps']==budget
        assert all(a['steps']<b['steps'] for a,b in zip(ev,ev[1:]))
    for e in [initial,*ev]:
        assert len(e['returns'])==len(e['lengths'])==32 and all(math.isfinite(v) for v in e['returns'])
        assert all(type(v) is int and 1<=v<=1000 for v in e['lengths'])
    pts=[(0,initial['mean'])]+[(e['steps'],e['mean']) for e in ev]
    return sum((b[0]-a[0])*(a[1]+b[1])/2 for a,b in zip(pts,pts[1:]))/budget,initial,ev
def verify_historical():
    m=check_manifest();count=0
    for name,digest in read(ROOT/'PROTECTED_SOURCE_PINS.json').items():
        assert sha(name)==digest,('preserved source changed',name);count+=1
    for row in [*controls(),*read(ROOT/'FULL_REFERENCE.json')['rows']]:
        p=Path(row['path'])
        for name,digest in row['artifact_hashes'].items():assert sha(p/name)==digest,('preserved result changed',p/name);count+=1
        area,initial,ev=reintegrate(p,10027008,strict_grid=False)
        summary=read(p/'summary.json');config=read(p/'config.json')
        assert summary['state']=='completed' and summary['reload_check']=='passed'
        assert area==row['auc'] and summary['final_eval']['mean']==row['final_return']
        assert config['xml_sha256']==m['xml_sha256']
    r1pins=read(ROOT/'R1_PRESERVATION_PINS.json')
    for name,digest in r1pins.items():assert sha(name)==digest,('preserved r1 failure/source/shortA changed',name);count+=1
    r2pins=read(ROOT/'R2_PRESERVATION_PINS.json')
    for name,digest in r2pins.items():assert sha(name)==digest,('preserved r2 failure/source/shortA changed',name);count+=1
    return {'state':'passed','original_r2_source_failure_and_shortA_preserved':True,'r2_additional_preserved_pins':len(r2pins),'pinned_files':count,'all88_controls_preserved':True,'all8_Full_results_preserved':True,'original_r1_source_failure_and_shortA_preserved':True,'r1_additional_preserved_pins':len(r1pins),'new_training_or_evaluation':0}
