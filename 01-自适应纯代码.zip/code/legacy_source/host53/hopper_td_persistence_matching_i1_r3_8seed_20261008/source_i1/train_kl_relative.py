"""Matching TD-persistence I1; ordinary64 PPO and primary fixed95 GAE."""
import argparse
from collections import deque
import csv
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import time

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
if os.environ.get("DPO_TORCH_DETERMINISTIC") == "1":
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
import numpy as np
import torch
from torch import nn
from locomotion_warp import LocomotionWarp, ASSETS, TASKS
from noisy_observation import NoisyObservation
if os.environ.get("DPO_TORCH_DETERMINISTIC") == "1":
    torch.use_deterministic_algorithms(True)


def write_json(path, data):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")
    tmp.replace(path)


class RunningStats(nn.Module):
    def __init__(self, shape, device):
        super().__init__()
        self.register_buffer("mean", torch.zeros(shape, device=device))
        self.register_buffer("var", torch.ones(shape, device=device))
        self.register_buffer("count", torch.tensor(1e-4, device=device))

    @torch.no_grad()
    def update(self, x):
        mean = x.mean(0)
        var = x.var(0, unbiased=False)
        count = x.shape[0]
        delta, total = mean - self.mean, self.count + count
        new_var = (self.var * self.count + var * count + delta.square() * self.count * count / total) / total
        self.mean.add_(delta * count / total)
        self.var.copy_(new_var)
        self.count.copy_(total)

    def normalize(self, x):
        return ((x - self.mean) / (self.var + 1e-8).sqrt()).clamp(-10, 10)


class ActorCritic(nn.Module):
    def __init__(self, obs_dim=11, action_dim=3):
        super().__init__()
        def mlp(out, gain):
            layers = []
            for i, (nin, nout) in enumerate([(obs_dim, 64), (64, 64), (64, out)]):
                layer = nn.Linear(nin, nout)
                nn.init.orthogonal_(layer.weight, gain=gain if i == 2 else math.sqrt(2))
                nn.init.zeros_(layer.bias)
                layers.append(layer)
                if i != 2:
                    layers.append(nn.Tanh())
            return nn.Sequential(*layers)
        self.actor, self.critic = mlp(action_dim, .01), mlp(1, 1)
        self.log_std = nn.Parameter(torch.zeros(action_dim))

    def distribution(self, obs):
        return torch.distributions.Normal(self.actor(obs), self.log_std.exp(), validate_args=False)

    def value(self, obs):
        return self.critic(obs).squeeze(-1)


@torch.jit.script
def gae(rewards, values, next_values, terminated, done, gamma: float = .99, lam: float = .95):
    advantages = torch.zeros_like(rewards)
    carry = torch.zeros_like(rewards[0])
    for t in range(rewards.shape[0] - 1, -1, -1):
        delta = rewards[t] + gamma * (~terminated[t]).float() * next_values[t] - values[t]
        carry = delta + gamma * lam * (~done[t]).float() * carry
        advantages[t] = carry
    return advantages, advantages + values


@torch.jit.script
def actor_gae(rewards, values, next_values, terminated, done, gamma: float = .99, lam: float = .95):
    advantages = torch.zeros_like(rewards)
    carry = torch.zeros_like(rewards[0])
    for t in range(rewards.shape[0] - 1, -1, -1):
        delta = rewards[t] + gamma * (~terminated[t]).float() * next_values[t] - values[t]
        carry = delta + gamma * lam * (~done[t]).float() * carry
        advantages[t] = carry
    return advantages, advantages + values


from signal_td_persistence import td_persistence
from lambda_td_persistence import TDPersistence
from full_capture import snapshot_state, physics_state, capture_window

@torch.no_grad()
def evaluate(model, stats, env):
    obs = env.reset()
    active = torch.ones(env.num_envs, device=env.device, dtype=torch.bool)
    returns = torch.zeros(env.num_envs, device=env.device)
    lengths = torch.zeros(env.num_envs, device=env.device, dtype=torch.long)
    # Exactly one complete episode per world; do not favor quickly ending episodes.
    for _ in range(env.max_steps):
        actions = model.actor(stats.normalize(obs))
        obs, reward, term, trunc, _info = env.step(actions)
        returns.add_(reward * active)
        lengths.add_(active.long())
        active &= ~(term | trunc)
        if not bool(active.any()):
            break
    env.check_capacity()
    if not bool(torch.isfinite(returns).all()):
        raise RuntimeError("Non-finite evaluation return")
    return {"mean": returns.mean().item(), "std": returns.std(unbiased=False).item(),
            "returns": returns.cpu().tolist(), "lengths": lengths.cpu().tolist()}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--steps',type=int,required=True,choices=(786432,10027008))
    parser.add_argument('--seed',type=int,required=True)
    parser.add_argument('--device',choices=('cuda:0','cuda:1'),required=True)
    args=parser.parse_args()
    args.num_envs,args.rollout,args.batch_size,args.epochs,args.eval_envs,args.eval_every=1024,64,1024,10,32,262144
    args.task,args.noise_mode,args.noise_scale='Hopper','none',0.
    if args.steps==10027008:assert args.seed in range(21,29)
    else:assert args.seed==91103 and args.device=='cuda:0'
    assert 'CUDA_VISIBLE_DEVICES' not in os.environ
    assert torch.are_deterministic_algorithms_enabled()
    from pathlib import Path as _Path
    import sys as _sys
    _sys.path.insert(0,str(_Path(__file__).resolve().parent.parent))
    from bundle_contract import require_runtime,check_manifest,DET,read,ROOT,sha
    manifest=require_runtime();assert check_manifest()['source_hashes']==manifest['source_hashes']
    monitor=read(ROOT/'LUNA_MONITOR_ACTIVE.json')
    if args.steps==10027008:
        from run_matching_i1 import formal_admission
        formal_admission()
        marker=read(ROOT/'FORMAL_STAGE_STARTED.json')
        assert marker['manifest_sha256']==sha(ROOT/'MANIFEST.json') and marker['stage']=='formal'
        assert marker['monitor_goal_id']==monitor['goal_id']
    else:
        assert monitor['fresh_stage']=='matching_i1_saved_strict_short'
        marker=read(ROOT/'SHORT_STAGE_STARTED.json')
        assert marker['manifest_sha256']==sha(ROOT/'MANIFEST.json') and marker['stage']=='short'
        assert marker['monitor_goal_id']==monitor['goal_id']
        assert read(ROOT/'results/saved24__saved-state.json')['state']=='passed'
        assert read(ROOT/'results/saved24__saved-state__exit.json')['returncode']==0
    args.out.mkdir(parents=True,exist_ok=False)
    torch.set_num_threads(1)
    torch.cuda.set_device(args.device)
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    obs_dim,action_dim=11,3
    XML_PATH=ASSETS/TASKS[args.task][0]
    effective_steps=args.steps
    updates=effective_steps//65536
    assert updates in (12,153)
    config={**vars(args),'out':str(args.out),'effective_steps':effective_steps,
        'algorithm':'Innovation1','algorithm_version':'hopper_i1_matching_td_persistence_r1',
        'backend':'MuJoCo Warp','gamma':.99,'learning_rate':3e-4,'clip_range':.2,
        'value_coef':.5,'entropy_coef':0.,'max_grad_norm':.5,'network':[64,64],'optimizer_eps':1e-5,
        'reward_normalization':True,'observation_normalization':True,'fixed_critic_lambda':.95,
        'xml_sha256':hashlib.sha256(XML_PATH.read_bytes()).hexdigest(),
        'versions':{p:importlib.metadata.version(p) for p in manifest['runtime_versions']},
        'determinism':DET,'source_sha256':manifest['source_hashes'],
        'lambda_design':{'version':'TD_persistence','initial':.95,'bounds':[.90,.99],
          'warmup_updates':4,'first_possible_changed_actor_update':5,'block_windows':4,
          'slow_ema':.9,'target':'.95+.04*tanh(2*slow_persistence)','tracking_rate':.1,'max_step':.001,
          'signal_domain':'all64fresh per world; adjacent same-world pairs exclude done[left]',
          'observation_clock':'frozen before PPO; observe after all10epochs; affects next window',
          'evaluation_return_used':False,'extra_environment_steps':0,'extra_optimizer_steps':0},
        'target_call_contract':{'primary95_calls_per_window':1,'primary_startup_warmups':0,
          'actor95_uses_primary_A95':True,'isolated_actor_warmups_if_adaptive':3,
          'isolated_actor_warmup_lambda':.95,'isolated_actor_returns_discarded':True},
        'i2':{'enabled':False,'retained_rows':0,'overlap':False,'stale_correction':False,'stage_switch':False},
        'signal_files':[f'window_audits/update_{u:03d}.pt' for u in range(1,updates+1)],
        'fixed_critic_audit_updates':[4,5,updates],
        'capture_cost':'all-window tensors and post-PPO states; measured trainer peak/RSS/disk/capture elapsed',
        'fixed_critic_caveat':'Fixed labels do not imply equal weights under shared joint gradient clipping.'}
    assert config['xml_sha256']==manifest['xml_sha256'] and config['versions']==manifest['runtime_versions']
    for sub in ('window_audits','scientific_states'):(args.out/sub).mkdir()
    write_json(args.out/'config.json',config)
    write_json(args.out/'status.json',{'state':'compiling','pid':os.getpid()})
    try:
        env = NoisyObservation(LocomotionWarp(args.num_envs, args.device, args.seed, task=args.task),args.noise_mode,args.noise_scale,args.seed+200000)
        eval_env = NoisyObservation(LocomotionWarp(args.eval_envs, args.device, args.seed + 10000,task=args.task),args.noise_mode,args.noise_scale,args.seed+300000)
        model = ActorCritic(obs_dim,action_dim).to(args.device)
        optimizer = torch.optim.Adam(model.parameters(), lr=3e-4, eps=1e-5)
        obs_stats = RunningStats((obs_dim,), args.device)
        reward_stats = RunningStats((), args.device)
        raw_obs = env.reset()
        obs_stats.update(raw_obs)
        obs = obs_stats.normalize(raw_obs)
        initial = evaluate(model, obs_stats, eval_env)
        write_json(args.out/'initial_evaluation.json',initial)
        shape=(args.rollout,args.num_envs)
        obuf=torch.empty((*shape,obs_dim),device=args.device)
        nbuf=torch.empty_like(obuf)
        abuf=torch.empty((*shape,action_dim),device=args.device)
        logbuf,rbuf,vbuf,nvbuf=[torch.empty(shape,device=args.device) for _ in range(4)]
        tbuf,dbuf=[torch.empty(shape,dtype=torch.bool,device=args.device) for _ in range(2)]
        discounted_return=torch.zeros(args.num_envs,device=args.device)
        recent=deque(maxlen=100)
        latest_eval,best=initial,-float('inf')
        next_eval=args.eval_every
        feedback=TDPersistence()
        collected_time=0
        started=time.monotonic()
        capture_seconds=0.
        fields=['steps','elapsed_seconds','steps_per_second','train_return_last_100','value_loss','policy_loss','entropy','approx_kl','clip_fraction','explained_variance','eval_mean','actor_lambda','critic_lambda','lambda_delta','fresh_per_world','used_per_world','retained_per_world']
        with (args.out/'progress.csv').open('w',buffering=1) as logfile:
            writer=csv.DictWriter(logfile,fieldnames=fields);writer.writeheader()
            for update in range(1,updates+1):
                current_steps=collected_time*args.num_envs
                controller_before_step=feedback.state_dict()
                delta=feedback.step(update)
                actor_lambda_used=feedback.value
                episode_values=[]
                fresh=end=used=64
                with torch.no_grad():
                    for t in range(0, end):
                        obuf[t].copy_(obs)
                        dist = model.distribution(obs)
                        actions = dist.sample()
                        abuf[t].copy_(actions)
                        logbuf[t].copy_(dist.log_prob(actions).sum(-1))
                        vbuf[t].copy_(model.value(obs))
                        raw_obs, reward, term, trunc, info = env.step(actions)
                        done = term | trunc
                        # Bootstrap time limits from terminal observations, never reset observations.
                        nbuf[t].copy_(obs_stats.normalize(info["terminal_observation"]))
                        nvbuf[t].copy_(model.value(nbuf[t]))
                        discounted_return.mul_(.99).add_(reward)
                        reward_stats.update(discounted_return)
                        rbuf[t].copy_((reward / (reward_stats.var + 1e-8).sqrt()).clamp(-10, 10))
                        discounted_return.masked_fill_(done, 0)
                        tbuf[t].copy_(term)
                        dbuf[t].copy_(done)
                        episode_values.append(torch.where(done, info["episode_return"], torch.nan))
                        obs_stats.update(raw_obs)
                        obs = obs_stats.normalize(raw_obs)
                    collected_time+=64
                    xs=(rbuf,vbuf,nvbuf,tbuf,dbuf)
                    # Exactly one primary call, including cold windows1/2; no startup warmup.
                    fixed95_actor_advantage,returns=gae(*xs,.99,.95)
                    if actor_lambda_used==.95:
                        advantages=fixed95_actor_advantage
                    else:
                        for _ in range(3):actor_gae(*xs,.99,.95)
                        advantages,_=actor_gae(*xs,.99,actor_lambda_used)
                    recent_values=torch.stack(episode_values).flatten()
                    recent.extend(recent_values[torch.isfinite(recent_values)].cpu().tolist())
                env.check_capacity()
                flat_obs, flat_actions = obuf[:used].flatten(0, 1), abuf[:used].flatten(0, 1)
                flat_log, flat_adv, flat_ret = logbuf[:used].flatten(), advantages[:used].flatten(), returns[:used].flatten()
                capture_started=time.monotonic()
                if update==1:
                    snapshot_state(args.out/'first_window_pre.pt',model,{'ppo':optimizer},obs_stats,reward_stats,
                        dict(update=1,steps=65536,physics=physics_state(env,eval_env),
                             observation=flat_obs.detach().cpu().clone(),action=flat_actions.detach().cpu().clone(),
                             behavior_logprob=flat_log.detach().cpu().clone(),actor_advantage=flat_adv.detach().cpu().clone(),
                             consumed_critic_return=flat_ret.detach().cpu().clone()))
                signal_metrics=td_persistence(*xs,0,64,.99)
                metadata=dict(update=update,steps=collected_time*1024,prior_collected_steps=current_steps,
                    fresh_per_world=64,incoming_retained_per_world=0,end_per_world=64,used_per_world=64,retained_per_world=0,
                    overlap_active=False,stage_boundary_flush=False,gamma=.99,actor_lambda=actor_lambda_used,critic_lambda=.95,
                    controller_before_step=controller_before_step,controller_before_observe=feedback.state_dict(),
                    primary95_call_index=update,isolated_actor_warmup_calls=0 if actor_lambda_used==.95 else 3,
                    target_device=args.device)
                capture_window(args.out/'window_audits'/f'update_{update:03d}.pt',
                    dict(zip(('normalized_reward','values','next_values','terminated','done'),xs)),
                    flat_adv,flat_ret,fixed95_actor_advantage.flatten(),signal_metrics,metadata)
                if update in (4,5,updates):
                    snapshot={**dict(zip(('normalized_reward','values','next_values','terminated','done'),[x.detach().cpu().clone() for x in xs])),
                        'actor_advantage':flat_adv.detach().cpu().clone(),'consumed_critic_return':flat_ret.detach().cpu().clone(),
                        **metadata}
                    torch.save(snapshot,args.out/f'fixed_critic_audit_{update:03d}.pt')
                if update==1:
                    snapshot_state(args.out/'first_window_after_observers.pt',model,{'ppo':optimizer},obs_stats,reward_stats,
                        dict(update=1,steps=65536,physics=physics_state(env,eval_env),
                             observation=flat_obs.detach().cpu().clone(),action=flat_actions.detach().cpu().clone(),
                             behavior_logprob=flat_log.detach().cpu().clone(),actor_advantage=flat_adv.detach().cpu().clone(),
                             consumed_critic_return=flat_ret.detach().cpu().clone()))
                capture_seconds+=time.monotonic()-capture_started
                train_size = used * args.num_envs
                with torch.no_grad():
                    old_dist=model.distribution(flat_obs)
                    old_mean=old_dist.loc.detach().clone()
                    old_scale=old_dist.scale.detach().clone()
                metrics = []
                for epoch in range(args.epochs):
                    permutation = torch.randperm(train_size, device=args.device)
                    for idx in permutation.split(args.batch_size):
                        dist = model.distribution(flat_obs[idx])
                        new_log = dist.log_prob(flat_actions[idx]).sum(-1)
                        log_ratio = new_log - flat_log[idx]
                        ratio = log_ratio.exp()
                        adv = flat_adv[idx]
                        adv = (adv - adv.mean()) / (adv.std(unbiased=False) + 1e-8)
                        pg = torch.maximum(-adv * ratio, -adv * ratio.clamp(.8, 1.2)).mean()
                        vl = (model.value(flat_obs[idx]) - flat_ret[idx]).square().mean()
                        entropy = dist.entropy().sum(-1).mean()
                        loss = pg + .5 * vl
                        optimizer.zero_grad(set_to_none=True)
                        loss.backward()
                        nn.utils.clip_grad_norm_(model.parameters(), .5)
                        optimizer.step()
                        with torch.no_grad():
                            metrics.append(torch.stack((vl, pg, entropy,
                                ((ratio - 1) - log_ratio).mean(), ((ratio - 1).abs() > .2).float().mean())))
                stats = torch.stack(metrics).mean(0).detach().cpu().tolist()
                if not all(math.isfinite(v) for v in stats):
                    raise RuntimeError("Non-finite PPO optimization metrics")
                with torch.no_grad():
                    old_policy=torch.distributions.Normal(old_mean,old_scale,validate_args=False)
                    realized_kl=float(torch.distributions.kl_divergence(old_policy,model.distribution(flat_obs)).sum(-1).mean())
                feedback.observe(signal_metrics['persistence'])
                with (args.out/'td_persistence_decisions.jsonl').open('a') as f:
                    f.write(json.dumps({**metadata,**signal_metrics,'lambda_delta':delta,
                        'controller_after_observe':feedback.state_dict(),'optimizer_steps_shared':update*640},allow_nan=False)+'\n')
                capture_started=time.monotonic()
                if update==1:
                    snapshot_state(args.out/'first_window_post.pt',model,{'ppo':optimizer},obs_stats,reward_stats,
                        dict(update=1,steps=65536,physics=physics_state(env,eval_env),controller=feedback.state_dict(),actor_lambda=actor_lambda_used,critic_lambda=.95))
                snapshot_state(args.out/'scientific_states'/f'update_{update:03d}.pt',model,{'ppo':optimizer},obs_stats,reward_stats,
                    dict(update=update,steps=collected_time*1024,physics=physics_state(env,eval_env),controller=feedback.state_dict(),actor_lambda=actor_lambda_used,critic_lambda=.95))
                capture_seconds+=time.monotonic()-capture_started
                steps=collected_time*1024
                evaluated=steps>=next_eval or steps>=effective_steps
                if evaluated:
                    latest_eval=evaluate(model,obs_stats,eval_env)
                    with (args.out/'evaluations.jsonl').open('a') as f:f.write(json.dumps({'steps':steps,**latest_eval})+'\n')
                    checkpoint={'model':model.state_dict(),'optimizer':optimizer.state_dict(),'obs_stats':obs_stats.state_dict(),
                        'reward_stats':reward_stats.state_dict(),'steps':steps,'update':update,'config':config,
                        'td_persistence_feedback':feedback.state_dict(),'actor_lambda':actor_lambda_used,'critic_lambda':.95,
                        'optimizer_steps_shared':update*640,'source_sha256':manifest['source_hashes']}
                    torch.save(checkpoint,args.out/'latest.pt')
                    if latest_eval['mean']>best:
                        best=latest_eval['mean'];torch.save(checkpoint,args.out/'best.pt')
                    next_eval=(steps//args.eval_every+1)*args.eval_every
                torch.cuda.synchronize()
                elapsed=time.monotonic()-started
                ret_var=flat_ret.var(unbiased=False)
                ev=(1-(flat_ret-vbuf[:used].flatten()).var(unbiased=False)/(ret_var+1e-8)).item()
                row=dict(zip(fields,[steps,elapsed,steps/elapsed,float(np.mean(recent)) if recent else None,*stats,ev,
                    latest_eval['mean'] if evaluated else None,actor_lambda_used,.95,delta,64,64,0]))
                writer.writerow(row)
                status={**row,'state':'running','pid':os.getpid(),'device':args.device,'physics_device':str(env.qpos.device),
                    'budget':effective_steps,'eta_seconds':(effective_steps-steps)/(steps/elapsed)}
                write_json(args.out/'status.json',status)
                print(f'{steps}/{effective_steps} | {steps/elapsed:.0f} steps/s',flush=True)
        # Reload verification constructs a model only after all training RNG/physics are captured.
        snapshot_state(args.out/'final_scientific_state.pt',model,{'ppo':optimizer},obs_stats,reward_stats,
            dict(update=updates,steps=steps,physics=physics_state(env,eval_env),controller=feedback.state_dict(),actor_lambda=actor_lambda_used,critic_lambda=.95))
        restored=ActorCritic(11,3).to(args.device)
        loaded=torch.load(args.out/'latest.pt',weights_only=False)
        restored.load_state_dict(loaded['model'])
        with torch.no_grad():
            torch.testing.assert_close(restored.actor(obs),model.actor(obs),rtol=0,atol=0)
            torch.testing.assert_close(restored.value(obs),model.value(obs),rtol=0,atol=0)
        import resource
        summary={**status,'state':'completed','initial_eval':initial,'final_eval':latest_eval,'best_eval_mean':best,
            'reload_check':'passed','training_transitions':effective_steps,'total_algorithm_transitions':effective_steps,
            'optimizer_steps':{'actor':updates*640,'critic':updates*640,'h':0},'optimizer_steps_shared':updates*640,
            'peak_torch_memory_reserved_bytes':torch.cuda.max_memory_reserved(args.device),
            'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'capture_seconds':capture_seconds,
            'serialized_output_bytes':sum(p.stat().st_size for p in args.out.rglob('*') if p.is_file()),
            'controller_observations':feedback.observations,'pending_block_observations':updates%4,
            'note':'One matching TD-persistence I1 recipe; performance evidence outstanding until formal cohort.'}
        write_json(args.out/'summary.json',summary);write_json(args.out/'status.json',summary)
    except BaseException as exc:
        write_json(args.out/'status.json',{'state':'failed','error':repr(exc),'pid':os.getpid()});raise

if __name__=='__main__':main()
