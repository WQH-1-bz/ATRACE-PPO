"""Root-admitted fresh native process: exact cold target timeline and all artifacts."""
import argparse
import csv
from collections import OrderedDict
import importlib
import math
from pathlib import Path
import resource
import struct
import sys
from bundle_contract import ROOT,read,sha,write_new,require_runtime,verify_historical,reintegrate,DET
from contracts import BUDGET,SHORT,SEEDS,ledger
from controller_oracle import replay as oracle
KEYS=('normalized_reward','values','next_values','terminated','done')
def jsonl(p):return [read_line(x) for x in Path(p).read_text().splitlines() if x.strip()]
def read_line(x):
    import json
    return json.loads(x)
def equal(a,b,path=''):
    assert type(a)==type(b),(path,type(a),type(b))
    if isinstance(a,torch.Tensor):
        assert a.shape==b.shape and a.dtype==b.dtype,(path,'shape/dtype')
        assert torch.equal(a.contiguous().reshape(-1).view(torch.uint8),b.contiguous().reshape(-1).view(torch.uint8)),(path,'tensor bytes')
    elif isinstance(a,dict):
        assert a.keys()==b.keys(),(path,'keys')
        for k in a:equal(a[k],b[k],path+'/'+str(k))
    elif isinstance(a,(tuple,list)):
        assert len(a)==len(b),path
        for i,(x,y) in enumerate(zip(a,b)):equal(x,y,path+'/'+str(i))
    elif isinstance(a,float):assert struct.pack('!d',a)==struct.pack('!d',b),(path,a,b)
    else:assert a==b,(path,a,b)
def compare_final_checkpoint_state_dicts(final,saved):
    # Only the three declared Module.state_dict boundaries use this representation conversion.
    model_names=('log_std',)+tuple(f'{net}.{layer}.{part}' for net in ('actor','critic') for layer in (0,2,4) for part in ('weight','bias'))
    for name,names in (('model',model_names),('obs_stats',('mean','var','count')),('reward_stats',('mean','var','count'))):
        assert type(final[name]) is dict,(name,'snapshot must be exactly plain dict')
        assert type(saved[name]) is OrderedDict,(name,'checkpoint must be exactly OrderedDict')
        assert tuple(final[name])==tuple(saved[name])==names,(name,'declared ordered names')
        # _metadata is module-loading metadata outside the declared parameter/buffer mapping.
        equal(final[name],dict(saved[name]),name)
def load(p):return torch.load(p,map_location='cpu',weights_only=False)
def api():
    sys.path.insert(0,str(ROOT/'source_i1'))
    train=importlib.import_module('train_kl_relative')
    assert Path(train.__file__).resolve()==(ROOT/'source_i1/train_kl_relative.py').resolve()
    return train
def validate_inputs(x):
    for key in KEYS:
        v=x[key];assert isinstance(v,torch.Tensor) and v.shape==(64,1024) and v.device.type=='cpu' and not v.requires_grad
        assert v.dtype==(torch.bool if key in ('terminated','done') else torch.float32)
        assert bool(torch.isfinite(v).all())
    assert not bool((x['terminated']&~x['done']).any())
def cpu_double_signal(x):
    """Independent CPU-double moments with explicit time/world pair indexing."""
    r,v,nv,t,d=(x[k] for k in KEYS)
    td=(r+.99*(~t).float()*nv-v).double()
    left=[];right=[]
    for time in range(63):
        for world in range(1024):
            if not bool(d[time,world]):
                left.append(float(td[time,world]));right.append(float(td[time+1,world]))
    n=len(left)
    if n:
        ml,mr=math.fsum(left)/n,math.fsum(right)/n
        vl=math.fsum((a-ml)**2 for a in left)/n
        vr=math.fsum((b-mr)**2 for b in right)/n
        cov=math.fsum((a-ml)*(b-mr) for a,b in zip(left,right))/n
    else:ml=mr=vl=vr=cov=0.
    valid=n>=2 and vl>0 and vr>0
    return {'td_pair_count':n,'td_pair_signal_valid':valid,'td_pair_mean_left':ml,'td_pair_mean_right':mr,
       'td_pair_variance_left':vl,'td_pair_variance_right':vr,'td_pair_covariance':cov,
       'persistence':max(-1.,min(1.,cov/math.sqrt(vl*vr))) if valid else 0.}
def oracle_signal_compare(actual,expected):
    for k,v in expected.items():
        if type(v) in (bool,int):equal(actual[k],v,k)
        else:assert math.isclose(actual[k],v,rel_tol=2e-12,abs_tol=2e-12),(k,actual[k],v)
def adam(x,steps):
    assert set(x)=={'state','param_groups'} and len(x['param_groups'])==1
    assert x['state'] and set(x['state'])==set(x['param_groups'][0]['params'])
    assert all(float(v['step'])==steps for v in x['state'].values())
    assert all(bool(torch.isfinite(v[k]).all()) for v in x['state'].values() for k in ('exp_avg','exp_avg_sq'))
def scientific(x,steps):
    assert set(x)=={'model','optimizers','obs_stats','reward_stats','physics','controller','update','steps','actor_lambda','critic_lambda'}
    assert set(x['optimizers'])=={'ppo'};adam(x['optimizers']['ppo'],steps)
    for key in ('model','obs_stats','reward_stats'):
        assert x[key] and all(isinstance(v,torch.Tensor) and v.device.type=='cpu' and not v.requires_grad and bool(torch.isfinite(v).all()) for v in x[key].values())
    modelkeys={'log_std'}|{f'{net}.{layer}.{part}' for net in ('actor','critic') for layer in (0,2,4) for part in ('weight','bias')}
    assert set(x['model'])==modelkeys and len(x['optimizers']['ppo']['state'])==len(modelkeys)
    assert set(x['obs_stats'])==set(x['reward_stats'])=={'mean','var','count'}
    assert set(x['physics'])=={'training','evaluation','torch_cpu_rng','torch_cuda_rng','numpy_rng'}
    for scope in ('training','evaluation'):
        p=x['physics'][scope]
        assert set(p)=={'qpos','qvel','ctrl','xipos','site_xpos','constraint_force','ant_x','qpos0','reset_mask','lengths','returns','overflow_seen','nonfinite_seen','rng','noise_rng','noise_factor','noise_mode','noise_scale'}
        assert p['noise_mode']=='none' and p['noise_scale']==0.
        assert all(bool(torch.isfinite(v).all()) and v.device.type=='cpu' for v in p.values() if isinstance(v,torch.Tensor))
def verify(job,train,device):
    p=Path(job['path']);assert p.parent==ROOT/'runs'
    short=job.get('short',False);budget=SHORT if short else BUDGET;clock=ledger(short)
    c=read(p/'config.json');s=read(p/'summary.json');equal(s,read(p/'status.json'))
    assert s['state']=='completed' and s['reload_check']=='passed' and c['algorithm_version']=='hopper_i1_matching_td_persistence_r1'
    m=read(ROOT/'MANIFEST.json')
    assert c['source_sha256']==m['source_hashes'] and c['versions']==m['runtime_versions'] and c['xml_sha256']==m['xml_sha256']
    assert c['determinism']==DET and c['seed']==job['seed'] and c['device']==s['device']==s['physics_device']==device
    assert c['steps']==c['effective_steps']==s['steps']==s['training_transitions']==s['total_algorithm_transitions']==budget
    assert c['i2']=={'enabled':False,'retained_rows':0,'overlap':False,'stale_correction':False,'stage_switch':False}
    for k,v in [('num_envs',1024),('rollout',64),('batch_size',1024),('epochs',10),('eval_envs',32),('eval_every',262144)]:assert c[k]==v
    assert s['optimizer_steps']=={'actor':budget//1024*10,'critic':budget//1024*10,'h':0}
    assert s['optimizer_steps_shared']==budget//1024*10
    names=[f'window_audits/update_{l["update"]:03d}.pt' for l in clock]
    state_names=[f'scientific_states/update_{l["update"]:03d}.pt' for l in clock]
    assert c['signal_files']==names
    assert {str(v.relative_to(p)) for v in (p/'window_audits').iterdir()}==set(names)
    assert {str(v.relative_to(p)) for v in (p/'scientific_states').iterdir()}==set(state_names)
    decisions=jsonl(p/'td_persistence_decisions.jsonl');progress=list(csv.DictReader((p/'progress.csv').open()))
    assert len(decisions)==len(progress)==len(clock)
    control=train.TDPersistence();history=[];values=[];separated=0;warmup_calls=0
    reports=[]
    # This fresh process has not called either ScriptFunction before window1.
    with torch.no_grad():
        for l,name,state_name,d,row in zip(clock,names,state_names,decisions,progress):
            u=l['update'];x=load(p/name);validate_inputs(x)
            for k,v in l.items():equal(x[k],v);equal(d[k],v)
            assert x['primary95_call_index']==u and x['target_device']==device
            equal(x['controller_before_step'],control.state_dict());equal(control.state_dict(),oracle(history))
            prior=control.value;delta=control.step(u)
            equal(control.state_dict(),oracle(history,before_window=True));equal(delta,control.value-prior)
            equal(x['controller_before_observe'],control.state_dict());equal(d['controller_before_observe'],control.state_dict())
            equal(x['actor_lambda'],control.value);equal(x['critic_lambda'],.95);equal(d['lambda_delta'],delta)
            xs=[x[k].to(device) for k in KEYS]
            # Strict real production timeline: one primary95 call per window, cold1/2 INCLUDED.
            a95,r95=train.gae(*xs,.99,.95)
            equal(a95.flatten().cpu(),x['fixed95_actor_advantage'],'primary_A95/'+str(u))
            equal(r95.flatten().cpu(),x['consumed_critic_return'],'primary_R95/'+str(u))
            if control.value==.95:
                a=a95;assert x['isolated_actor_warmup_calls']==0
            else:
                for _ in range(3):train.actor_gae(*xs,.99,.95)
                a,_=train.actor_gae(*xs,.99,control.value)
                warmup_calls+=3;assert x['isolated_actor_warmup_calls']==3
            equal(a.flatten().cpu(),x['actor_advantage'],'actor/'+str(u))
            metrics=train.td_persistence(*xs,0,64,.99)
            for k,v in metrics.items():equal(x[k],v);equal(d[k],v)
            oracle_signal_compare(metrics,cpu_double_signal(x))
            history.append(metrics['persistence']);control.observe(metrics['persistence'])
            equal(control.state_dict(),oracle(history));equal(d['controller_after_observe'],control.state_dict())
            assert d['optimizer_steps_shared']==u*640 and int(row['steps'])==l['steps']
            for k in ('fresh_per_world','used_per_world','retained_per_world'):assert int(row[k])==l[k]
            equal(float(row['actor_lambda']),control.value);equal(float(row['critic_lambda']),.95)
            state=load(p/state_name);scientific(state,u*640)
            equal(state['controller'],control.state_dict());equal(state['actor_lambda'],control.value)
            assert state['critic_lambda']==.95 and state['steps']==l['steps'] and state['update']==u
            effect=not torch.equal(x['actor_advantage'],x['fixed95_actor_advantage']);separated+=int(effect)
            if u<=4:assert control.value==.95 and not effect
            if short and u==5:assert control.value!=.95 and effect,'Inactive first-block adaptation: preserve failure; no retry or waiver'
            if u in (4,5,len(clock)):
                legacy=load(p/f'fixed_critic_audit_{u:03d}.pt')
                for k in (*KEYS,'actor_advantage','consumed_critic_return'):equal(legacy[k],x[k])
            values.append(control.value);reports.append({'update':u,'cold_primary_exact':u<=2,'signal':metrics,'actor_lambda':control.value,'labels_separated':effect})
    equal(load(p/'first_window_pre.pt'),load(p/'first_window_after_observers.pt'),'actual_firstwindow_observer_neutrality')
    equal(load(p/'first_window_post.pt'),load(p/state_names[0]),'post_first_window')
    saved=load(p/'latest.pt');final=load(p/'final_scientific_state.pt');scientific(final,budget//1024*10)
    adam(saved['optimizer'],budget//1024*10)
    compare_final_checkpoint_state_dicts(final,saved)
    equal(final['optimizers']['ppo'],saved['optimizer']);equal(final['controller'],saved['td_persistence_feedback']);equal(final['controller'],control.state_dict())
    equal(saved['config'],c);assert saved['actor_lambda']==control.value and saved['critic_lambda']==.95
    assert saved['optimizer_steps_shared']==budget//1024*10 and saved['source_sha256']==m['source_hashes']
    assert s['controller_observations']==len(clock) and s['pending_block_observations']==len(clock)%4
    side=read(p/'checkpoint_stress_result.json');assert side['state']=='passed' and side['training_transitions']==side['optimizer_steps']==0
    assert side['model_unchanged'] and side['normalizer_unchanged']
    auc,initial,ev=reintegrate(p,budget)
    # Validate logged FP32 primary statistics against actual arrays on the same device.
    for e in [initial,*ev]:
        returns=torch.tensor(e['returns'],dtype=torch.float32,device=device)
        equal(e['mean'],float(returns.mean()));equal(e['std'],float(returns.std(unbiased=False)))
    equal(ev[-1],{'steps':budget,**s['final_eval']})
    artifacts=[v for v in p.rglob('*') if v.is_file()]
    return {'state':'passed','seed':job['seed'],'path':str(p),'final_return':ev[-1]['mean'],'auc':auc,
      'all_window_signal_controller_actor_critic_replay':'passed','strict_primary_cold_windows1_2_exact':True,
      'first_window_observer_state_exact':True,'updates':len(clock),'primary95_replay_calls':len(clock),
      'isolated_actor_warmup_replay_calls':warmup_calls,'actual_labels_separated_windows':separated,
      'lambda_min':min(values),'lambda_max':max(values),'window_reports':reports,'stress_verified':True,
      'controller_replay':'passed','declared_native_replays':'passed','artifact_hashes':{str(v.relative_to(p)):sha(v) for v in artifacts},
      'peak_torch_memory_reserved_bytes':torch.cuda.max_memory_reserved(device),
      'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
def saved_state(train,device):
    rows=[]
    for row in read(ROOT/'COMPARISON_REFERENCE.json')['rows']:
        if row['method']!='innovation1':continue
        p=Path(row['path'])
        for u in (4,5,153):
            name=f'fixed_critic_audit_{u:03d}.pt';pin=row['artifact_hashes'][name]
            assert sha(p/name)==pin;x=load(p/name);validate_inputs(x)
            xs=[x[k].to(device) for k in KEYS]
            # Historical naturally warmed boundary labels only; no cold historical claims.
            for _ in range(3):train.gae(*xs,.99,.95)
            a95,r95=train.gae(*xs,.99,.95)
            equal(r95.cpu(),x['consumed_critic_return'].reshape(64,1024),'historical_R95')
            metrics=train.td_persistence(*xs,0,64,.99);oracle_signal_compare(metrics,cpu_double_signal(x))
            # Fixed-input actor recurrence diagnostic at the declared bounded first-step value.
            for _ in range(3):train.actor_gae(*xs,.99,.95)
            actor,_=train.actor_gae(*xs,.99,.951)
            assert bool(torch.isfinite(actor).all())
            # Independent CPU-double expanded future-TD recurrence on three complete worlds.
            from contracts import ordinary_reference
            for world in (0,511,1023):
                columns=[x[k][:,world].tolist() for k in KEYS]
                expected,_=ordinary_reference(*columns,.951)
                for t,e in enumerate(expected):assert math.isclose(float(actor[t,world]),e,rel_tol=3e-5,abs_tol=3e-5)
            assert sha(p/name)==pin
            rows.append({'seed':row['seed'],'update':u,'input_sha256':pin,**metrics})
    assert len(rows)==24
    return {'state':'passed','historical_warmed_boundaries':[4,5,153],'all24_saved_windows':True,
      'native_TD_vs_independent_CPU_double':'passed','ordinary_actor_recurrence_vs_independent_CPU_double':'passed',
      'production_cold_replay_not_claimed_by_this_check':True,'training_or_evaluation_calls':0,'rows':rows}
def pair(paths):
    a,b=map(Path,paths)
    ca,cb=read(a/'config.json'),read(b/'config.json')
    assert ca['device']==cb['device']=='cuda:0' and ca['seed']==cb['seed']==91103
    for c in (ca,cb):c.pop('out')
    equal(ca,cb)
    names={str(v.relative_to(a)) for v in a.rglob('*') if v.is_file()}
    assert names=={str(v.relative_to(b)) for v in b.rglob('*') if v.is_file()}
    for name in sorted(names):
        if name=='config.json':continue
        if name.endswith('.pt'):
            left,right=load(a/name),load(b/name)
            for value in (left,right):
                if 'config' in value:value['config'].pop('out')
            equal(left,right,name)
        elif name=='progress.csv':
            rows=[list(csv.DictReader((p/name).open())) for p in (a,b)]
            for rs in rows:
                for r in rs:
                    for k in ('elapsed_seconds','steps_per_second'):r.pop(k)
            equal(*rows,name)
        elif name in ('summary.json','status.json'):
            rows=[read(p/name) for p in (a,b)]
            for r in rows:
                for k in ('pid','elapsed_seconds','steps_per_second','eta_seconds','peak_torch_memory_reserved_bytes','peak_rss_kib','capture_seconds','serialized_output_bytes'):r.pop(k,None)
            equal(*rows,name)
        elif name=='checkpoint_stress_result.json':
            rows=[read(p/name) for p in (a,b)]
            for r in rows:
                for k in ('checkpoint_sha256','protected_training_artifacts','stress_sha256','peak_torch_memory_reserved_bytes','peak_rss_kib'):r.pop(k,None)
            equal(*rows,name)
        elif name.endswith('.json'):equal(read(a/name),read(b/name),name)
        else:assert (a/name).read_bytes()==(b/name).read_bytes(),name
    return {'state':'passed','same_seed91103_same_physical_GPU0_sequential':True,'short_windows':12,
      'all_model_Adam_normalizer_RNG_physics_labels_controller_primary_stress_arrays_exact':True,
      'all_checkpoint_tensor_and_fields_compared_not_serialized_hash_equivalence':True,
      'named_operational_exclusions':['out','pid','elapsed_seconds','steps_per_second','eta_seconds','allocator_peak','RSS_peak','capture_seconds','serialized_output_bytes','binary_file_hashes_and_artifact_paths'],
      'no_tolerance_or_retry':True}
def main():
    p=argparse.ArgumentParser();p.add_argument('--operation',choices=('protected','saved-state','verify','pair'),required=True)
    p.add_argument('--gpu',type=int,choices=(0,1),required=True);p.add_argument('--job-json',type=Path)
    p.add_argument('--paths',nargs='*');p.add_argument('--result',type=Path,required=True);a=p.parse_args()
    m=require_runtime()
    if a.operation=='protected':result=verify_historical()
    else:
        global torch
        import torch
        torch.set_num_threads(1);torch.cuda.set_device(a.gpu)
        device='cuda:'+str(a.gpu)
        if a.operation=='pair':result=pair(a.paths)
        else:
            train=api()
            result=verify(read(a.job_json),train,device) if a.operation=='verify' else saved_state(train,device)
        result.update(peak_torch_memory_reserved_bytes=torch.cuda.max_memory_reserved(a.gpu),peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    result.update(manifest_sha256=sha(ROOT/'MANIFEST.json'),operation=a.operation)
    write_new(a.result,result)
if __name__=='__main__':main()
