"""Static import-closure check; never import scientific or native source modules.

This verifies source resolution and pinned declarations only. It does not replace
the separately admitted native Torch import and actual train/stress completion.
"""
import ast
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
R1 = ROOT.parent / 'hopper_td_persistence_matching_i1_r1_8seed_20261007'
R1_MANIFEST_SHA256 = '67bb1566185ab8c3753a1692e8dd49b9d8ebb780f3bfac143bd53fdbfe15d7b8'
SCIENTIFIC_FILES = {
    'train_kl_relative.py', 'train_noisy_warp.py', 'locomotion_warp.py',
    'noisy_observation.py', 'signal_td_persistence.py',
    'lambda_td_persistence.py', 'full_capture.py',
}
IMPORT_DISTRIBUTIONS = {
    'numpy': 'numpy', 'torch': 'torch', 'gymnasium': 'gymnasium',
    'mujoco': 'mujoco', 'warp': 'warp-lang', 'mujoco_warp': 'mujoco-warp',
}
FORBIDDEN_LOADED_ROOTS = set(IMPORT_DISTRIBUTIONS) | {'scipy'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def tree(path):
    return ast.parse(path.read_text(), filename=str(path))


def dump(node):
    return ast.dump(node, include_attributes=False)


def named(module, name):
    matches = [node for node in module.body if getattr(node, 'name', None) == name]
    assert len(matches) == 1, ('expected one definition', name)
    return matches[0]


def main_guard(node):
    return isinstance(node, ast.If) and dump(node.test) == dump(
        ast.parse("__name__ == '__main__'", mode='eval').body)


class ImportScope(ast.NodeVisitor):
    """Include conditional/class import-time code; skip deferred function bodies."""
    def __init__(self):
        self.imports = []
        self.main_calls = []

    def visit_FunctionDef(self, node):
        # Defaults, annotations and decorators execute during import.
        for value in [*node.decorator_list, *node.args.defaults,
                      *[v for v in node.args.kw_defaults if v is not None]]:
            self.visit(value)
        if node.returns is not None:
            self.visit(node.returns)
        for argument in [*node.args.posonlyargs, *node.args.args,
                         *node.args.kwonlyargs, node.args.vararg, node.args.kwarg]:
            if argument is not None and argument.annotation is not None:
                self.visit(argument.annotation)

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_If(self, node):
        if main_guard(node):
            for value in node.orelse:
                self.visit(value)
        else:
            self.generic_visit(node)

    def visit_Import(self, node):
        self.imports.extend((alias.name, node.lineno) for alias in node.names)

    def visit_ImportFrom(self, node):
        assert node.level == 0 and node.module, 'unexpected relative scientific import'
        self.imports.append((node.module, node.lineno))

    def visit_Call(self, node):
        if isinstance(node.func, ast.Name) and node.func.id == 'main':
            self.main_calls.append(node.lineno)
        self.generic_visit(node)


def inventory(module, import_time_only=True):
    if import_time_only:
        visitor = ImportScope()
        visitor.visit(module)
        return visitor.imports
    result = []
    for node in ast.walk(module):
        if isinstance(node, ast.Import):
            result.extend((alias.name, node.lineno) for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            assert node.level == 0 and node.module, 'unexpected relative import'
            result.append((node.module, node.lineno))
    return result


def closure(source, entry):
    pending = [entry]
    visited, external, edges, missing = set(), set(), [], []
    while pending:
        module = pending.pop()
        if module in visited:
            continue
        visited.add(module)
        path = source / (module + '.py')
        assert path.is_file(), ('entry source missing', path)
        for imported, line in inventory(tree(path)):
            root = imported.split('.')[0]
            if root in IMPORT_DISTRIBUTIONS:
                external.add(root)
            elif root not in sys.stdlib_module_names:
                assert imported == root, ('unsupported local submodule', imported)
                edge = {'importer': module, 'module': root, 'line': line}
                edges.append(edge)
                if not (source / (root + '.py')).is_file():
                    missing.append(edge)
                else:
                    pending.append(root)
    return {'modules': sorted(visited), 'external_roots': sorted(external),
            'local_edges': edges, 'missing': missing}


def helper_selection(stress):
    run = named(stress, 'run')
    selections = [node for node in ast.walk(run) if isinstance(node, ast.Assign)
                  and any(isinstance(target, ast.Name) and target.id == 'helper'
                          for target in node.targets)]
    assert len(selections) == 1, 'stress helper must be selected once'
    value = selections[0].value
    assert isinstance(value, ast.Call) and dump(value.func) == dump(
        ast.parse('importlib.import_module', mode='eval').body)
    assert len(value.args) == 1 and not value.keywords
    assert isinstance(value.args[0], ast.Constant) and isinstance(value.args[0].value, str)
    return value.args[0].value


def main():
    assert not any(name.split('.')[0] in FORBIDDEN_LOADED_ROOTS for name in sys.modules)
    assert sha(R1 / 'MANIFEST.json') == R1_MANIFEST_SHA256
    assert (R1 / 'MANIFEST.sha256').read_text().strip() == R1_MANIFEST_SHA256
    original = read(R1 / 'MANIFEST.json')
    for member, digest in original['bundle_hashes'].items():
        path = R1 / member
        assert sha(path) == digest and not path.stat().st_mode & 0o222, member
    assert set(original['source_hashes']) == SCIENTIFIC_FILES
    source = ROOT / 'source_i1'
    assert {path.name for path in source.iterdir()} == SCIENTIFIC_FILES
    for name, digest in original['source_hashes'].items():
        assert sha(source / name) == digest
        assert (source / name).read_bytes() == (R1 / 'source_i1' / name).read_bytes()
        # No scientific dynamic imports are hidden outside the AST inventory.
        for node in ast.walk(tree(source / name)):
            if isinstance(node, ast.Call):
                assert not (isinstance(node.func, ast.Name) and node.func.id == '__import__')
                assert not (isinstance(node.func, ast.Attribute) and node.func.attr == 'import_module')

    r1_stress = tree(R1 / 'stress_checkpoint.py')
    r2_stress = tree(ROOT / 'stress_checkpoint.py')
    assert helper_selection(r1_stress) == 'train_noisy_warp'
    assert helper_selection(r2_stress) == 'train_kl_relative'
    dynamic = [node.args[0].value for node in ast.walk(r2_stress)
               if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
               and dump(node.func) == dump(ast.parse('importlib.import_module', mode='eval').body)]
    assert sorted(dynamic) == ['locomotion_warp', 'noisy_observation', 'train_kl_relative']
    run = named(r2_stress, 'run')
    helper_calls = {node.func.attr for node in ast.walk(run)
                    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                    and isinstance(node.func.value, ast.Name) and node.func.value.id == 'helper'}
    assert helper_calls == {'ActorCritic', 'RunningStats', 'evaluate'}
    trainer = tree(source / 'train_kl_relative.py')
    baseline = tree(source / 'train_noisy_warp.py')
    for name in ('ActorCritic', 'RunningStats', 'evaluate'):
        assert dump(named(trainer, name)) == dump(named(baseline, name)), name
    guards = [node for node in trainer.body if main_guard(node)]
    assert len(guards) == 1 and not guards[0].orelse
    assert [dump(node) for node in guards[0].body] == [dump(ast.parse('main()').body[0])]
    scope = ImportScope()
    scope.visit(trainer)
    assert not scope.main_calls, ('unguarded trainer main call', scope.main_calls)
    command = named(tree(ROOT / 'run_matching_i1.py'), 'command')
    command_strings = [node.value for node in ast.walk(command)
                       if isinstance(node, ast.Constant) and isinstance(node.value, str)]
    assert 'source_i1/train_kl_relative.py' in command_strings
    assert not any('train_noisy_warp' in value for value in command_strings)

    actual = closure(source, 'train_kl_relative')
    assert not actual['missing'], actual['missing']
    assert set(actual['modules']) == {name[:-3] for name in SCIENTIFIC_FILES
                                      if name != 'train_noisy_warp.py'}
    old = closure(R1 / 'source_i1', helper_selection(r1_stress))
    assert {edge['module'] for edge in old['missing']} == {'lambda_control', 'lambda_lookahead'}
    assert not (source / 'lambda_control.py').exists()
    assert not (source / 'lambda_lookahead.py').exists()

    pins = original['runtime_versions']
    assert read(R1 / 'RUNTIME_REFERENCE.json')['versions'] == pins
    assert read(ROOT / 'RUNTIME_REFERENCE.json')['versions'] == pins
    external = set()
    deferred_bundle_imports = []
    for module in actual['modules']:
        for imported, _line in inventory(tree(source / (module + '.py')), False):
            root = imported.split('.')[0]
            if root in IMPORT_DISTRIBUTIONS:
                external.add(root)
            elif root not in sys.stdlib_module_names and root not in actual['modules']:
                assert root in {'bundle_contract', 'run_matching_i1'}, ('unresolved deferred dependency', imported)
                assert (ROOT / (root + '.py')).is_file(), ('missing bundle dependency', imported)
                deferred_bundle_imports.append({'importer': module, 'module': root, 'line': _line})
    for imported, _line in inventory(r2_stress, False):
        root = imported.split('.')[0]
        if root in IMPORT_DISTRIBUTIONS:
            external.add(root)
        elif root not in sys.stdlib_module_names:
            assert root == 'bundle_contract' and (ROOT / 'bundle_contract.py').is_file(), imported
    assert {IMPORT_DISTRIBUTIONS[root] for root in external} == set(pins)
    frozen = (ROOT / 'MANIFEST.json').is_file()
    if frozen:
        current = read(ROOT / 'MANIFEST.json')
        assert current['source_hashes'] == original['source_hashes']
        assert current['runtime_versions'] == pins
        for module in actual['modules']:
            member = 'source_i1/' + module + '.py'
            path = ROOT / member
            assert current['bundle_hashes'][member] == sha(path)
            assert not path.stat().st_mode & 0o222
    assert not any(name.split('.')[0] in FORBIDDEN_LOADED_ROOTS for name in sys.modules)
    print(json.dumps({
        'state': 'passed', 'stdlib_only': True,
        'scope': 'static source resolution and pinned declarations; native import/stress pending',
        'original_manifest_sha256': R1_MANIFEST_SHA256,
        'original_frozen_bundle_members_unchanged': len(original['bundle_hashes']),
        'scientific_files_byte_identical_to_r1': len(SCIENTIFIC_FILES),
        'new_scientific_files': 0, 'stress_helper': helper_selection(r2_stress),
        'actual_trainer_import_closure': actual,
        'guarded_training_deferred_bundle_imports': deferred_bundle_imports,
        'r1_real_source_negative_control': old,
        'API_AST_equal_baseline': ['ActorCritic', 'RunningStats', 'evaluate'],
        'training_main_guard_intact': True,
        'existing_runtime_pins': {IMPORT_DISTRIBUTIONS[root]: pins[IMPORT_DISTRIBUTIONS[root]]
                                  for root in sorted(external)},
        'closure_sources_pinned_for_freeze': True,
        'current_manifest_frozen_members_checked': frozen,
        'SSH_Torch_native_GPU_service_deploy_training_evaluation_calls': 0,
    }, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
