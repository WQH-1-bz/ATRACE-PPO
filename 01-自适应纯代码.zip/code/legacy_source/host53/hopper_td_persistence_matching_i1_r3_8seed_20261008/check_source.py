"""Meaningful pure stdlib checks: source scope, scientific clocks and edge handling."""
import ast
import importlib.util
import json
import math
from pathlib import Path
import sys
from contracts import ledger,evaluation_grid,BUDGET,SHORT,ordinary_reference
ROOT=Path(__file__).resolve().parent
BACK=ROOT.parent/'hopper_centered_ncs2_i1_scheduler_r2_8seed_20261006'
FULL=ROOT.parent/'hopper_full_practical_adjustment_r2_8seed_20261007'
def module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def dump(node):return ast.dump(node,include_attributes=False)
def named(tree,name):return next(n for n in tree.body if getattr(n,'name',None)==name)
def main():
    files=list(ROOT.glob('*.py'))+list((ROOT/'source_i1').glob('*.py'))
    for p in files:compile(p.read_text(),str(p),'exec')
    new=ast.parse((ROOT/'source_i1/train_kl_relative.py').read_text());old=ast.parse((BACK/'source_i1/train_kl_relative.py').read_text());full=ast.parse((FULL/'source_full/train_kl_relative.py').read_text())
    for name in ('ActorCritic','RunningStats','gae','evaluate'):
        assert dump(named(new,name))==dump(named(old,name)),name
    assert dump(named(new,'gae'))==dump(named(full,'gae'))
    primary=named(new,'gae');actor=named(new,'actor_gae');actor.name='gae'
    assert dump(primary)==dump(actor)
    oldloop=next(n for n in ast.walk(old) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='epoch')
    newloop=next(n for n in ast.walk(new) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='epoch')
    assert dump(oldloop)==dump(newloop),'PPO/minibatch permutation/shared Adam/joint clip body changed'
    oldcollect=next(n for n in ast.walk(old) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='t' and any(isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr=='step' for x in ast.walk(n)))
    newcollect=next(n for n in ast.walk(new) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='t' and any(isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr=='step' for x in ast.walk(n)))
    assert [dump(x) for x in oldcollect.body]==[dump(x) for x in newcollect.body]
    for name in ('locomotion_warp.py','noisy_observation.py','train_noisy_warp.py'):assert (ROOT/'source_i1'/name).read_bytes()==(BACK/'source_i1'/name).read_bytes()
    for name in ('signal_td_persistence.py','lambda_td_persistence.py'):assert (ROOT/'source_i1'/name).read_bytes()==(FULL/'source_full'/name).read_bytes()
    text=(ROOT/'source_i1/train_kl_relative.py').read_text()
    for forbidden in ('gae_signal','normalized_credit_sensitivity','signal_a90','signal_a99','filled','raw_rhos','capped_cs','split_tail_trace','stage_switch_steps'):
        assert forbidden not in text,forbidden
    mainnode=named(new,'main')
    primarycalls=[n for n in ast.walk(mainnode) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='gae']
    assert len(primarycalls)==1 and [dump(a) for a in primarycalls[0].args[-2:]]==[dump(ast.Constant(.99)),dump(ast.Constant(.95))]
    assert text.index('delta=feedback.step(update)')<text.index('for t in range(0, end)')<text.index('fixed95_actor_advantage,returns=gae')<text.index('signal_metrics=td_persistence')<text.index('for epoch in range(args.epochs)')<text.index("feedback.observe(signal_metrics['persistence'])")
    assert 'if actor_lambda_used==.95:\n                        advantages=fixed95_actor_advantage' in text
    assert 'else:\n                        for _ in range(3):actor_gae(*xs,.99,.95)' in text
    assert len(ledger())==153 and len(ledger(True))==12 and len(evaluation_grid())==39 and len(evaluation_grid(True))==3
    assert BUDGET==153*1024*64 and SHORT==12*1024*64
    c=module(ROOT/'source_i1/lambda_td_persistence.py','checked_controller');s=module(ROOT/'source_i1/signal_td_persistence.py','checked_signal');o=module(ROOT/'controller_oracle.py','checked_oracle')
    histories=[([.4]*153),([-1.]*153),([0.]*153),([math.sin(i) for i in range(153)])]
    for history in histories:
        control=c.TDPersistence();seen=[]
        for u,p in enumerate(history,1):
            assert control.state_dict()==o.replay(seen)
            previous=control.value;delta=control.step(u)
            assert control.state_dict()==o.replay(seen,before_window=True)
            assert abs(delta)<=.001000000000001
            if u<=4:assert control.value==.95
            control.observe(p);seen.append(p);assert control.state_dict()==o.replay(seen)
        assert control.observations==153 and control.observations%4==1
    for invalid in (float('nan'),float('inf'),-1.1,1.1):
        try:c.TDPersistence().observe(invalid)
        except ValueError:pass
        else:raise AssertionError('Invalid signal accepted')
    for count in (0,1):assert s.persistence_from_moments(count,0.,0.,1.,1.,1.)['persistence']==0.
    assert s.persistence_from_moments(3,0.,0.,0.,1.,0.)['persistence']==0.
    assert s.persistence_from_moments(3,0.,0.,1.,1.,-.5)['persistence']==-.5
    for args in ((-1,0.,0.,1.,1.,0.),(2,0.,0.,-1.,1.,0.),(2,0.,0.,1.,1.,float('nan'))):
        try:s.persistence_from_moments(*args)
        except ValueError:pass
        else:raise AssertionError('Invalid moments accepted')
    a,r=ordinary_reference([1,2,3],[.2,.3,.4],[.3,.4,.5],[False,True,False],[False,True,False],.95)
    assert a[1]==2-.3 and math.isclose(a[0],1+.99*.3-.2+.99*.95*a[1]) and r[2]==a[2]+.4
    assert not any(n.split('.')[0] in ('torch','numpy','warp','mujoco','gymnasium') for n in sys.modules)
    print(json.dumps({'state':'passed','stdlib_only':True,'compiled_python_sources':len(files),
      'exact_backbone_model_normalizer_evaluate_GAE_AST':True,'exact_collection_and_PPO_AST':True,
      'copied_signal_controller_byte_identical':True,'no_I2_or_NCS_path':True,'primary95_once_no_startup_warmup':True,
      'isolated_actor_warmup_only_if_adaptive':True,'independent_scalar_controller_4x153_windows':True,
      'invalid_and_neutral_moment_handling':True,'formal_updates':153,'formal_shared_Adam':97920,
      'short_updates':12,'short_shared_Adam':7680,'native_actions':0},indent=2))
if __name__=='__main__':main()
