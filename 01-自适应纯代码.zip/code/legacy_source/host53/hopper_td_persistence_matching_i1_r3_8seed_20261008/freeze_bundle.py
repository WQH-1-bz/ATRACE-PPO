"""Fresh execution-only r3 freeze; pure stdlib; preserve exact r1/r2 and all science."""
import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parent
R2=ROOT.parent/'hopper_td_persistence_matching_i1_r2_8seed_20261007'
PARENT=ROOT.parent/'practical_two_env_parent_20261007/hopper_matching_i1_r2'
R2_SHA='c1ce43849b7cf18501b98266d67f5daefe96170b9c338ab327f785f68a54bcbe'
FAILURE_SHA='375cc5e956ceb347fcd68cd081709330f269ba3913838ec3f75e62bbbd638be3'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(name,x):
    with (ROOT/name).open('x') as f:f.write(json.dumps(x,indent=2,sort_keys=True,allow_nan=False)+'\n')
def main():
    assert not (ROOT/'MANIFEST.json').exists()
    assert sha(R2/'MANIFEST.json')==R2_SHA
    old=read(R2/'MANIFEST.json');original_members={}
    for name,digest in old['bundle_hashes'].items():
        p=R2/name;assert sha(p)==digest and not p.stat().st_mode&0o222;original_members[name]=digest
    for name in ('MANIFEST.json','MANIFEST.sha256'):original_members[name]=sha(R2/name)
    assert len(original_members)==58
    source={p.name:sha(p) for p in sorted((ROOT/'source_i1').iterdir()) if p.is_file()}
    assert source==old['source_hashes'] and len(source)==7
    assert sha(ROOT/'R2_FAILURE_NATIVE.json')==sha(PARENT/'FAILURE_NATIVE.json')==FAILURE_SHA
    failure=read(ROOT/'R2_FAILURE_NATIVE.json');capture=read(ROOT/'R2_FAILURE_CAPTURE_EXECUTION.json');verified=read(ROOT/'R2_PARENT_FAILURE_VERIFICATION.json')
    assert capture['actual_exit']==0 and capture['actual_ssh_pid']==3608247 and capture['stdout_sha256']==FAILURE_SHA
    assert verified['state']=='R2_failure_root_verified_narrow_mapping_repair_preparation_authorized' and verified['actual_ssh_exit']==0
    assert not verified['short_B_started'] and not verified['formal_training_started']
    assert verified['training_pid']==1770407 and verified['training_exit']==0
    assert verified['stress_pid']==1790948 and verified['stress_exit']==0
    assert verified['failed_verify_pid']==1795601 and verified['failed_verify_exit']==1
    assert failure['native_manifest_sha256']==R2_SHA
    native='/ssd_2/wch/'+R2.name
    pins={native+'/'+name:digest for name,digest in original_members.items()}
    for name,digest in failure['original_A_artifact_hashes'].items():pins[native+'/runs/short_A/'+name]=digest
    assert len(failure['original_A_artifact_hashes'])==42
    for name,entry in failure['native_records'].items():
        if native+'/'+name in pins:assert pins[native+'/'+name]==entry['sha256']
        pins[native+'/'+name]=entry['sha256']
    write('R2_PRESERVATION_PINS.json',pins)
    repair={'state':'source_only_execution_state_dict_representation_repair','execution_version':'r3',
      'scientific_algorithm_version_unchanged':old['algorithm_version'],'scientific_files_byte_identical_to_r2':7,
      'scientific_changes':0,'corrected_stress_helper_byte_identical_to_r2':True,
      'generic_equal_AST_unchanged':True,'exact_named_boundaries':['model','obs_stats','reward_stats'],
      'required_snapshot_type':'dict','required_checkpoint_type':'collections.OrderedDict',
      'model_ordered_keys':['log_std']+[f'{net}.{layer}.{part}' for net in ('actor','critic') for layer in (0,2,4) for part in ('weight','bias')],
      'normalizer_ordered_keys':['mean','var','count'],'numeric_tolerance_or_general_mapping_conversion':False,
      'preserved_r2_manifest_sha256':R2_SHA,'root_actual_failure_capture_sha256':FAILURE_SHA,
      'root_actual_failure_capture_PID':3608247,'root_actual_failure_capture_exit':0,
      'preserved_completed_r2_short_A_training_PID':1770407,'preserved_completed_r2_stress_PID':1790948,
      'preserved_failed_r2_verify_PID':1795601,'preserved_failed_r2_verify_exit':1,'numerical_verdict_inferred_from_failure':False,
      'preserved_r2_source_members':58,'preserved_r2_A_artifacts':42,'preserved_r1_extra_pins':96,
      'new_r3_engineering_shorts':2,'new_r3_short_pair_transitions':1572864,
      'earlier_r1_r2_short_A_transitions':1572864,'total_matching_I1_engineering_transitions_if_pair_completes':3145728,
      'engineering_scores_excluded_from_formal':True,'old_namespace_restart_or_silent_retry':False,
      'native_r3_checks_pending_independent_review_and_NEW_ACTIVE_Luna':True,'builder_native_actions':0}
    write('EXECUTION_REPAIR.json',repair)
    write('SOURCE_PROVENANCE.json',{'state':'execution_only_r3','original_r2_manifest_sha256':R2_SHA,
      'scientific_files_byte_identical_to_r2':7,'changed_scientific_files':[],'actual_source_hashes':source,
      'corrected_stress_helper_byte_identical_to_r2':True,
      'actual_replay_change':'exact three named final-checkpoint state_dict representation boundaries; generic equal unchanged',
      'namespace_unit_runtime_and_protection_changes_only_otherwise':True,
      'accepted_backbone_manifest_sha256':old['original_backbone_manifest_sha256'],
      'immutable_Full_manifest_sha256':old['original_Full_manifest_sha256'],'native_actions':0})
    diff=[]
    for name in ('replay_helper.py','bundle_contract.py','RUNTIME_REFERENCE.json'):
        diff.extend(difflib.unified_diff((R2/name).read_text().splitlines(True),(ROOT/name).read_text().splitlines(True),fromfile=str(R2/name),tofile=str(ROOT/name)))
    for p in sorted(ROOT.glob('*.service')):
        previous=R2/p.name.replace('-r3-','-r2-').replace('20261008','20261007')
        diff.extend(difflib.unified_diff(previous.read_text().splitlines(True),p.read_text().splitlines(True),fromfile=str(previous),tofile=str(p)))
    (ROOT/'SOURCE_DIFF.patch').write_text(''.join(diff))
    receipts=[]
    for file in ('build_sources.py','check_source.py','check_scheduler.py','check_import_closure.py','check_state_dict_boundary.py'):
        argv=[sys.executable,str(ROOT/file)];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
        child=subprocess.Popen(argv,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        stdout,stderr=child.communicate();label=file.removesuffix('.py')
        (ROOT/(label+'.stdout.json')).write_text(stdout);(ROOT/(label+'.stderr.log')).write_text(stderr)
        receipts.append({'command':argv,'actual_local_child_pid':child.pid,'actual_exit_code':child.returncode,
          'started_UTC':started,'completed_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'stdout_sha256':sha(ROOT/(label+'.stdout.json')),'stderr_sha256':sha(ROOT/(label+'.stderr.log')),
          'stdlib_only':True,'SSH_Torch_native_GPU_deploy_service_training_evaluation_calls':0})
        assert child.returncode==0,(file,stdout,stderr)
    write('CHECK_EXECUTIONS.json',receipts)
    assert all(sha(R2/name)==digest for name,digest in original_members.items())
    write('PRESERVATION_CHECK.json',{'state':'passed','all58_frozen_r2_source_members_unchanged':True,
      'all7_scientific_files_and_corrected_stress_byte_identical_to_r2':True,
      'original_r2_native_pins_from_actual_exit0_root_capture':len(pins),'original_r2_A_artifact_pins':42,
      'inherited_r1_additional_pins':96,'all88_plus8_Full_comparator_rows':96,
      'failed_native_units_and_old_artifact_checks_pending_root_native_protection':True,'native_actions':0})
    members={str(p.relative_to(ROOT)):sha(p) for p in sorted(ROOT.rglob('*')) if p.is_file()}
    m={k:v for k,v in old.items() if k not in ('bundle_hashes','native_root','native_actions_performed')}
    m.update(native_root='/ssd_2/wch/'+ROOT.name,bundle_hashes=members,source_hashes=source,
      execution_version='r3_final_checkpoint_state_dict_representation_repair',
      scientific_source_identity_r2_manifest_sha256=R2_SHA,
      original_rejected_in_native_r2_manifest_sha256=R2_SHA,original_r2_source_members=58,
      original_r2_A_artifact_pins=42,root_actual_r2_failure_capture_sha256=FAILURE_SHA,
      corrected_stress_helper_unchanged_from_r2=True,generic_equal_AST_unchanged=True,
      exact_final_state_dict_representation_boundaries=['model','obs_stats','reward_stats'],
      new_r3_short_pair_transitions=1572864,earlier_r1_r2_engineering_transitions=1572864,
      total_matching_I1_engineering_transitions_after_new_r3_pair=3145728,
      native_actions_performed=0,source_import_closure_statically_verified=True,
      actual_r3_Torch_stress_short_saved_replay_checks='pending native independent root admission')
    m.pop('actual_r2_Torch_import_stress_short_saved_checks',None)
    write('MANIFEST.json',m);(ROOT/'MANIFEST.sha256').write_text(sha(ROOT/'MANIFEST.json')+'\n')
    for p in ROOT.rglob('*'):
        if p.is_file():p.chmod(0o444)
    print(json.dumps({'state':'READY_source_only','execution_version':m['execution_version'],
      'manifest_sha256':sha(ROOT/'MANIFEST.json'),'members':len(members),'scientific_byte_identical_files':7,
      'actual_stdlib_check_exits':[r['actual_exit_code'] for r in receipts],'native_actions':0,
      'total_bundle_bytes':sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())},indent=2))
if __name__=='__main__':main()
