"""Stdlib async coordinator; root admits native saved/short and formal separately."""
import argparse
import importlib.abc
import math
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
from bundle_contract import ROOT,PYTHON,DISK_FLOOR,read,write,write_new,sha,child_env,check_manifest,require_runtime,gpu_snapshot
from contracts import BUDGET,SHORT,SEEDS
class NoScientificImports(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in ('torch','warp','mujoco','mujoco_warp','numpy','scipy','gymnasium'):raise ImportError('Scientific import forbidden in coordinator: '+fullname)
def reap_all(active):
    finished=[]
    for ident,value in list(active.items()):
        code=value['process'].poll()
        if code is not None:value['returncode']=code;finished.append((ident,value))
    for ident,value in finished:value['stream'].close();del active[ident]
    return finished
def drain_completions(active,finished,failed):
    completions=reap_all(active)
    for ident,value in completions:
        try:finished(ident,value)
        except BaseException as exc:failed(ident,value,exc,traceback.format_exc())
    return len(completions)
def admission_snapshot(drain,has_failure,snapshot,capacity,current=None):
    changed=drain()
    if has_failure():return None
    if current is None or changed:
        while True:
            current=snapshot();changed=drain()
            if has_failure():return None
            if not changed:break
    return current if capacity(current) else None
def reservation_for_peak(peak):return max(3500,math.ceil(peak)+256)
def fits(snapshot,active,reservation,cpu_reservation,disk_reservation,gpu):
    workers=[v for v in active.values() if v['job']['gpu']==gpu]
    memory=snapshot['process_mib'][gpu]
    initializing=sum(max(0,max(reservation,v['reservation'])-memory.get(v['process'].pid,0)) for v in workers)
    cpu_initializing=sum(max(0,v['cpu_reservation']-v['rss_bytes']) for v in active.values())
    pending_disk=sum(v['disk_reservation'] for v in active.values())
    return (len(workers)<4 and snapshot['cards'][gpu]['free_mib']-initializing>=reservation+512
      and snapshot['cpu_available_bytes']-cpu_initializing>=cpu_reservation+2*1024**3
      and snapshot['disk_free_bytes']>=DISK_FLOOR+pending_disk+disk_reservation)
def check_deadline(deadline,now):
    if now>=deadline:raise TimeoutError('Elapsed admission deadline expired BEFORE Popen; no dispatch/retry')
def command(job):
    assert job['gpu'] in (0,1)
    return [str(PYTHON),str(ROOT/'source_i1/train_kl_relative.py'),'--out',job['path'],
      '--seed',str(job['seed']),'--device','cuda:'+str(job['gpu']),'--steps',str(SHORT if job['short'] else BUDGET)]
def new_job(ident,seed,gpu,short=False):
    return {'id':ident,'seed':seed,'gpu':gpu,'short':short,'path':str(ROOT/'runs'/ident),'state':'training_pending','process_history':[]}
def plan(short=False):
    return [new_job('short_'+x,91103,0,True) for x in ('A','B')] if short else [new_job('Hopper__matching_TDp_I1__seed'+str(s),s,(s-21)%2) for s in SEEDS]
def formal_admission():
    admission=read(ROOT/'PARENT_SHORT_ADMISSION.json');resources=read(ROOT/'PARENT_RESOURCE_ADMISSION.json')
    prior=read(ROOT/'SHORT_STAGE_STATUS.json');gate=read(ROOT/'SHORT_VERIFIED.json');monitor=read(ROOT/'LUNA_MONITOR_ACTIVE.json')
    digest=sha(ROOT/'MANIFEST.json')
    assert admission['state']=='passed' and admission['manifest_sha256']==digest and admission['independent_actual_saved_strict_short_pass_verified']
    assert admission['short_verified_sha256']==sha(ROOT/'SHORT_VERIFIED.json')
    assert admission['resource_admission_sha256']==sha(ROOT/'PARENT_RESOURCE_ADMISSION.json')
    assert resources['state']=='passed' and resources['manifest_sha256']==digest and resources['measured_trainer_AND_helper_peaks_used']
    assert resources['gpu_reservation_mib']>=gate['gpu_reservation_mib'] and resources['cpu_reservation_bytes']>=gate['cpu_reservation_bytes']
    assert resources['per_formal_job_disk_reservation_bytes']>=gate['per_formal_job_disk_reservation_bytes']
    assert gate['strict_primary_cold_windows1_2_exact'] and gate['first4_actor95'] and gate['actual_u5_adaptation_and_target_separation_verified']
    assert prior['state']=='short_completed_awaiting_root_formal_admission' and prior['formal_training_started_count']==0 and not prior['active'] and not prior['failures']
    assert monitor['fresh_stage']=='formal_training' and monitor['goal_id']!=gate['short_monitor_goal_id']
    assert all(j['state']=='completed' for j in prior['short_jobs'])
    assert all(j['state']=='completed' for j in prior['short_checks'])
    return prior,gate,resources
def main():
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=('short','formal'),required=True);a=p.parse_args()
    sys.meta_path.insert(0,NoScientificImports());require_runtime();m=check_manifest()
    assert not any(n.split('.')[0] in ('torch','warp','numpy','mujoco','scipy') for n in sys.modules)
    assert not (ROOT/(a.stage.upper()+'_STAGE_STARTED.json')).exists(),'No stage restart or silent retry'
    jobs=plan();shorts=plan(True)
    checks=[dict(id=name,gpu=0,state=op+'_pending',operation=op,process_history=[]) for name,op in
      [('protected_before','protected'),('saved24','saved-state'),('pair','pair'),('protected_after','protected')]]
    terminal=dict(id='protected_terminal',gpu=0,state='protected_pending',operation='protected',process_history=[])
    active={};failures=[];latest=None;start=time.monotonic();gpu_reservation=6506;cpu_reservation=8*1024**3;disk_reservation=1024**3
    all_peak=all_rss=0;gate=None
    if a.stage=='formal':
        previous,gate,resources=formal_admission();shorts=previous['short_jobs'];checks=previous['short_checks']
        gpu_reservation=resources['gpu_reservation_mib'];cpu_reservation=resources['cpu_reservation_bytes'];disk_reservation=resources['per_formal_job_disk_reservation_bytes']
    else:assert read(ROOT/'LUNA_MONITOR_ACTIVE.json')['fresh_stage']=='matching_i1_saved_strict_short'
    assert all(not Path(j['path']).exists() for j in (shorts if a.stage=='short' else jobs))
    write_new(ROOT/(a.stage.upper()+'_STAGE_STARTED.json'),{'manifest_sha256':sha(ROOT/'MANIFEST.json'),'stage':a.stage,'monitor_goal_id':read(ROOT/'LUNA_MONITOR_ACTIVE.json')['goal_id'],'all8_one_configuration':True})
    def status(state):
        write(ROOT/'suite_status.json',{'state':state,'stage':a.stage,'jobs':jobs,'short_jobs':shorts,'short_checks':checks,
          'terminal_protection':terminal,'completed_count':sum(j['state']=='completed' for j in jobs),
          'formal_training_started_count':sum('training_pid' in j for j in jobs),'active':{k:{'pid':v['process'].pid,'gpu':v['job']['gpu'],'stage':v['stage'],'command':v['command'],'sampled_peak_mib':v['peak'],'sampled_peak_rss_bytes':v['peak_rss']} for k,v in active.items()},
          'failures':failures,'elapsed_seconds':time.monotonic()-start,'gpu_reservation_mib':gpu_reservation,
          'cpu_reservation_bytes':cpu_reservation,'per_job_disk_reservation_bytes':disk_reservation,
          'all_child_peak_mib':all_peak,'all_child_peak_rss_bytes':all_rss,'latest_snapshot':latest,
          'initial_reservations_are_conservative_bounds_not_native_profiles':True,'initializing_workers_charged':True,
          'headroom_mib':512,'max_per_gpu':4,'coordinator_cuda_imported':False,'automatic_retry':False})
    def failed(ident,value,exc,tb):
        value['job']['state']='failed';failures.append({'id':ident,'stage':value['stage'],'returncode':value['returncode'],'error':repr(exc),'traceback':tb})
    def finished(ident,value):
        nonlocal all_peak,all_rss
        j=value['job'];stage=value['stage'];code=value['returncode'];data=None
        if stage=='training':
            if code==0:data=read(Path(j['path'])/'summary.json')
        elif stage=='stress':
            if code==0:data=read(Path(j['path'])/'checkpoint_stress_result.json')
        elif value['result'].exists():data=read(value['result'])
        allocator=(data or {}).get('peak_torch_memory_reserved_bytes',0)/1024**2
        peak=max(value['peak'],allocator);rss=max(value['peak_rss'],(data or {}).get('peak_rss_kib',0)*1024)
        receipt={'stage':stage,'pid':value['process'].pid,'gpu':j['gpu'],'command':value['command'],'returncode':code,
          'sampled_physical_peak_mib':value['peak'],'reported_allocator_peak_mib':allocator,'reservation_peak_mib':peak,
          'peak_rss_bytes':rss,'manifest_sha256':sha(ROOT/'MANIFEST.json'),
          'result_sha256':sha(value['result']) if value['result'].exists() else None,'automatic_retry':False}
        j['process_history'].append(receipt);write_new(ROOT/'results'/(ident+'__'+stage+'__exit.json'),receipt)
        assert code==0 and data is not None,(ident,stage,code)
        assert data['state'] in ('completed','passed')
        all_peak=max(all_peak,peak);all_rss=max(all_rss,rss)
        if stage=='training':j['state']='stress_pending'
        elif stage=='stress':j['state']='verify_pending'
        else:j['state']='completed';j['metrics']=data
    def drain():return drain_completions(active,finished,failed)
    def spawn(job,stage):
        nonlocal latest
        timeout=1800 if stage=='training' else 300
        deadline=job.setdefault('admission_deadline_'+stage,time.monotonic()+timeout)
        if failures:return False
        result=ROOT/'results'/(job['id']+'__'+stage+'.json')
        assert not result.exists()
        input_file=None
        if stage=='training':argv=command(job)
        elif stage=='stress':argv=[str(PYTHON),str(ROOT/'stress_checkpoint.py'),'--job-path',job['path'],'--device','cuda:'+str(job['gpu'])]
        else:
            argv=[str(PYTHON),str(ROOT/'replay_helper.py'),'--operation',stage,'--gpu',str(job['gpu']),'--result',str(result)]
            if stage=='verify':input_file=ROOT/'results'/(job['id']+'__verify_input.json');argv+=['--job-json',str(input_file)]
            elif stage=='pair':argv+=['--paths',*[j['path'] for j in shorts]]
        while True:
            check_deadline(deadline,time.monotonic())
            latest=admission_snapshot(drain,lambda:bool(failures),gpu_snapshot,lambda s:fits(s,active,gpu_reservation,cpu_reservation,disk_reservation,job['gpu']))
            # Capacity becoming available at/after deadline MUST NOT dispatch a child.
            check_deadline(deadline,time.monotonic())
            if latest is None:return False
            changed=drain()
            if failures:return False
            if changed:continue
            check_deadline(deadline,time.monotonic())
            if input_file is not None:write_new(input_file,job)
            stream=(ROOT/'logs'/(job['id']+'__'+stage+'.log')).open('x')
            try:
                check_deadline(deadline,time.monotonic())
                process=subprocess.Popen(argv,cwd=ROOT,env=child_env(),stdout=stream,stderr=subprocess.STDOUT)
            except BaseException as exc:
                stream.close();write_new(ROOT/'results'/(job['id']+'__'+stage+'__launch_failure.json'),
                  {'state':'actual_launch_exception_no_child','command':argv,'error':repr(exc),'child_pid':None,'child_returncode':None,'automatic_retry':False});raise
            break
        active[job['id']]={'process':process,'stream':stream,'job':job,'stage':stage,'result':result,'command':argv,
          'peak':0,'rss_bytes':0,'peak_rss':0,'reservation':gpu_reservation,'cpu_reservation':cpu_reservation,'disk_reservation':disk_reservation}
        job.update(state=stage+'_running',pid=process.pid)
        if stage=='training':job['training_pid']=process.pid
        return True
    try:
        while True:
            drain();latest=gpu_snapshot();drain()
            for v in active.values():
                v['peak']=max(v['peak'],latest['process_mib'][v['job']['gpu']].get(v['process'].pid,0))
                path=Path('/proc')/str(v['process'].pid)/'status'
                try:
                    line=next(x for x in path.read_text().splitlines() if x.startswith('VmRSS:'))
                    v['rss_bytes']=int(line.split()[1])*1024;v['peak_rss']=max(v['peak_rss'],v['rss_bytes'])
                except (FileNotFoundError,StopIteration,ProcessLookupError):pass
            if failures:
                status('failed_active_workers_preserved' if active else 'failed')
                if not active:return 1
            elif a.stage=='short':
                if not active:
                    if checks[0]['state']!='completed':spawn(checks[0],'protected')
                    elif checks[1]['state']!='completed':spawn(checks[1],'saved-state')
                    else:
                        pending=next((j for j in shorts if j['state']!='completed'),None)
                        if pending:spawn(pending,pending['state'].removesuffix('_pending'))
                        elif checks[2]['state']!='completed':spawn(checks[2],'pair')
                        elif checks[3]['state']!='completed':spawn(checks[3],'protected')
                        else:
                            check_manifest()
                            disk_peak=max(read(Path(j['path'])/'summary.json')['serialized_output_bytes'] for j in shorts)
                            # Transparent extrapolation from measured short serialized bytes, not profiling fiction.
                            gate={'state':'passed','manifest_sha256':sha(ROOT/'MANIFEST.json'),'short_pair_transitions':2*SHORT,
                              'saved24_result_sha256':sha(ROOT/'results/saved24__saved-state.json'),
                              'strict_primary_cold_windows1_2_exact':True,'first4_actor95':True,
                              'actual_u5_adaptation_and_target_separation_verified':True,'all12_window_full_label_controller_replay':True,
                              'pair_result_sha256':sha(ROOT/'results/pair__pair.json'),'same_physical_GPU0_sequential':True,
                              'gpu_reservation_mib':reservation_for_peak(all_peak),'cpu_reservation_bytes':max(1024**3,math.ceil(all_rss*1.25)),
                              'per_formal_job_disk_reservation_bytes':math.ceil(disk_peak*153/12*1.25),
                              'measured_all_trainer_AND_helper_peak_mib':all_peak,'measured_all_child_peak_rss_bytes':all_rss,
                              'measured_short_output_bytes':disk_peak,'disk_forecast_rule':'short measured bytes *153/12 *1.25',
                              'short_monitor_goal_id':read(ROOT/'LUNA_MONITOR_ACTIVE.json')['goal_id'],'formal_training_started_count':0}
                            write_new(ROOT/'SHORT_VERIFIED.json',gate);status('short_completed_awaiting_root_formal_admission')
                            write_new(ROOT/'SHORT_STAGE_STATUS.json',read(ROOT/'suite_status.json'));return 0
                status('short_running' if active else 'short_waiting_for_resource_admission')
            elif all(j['state']=='completed' for j in jobs):
                if not active and terminal['state']!='completed':spawn(terminal,'protected')
                elif terminal['state']=='completed':
                    from analysis_matching import analyze
                    write_new(ROOT/'ANALYSIS.json',analyze(jobs));status('completed');return 0
            else:
                for j in jobs:
                    if j['id'] in active or j['state']=='completed':continue
                    spawn(j,j['state'].removesuffix('_pending'))
                    if failures:break
                status('formal_running' if active else 'formal_waiting_for_resource_admission')
            time.sleep(2)
    except BaseException as exc:
        failures.append({'id':'coordinator','error':repr(exc),'traceback':traceback.format_exc()})
        status('failed_active_workers_preserved' if active else 'failed');raise
if __name__=='__main__':sys.exit(main())
