"""Root invokes only after exact review and NEW actual ACTIVE Luna admission."""
import sys
import importlib.metadata
from bundle_contract import ROOT,require_review,sha,write_new,verify_historical
def main():
    m=require_review();proof=verify_historical()
    xml=importlib.metadata.distribution('gymnasium').locate_file('gymnasium/envs/mujoco/assets/hopper.xml')
    assert sha(xml)==m['xml_sha256']
    for sub in ('runs','results','logs'):(ROOT/sub).mkdir(exist_ok=False)
    write_new(ROOT/'PARENT_NATIVE_BINDINGS.json',{'state':'verified','manifest_sha256':sha(ROOT/'MANIFEST.json'),
        'source_hashes':m['source_hashes'],'actual_interpreter':sys.executable,'protected':proof,
        'actual_XML_path':str(xml),'actual_XML_sha256':sha(xml),
        'scientific_imports':0,'new_training_or_evaluation':0})
if __name__=='__main__':main()
