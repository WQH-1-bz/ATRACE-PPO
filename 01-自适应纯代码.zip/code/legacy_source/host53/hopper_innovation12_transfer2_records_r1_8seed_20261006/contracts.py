"""Prospective shared schedules and independent stdlib numerical fixtures."""
import math
BUDGET,SHORT,SWITCH,SHORT_SWITCH=10027008,524288,4980736,262144
SEEDS=tuple(range(21,29))
ARMS=('innovation1','innovation2')
METHODS=('fixed90','fixed95','fixed99','linear','critic_aware','gradient_ppo','reward_profiling','pae')
DET={'torch':True,'warp':'run_to_run','warp_max_records':8,'cublas_workspace_config':':4096:8'}
CONFIG_TELEMETRY=('device','physics_device','out','pid','elapsed_seconds','steps_per_second','eta_seconds','peak_torch_memory_bytes')
PROGRESS_TELEMETRY=('elapsed_seconds','steps_per_second')
def ledger(arm,short=False):
    budget,switch=(SHORT,SHORT_SWITCH) if short else (BUDGET,SWITCH)
    rows=[];steps=trained=retained=0
    while steps<budget:
        early=arm=='innovation2' and steps<switch
        fresh=min(64-retained,(budget-steps)//1024)
        if early:fresh=min(fresh,(switch-steps)//1024)
        end=retained+fresh;next_steps=steps+fresh*1024;flush=early and next_steps==switch
        used=end if flush or not early or next_steps==budget else min(56,end)
        rows.append({'update':len(rows)+1,'prior_collected_steps':steps,'steps':next_steps,'incoming_retained_per_world':retained,'fresh_per_world':fresh,'end_per_world':end,'used_per_world':used,'retained_out_per_world':end-used,'early':early,'stage_boundary_flush':flush})
        retained=end-used;steps=next_steps;trained+=used*1024
    assert steps==trained==budget and retained==0
    assert len(rows)==((8 if short else 153) if arm=='innovation1' else (9 if short else 164))
    assert sum(r['used_per_world']*1024//1024*10 for r in rows)==budget//1024*10
    return rows
def sensitivity(a,b):
    assert len(a)==len(b)>1 and all(math.isfinite(x) for x in [*a,*b])
    def normalize(xs):
        mean=sum(xs)/len(xs);var=sum((x-mean)**2 for x in xs)/len(xs)
        assert math.isfinite(var) and var>0
        return [(x-mean)/math.sqrt(var) for x in xs]
    x,y=normalize(a),normalize(b)
    return min(1.,max(0.,.5*math.sqrt(sum((p-q)**2 for p,q in zip(x,y))/len(x))))
def expanded_trace(reward,value,next_value,terminated,done,rho,cap,lam):
    n=len(reward);assert all(len(x)==n for x in (value,next_value,terminated,done,rho,cap))
    assert all(not term or final for term,final in zip(terminated,done))
    delta=[reward[i]+.99*(not terminated[i])*next_value[i]-value[i] for i in range(n)]
    trace=[];actor=[]
    for i in range(n):
        total=0.;weight=1.
        for j in range(i,n):
            total+=weight*rho[j]*delta[j]
            weight*=cap[j]*.99*lam*(not done[j])
        trace.append(total)
    for i in range(n):actor.append(delta[i]+.99*lam*(not done[i])*(trace[i+1] if i+1<n else 0.))
    return actor,[v+d for v,d in zip(value,trace)]
