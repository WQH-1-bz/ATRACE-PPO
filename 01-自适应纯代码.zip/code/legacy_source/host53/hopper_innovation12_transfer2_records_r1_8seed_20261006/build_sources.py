"""Source-only isolated Hopper port; standard library only, no native action."""
import ast, copy, difflib, hashlib, json, shutil, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
WORK=ROOT.parents[1]
ORIGIN=WORK/'runs/swimmer_innovation12_transfer1_8seed_20261005'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,text):
    path=ROOT/name;assert not path.exists(),path;path.write_text(text)
def extract(path,names):
    text=path.read_text();nodes={n.name:n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
    return '\n\n'.join(ast.get_source_segment(text,nodes[name]) for name in names)+'\n'
def main():
    assert not any(n in sys.modules for n in ('torch','warp','mujoco'))
    original={};actual={}
    for arm,folder,count in [('innovation1','source_i1',21),('innovation2','source_i2',18)]:
        dest=ROOT/folder;dest.mkdir(exist_ok=False)
        for p in (ORIGIN/folder).iterdir():
            if p.is_file():shutil.copyfile(p,dest/p.name)
        original[arm]={p.name:sha(p) for p in (ORIGIN/folder).iterdir() if p.is_file()};assert len(original[arm])==count
    trainer=ROOT/'source_i1/train_kl_relative.py';old=trainer.read_text()
    new=old.replace("assert args.task == 'Swimmer' and", "assert args.task == 'Hopper' and").replace("'swimmer_i1_normalized_credit_sensitivity1_v1'", "'hopper_i1_normalized_credit_sensitivity1_v1'")
    assert old!=new and new.count("assert args.task == 'Hopper' and")==1
    trainer.write_text(new)
    write('SOURCE_I1_TASK_DIFF.patch',''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='Swimmer/source_i1/train_kl_relative.py',tofile='Hopper/source_i1/train_kl_relative.py')))
    for folder in ('source_i1','source_i2'):
        arm='innovation1' if folder=='source_i1' else 'innovation2'
        actual[arm]={p.name:sha(p) for p in (ROOT/folder).iterdir() if p.is_file()}
        write(folder+'_hashes.json',json.dumps(actual[arm],indent=2)+'\n')
    assert actual['innovation2']==original['innovation2']
    assert {n:h for n,h in actual['innovation1'].items() if n!='train_kl_relative.py'}=={n:h for n,h in original['innovation1'].items() if n!='train_kl_relative.py'}
    assert new.replace("assert args.task == 'Hopper' and", "assert args.task == 'Swimmer' and").replace("'hopper_i1_normalized_credit_sensitivity1_v1'","'swimmer_i1_normalized_credit_sensitivity1_v1'")==old
    for name in ('contracts.py','i2_native_verifier.py'):
        write(name,(ORIGIN/name).read_text())
    ncs=(ORIGIN/'ncs1_native_verifier.py').read_text().replace("'swimmer_i1_normalized_credit_sensitivity1_v1'","'hopper_i1_normalized_credit_sensitivity1_v1'")
    write('ncs1_native_verifier.py',ncs)
    stress=(ORIGIN/'stress_checkpoint.py').read_text()
    for a,b in [("('cuda:0', 'cuda:1', 'cuda:2')","('cuda:0', 'cuda:1')"),("'Swimmer'","'Hopper'"),("ActorCritic(8, 2)","ActorCritic(11, 3)"),("RunningStats((8,),","RunningStats((11,),"),("(32, 8, 2, 1000)","(32, 11, 3, 1000)")]:
        assert a in stress;stress=stress.replace(a,b)
    write('stress_checkpoint.py',stress)
    selected=('verify_protected','verify_i2','verify','normalize_config','exact_pair')
    inherited=extract(ORIGIN/'run_transfer.py',selected).replace("'Swimmer'","'Hopper'").replace(".startswith('Swimmer')",".startswith('Hopper')").replace("read(ROOT/'COMPARISON_REFERENCE.json')['files']","read(ROOT/'COMPARISON_NATIVE_FILES.json')['files']")
    write('inherited_verification.py',inherited)
    (ROOT/'evidence').mkdir(exist_ok=False)
    write('evidence/SWIMMER_RUN_TRANSFER_ORIGINAL.py',(ORIGIN/'run_transfer.py').read_text())
    walker_path=WORK/'runs/walker_full_block_reference_capture_r1_i2_8seed_20261006/MANIFEST.json'
    walker=json.loads(walker_path.read_text())
    xml=json.loads((WORK/'runs/full_deterministic_matrix_20260922/Hopper__fixed95__seed21/config.json').read_text())['xml_sha256']
    runtime={'state':'prospective_host53_existing_runtime_pinned','python':walker['native_python_metadata'],'versions':walker['runtime_versions'],'xml_sha256':xml,'native_root':'/ssd_2/wch/hopper_innovation12_transfer2_8seed_20261006','host':'wch@192.168.5.53','venv':'/ssd_2/wch/walker_full_block_reference_capture_r1_i2_8seed_20261006/.venv','actual_python':'/ssd_2/wch/code/dag_scheduler_v2_remote/.conda/bin/python3.11','lineage_manifest_path':str(walker_path),'lineage_manifest_sha256':sha(walker_path),'actual_new_native_capture_required':True}
    write('RUNTIME_REFERENCE.json',json.dumps(runtime,indent=2)+'\n')
    rows={};refs=[]
    for source in ('runs/baseline5_8seed_20260929/ANALYSIS.json','runs/remote_external_base8_20260925/ANALYSIS.json'):
        path=WORK/source;d=json.loads(path.read_text());refs.append({'path':str(path),'sha256':sha(path)})
        for row in d['rows']:
            if row['task']!='Hopper':continue
            key=(row['method'],row['seed'])
            if key in rows:
                assert all(rows[key][e]==row[e] for e in ('final_return','auc'));continue
            r=copy.deepcopy(row);r['original_path']=r['path'];r['path']=None;r['total_algorithm_transitions']=row.get('total_algorithm_transitions',10027008);r['source_reference']=str(path);rows[key]=r
    assert len(rows)==64
    parent_path=WORK/'runs/five_env_parent_native_bindings_20261006/HOPPER_COMPARISON_ROWS.json';parent=json.loads(parent_path.read_text())
    for row in parent['rows']:
        saved=rows[(row['method'],row['seed'])]
        for key in ('final_return','auc','total_algorithm_transitions','original_path'):assert saved[key]==row[key]
    write('COMPARISON_REFERENCE.json',json.dumps({'state':'frozen64metrics_paths_artifact_hashes_copy_pending_actual_parent_admission','rows':parent['rows'],'source_references':refs,'native_root_internal':'/ssd_2/wch/dpo_baseline5_8seed_20260929','native_root_external':'/ssd_2/wch/dpo_external_base8_20260925','new_baseline_or_external_runs':0,'parent_actual_native_paths_and_artifact_hashes_required':True,'parent_binding_source_path':str(parent_path),'parent_binding_source_sha256':sha(parent_path),'native_files_source_count':len(parent['protected_files']),'copied_run_count':parent['copied_run_count'],'copied_control_archive_sha256':parent['archive_sha256']},indent=2)+'\n')
    write('PARENT_CONTROL_PATH_PROVENANCE.json',json.dumps({'state':'actual_parent_existing_data_copy_pending','source_path':str(parent_path),'source_sha256':sha(parent_path),'existing_native49_verified_by_parent':True,'copied_controls15_actual_copy_check_required':True,'archive_sha256':parent['archive_sha256'],'files':parent['protected_files'],'available_original_files_only_no_new_stress':True},indent=2)+'\n')
    proof={'state':'built_local_only','Torch_imported':False,'native_actions':0,'original_source_hashes':original,'source_hashes':actual,'I1_only_task_guard_and_algorithm_version_changed':True,'I1_remaining_complete_AST_exact':True,'I2_all18_bytes_unchanged':True,'original_source_root':str(ORIGIN),'inherited_verifier_origin_sha256':sha(ORIGIN/'run_transfer.py'),'literal_inherited_verification_functions':selected,'original_NCS1_verifier_sha256':sha(ORIGIN/'ncs1_native_verifier.py'),'original_I2_verifier_sha256':sha(ORIGIN/'i2_native_verifier.py'),'warmup_count_unchanged':3,'cold_first_two_I2_target_scope_not_expanded':True,'stress_task_port':'Hopper11obs/3actions/GPU0,1; six frozen-checkpoint conditions unchanged'}
    write('SOURCE_BUILD_MANIFEST.json',json.dumps(proof,indent=2)+'\n')
    print(json.dumps({'state':'source_built','source_files':39,'controls':64,'Torch_imported':False,'native_actions':0}))
if __name__=='__main__':main()
