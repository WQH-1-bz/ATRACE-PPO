"""Stdlib-only Hopper queue; CUDA trainers and replay helpers are fresh processes."""
import argparse,csv,hashlib,itertools,json,math,os,shutil,statistics,subprocess,sys,time,traceback
from pathlib import Path
from contracts import ARMS,SEEDS,METHODS,BUDGET,SHORT,SWITCH,SHORT_SWITCH,DET,CONFIG_TELEMETRY
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
UNIT='dpo-hopper-innovation12-transfer2-records-r1-8seed-20261006.service'
GPUS=(0,1)
ENV={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONUNBUFFERED':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','DPO_TORCH_DETERMINISTIC':'1','DPO_WARP_DETERMINISTIC':'run_to_run','DPO_WARP_DETERMINISTIC_MAX_RECORDS':'8','CUBLAS_WORKSPACE_CONFIG':':4096:8','DPO_PPO_GRAPH':'0','XDG_CACHE_HOME':str(ROOT/'cache'),'WARP_CACHE_PATH':str(ROOT/'cache/warp'),'CUDA_CACHE_PATH':str(ROOT/'cache/cuda'),'TORCH_HOME':str(ROOT/'cache/torch'),'TMPDIR':str(ROOT/'tmp')}
def read(path):
    def reject(x):raise ValueError('nonfinite JSON '+x)
    return json.loads(Path(path).read_text(),parse_constant=reject)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for data in iter(lambda:stream.read(1048576),b''):h.update(data)
    return h.hexdigest()
def write(path,obj):
    path=Path(path);temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n');temp.replace(path)
def command(j):
    short=bool(j.get('smoke'));budget=SHORT if short else BUDGET
    folder='source_i1' if j['arm']=='innovation1' else 'source_i2';trainer='train_kl_relative.py' if j['arm']=='innovation1' else 'train_pae_baseline.py'
    cmd=[str(ROOT/'.venv/bin/python'),str(ROOT/folder/trainer),'--out',j['path'],'--task','Hopper','--seed',str(j['seed']),'--device','cuda:'+str(j['gpu']),'--steps',str(budget),'--num-envs','1024','--rollout','64','--batch-size','1024','--eval-envs','32','--eval-every','262144']
    if j['arm']=='innovation1':cmd+=['--epochs','10','--adaptive-start-update','4','--adaptive-start-steps','0','--fixed-critic-lambda','.95','--save-fixed-critic-audit']
    else:cmd+=['--method','pae','--staged-full','--stage-switch-steps',str(SHORT_SWITCH if short else SWITCH),'--overlap-start-steps','0','--overlap-stop-steps',str(budget),'--retained-tail-steps','8','--retained-tail-correction','--retained-tail-diagnostics','--retained-td-unclipped','--save-split-trace-audit']
    return cmd
def analyze(jobs):
    assert len(jobs)==16 and all(j['state']=='completed' for j in jobs)
    controls=read(ROOT/'PARENT_NATIVE_BINDINGS.json')['control_rows'];rows=[j['metrics'] for j in jobs]
    summary={};paired=[];available={};base={r['seed']:r for r in controls if r['method']=='fixed95'}
    for arm in ARMS:
        actual=sorted([r for r in rows if r['arm']==arm],key=lambda r:r['seed']);assert [r['seed'] for r in actual]==list(SEEDS)
        available[arm]={r['seed']:r for r in actual}
        summary[arm]={e:{'mean':statistics.mean(r[e] for r in actual),'sd':statistics.stdev(r[e] for r in actual)} for e in ('final_return','auc')}
        for method in METHODS:
            refs={r['seed']:r for r in controls if r['method']==method};assert sorted(refs)==list(SEEDS)
            for r in actual:paired.append({'arm':arm,'method':method,'seed':r['seed'],**{e:r[e]-refs[r['seed']][e] for e in ('final_return','auc')}})
    passing={}
    for n in (3,5):
        evaluated=[]
        for seeds in itertools.combinations(SEEDS,n):
            mean={arm:{e:statistics.mean(available[arm][s][e] for s in seeds) for e in ('final_return','auc')} for arm in ARMS}
            baseline={e:statistics.mean(base[s][e] for s in seeds) for e in ('final_return','auc')}
            passed=all(mean[arm][e]>baseline[e] for arm in ARMS for e in ('final_return','auc'))
            evaluated.append({'seeds':list(seeds),'means':mean,'base_means':baseline,'passed':passed})
        passing[str(n)]={'enumerated_count':56,'passing_count':sum(x['passed'] for x in evaluated),'passing_seed_sets':[x['seeds'] for x in evaluated if x['passed']],'evaluated':evaluated}
    full8={arm:all(summary[arm][e]['mean']>statistics.mean(base[s][e] for s in SEEDS) for e in ('final_return','auc')) for arm in ARMS}
    return {'state':'completed','task':'Hopper','version':'transfer2_NCS1_and_accepted_I2','rows':rows,'control_rows':controls,'summary':summary,'paired_differences':paired,'all8_seeds':list(SEEDS),'all8_Base_both_means_passed_per_arm':full8,'retrospective_common_standalone_subsets':passing,'standalone_development_admission_passed':any(x['passing_count'] for x in passing.values()),'subset_scope':'Retrospective descriptive same seeds for both arms and both means; all8 primary retained. No subset hypothesis tests or independent confirmation.','automatic_Full_or_tuning':False,'base_reruns':0,'external_reruns':0,'engineering_passed':True}
def snapshot():
    lines=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'],text=True,timeout=15).splitlines()
    free={int(x.split(',')[0]):int(x.split(',')[1]) for x in lines};mem={}
    lines=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,used_gpu_memory','--format=csv,noheader,nounits'],text=True,timeout=15).splitlines()
    for line in lines:
        try:pid,used=[int(x.strip()) for x in line.split(',')];mem[pid]=mem.get(pid,0)+used
        except ValueError:pass
    return free,mem
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--prepare-only',action='store_true');parser.add_argument('--verify-startup',action='store_true');parser.add_argument('--verify-only',action='store_true');args=parser.parse_args()
    assert not any(x in sys.modules for x in ('torch','warp','mujoco','numpy','scipy'))
    assert 'CUDA_VISIBLE_DEVICES' not in os.environ
    runtime=read(ROOT/'RUNTIME_REFERENCE.json');assert str(ROOT)==runtime['native_root'] and sys.version==runtime['python']
    manifest=read(ROOT/'MANIFEST.json');assert manifest['state']=='READY_local_only' and manifest['gpus']==[0,1]
    for name,digest in manifest['bundle_hashes'].items():assert sha(ROOT/name)==digest and not((ROOT/name).stat().st_mode&0o222)
    if args.verify_startup or args.verify_only:
        mode='startup' if args.verify_startup else 'terminal16';out=ROOT/('NATIVE_VERIFIED_'+mode+'.json')
        cmd=[str(ROOT/'.venv/bin/python'),str(ROOT/'worker_helper.py'),'--mode',mode,'--output',str(out)]
        result=subprocess.run(cmd,env=ENV,capture_output=True,text=True);assert result.returncode==0,(result.stdout,result.stderr)
        write(ROOT/('ACTUAL_HELPER_'+mode+'.json'),{'command':cmd,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'output_sha256':sha(out)});return
    if args.prepare_only:
        out=ROOT/'PREPARE_PROTECTED.json';cmd=[str(ROOT/'.venv/bin/python'),str(ROOT/'worker_helper.py'),'--mode','protected','--output',str(out)]
        result=subprocess.run(cmd,env=ENV,capture_output=True,text=True);assert result.returncode==0,(result.stdout,result.stderr)
        write(ROOT/'PREPARE_PASSED.json',{'state':'passed','command':cmd,'returncode':result.returncode,'protected_sha256':sha(out),'training_launched':False});return
    assert not(ROOT/'suite_status.json').exists()
    receipt=read(ROOT/'PARENT_LUNA_PRELAUNCH_VERIFIED.json');assert receipt['state']=='passed' and receipt['manifest_sha256']==sha(ROOT/'MANIFEST.json')
    assert receipt['native_root']==str(ROOT) and receipt['unit']==UNIT and receipt['physical_GPU_indices']==[0,1]
    assert read(ROOT/'PARENT_CONTEXT_PROTECTION_VERIFIED.json')['state']=='passed'
    assert read(ROOT/'REMOTE_PREPARED.json')['state']=='prepared'
    jobs=[{'id':arm+'__seed'+str(seed),'arm':arm,'seed':seed,'gpu':si%2,'path':str(ROOT/'runs'/(arm+'__seed'+str(seed))),'state':'pending'} for arm in ARMS for si,seed in enumerate(SEEDS)]
    shorts=[{'id':'short__'+arm+'__gpu'+str(gpu),'arm':arm,'seed':91088,'gpu':gpu,'path':str(ROOT/'runs'/('short__'+arm+'__gpu'+str(gpu))),'state':'pending','smoke':True} for arm in ARMS for gpu in GPUS]
    for j in jobs+shorts:j['planned_command']=command(j)
    active={};gate=False;failure=None;reservation=3500;peaks={};helper_active=None;start=time.time()
    initial_free,initial_mem=snapshot()
    def measure():
        free,mem=snapshot()
        for ident,(proc,stream,j) in active.items():peaks[ident]=max(peaks.get(ident,0),mem.get(proc.pid,0))
        if helper_active:peaks[helper_active['id']]=max(peaks.get(helper_active['id'],0),mem.get(helper_active['pid'],0))
        return free,mem
    def status(state):
        write(ROOT/'suite_status.json',{'state':state,'task':'Hopper','total':16,'completed_count':sum(j['state']=='completed' for j in jobs),'jobs':jobs,'smoke_jobs':shorts,'engineering_gate':gate,'active':{k:{'pid':v[0].pid,'gpu':v[2]['gpu'],'smoke':bool(v[2].get('smoke'))} for k,v in active.items()},'active_helper':helper_active,'failure':failure,'reservation_mib':reservation,'sampled_process_peak_MiB':peaks,'initial_GPU_free_MiB':initial_free,'initial_unrelated_compute_process_memory_MiB':initial_mem,'coordinator_pid':os.getpid(),'coordinator_command':[str(ROOT/'.venv/bin/python'),str(ROOT/'run_transfer.py')],'coordinator_uses_only_stdlib':True,'elapsed_seconds':time.time()-start})
    def can_admit(gpu,free,mem):
        running=[v for v in active.values() if v[2]['gpu']==gpu]
        pending_charge=sum(max(0,reservation-mem.get(v[0].pid,0)) for v in running)
        return len(running)<8 and free[gpu]>=reservation+512+pending_charge and shutil.disk_usage(ROOT).free>=10*1024**3
    def launch(j):
        stream=(ROOT/(j['id']+'.log')).open('x');cmd=command(j);proc=subprocess.Popen(cmd,stdout=stream,stderr=subprocess.STDOUT,env=ENV,cwd=ROOT)
        j.update(state='running',pid=proc.pid,command=cmd,log=str(ROOT/(j['id']+'.log')));active[j['id']]=(proc,stream,j)
    def helper(ident,cmd,gpu=None):
        nonlocal helper_active,reservation
        if gpu is not None:
            free,mem=measure()
            while not can_admit(gpu,free,mem):
                if shutil.disk_usage(ROOT).free<10*1024**3:raise RuntimeError('Disk capture headroom below10GiB')
                status('waiting_helper_memory');time.sleep(1.);free,mem=measure()
        stream=(ROOT/(ident+'.log')).open('x');proc=subprocess.Popen(cmd,stdout=stream,stderr=subprocess.STDOUT,env=ENV,cwd=ROOT)
        helper_active={'id':ident,'pid':proc.pid,'gpu':gpu,'command':cmd};status('engineering' if not gate else 'running')
        while proc.poll() is None:measure();time.sleep(.5)
        stream.close();record={**helper_active,'returncode':proc.returncode,'sampled_peak_MiB':peaks.get(ident,0)}
        write(ROOT/(ident+'.execution.json'),record);helper_active=None
        if proc.returncode!=0:raise RuntimeError('Fresh helper failed '+ident)
        reservation=max(reservation,math.ceil(peaks.get(ident,0)+256));return record
    def protected(ident):
        out=ROOT/(ident+'.json');cmd=[str(ROOT/'.venv/bin/python'),str(ROOT/'worker_helper.py'),'--mode','protected','--output',str(out)]
        helper(ident,cmd);assert read(out)['state']=='passed'
    def reap():
        nonlocal reservation
        for ident,(proc,stream,j) in list(active.items()):
            code=proc.poll()
            if code is None:continue
            stream.close();del active[ident];j['returncode']=code
            if code!=0:j['state']='failed';raise RuntimeError('Training failed '+ident)
            j['state']='verifying';status('engineering' if not gate else 'running')
            if j['arm']=='innovation2':
                cmd=[str(ROOT/'.venv/bin/python'),str(ROOT/'stress_checkpoint.py'),'--job-path',j['path'],'--device','cuda:'+str(j['gpu'])]
                helper(ident+'.stress',cmd,j['gpu'])
            jobfile=ROOT/(ident+'.helper_input.json');out=ROOT/(ident+'.verified.json');write(jobfile,j)
            cmd=[str(ROOT/'.venv/bin/python'),str(ROOT/'worker_helper.py'),'--mode','job','--job-file',str(jobfile),'--output',str(out)]
            helper(ident+'.replay',cmd,j['gpu']);j['metrics']=read(out);j['state']='completed'
            summary=read(Path(j['path'])/'summary.json');alloc=max(summary.get('peak_torch_memory_bytes',0),j['metrics'].get('verification_helper_peak_reserved_bytes',0))/1024**2
            if j['arm']=='innovation2':alloc=max(alloc,read(Path(j['path'])/'checkpoint_stress_result.json')['peak_torch_memory_reserved_bytes']/1024**2)
            reservation=max(reservation,math.ceil(max(peaks.get(ident,0),alloc)+256));status('engineering' if not gate else 'running')
    try:
        protected('PROTECTED_before')
        for arm in ARMS:
            cohort=[j for j in shorts if j['arm']==arm]
            while not all(j['state']=='completed' for j in cohort):
                reap();free,mem=measure()
                if all(j['state']=='pending' for j in cohort) and all(can_admit(j['gpu'],free,mem) for j in cohort):
                    for j in cohort:launch(j)
                status('engineering');time.sleep(1.)
            pair=sorted(cohort,key=lambda j:j['gpu']);out=ROOT/('SHORT_'+arm+'_VERIFIED.json')
            cmd=[str(ROOT/'.venv/bin/python'),str(ROOT/'worker_helper.py'),'--mode','pair','--arm',arm,'--left',pair[0]['path'],'--right',pair[1]['path'],'--output',str(out)]
            helper('PAIR_'+arm,cmd);assert read(out)['state']=='passed'
        protected('PROTECTED_after_shorts');gate=True
        write(ROOT/'SMOKE_VERIFIED.json',{'state':'passed','shorts':4,'engineering_seed':91088,'gpus':[0,1],'exact_scientific_crossGPU':True,'reservation_mib':reservation,'tolerance':0,'retry':False,'manifest_sha256':sha(ROOT/'MANIFEST.json')})
        while not all(j['state']=='completed' for j in jobs):
            reap();free,mem=measure()
            for j in jobs:
                if j['state']=='pending' and can_admit(j['gpu'],free,mem):launch(j);free,mem=measure()
            status('running');time.sleep(1.)
        protected('PROTECTED_terminal');write(ROOT/'ANALYSIS.json',analyze(jobs));status('completed')
    except BaseException:
        failure={'state':'failed','traceback':traceback.format_exc(),'new_admissions_stopped':True,'active_workers_preserved':True,'retry':False}
        write(ROOT/'FAILURE.json',failure);status('failed');raise
    assert not any(x in sys.modules for x in ('torch','warp','mujoco','numpy','scipy'))
if __name__=='__main__':main()
