"""Fresh-process source-native checkpoint replay and independent verification."""
import argparse,ast,copy,csv,hashlib,importlib.metadata,itertools,json,math,os,statistics,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import torch
import ncs1_native_verifier as ncs
import i2_native_verifier as i2
from historical_execution import validate_historical_execution
from contracts import ARMS,SEEDS,METHODS,BUDGET,SHORT,SWITCH,SHORT_SWITCH,DET,CONFIG_TELEMETRY,PROGRESS_TELEMETRY
ROOT=Path(__file__).resolve().parent
STRESS=(('none',0.),('gaussian',.1),('gaussian',.15),('gaussian',.3),('multiplicative',.2),('multiplicative',.3))
read=ncs.read;sha=ncs.sha;jsonl=ncs.jsonl;exact=ncs.exact;differences=ncs.differences;batch=ncs.batch;auc=ncs.auc
def write(path,obj):
    path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n');tmp.replace(path)
def controls():
    expected=read(ROOT/'COMPARISON_REFERENCE.json')['rows'];binding=read(ROOT/'PARENT_NATIVE_BINDINGS.json')
    assert binding['state']=='parent_actual_native_verified' and binding['manifest_sha256']==sha(ROOT/'MANIFEST.json')
    actual=binding['control_rows'];assert len(actual)==64
    assert {(r['method'],r['seed']) for r in actual}=={(m,s) for m in METHODS for s in SEEDS}
    want={(r['method'],r['seed']):r for r in expected}
    for row in actual:
        source=want[(row['method'],row['seed'])]
        for e in ('final_return','auc','total_algorithm_transitions','original_path','path','artifact_hashes'):assert row[e]==source[e],(row['method'],row['seed'],e)
        path=Path(row['path']);assert path.is_absolute() and '/ssd_2/wch/' in str(path)
        assert row['artifact_hashes'] and all(x in row['artifact_hashes'] for x in ('config.json','summary.json','status.json','progress.csv','initial_evaluation.json','evaluations.jsonl','latest.pt'))
    return actual
def check_sources():
    manifest=read(ROOT/'MANIFEST.json');runtime=read(ROOT/'RUNTIME_REFERENCE.json');binding=read(ROOT/'PARENT_NATIVE_BINDINGS.json')
    assert str(ROOT)==runtime['native_root'] and manifest['task']=='Hopper' and manifest['gpus']==[0,1]
    assert binding['manifest_sha256']==sha(ROOT/'MANIFEST.json') and binding['state']=='parent_actual_native_verified'
    assert binding['python']==sys.version==runtime['python']
    assert Path(sys.executable).resolve()==Path(runtime['actual_python']).resolve()
    for name,digest in manifest['bundle_hashes'].items():assert sha(ROOT/name)==digest and not((ROOT/name).stat().st_mode&0o222),(name,'frozen mutation')
    for name,version in runtime['versions'].items():assert importlib.metadata.version(name)==version
    assert 'CUDA_VISIBLE_DEVICES' not in os.environ
    import gymnasium
    assert sha(Path(gymnasium.__file__).parent/'envs/mujoco/assets/hopper.xml')==runtime['xml_sha256']==binding['xml_sha256']
    assert binding['physical_GPU_indices']==[0,1] and set(binding['physical_GPU_UUIDs'])=={'0','1'}
    gpu_rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid','--format=csv,noheader'],text=True).splitlines()
    gpu_ids={line.split(',')[0].strip():line.split(',')[1].strip() for line in gpu_rows}
    assert all(gpu_ids[k]==v for k,v in binding['physical_GPU_UUIDs'].items())
    source=ast.parse((ROOT/'source_i1/train_kl_relative.py').read_text());nodes={n.name:n for n in source.body if isinstance(n,ast.FunctionDef)}
    clone=copy.deepcopy(nodes['gae_signal']);clone.name='gae';assert ast.dump(clone,include_attributes=False)==ast.dump(nodes['gae'],include_attributes=False)
    for arm,folder in [('innovation1','source_i1'),('innovation2','source_i2')]:
        hashes=manifest['source_hashes'][arm];assert hashes==read(ROOT/(folder+'_hashes.json'))
        assert {p.name for p in (ROOT/folder).iterdir() if p.is_file()}==set(hashes)
    # These two parent-owned files are external admission evidence, never rebuilt by this helper.
    p=read(ROOT/'PROTECTED_INVENTORY.json');c=read(ROOT/'COMPARISON_NATIVE_FILES.json')
    assert sha(ROOT/'PROTECTED_INVENTORY.json')==binding['protected_inventory_sha256']
    assert sha(ROOT/'COMPARISON_NATIVE_FILES.json')==binding['comparison_native_files_sha256']
    assert p['state']=='verified' and p['files'] and c['files']
    return manifest

# Literal task-ported bodies: controller, targets, cold/warm replay and scientific
# comparison logic remain the inherited verifier's actual source functions.
exec(compile((ROOT/'inherited_verification.py').read_text(),str(ROOT/'inherited_verification.py'),'exec'),globals())

def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=('protected','job','pair','startup','terminal16'),required=True);p.add_argument('--job-file');p.add_argument('--output',required=True);p.add_argument('--arm');p.add_argument('--left');p.add_argument('--right');args=p.parse_args()
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True);check_sources()
    # The inherited control checker expects the copied file map alongside its rows;
    # inject the parent-owned map only at the one explicit read site below.
    if args.mode=='protected':result=verify_protected()
    elif args.mode=='job':
        job=read(Path(args.job_file));assert job['gpu'] in (0,1)
        result=verify(job);result['verification_helper_peak_reserved_bytes']=torch.cuda.max_memory_reserved(job['gpu'])
    elif args.mode=='pair':result=exact_pair(args.left,args.right,args.arm)
    else:
        from run_transfer import command,analyze
        state=read(ROOT/'suite_status.json');assert state['failure'] is None and state['engineering_gate']
        shorts=state['smoke_jobs'];jobs=state['jobs'];assert len(shorts)==4 and len(jobs)==16
        assert {(j['arm'],j['seed']) for j in jobs}=={(a,s) for a in ARMS for s in SEEDS}
        verified=[]
        for j in shorts:
            assert j['state']=='completed' and j['returncode']==0 and j['command']==command(j)
            verify(j)
        for arm in ARMS:
            pair=sorted([j for j in shorts if j['arm']==arm],key=lambda j:j['gpu']);assert [j['gpu'] for j in pair]==[0,1]
            exact_pair(pair[0]['path'],pair[1]['path'],arm)
        for j in jobs:
            assert j['planned_command']==command(j)
            if j['state']=='pending':assert 'pid' not in j
            elif j['state']=='running':
                assert j['command']==command(j)
                assert (Path('/proc')/str(j['pid'])/'cmdline').read_bytes().rstrip(b'\0').split(b'\0')==[v.encode() for v in command(j)]
                cpath=Path(j['path'])/'config.json'
                if cpath.exists():
                    config=read(cpath);assert config['task']=='Hopper' and config['device']=='cuda:'+str(j['gpu']) and config['seed']==j['seed'] and config['determinism']==DET
            else:
                assert j['state']=='completed' and j['returncode']==0
                metric=verify(j);assert not differences(metric,{k:v for k,v in j['metrics'].items() if k!='verification_helper_peak_reserved_bytes'})
                verified.append(j)
        if args.mode=='terminal16':
            assert state['state']=='completed' and len(verified)==16 and not state['active']
            assert read(ROOT/'ANALYSIS.json')==analyze(jobs)
        else:assert any(j['state'] in ('running','completed') for j in jobs)
        result={'state':'passed','phase':args.mode,'shorts_verified':4,'formal_count':16,'complete_formal_count':len(verified),'protected':verify_protected()}
    write(args.output,result);print(json.dumps({'state':'passed','mode':args.mode}))
if __name__=='__main__':main()
