"""CEF1: causal frozen fixed95 critic prediction-error fraction; heuristic actor trace."""
import math
from dataclasses import asdict, dataclass

@dataclass
class CriticErrorFraction:
    value: float = .95
    target: float = .95
    observations: int = 0
    block_sum: float = 0.
    last_q: float = 0.
    last_block_mean: float = 0.

    def observe(self, q):
        if not math.isfinite(q) or not 0. <= q <= 1.:
            raise ValueError('Critic error fraction must be finite in [0,1]')
        self.last_q = q
        self.observations += 1
        self.block_sum += q
        if self.observations % 4 == 0:
            self.last_block_mean = self.block_sum / 4.
            self.target = min(.99, max(.90, .90 + .09 * self.last_block_mean))
            self.block_sum = 0.

    def step(self, update):
        old = self.value
        if update > 4:
            self.value = min(.99, max(.90,
                old + max(-.001, min(.001, .1 * (self.target - old)))))
        return self.value - old

    def state_dict(self):
        return asdict(self)
