"""Dimensionless frozen-rollout lambda sensitivity; no advantage-truth claim."""
import math
import torch

METRIC_KEYS=('mean90','variance90','mean99','variance99','squared_distance','rms_distance','d')
def normalized_credit_sensitivity(advantage90, advantage99):
    if not isinstance(advantage90,torch.Tensor) or not isinstance(advantage99,torch.Tensor):
        raise ValueError('Expected two tensors')
    if advantage90.ndim!=1 or advantage90.shape!=advantage99.shape or advantage90.numel()==0:
        raise ValueError('Expected matching nonempty flattened credits')
    if advantage90.dtype!=advantage99.dtype or advantage90.dtype not in (torch.float32,torch.float64) or advantage90.device!=advantage99.device:
        raise ValueError('Credit dtype/device mismatch')
    if not bool(torch.isfinite(advantage90).all()) or not bool(torch.isfinite(advantage99).all()):
        raise ValueError('Nonfinite credit vectors')
    mean90=advantage90.mean(); variance90=advantage90.var(unbiased=False)
    mean99=advantage99.mean(); variance99=advantage99.var(unbiased=False)
    if not all(math.isfinite(float(x)) for x in (mean90,variance90,mean99,variance99)) or float(variance90)<=0 or float(variance99)<=0:
        raise ValueError('Nonfinite or zero population SD')
    z90=(advantage90-mean90)/variance90.sqrt()
    z99=(advantage99-mean99)/variance99.sqrt()
    squared_distance=(z90-z99).square().mean()
    rms_distance=squared_distance.sqrt()
    d=(.5*rms_distance).clamp(0.,1.)
    metrics=dict(zip(METRIC_KEYS,map(float,(mean90,variance90,mean99,variance99,squared_distance,rms_distance,d))))
    if not all(math.isfinite(x) for x in metrics.values()):
        raise ValueError('Nonfinite normalized sensitivity')
    return metrics
