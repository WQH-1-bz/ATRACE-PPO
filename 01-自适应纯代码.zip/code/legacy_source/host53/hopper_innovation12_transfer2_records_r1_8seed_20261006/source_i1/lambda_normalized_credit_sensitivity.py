"""NCS1: same causal CEF1 controller, observed normalized credit sensitivity."""
import math
from dataclasses import asdict, dataclass

@dataclass
class NormalizedCreditSensitivity:
    value: float = .95
    target: float = .95
    observations: int = 0
    block_sum: float = 0.
    last_d: float = 0.
    last_block_mean: float = 0.

    def observe(self, d):
        if not math.isfinite(d) or not 0. <= d <= 1.:
            raise ValueError('Normalized credit sensitivity must be finite in [0,1]')
        self.last_d = d
        self.observations += 1
        self.block_sum += d
        if self.observations % 4 == 0:
            self.last_block_mean = self.block_sum / 4.
            self.target = min(.99, max(.90, .90 + .09 * self.last_block_mean))
            self.block_sum = 0.

    def step(self, update):
        old = self.value
        if update > 4:
            self.value = min(.99, max(.90,
                old + max(-.001, min(.001, .1 * (self.target - old)))))
        return self.value - old

    def state_dict(self):
        return asdict(self)
