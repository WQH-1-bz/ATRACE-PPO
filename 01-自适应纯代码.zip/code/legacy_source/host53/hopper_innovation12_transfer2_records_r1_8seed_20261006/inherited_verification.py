def verify_protected():
    inventory=read(ROOT/'PROTECTED_INVENTORY.json');assert inventory['state']=='verified' and inventory['files']
    copied=read(ROOT/'COMPARISON_NATIVE_FILES.json')['files']
    for name,digest in inventory['files'].items():
        assert sha(name)==digest,('protected mutation',name)
        if name in copied:assert not(Path(name).stat().st_mode&0o222),('copied control unfrozen',name)
    reports=[]
    for row in controls():
        p=Path(row['path']);c=read(p/'config.json');s=read(p/'summary.json');status=read(p/'status.json');method=row['method']
        assert c['task'].startswith('Hopper') and c['seed']==row['seed']
        validate_historical_execution(row,c,sha(p/'config.json'))
        assert c['xml_sha256']==read(ROOT/'RUNTIME_REFERENCE.json')['xml_sha256']
        assert s['state']==status['state']=='completed' and s['reload_check']=='passed' and s['steps']==BUDGET
        assert c.get('effective_steps',c.get('steps'))==BUDGET
        for k,v in [('num_envs',1024),('rollout',64),('batch_size',1024),('eval_envs',32),('eval_every',262144)]:assert c[k]==v
        for name,digest in row['artifact_hashes'].items():assert sha(p/name)==digest and inventory['files'][str(p/name)]==digest
        area,initial,ev=auc(p,BUDGET);exact(area,row['auc']);exact(s['final_eval']['mean'],row['final_return']);assert len(ev)==39
        progress=list(csv.DictReader((p/'progress.csv').open()));assert len(progress)==(204 if method=='pae' else 153)
        expected=[];threshold=262144
        for point in progress:
            step=int(point['steps'])
            if step>=threshold or step==BUDGET:expected.append(step);threshold=(step//262144+1)*262144
        assert [v['steps'] for v in ev]==expected
        total=s.get('total_algorithm_transitions',BUDGET);assert total==row['total_algorithm_transitions']
        if method=='reward_profiling':
            decisions=jsonl(p/'profiling_decisions.jsonl');assert len(decisions)==10;extra=physical=0
            for decision in decisions:
                lengths=[decision[k]['lengths'] for k in ('old','new')];assert all(len(xs)==5 and all(type(x) is int and 1<=x<=1000 for x in xs) for xs in lengths)
                valid=sum(lengths[0])+sum(lengths[1]);simulated=5*(max(lengths[0])+max(lengths[1]));assert valid==decision['extra_transitions'] and simulated==decision['simulated_transitions'];extra+=valid;physical+=simulated
            assert total==BUDGET+extra and extra==s['profiling_extra_transitions'] and physical==s['profiling_simulated_transitions']
        else:assert total==BUDGET
        saved=torch.load(p/'latest.pt',map_location='cpu',weights_only=False)
        if method=='gradient_ppo':
            assert set(saved['optimizers'])=={'actor','critic','h'}
            for optimizer in saved['optimizers'].values():assert {float(v['step']) for v in optimizer['state'].values()}=={39168.}
        else:
            optimizer=saved.get('optimizer') or saved['optimizers']['ppo'];values={float(v['step']) for v in optimizer['state'].values()};assert values==({48960.,97920.} if method=='critic_aware' else {97920.})
        reports.append({'method':method,'seed':row['seed'],'original_path':row['original_path'],'copied_path':str(p),'final_return':row['final_return'],'auc':area,'initial_return':initial['mean'],'original_total_algorithm_transitions':total})
    return {'state':'passed','protected_files':len(inventory['files']),'control_rows':64,'original_control_reports':reports,'crosshost_initial_byte_equality_required':False}

def verify_i2(j):
    p=Path(j['path']);short=bool(j.get('smoke'));budget=SHORT if short else BUDGET
    c=read(p/'config.json');s=read(p/'summary.json');assert s==read(p/'status.json') and s['state']=='completed' and s['reload_check']=='passed'
    assert c['task']=='Hopper' and c['seed']==j['seed'] and c['device']=='cuda:'+str(j['gpu']) and c['determinism']==DET
    # Original accepted I2 config does not record package versions; check_sources pins actual interpreter/runtime globally.
    assert c['xml_sha256']==read(ROOT/'RUNTIME_REFERENCE.json')['xml_sha256']
    assert c['steps']==c['effective_steps']==s['steps']==budget
    for k,v in [('num_envs',1024),('rollout',64),('batch_size',1024),('epochs',10),('eval_envs',32),('eval_every',262144)]:assert c[k]==v
    assert c['method']=='pae' and c['staged_full'] and c['stage_switch_steps']==(SHORT_SWITCH if short else SWITCH)
    assert c['pae_prefix']==56 and c['pae_tail']==c['retained_tail_steps']==8 and c['initial_lambda']==.95
    assert c['retained_tail_correction'] and c['retained_tail_diagnostics'] and c['retained_td_unclipped'] and c['save_split_trace_audit']
    assert not any(c[k] for k in ('adaptive_kl','readiness_boost','adaptive_overlap','force_pae_overlap'))
    for name,digest in c['source_sha256'].items():assert digest==read(ROOT/'MANIFEST.json')['source_hashes']['innovation2'][name]
    assert s['training_transitions']==s['total_algorithm_transitions']==budget and s['optimizer_steps']=={'actor':budget//1024*10,'critic':budget//1024*10,'h':0} and s['pae_retained_per_world']==0
    progress=list(csv.DictReader((p/'progress.csv').open()));_,detail=i2.verify_i2(progress,p,c,short);detail.update(i2.verify_split_trace_audits(j,c,short))
    checkpoint=i2.checkpoint_steps(p,'innovation2',budget//1024*10);assert checkpoint['steps']==budget
    area,initial,ev=auc(p,budget);assert len(ev)==(2 if short else 39)
    expected=[];threshold=262144
    for point in progress:
        step=int(point['steps'])
        if step>=threshold or step==budget:expected.append(step);threshold=(step//262144+1)*262144
    assert [e['steps'] for e in ev]==expected
    for e in [initial,*ev,s['final_eval']]:batch(e,c['device'])
    exact(ev[-1]['mean'],s['final_eval']['mean']);assert ev[-1]['returns']==s['final_eval']['returns']
    if 'normalized_return_auc' in s:assert abs(area-s['normalized_return_auc'])<1e-10
    stress=read(p/'stress_evaluation.json');assert [(r['mode'],r['scale']) for r in stress]==list(STRESS)
    for value in stress:batch(value,c['device'])
    proof=read(p/'checkpoint_stress_result.json');assert proof['state']=='passed' and proof['training_transitions']==proof['optimizer_steps']==proof['optimizer_constructions']==0 and proof['model_unchanged'] and proof['normalizer_unchanged'] and proof['training_files_unchanged']
    assert proof['runtime_versions']==read(ROOT/'RUNTIME_REFERENCE.json')['versions']
    names=['config.json','summary.json','status.json','progress.csv','initial_evaluation.json','evaluations.jsonl','latest.pt','retained_tail_diagnostics.jsonl','stress_evaluation.json','checkpoint_stress_result.json',*i2.split_audit_names(c)]
    return {'seed':j['seed'],'path':j['path'],'final_return':s['final_eval']['mean'],'auc':area,'initial_return':initial['mean'],'updates':len(progress),'steps':budget,'actor_adam_steps':budget//1024*10,'critic_adam_steps':budget//1024*10,'auxiliary_adam_steps':0,'artifact_hashes':{n:sha(p/n) for n in names},**detail}

def verify(j):
    summary=read(Path(j['path'])/'summary.json');assert summary['physics_device']==summary['device']=='cuda:'+str(j['gpu']),('actual physics placement',j['id'])
    result=ncs.verify(j) if j['arm']=='innovation1' else verify_i2(j);return {'arm':j['arm'],**result}

def normalize_config(c):
    c=copy.deepcopy(c)
    for key in CONFIG_TELEMETRY:c.pop(key,None)
    if c.get('lambda_mode')=='normalized_credit_sensitivity':c['lambda_design'].pop('signal_reduction_device')
    return c

def exact_pair(a,b,arm):
    paths=[Path(a),Path(b)];delta=[]
    for name in ('latest.pt','best.pt'):
        present=[(p/name).exists() for p in paths];assert present[0]==present[1]
        if not present[0]:continue
        data=[torch.load(p/name,map_location='cpu',weights_only=False) for p in paths]
        for d in data:d['config']=normalize_config(d['config'])
        delta+=differences(*data,path=name)
    audit_names=[*ncs.signal_names(True),*ncs.audit_names(True)] if arm=='innovation1' else i2.split_audit_names(read(paths[0]/'config.json'))
    for name in audit_names:
        data=[torch.load(p/name,map_location='cpu',weights_only=False) for p in paths]
        for d in data:d.pop('target_device',None)
        delta+=differences(*data,path=name)
    for name in ('config.json','summary.json','status.json'):
        data=[read(p/name) for p in paths]
        data=[normalize_config(d) if name=='config.json' else {k:v for k,v in d.items() if k not in CONFIG_TELEMETRY} for d in data]
        delta+=differences(*data,path=name)
    for name in ('initial_evaluation.json','evaluations.jsonl','stress_evaluation.json','lambda_decisions.jsonl' if arm=='innovation1' else 'retained_tail_diagnostics.jsonl'):
        assert (paths[0]/name).read_bytes()==(paths[1]/name).read_bytes(),name
    rows=[list(csv.DictReader((p/'progress.csv').open())) for p in paths];assert len(rows[0])==len(rows[1])==(8 if arm=='innovation1' else 9)
    for ra,rb in zip(*rows):
        for key in ra:
            if key not in PROGRESS_TELEMETRY:assert ra[key]==rb[key],('progress',key)
    assert not delta,delta
    return {'state':'passed','arm':arm,'all_scientific_tensor_bytes_and_fields_exact':True,'config_summary_status_operational_exclusions':list(CONFIG_TELEMETRY),'nested_config_operational_exclusion':'lambda_design.signal_reduction_device for NCS1 only','saved_payload_operational_exclusion':'target_device only','progress_exclusions':list(PROGRESS_TELEMETRY),'tolerance':0}
