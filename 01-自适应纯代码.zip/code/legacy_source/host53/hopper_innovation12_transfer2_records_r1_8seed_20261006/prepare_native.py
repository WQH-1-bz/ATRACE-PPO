"""Parent-invoked existing-runtime preparation; no install or training."""
import json,os,shutil,subprocess,sys
from pathlib import Path
import run_transfer as r
ROOT=Path(__file__).resolve().parent
def main():
    expected=r.read(ROOT/'RUNTIME_REFERENCE.json');assert str(ROOT)==expected['native_root'] and sys.version==expected['python']
    assert os.geteuid()!=0 and not(ROOT/'REMOTE_PREPARED.json').exists()
    assert not[(p/'AGENTS.md') for p in (ROOT,*ROOT.parents) if (p/'AGENTS.md').exists()],'Applicable native instructions require parent review'
    assert not(Path.home()/'.config/systemd/user'/r.UNIT).exists()
    assert ROOT.stat().st_dev!=Path('/').stat().st_dev and shutil.disk_usage(ROOT).free>=10*1024**3
    assert Path(expected['venv']).is_dir() and Path(sys.executable).resolve()==Path(expected['actual_python']).resolve()
    (ROOT/'.venv').symlink_to(expected['venv'],target_is_directory=True)
    for name in ('runs','cache','tmp'):(ROOT/name).mkdir(exist_ok=False)
    result=subprocess.run([str(ROOT/'.venv/bin/python'),str(ROOT/'run_transfer.py'),'--prepare-only'],env=r.ENV,capture_output=True,text=True)
    assert result.returncode==0,(result.stdout,result.stderr)
    r.write(ROOT/'REMOTE_PREPARED.json',{'state':'prepared','python':sys.version,'manifest_sha256':r.sha(ROOT/'MANIFEST.json'),'native_binding_sha256':r.sha(ROOT/'PARENT_NATIVE_BINDINGS.json'),'protected_inventory_sha256':r.sha(ROOT/'PROTECTED_INVENTORY.json'),'venv':expected['venv'],'training_launched':False,'installation':False,'disk_free_bytes':shutil.disk_usage(ROOT).free,'helper_returncode':result.returncode})
    print(json.dumps({'state':'prepared','training_launched':False}))
if __name__=='__main__':main()
