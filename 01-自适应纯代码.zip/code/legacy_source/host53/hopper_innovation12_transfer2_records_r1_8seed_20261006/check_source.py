"""Independent stdlib-only source/queue/controller/accounting fixtures."""
import ast,copy,hashlib,importlib.util,json,math,sys
from pathlib import Path
import contracts as c
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def functions(path):
    source=Path(path).read_text();return {n.name:ast.get_source_segment(source,n) for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)}
def rejects(fn,*args):
    try:fn(*args)
    except (AssertionError,ValueError,OverflowError):return
    raise AssertionError('invalid fixture accepted')
def main():
    assert not any(n in sys.modules for n in ('torch','warp','mujoco','numpy','scipy'))
    proof=json.loads((ROOT/'SOURCE_BUILD_MANIFEST.json').read_text())
    actual={arm:{p.name:sha(p) for p in (ROOT/folder).iterdir() if p.is_file()} for arm,folder in [('innovation1','source_i1'),('innovation2','source_i2')]}
    assert actual==proof['source_hashes'] and actual['innovation2']==proof['original_source_hashes']['innovation2']
    new=(ROOT/'source_i1/train_kl_relative.py').read_text()
    old=new.replace("assert args.task == 'Hopper' and","assert args.task == 'Swimmer' and").replace("'hopper_i1_normalized_credit_sensitivity1_v1'","'swimmer_i1_normalized_credit_sensitivity1_v1'")
    assert hashlib.sha256(old.encode()).hexdigest()==proof['original_source_hashes']['innovation1']['train_kl_relative.py']
    assert len(actual['innovation1'])==21 and len(actual['innovation2'])==18
    for name in actual['innovation1']:
        if name!='train_kl_relative.py':assert actual['innovation1'][name]==proof['original_source_hashes']['innovation1'][name]
    for p in ROOT.rglob('*.py'):ast.parse(p.read_text(),feature_version=(3,11));compile(p.read_text(),str(p),'exec')
    original_path=ROOT/'evidence/SWIMMER_RUN_TRANSFER_ORIGINAL.py';assert sha(original_path)==proof['inherited_verifier_origin_sha256']
    scientific=functions(ROOT/'inherited_verification.py');original=functions(original_path)
    for name,body in scientific.items():
        expected=original[name].replace("'Swimmer'","'Hopper'").replace(".startswith('Swimmer')",".startswith('Hopper')")
        if name=='verify_protected':
            expected=expected.replace("read(ROOT/'COMPARISON_REFERENCE.json')['files']","read(ROOT/'COMPARISON_NATIVE_FILES.json')['files']")
            expected=expected.replace("        assert c['task'].startswith('Hopper') and c['seed']==row['seed'] and c['determinism']==DET", "        assert c['task'].startswith('Hopper') and c['seed']==row['seed']\n        validate_historical_execution(row,c,sha(p/'config.json'))")
        assert body==expected,(name,'inherited numerical body changed')
    original_ncs=(ROOT/'ncs1_native_verifier.py').read_text().replace("'hopper_i1_normalized_credit_sensitivity1_v1'","'swimmer_i1_normalized_credit_sensitivity1_v1'")
    assert hashlib.sha256(original_ncs.encode()).hexdigest()==proof['original_NCS1_verifier_sha256']
    assert sha(ROOT/'i2_native_verifier.py')==proof['original_I2_verifier_sha256']
    tree=ast.parse(new);nodes={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)};clone=copy.deepcopy(nodes['gae_signal']);clone.name='gae';assert ast.dump(clone,include_attributes=False)==ast.dump(nodes['gae'],include_attributes=False)
    ctrl=module('hopper_stdlib_controller_fixture',ROOT/'source_i1/lambda_normalized_credit_sensitivity.py').NormalizedCreditSensitivity
    control=ctrl();sequence=[.2,.3,.4,.5,.6,.7,.8,.9]
    for u,d in enumerate(sequence,1):
        before=control.state_dict();delta=control.step(u)
        if u<=4:assert control.value==.95 and delta==0.
        else:assert control.value==min(.99,max(.90,before['value']+max(-.001,min(.001,.1*(before['target']-before['value'])))))
        used=control.value;control.observe(d);assert control.value==used
        if u%4==0:assert control.target==min(.99,max(.90,.90+.09*sum(sequence[u-4:u])/4))
    for d in (math.nan,math.inf,-.01,1.01):rejects(ctrl().observe,d)
    for arm in c.ARMS:
        for short in (False,True):
            rows=c.ledger(arm,short);budget=c.SHORT if short else c.BUDGET
            assert sum(r['fresh_per_world']*1024 for r in rows)==sum(r['used_per_world']*1024 for r in rows)==budget
            assert len(rows)==((8 if short else 153) if arm=='innovation1' else (9 if short else 164))
            if arm=='innovation2':
                flush=[r for r in rows if r['stage_boundary_flush']];assert len(flush)==1 and flush[0]['used_per_world']==(32 if short else 48)
    reward=[.2,.4,-.3,.1,.7];value=[.3,.2,.1,.4,.2];nv=[.2,.1,.4,.2,.5];term=[False,False,False,True,False];done=[False,True,False,True,False];rho=[.8,1.6,1.,1.,1.];cap=[min(1.,x) for x in rho]
    endpoints=[]
    for lam in (.90,.95,.99):
        actor,ret=c.expanded_trace(reward,value,nv,term,done,rho,cap,lam);carry=0.;a=[0.]*5;r=[0.]*5
        for i in range(4,-1,-1):
            delta=reward[i]+.99*(not term[i])*nv[i]-value[i];a[i]=delta+.99*lam*(not done[i])*carry;carry=cap[i]*a[i]+(rho[i]-cap[i])*delta;r[i]=value[i]+carry
        assert all(abs(x-y)<1e-12 for xs,ys in ((actor,a),(ret,r)) for x,y in zip(xs,ys));endpoints.append(actor)
    assert abs(c.sensitivity(endpoints[0],endpoints[2])-c.sensitivity([2*x+3 for x in endpoints[0]],[5*x-7 for x in endpoints[2]]))<1e-12
    rejects(c.sensitivity,[1.,1.],[1.,2.]);rejects(c.sensitivity,[1.,math.nan],[1.,2.])
    coordinator=module('hopper_stdlib_queue_fixture',ROOT/'run_transfer.py');assert not any(n in sys.modules for n in ('torch','warp','mujoco','numpy','scipy'))
    for arm in c.ARMS:
        for short in (False,True):
            for gpu in (0,1):
                cmd=coordinator.command({'arm':arm,'smoke':short,'seed':91088 if short else 21,'gpu':gpu,'path':'fixture'})
                assert cmd[cmd.index('--task')+1]=='Hopper' and cmd[cmd.index('--device')+1]=='cuda:'+str(gpu)
                assert cmd[cmd.index('--steps')+1]==str(c.SHORT if short else c.BUDGET)
                if arm=='innovation2':assert cmd[cmd.index('--overlap-start-steps')+1]=='0' and cmd[cmd.index('--overlap-stop-steps')+1]==str(c.SHORT if short else c.BUDGET)
    allowed={'argparse','csv','hashlib','itertools','json','math','os','shutil','statistics','subprocess','sys','time','traceback','pathlib','contracts'}
    driver=ast.parse((ROOT/'run_transfer.py').read_text())
    for node in ast.walk(driver):
        if isinstance(node,ast.Import):assert all(x.name.split('.')[0] in allowed for x in node.names)
        if isinstance(node,ast.ImportFrom):assert node.module.split('.')[0] in allowed
    source=(ROOT/'run_transfer.py').read_text();assert 'subprocess.Popen' in source and 'torch.cuda' not in source and 'kill(' not in source and 'terminate(' not in source
    normalize=ast.parse(scientific['normalize_config']).body[0];scope={'copy':copy,'CONFIG_TELEMETRY':c.CONFIG_TELEMETRY}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[normalize],type_ignores=[])),'named_exclusions_fixture','exec'),scope)
    a={'device':'cuda:0','physics_device':'cuda:0','out':'A','lambda_mode':'normalized_credit_sensitivity','lambda_design':{'signal_reduction_device':'cuda:0','tracking_rate':.1},'science':1.}
    b=copy.deepcopy(a);b.update(device='cuda:1',physics_device='cuda:1',out='B');b['lambda_design']['signal_reduction_device']='cuda:1';assert scope['normalize_config'](a)==scope['normalize_config'](b)
    b['science']=1.00001;assert scope['normalize_config'](a)!=scope['normalize_config'](b)
    ref=json.loads((ROOT/'COMPARISON_REFERENCE.json').read_text());assert len(ref['rows'])==64 and {(r['method'],r['seed']) for r in ref['rows']}=={(m,s) for m in c.METHODS for s in c.SEEDS}
    assert ref['copied_run_count']==15 and all(r['artifact_hashes'] for r in ref['rows'])
    recovery=json.loads((ROOT/'RECOVERY_BUILD_PROOF.json').read_text());assert recovery['all39_scientific_source_bytes_unchanged'] and recovery['source_hashes']==actual
    expectations=json.loads((ROOT/'HISTORICAL_EXECUTION_EXPECTATIONS.json').read_text());assert len(expectations['rows'])==64
    assert sum(r['determinism']['warp_max_records']==4 for r in expectations['rows'].values())==20
    assert c.DET==expectations['new_formal_and_short_determinism'] and c.DET['warp_max_records']==8
    validator=module('historical_execution_fixture',ROOT/'historical_execution.py').validate_historical_execution
    for row in ref['rows']:
        key=row['method']+'__seed'+str(row['seed']);record=expectations['rows'][key]
        config={'determinism':copy.deepcopy(record['determinism'])};digest=row['artifact_hashes']['config.json']
        assert validator(row,config,digest,expectations['rows'])['state']=='passed'
        for field,bad in [('torch',False),('torch',1),('warp','none'),('cublas_workspace_config',':16:8'),('warp_max_records',7),('warp_max_records',8 if record['determinism']['warp_max_records']==4 else 4)]:
            tampered=copy.deepcopy(config);tampered['determinism'][field]=bad;rejects(validator,row,tampered,digest,expectations['rows'])
        rejects(validator,row,config,'0'*64,expectations['rows'])
        tampered_row=copy.deepcopy(row);tampered_row['method']='unknown';rejects(validator,tampered_row,config,digest,expectations['rows'])
    # A standalone all8 gain can coexist with zero joint subset gains; enforce SAME
    # seed subset across both arms and endpoints in the independent analysis fixture.
    realread=coordinator.read;baseline=[{'method':'fixed95','seed':s,'final_return':0.,'auc':0.} for s in c.SEEDS]
    for method in c.METHODS:
        if method!='fixed95':baseline.extend({'method':method,'seed':s,'final_return':0.,'auc':0.} for s in c.SEEDS)
    coordinator.read=lambda path:{'control_rows':baseline}
    jobs=[{'state':'completed','metrics':{'arm':arm,'seed':s,'final_return':1.,'auc':1.}} for arm in c.ARMS for s in c.SEEDS]
    report=coordinator.analyze(jobs);assert report['retrospective_common_standalone_subsets']['3']['passing_count']==56 and report['retrospective_common_standalone_subsets']['5']['passing_count']==56
    for j in jobs:
        if j['metrics']['arm']=='innovation2':j['metrics']['auc']=-1.
    report=coordinator.analyze(jobs);assert not report['standalone_development_admission_passed'] and all(x['passing_count']==0 for x in report['retrospective_common_standalone_subsets'].values())
    # No individual seed wins all four arm/endpoints, but the common triple's
    # four means are positive. Eligibility must use means, never winner counts.
    values={21:{'innovation1':(3.,-1.),'innovation2':(-1.,3.)},22:{'innovation1':(-1.,3.),'innovation2':(-1.,-1.)},23:{'innovation1':(-1.,-1.),'innovation2':(3.,-1.)}}
    for j in jobs:
        m=j['metrics'];m['final_return'],m['auc']=values.get(m['seed'],{}).get(m['arm'],(-100.,-100.))
    assert not any(all(values[s][arm][i]>0 for arm in c.ARMS for i in (0,1)) for s in values)
    report=coordinator.analyze(jobs);assert report['standalone_development_admission_passed']
    assert report['retrospective_common_standalone_subsets']['3']['passing_seed_sets']==[[21,22,23]] and report['retrospective_common_standalone_subsets']['5']['passing_count']==0
    coordinator.read=realread
    assert not any(n in sys.modules for n in ('torch','warp','mujoco','numpy','scipy'))
    result={'state':'passed','scope':'local stdlib fixtures only; no native numerical or training compatibility claim','Torch_imported':False,'native_actions':0,'checker_sha256':sha(__file__),'source_hashes':actual,'inherited_verifier_functions_literal_except_task_control_map_and_declared_historical_metadata_guard':True,'I1_complete_AST_only_taskguard_version_port':True,'I2_source18_and_native_verifier_bytes_identical':True,'all39_recovery_scientific_source_bytes_unchanged':True,'historical_only20_records4_and44_records8_fixtures_passed':True,'new_short_formal_records8_exact':True,'coordinator_stdlib_only_imported_and_AST_checked':True,'checks':['causal controller invalid rejection','153/164formal and8/9short directonce ledger','independent forward/backward split recursion','sensitivity finite/variance checks','eight shared command fixtures on physical0/1','named device exclusions preserve science tamper','64control provenance schema','same-seed standalone subset positive/negative fixtures','zero individual joint winners but shared triple allfour means pass fixture','historical records4 knownrow+hash-only admission; torchfalse/CUBLAS/recordswap/unknown/hash tamper rejected']}
    dest=ROOT/'CPU_SOURCE_FIXTURES_VERIFIED.json'
    if dest.exists() and not(dest.stat().st_mode&0o222):dest=ROOT/'NATIVE_STDLIB_FIXTURES_VERIFIED.json'
    dest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'state':'passed','Torch_imported':False,'native_actions':0}))
if __name__=='__main__':main()
