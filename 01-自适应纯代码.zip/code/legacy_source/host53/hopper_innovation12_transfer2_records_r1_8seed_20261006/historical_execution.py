"""Verify frozen historical per-row execution metadata; never changes configurations."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def validate_historical_execution(row,config,actual_config_sha256,expectations=None):
    if expectations is None:expectations=json.loads((ROOT/'HISTORICAL_EXECUTION_EXPECTATIONS.json').read_text())['rows']
    key=row['method']+'__seed'+str(row['seed']);assert key in expectations,('unknown historical row',key)
    expected=expectations[key]
    assert expected['method']==row['method'] and expected['seed']==row['seed'] and expected['task']=='Hopper'
    assert actual_config_sha256==row['artifact_hashes']['config.json']==expected['config_sha256'],('historical config hash',key)
    assert row.get('execution_backend','original_eager8')==expected['execution_backend']
    recorded=config['determinism'];required=expected['determinism']
    assert type(recorded) is dict and set(recorded)=={'torch','warp','warp_max_records','cublas_workspace_config'}
    assert type(recorded['torch']) is bool and recorded['torch'] is True
    assert recorded['warp']=='run_to_run' and recorded['cublas_workspace_config']==':4096:8'
    assert type(recorded['warp_max_records']) is int and recorded['warp_max_records'] in (4,8)
    assert recorded==required,('original per-row execution metadata',key)
    if recorded['warp_max_records']==4:
        assert row['method'] in ('fixed90','fixed95','fixed99','linear') and row['seed'] in range(24,29)
        assert expected['execution_backend']=='hopper_graph4_v1'
    return {'state':'passed','config_sha256':actual_config_sha256,'original_determinism':recorded,'execution_backend':expected['execution_backend']}
