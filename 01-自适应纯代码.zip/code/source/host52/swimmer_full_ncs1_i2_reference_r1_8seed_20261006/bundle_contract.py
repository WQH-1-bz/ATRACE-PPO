"""Cold standard-library contracts; no CUDA or scientific package imports."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
NATIVE_ROOT = Path('/home/mumu01/ssd3/wch/swimmer_full_ncs1_i2_reference_r1_8seed_20261006')
OLD_ROOT = Path('/home/mumu01/ssd3/wch/swimmer_innovation12_transfer1_8seed_20261005')
PYTHON = OLD_ROOT / '.venv/bin/python'
GPU_UUID = 'GPU-0fbea1d5-c9c9-392e-5241-f31b8aec2518'
UNIT = 'dpo-swimmer-full-ncs1-i2-reference-r1-8seed-20261006.service'
FLAGS = {'PYTHONUNBUFFERED':'1','PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'1',
         'MKL_NUM_THREADS':'1','DPO_TORCH_DETERMINISTIC':'1',
         'DPO_WARP_DETERMINISTIC':'run_to_run','DPO_WARP_DETERMINISTIC_MAX_RECORDS':'8',
         'CUBLAS_WORKSPACE_CONFIG':':4096:8','DPO_PPO_GRAPH':'0'}
DET = {'torch':True,'warp':'run_to_run','warp_max_records':8,'cublas_workspace_config':':4096:8'}
STRESS = (('none',0.),('gaussian',.1),('gaussian',.15),('gaussian',.3),
          ('multiplicative',.2),('multiplicative',.3))
DISK_FLOOR = 10 * 1024**3

def read(path):
    def invalid(value): raise ValueError('Nonfinite JSON: ' + value)
    return json.loads(Path(path).read_text(), parse_constant=invalid)

def write(path, value):
    path=Path(path); temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temporary.replace(path)

def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):digest.update(block)
    return digest.hexdigest()

def child_env():
    assert 'CUDA_VISIBLE_DEVICES' not in os.environ
    env={**os.environ,**FLAGS}
    for key,sub in [('XDG_CACHE_HOME','cache'),('WARP_CACHE_PATH','cache/warp'),
                    ('CUDA_CACHE_PATH','cache/cuda'),('TORCH_HOME','cache/torch'),('TMPDIR','tmp')]:
        env[key]=str(ROOT/sub)
    return env

def check_manifest():
    manifest=read(ROOT/'MANIFEST.json')
    assert sha(ROOT/'MANIFEST.json')==(ROOT/'MANIFEST.sha256').read_text().strip()
    assert manifest['state']=='READY_source_only' and manifest['formal_total']==8
    for name,digest in manifest['bundle_hashes'].items():
        path=ROOT/name
        assert path.is_file() and sha(path)==digest,('frozen bundle changed',name)
        assert not path.stat().st_mode & 0o222,('frozen file writable',name)
    for sub,key in [('source_full','source_hashes'),('reference_i2','reference_i2_hashes')]:
        assert {p.name for p in (ROOT/sub).iterdir() if p.is_file()}==set(manifest[key])
    return manifest

def gpu_snapshot():
    rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,memory.free,memory.total',
                                  '--format=csv,noheader,nounits'],text=True,timeout=20).splitlines()
    cards={}
    for line in rows:
        index,uuid,free,total=[x.strip() for x in line.split(',')]
        cards[int(index)]={'uuid':uuid,'free_mib':int(free),'total_mib':int(total)}
    assert cards[1]['uuid']==GPU_UUID,('physical GPU1 UUID changed',cards)
    rows=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_gpu_memory',
                                  '--format=csv,noheader,nounits'],text=True,timeout=20).splitlines()
    processes={}
    for line in rows:
        pid,uuid,memory=[x.strip() for x in line.split(',')]
        if uuid==GPU_UUID:
            try:processes[int(pid)]=int(memory)
            except ValueError:raise RuntimeError('Unknown physical GPU1 memory: '+line)
    return {'cards':cards,'gpu1_process_mib':processes,'gpu':1,'uuid':GPU_UUID}

def require_runtime():
    assert ROOT==NATIVE_ROOT,('native execution only',ROOT)
    assert 'CUDA_VISIBLE_DEVICES' not in os.environ
    manifest=check_manifest()
    assert sys.version.startswith('3.10.20 '),(sys.version,'native Python3.10.20 required')
    for name,version in manifest['runtime_versions'].items():
        assert importlib.metadata.version(name)==version,(name,version)
    for key,value in FLAGS.items():assert os.environ.get(key)==value,(key,os.environ.get(key))
    review=read(ROOT/'PARENT_REVIEW_ADMISSION.json')
    assert review['state']=='passed' and review['independent_source_review_passed']
    assert review['manifest_sha256']==sha(ROOT/'MANIFEST.json')
    return manifest

def require_launch():
    require_runtime()
    monitor=read(ROOT/'LUNA_MONITOR_ACTIVE.json')
    assert monitor['state']=='ACTIVE' and monitor['manifest_sha256']==sha(ROOT/'MANIFEST.json')
    assert monitor['initial_snapshot_recorded']
    assert shutil.disk_usage(ROOT).free>=DISK_FLOOR, '10GiB disk reserve required'
    return gpu_snapshot()

def controls():
    from contracts import SEEDS,REPORT_METHODS
    rows=read(ROOT/'COMPARISON_REFERENCE.json')['rows']
    assert len(rows)==80 and {(r['method'],r['seed']) for r in rows}=={(m,s) for m in REPORT_METHODS for s in SEEDS}
    return rows

def verify_historical():
    """Recheck the scoped, parent-verified source/result artifacts; never write old roots."""
    manifest=read(ROOT/'MANIFEST.json');count=0
    for name,digest in manifest['protected_native_sources'].items():
        assert sha(name)==digest,('protected original source changed',name);count+=1
    for row in controls():
        path=Path(row['path'])
        for name,digest in row['artifact_hashes'].items():
            assert sha(path/name)==digest,('protected result changed',path/name);count+=1
        config=read(path/'config.json');summary=read(path/'summary.json')
        assert config['task'] in ('Swimmer','Swimmer-v4 semantics / MJWarp backend') and config['seed']==row['seed']
        assert config['effective_steps']==summary['steps']==10027008
        assert config['xml_sha256']==manifest['xml_sha256']
        assert summary['state']=='completed' and summary['reload_check']=='passed'
        assert summary['final_eval']['mean']==row['final_return']
        assert summary.get('total_algorithm_transitions',10027008)==row.get('total_algorithm_transitions',10027008)
    return {'state':'passed','scoped_protected_files':count,'comparison_rows':80,'old_coordinator_3836894_untouched':True}
