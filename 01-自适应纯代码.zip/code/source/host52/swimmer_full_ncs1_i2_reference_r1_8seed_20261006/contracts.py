"""Pure standard-library budgets and invariants; safe for source-only fixtures."""
import math
SEEDS=tuple(range(21,29))
BUDGET,SHORT=10027008,524288
SWITCH,SHORT_SWITCH=4980736,262144
CONTROL_METHODS=('fixed90','fixed95','fixed99','linear','critic_aware','gradient_ppo','reward_profiling','pae')
REPORT_METHODS=(*CONTROL_METHODS,'innovation1','innovation2')
def ledger(short=False):
    total=(SHORT if short else BUDGET)//1024;switch=(SHORT_SWITCH if short else SWITCH)//1024
    collected=0;retained=[];records=[];consumed=[0]*total
    while collected<total or retained:
        prior=collected;incoming=len(retained);early=prior<switch
        fresh=min(64-incoming,total-prior)
        if early:fresh=min(fresh,switch-prior)
        batch=retained+list(range(prior,prior+fresh));collected+=fresh;flush=early and collected==switch
        used=len(batch) if flush or collected==total else min(56 if early else 64,len(batch))
        for sample in batch[:used]:consumed[sample]+=1
        records.append({'update':len(records)+1,'steps':collected*1024,'prior_collected_steps':prior*1024,'fresh_per_world':fresh,'incoming_retained_per_world':incoming,'end_per_world':len(batch),'used_per_world':used,'retained_per_world':len(batch)-used,'overlap_active':early,'stage_boundary_flush':flush})
        retained=batch[used:]
    assert all(x==1 for x in consumed)
    assert len(records)==(9 if short else 164)
    assert sum(x['overlap_active'] for x in records)==(5 if short else 87)
    assert sum(x['used_per_world'] for x in records)*1024==(SHORT if short else BUDGET)
    assert sum(x['used_per_world'] for x in records)*10==(5120 if short else 97920)
    return records

def require_finite(values):
    if not all(math.isfinite(x) for x in values):raise ValueError('Nonfinite values')

def sensitivity(a,b):
    if len(a)!=len(b) or not a:raise ValueError('Wrong vector shape')
    require_finite([*a,*b]);ma=sum(a)/len(a);mb=sum(b)/len(b)
    va=sum((x-ma)**2 for x in a)/len(a);vb=sum((x-mb)**2 for x in b)/len(b)
    if not(math.isfinite(va) and math.isfinite(vb) and va>0 and vb>0):raise ValueError('Zero/nonfinite SD')
    distance=sum(((x-ma)/math.sqrt(va)-(y-mb)/math.sqrt(vb))**2 for x,y in zip(a,b))/len(a)
    d=min(1.,max(0.,.5*math.sqrt(distance)));require_finite([d]);return d

def split_reference(reward,value,nextvalue,term,done,rho,c,lam):
    n=len(reward)
    if not all(len(x)==n for x in (value,nextvalue,term,done,rho,c)):raise ValueError('Trace shape')
    require_finite([*reward,*value,*nextvalue,*rho,*c])
    if any(t and not d for t,d in zip(term,done)):raise ValueError('terminated implies done')
    delta=[r+.99*(not t)*nv-v for r,t,nv,v in zip(reward,term,nextvalue,value)]
    # Independently expanded future-TD sum, rather than implementation carry loop.
    corrections=[]
    for t in range(n):
        weight=1.;correction=0.
        for k in range(t,n):
            correction+=weight*rho[k]*delta[k]
            weight*=.99*lam*(not done[k])*c[k]
        corrections.append(correction)
    actor=[delta[t]+(.99*lam*(not done[t])*corrections[t+1] if t+1<n else 0.) for t in range(n)]
    returns=[v+d for v,d in zip(value,corrections)];require_finite([*actor,*returns]);return actor,returns
