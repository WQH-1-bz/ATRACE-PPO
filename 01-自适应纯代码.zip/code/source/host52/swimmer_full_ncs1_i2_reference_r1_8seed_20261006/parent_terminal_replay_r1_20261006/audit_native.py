"""Parent terminal saved-data audit; no training or historical score writes."""
import argparse
import hashlib
import importlib.abc
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/home/mumu01/ssd3/wch/swimmer_full_ncs1_i2_reference_r1_8seed_20261006')
OUT = ROOT / 'parent_terminal_replay_r1_20261006'
PIN = 'f58a09d4cf9356fc56e356c74c570b4bb6fd77fab1fa9dd273bd27b1de1bc382'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))

class NoScientificImports(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in ('torch', 'warp', 'mujoco', 'mujoco_warp', 'numpy', 'scipy', 'gymnasium'):
            raise ImportError('Scientific imports forbidden in parent coordinator: ' + fullname)
        return None

sys.meta_path.insert(0, NoScientificImports())
from bundle_contract import PYTHON, read, write, sha, child_env, require_launch, verify_historical, gpu_snapshot, DISK_FLOOR

def binding():
    record = read(OUT / 'LUNA_ACTIVE.json')
    assert record['state'] == 'ACTIVE' and record['manifest_sha256'] == PIN
    assert sha(OUT / 'actual_goal_receipt.json') == record['actual_goal_receipt_sha256']
    assert sha(OUT / 'initial_snapshot.txt') == record['initial_snapshot_sha256']
    actual = read(OUT / 'actual_goal_receipt.json')
    assert actual['goal']['status'] == 'active' and actual['goal']['threadId'] == record['goal_id']
    return record

def normalized_metrics(value):
    result = dict(value)
    result.pop('peak_torch_memory_reserved_bytes', None)
    return result

def main():
    assert Path(__file__).resolve().parent == OUT
    assert not (OUT / 'status.json').exists(), 'No retries or overwrite'
    assert sha(ROOT / 'MANIFEST.json') == PIN
    monitor = binding()
    require_launch()
    protected_before = verify_historical()
    suite = read(ROOT / 'suite_status.json')
    assert suite['state'] == 'completed' and suite['completed_count'] == 8
    assert not suite['active'] and suite['failure'] is None
    assert {j['seed'] for j in suite['jobs']} == set(range(21, 29))
    assert all(j['state'] == 'completed' for j in suite['jobs'])
    original_pins = {str(p): sha(p) for p in (ROOT / 'suite_status.json', ROOT / 'ANALYSIS.json', ROOT / 'ENGINEERING_ACCOUNTING.json', ROOT / 'LUNA_MONITOR_ACTIVE.json')}
    jobs = sorted(suite['jobs'], key=lambda j: j['seed'])
    records = []
    active = {}
    pending = list(jobs)
    failure = None
    start = time.time()
    reservation = 6506

    def status(state):
        write(OUT / 'status.json', {'state': state, 'expected_replays': 8, 'completed_replays': len(records),
            'records': records, 'active': {k: {'pid': v['process'].pid, 'gpu': 1, 'command': v['argv']} for k, v in active.items()},
            'pending_seeds': [j['seed'] for j in pending], 'failure': failure, 'coordinator_pid': os.getpid(),
            'manifest_sha256': PIN, 'reservation_mib': reservation, 'headroom_mib': 512, 'cap': 4,
            'training_transitions': 0, 'new_training_runs': 0, 'elapsed_seconds': time.time() - start})

    def frozen_scalar_check(name):
        argv = [str(PYTHON), str(ROOT / 'run_full.py'), '--verify-only']
        log = OUT / (name + '.log')
        with log.open('x') as stream:
            process = subprocess.Popen(argv, cwd=ROOT, env=child_env(), stdout=stream, stderr=subprocess.STDOUT)
            rc = process.wait()
        result = {'pid': process.pid, 'returncode': rc, 'argv': argv,
                  'output': str(ROOT / 'PARENT_VERIFIED_terminal8.json'),
                  'output_sha256': sha(ROOT / 'PARENT_VERIFIED_terminal8.json') if rc == 0 else None}
        write(OUT / (name + '__execution.json'), result)
        assert rc == 0, (name, rc)
        proof = read(ROOT / 'PARENT_VERIFIED_terminal8.json')
        assert proof['state'] == 'passed' and proof['all8_retained'] and proof['analysis_recomputed']

    try:
        status('starting')
        frozen_scalar_check('PROTECTED_before')
        while pending or active:
            # Reap every finished child before any memory admission.
            for key, item in list(active.items()):
                rc = item['process'].poll()
                if rc is None:
                    continue
                item['stream'].close()
                job = item['job']
                result = {'seed': job['seed'], 'pid': item['process'].pid, 'gpu': 1,
                          'returncode': rc, 'argv': item['argv'], 'output': str(item['result']),
                          'output_sha256': sha(item['result']) if item['result'].exists() else None}
                write(OUT / (key + '__execution.json'), result)
                del active[key]
                if rc != 0:
                    failure = result
                    continue
                value = read(item['result'])
                assert normalized_metrics(value) == normalized_metrics(job['metrics']), ('Saved native result differs', key)
                assert value['controller_replay'] == value['declared_native_replays'] == 'passed'
                assert value['updates'] == 164 and value['steps'] == 10027008
                assert value['all_window_signal_controller_replay'] == 'passed'
                assert value['actual_labels_separated_windows'] > 0 and value['stress_verified']
                reservation = max(reservation, 3500, math.ceil(value['peak_torch_memory_reserved_bytes'] / 1024**2) + 256)
                result['complete_metrics_match'] = True
                records.append(result)
            if failure and not active:
                raise RuntimeError('Replay helper failed; no new admissions')
            if not failure:
                while pending and len(active) < 4:
                    assert shutil.disk_usage(ROOT).free >= DISK_FLOOR
                    snap = gpu_snapshot()
                    initializing = sum(max(0, reservation - snap['gpu1_process_mib'].get(v['process'].pid, 0)) for v in active.values())
                    if snap['cards'][1]['free_mib'] - initializing < reservation + 512:
                        break
                    job = pending.pop(0)
                    key = 'seed' + str(job['seed'])
                    result_path = OUT / (key + '.json')
                    assert not result_path.exists()
                    argv = [str(PYTHON), str(ROOT / 'replay_helper.py'), '--operation', 'verify',
                            '--job-json', str(ROOT / 'results' / (job['id'] + '__input.json')), '--result', str(result_path)]
                    stream = (OUT / (key + '.log')).open('x')
                    process = subprocess.Popen(argv, cwd=ROOT, env=child_env(), stdout=stream, stderr=subprocess.STDOUT)
                    active[key] = {'process': process, 'stream': stream, 'job': job, 'argv': argv, 'result': result_path}
            status('running' if not failure else 'draining_failure')
            if pending or active:
                time.sleep(2)
        frozen_scalar_check('PROTECTED_after')
        assert verify_historical() == protected_before
        assert all(sha(path) == digest for path, digest in original_pins.items())
        write(OUT / 'PARENT_NATIVE_TERMINAL8_VERIFIED.json', {'state': 'passed',
            'manifest_sha256': PIN, 'all8_source_native_results_exact': True,
            'native_replay_exits_zero': 8, 'frozen_scalar_verifier_exits_zero': 2,
            'all8_windows': 164, 'adaptive_actor_replay_scope': 'all adaptive windows',
            'fixed95_critic_exact_replay_updates': [3, 4, 5, 87, 88, 164],
            'cold_first2_primary_scope': 'finite captured payloads; no warmed retroactive equality claim',
            'historical_sources_controls_and_scores_preserved': True, 'protected': protected_before,
            'original_pins': original_pins, 'new_training_runs': 0, 'training_transitions': 0,
            'old_coordinator_3836894_untouched': True, 'Luna': monitor})
        status('completed')
    except Exception as exc:
        failure = {'type': type(exc).__name__, 'message': str(exc), 'existing_failure': failure}
        status('failed')
        raise

if __name__ == '__main__':
    main()
