"""All8 statistical reporting and descriptive same-seed retrospective gate."""
import itertools
import math
import statistics
from contracts import SEEDS,REPORT_METHODS
from bundle_contract import controls
ENDPOINTS=('final_return','auc')
EXTERNAL=('critic_aware','gradient_ppo','reward_profiling','pae')

def beta_fraction(a,b,x):
    # Continued fraction for regularized beta; used only for all8 t-test reporting.
    qab=a+b;qap=a+1.;qam=a-1.;c=1.;d=1.-qab*x/qap
    if abs(d)<1e-300:d=1e-300
    d=1./d;h=d
    for m in range(1,401):
        aa=m*(b-m)*x/((qam+2*m)*(a+2*m))
        d=1.+aa*d;c=1.+aa/c
        if abs(d)<1e-300:d=1e-300
        if abs(c)<1e-300:c=1e-300
        d=1./d;h*=d*c
        aa=-(a+m)*(qab+m)*x/((a+2*m)*(qap+2*m))
        d=1.+aa*d;c=1.+aa/c
        if abs(d)<1e-300:d=1e-300
        if abs(c)<1e-300:c=1e-300
        d=1./d;delta=d*c;h*=delta
        if abs(delta-1.)<3e-14:return h
    raise ArithmeticError('Incomplete beta did not converge')

def t_probability(t):
    x=7./(7.+t*t);a=3.5;b=.5
    if x>=1:return 1.
    front=math.exp(math.lgamma(a+b)-math.lgamma(a)-math.lgamma(b)+a*math.log(x)+b*math.log1p(-x))
    if x<(a+1)/(a+b+2):return front*beta_fraction(a,b,x)/a
    return 1.-front*beta_fraction(b,a,1.-x)/b

def paired(a,b):
    differences=[x-y for x,y in zip(a,b)];mean=statistics.mean(differences);sd=statistics.stdev(differences)
    t=mean/(sd/math.sqrt(8)) if sd else None
    half=2.3646242510102993*sd/math.sqrt(8)
    exact=sum(abs(sum(s*x for s,x in zip(signs,differences))/8)>=abs(mean)-1e-12 for signs in itertools.product((-1,1),repeat=8))/256
    return {'n':8,'df':7,'mean_difference':mean,'sd_difference':sd,'t':t,
            'p_two_sided':t_probability(t) if sd else (0. if mean else 1.),
            'ci95':[mean-half,mean+half],'exact_sign_flip_p':exact,'differences':differences}

def analyze(jobs):
    rows=[j['metrics'] for j in jobs];ours={r['seed']:r for r in rows}
    assert len(rows)==8 and sorted(ours)==list(SEEDS)
    historical=controls();base={(r['method'],r['seed']):r for r in historical}
    tests=[];comparisons={}
    for method in REPORT_METHODS:
        comparisons[method]={}
        for endpoint in ENDPOINTS:
            a=[ours[s][endpoint] for s in SEEDS];b=[base[(method,s)][endpoint] for s in SEEDS]
            result={**paired(a,b),'full_mean':statistics.mean(a),'historical_mean':statistics.mean(b)}
            comparisons[method][endpoint]=result;tests.append(result)
    for source,target in [('p_two_sided','p_holm20'),('exact_sign_flip_p','exact_p_holm20')]:
        carry=0.
        for i,test in enumerate(sorted(tests,key=lambda v:v[source])):
            carry=max(carry,min(1.,(20-i)*test[source]));test[target]=carry
    seed_gate=[]
    for seed in SEEDS:
        endpoints={}
        for endpoint in ENDPOINTS:
            v=lambda method:base[(method,seed)][endpoint]
            endpoints[endpoint]={'base':v('fixed95'),'standalone_i1':v('innovation1'),
                                 'standalone_i2':v('innovation2'),'both':ours[seed][endpoint],
                                 'external':{m:v(m) for m in EXTERNAL},
                                 'passed':v('fixed95')<v('innovation1')<ours[seed][endpoint]
                                          and v('fixed95')<v('innovation2')<ours[seed][endpoint]
                                          and all(ours[seed][endpoint]>v(m) for m in EXTERNAL)}
        seed_gate.append({'seed':seed,'endpoints':endpoints,'passed':all(x['passed'] for x in endpoints.values())})
    qualifying=[r['seed'] for r in seed_gate if r['passed']]
    # User gate is a common subset of paired MEANS, not individual winners.
    subset_reports={};subsets={}
    for n in (3,5):
        reports=[]
        for seeds in itertools.combinations(SEEDS,n):
            full={e:statistics.mean(ours[s][e] for s in seeds) for e in ENDPOINTS}
            means={m:{e:statistics.mean(base[(m,s)][e] for s in seeds) for e in ENDPOINTS}
                   for m in ('fixed95','innovation1','innovation2',*EXTERNAL)}
            passed_by_endpoint={e:means['fixed95'][e]<means['innovation1'][e]<full[e]
                                  and means['fixed95'][e]<means['innovation2'][e]<full[e]
                                  and all(full[e]>means[m][e] for m in EXTERNAL)
                                for e in ENDPOINTS}
            reports.append({'seeds':list(seeds),'Full_mean':full,'historical_means':means,
                            'passed_by_endpoint':passed_by_endpoint,
                            'passed':all(passed_by_endpoint.values())})
        subset_reports[str(n)]=reports
        subsets[str(n)]=[r['seeds'] for r in reports if r['passed']]
    engineering=all(r['controller_replay']==r['declared_native_replays']=='passed' and r['stress_verified'] for r in rows)
    passed=bool(subsets['3'] or subsets['5'])
    return {'state':'completed','task':'Swimmer','round':'Full_NCS1_I2','rows':rows,
            'control_rows':historical,'all8_seeds':list(SEEDS),'engineering_passed':engineering,
            'same_seed_both_endpoint_gate':seed_gate,'qualifying_same_seeds':qualifying,
            'retrospective_qualifying_subsets':subsets,'retrospective_subset_mean_reports':subset_reports,
            'retrospective_subset_pass_counts':{n:len(v) for n,v in subsets.items()},
            'new_user_descriptive_gate_passed':passed,
            'full_training_success':engineering and passed,'all8_comparisons':comparisons,
            'Holm_family':20,'selected_subset_significance_computed':False,
            'subset_scope':'Retrospective development description; same seeds on final and AUC; all8 retained',
            'valid_independent_confirmation':False,'base_reruns':0,'external_reruns':0}
