"""Fresh-process exact Full1 replay; GPU imports never reach coordinator."""
import argparse,ast,copy,csv,hashlib,importlib.util,json,math,os,struct,sys,types
from pathlib import Path
from contracts import BUDGET,SHORT,SWITCH,SHORT_SWITCH,ledger
from bundle_contract import ROOT,DET,STRESS,check_manifest,require_runtime
sys.dont_write_bytecode=True
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import torch
BASEFILES=('config.json','summary.json','status.json','progress.csv','initial_evaluation.json','evaluations.jsonl','latest.pt','stress_evaluation.json','checkpoint_stress_result.json','retained_tail_diagnostics.jsonl','ncs1_decisions.jsonl','first_window_pre.pt','first_window_post.pt')
def read(p):
    def invalid(value):raise ValueError('Nonfinite JSON constant: '+value)
    return json.loads(Path(p).read_text(),parse_constant=invalid)

def write(p,x):
    p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n');tmp.replace(p)

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def jsonl(p):return [json.loads(x) for x in Path(p).read_text().splitlines() if x.strip()]

def exact(a,b):assert type(a)==type(b) and (struct.pack('!d',a)==struct.pack('!d',b) if isinstance(a,float) else a==b),(a,b)

def differences(a,b,path=''):
    if isinstance(a,torch.Tensor):
        if not isinstance(b,torch.Tensor) or a.dtype!=b.dtype or a.shape!=b.shape:return [path]
        return [] if torch.equal(a.detach().cpu().contiguous().reshape(-1).view(torch.uint8),b.detach().cpu().contiguous().reshape(-1).view(torch.uint8)) else [path]
    if isinstance(a,dict):
        if not isinstance(b,dict) or a.keys()!=b.keys():return [path+'.keys']
        return [v for k in a for v in differences(a[k],b[k],path+'.'+str(k))]
    if isinstance(a,(list,tuple)):
        if type(a)!=type(b) or len(a)!=len(b):return [path+'.len']
        return [v for i,(x,y) in enumerate(zip(a,b)) for v in differences(x,y,path+'.'+str(i))]
    if type(a)!=type(b):return [path+'.type']
    return [] if (struct.pack('!d',a)==struct.pack('!d',b) if isinstance(a,float) else a==b) else [path]

def batch(e,device=None):
    assert len(e['returns'])==len(e['lengths'])==32 and all(math.isfinite(v) for v in e['returns'])
    assert all(type(v) is int and 1<=v<=1000 for v in e['lengths'])
    assert math.isfinite(e['mean']) and math.isfinite(e['std'])
    if device:
        v=torch.tensor(e['returns'],dtype=torch.float32,device=device);exact(float(v.mean()),e['mean']);exact(float(v.std(unbiased=False)),e['std'])

def auc(p,budget):
    initial=read(p/'initial_evaluation.json');ev=jsonl(p/'evaluations.jsonl')
    for e in [initial,*ev]:batch(e)
    pts=[(0,initial['mean'])]+[(e['steps'],e['mean']) for e in ev]
    assert pts[-1][0]==budget and all(a[0]<b[0] for a,b in zip(pts,pts[1:]))
    return sum((b[0]-a[0])*(a[1]+b[1])/2 for a,b in zip(pts,pts[1:]))/budget,initial,ev

def controller_class():
    name='full_ncs1_controller'
    if name not in sys.modules:
        spec=importlib.util.spec_from_file_location(name,ROOT/'source_full/lambda_normalized_credit_sensitivity.py');module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return sys.modules[name].NormalizedCreditSensitivity

def signal_reducer():
    name='full_ncs1_signal'
    if name not in sys.modules:
        spec=importlib.util.spec_from_file_location(name,ROOT/'source_full/signal_normalized_credit.py');module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return sys.modules[name].normalized_credit_sensitivity

def primitive(function_name,reference=False):
    name='full_replay_'+function_name+('_reference' if reference else '')
    if name not in sys.modules:
        source=ROOT/('reference_i2' if reference else 'source_full')/'train_pae_baseline.py'
        nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==function_name];assert len(nodes)==1
        module=types.ModuleType(name);module.torch=torch;sys.modules[name]=module
        exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(source),'exec'),module.__dict__)
    return getattr(sys.modules[name],function_name)

def window_names(short=False):return [f'full_window_audits/update_{x["update"]:03d}.pt' for x in ledger(short)]

def legacy_audit_names(short=False):return [f'split_trace_audit_{u:03d}.pt' for u in (3,4 if short else 86,9 if short else 164)]

def checkpoint(path,expected,config):
    x=torch.load(path/'latest.pt',map_location='cpu',weights_only=False);assert x['config']==config and x['steps']==(expected//10*1024)
    assert x['optimizer_steps']=={'actor':expected,'critic':expected,'h':0} and set(x['optimizers'])=={'ppo'}
    opt=x['optimizers']['ppo'];assert opt['state'] and len(opt['state'])==len(x['model'])
    for d in opt['state'].values():
        assert float(d['step'])==expected
        for k in ('exp_avg','exp_avg_sq'):assert bool(torch.isfinite(d[k]).all())
    assert all(bool(torch.isfinite(v).all()) for v in x['model'].values());return x

def replay_window(x,l,device,actual_target_audit):
    for key,value in l.items():exact(x[key],value)
    assert x['target_device']==device and x['gamma']==.99 and x['critic_lambda']==.95
    end,used,incoming=l['end_per_world'],l['used_per_world'],l['incoming_retained_per_world']
    keys=('normalized_reward','values','next_values','terminated','done','raw_rhos','capped_cs')
    for key in (*keys,'trace_logratios','advantage90_full','advantage99_full'):
        t=x[key];assert isinstance(t,torch.Tensor) and t.shape==(end,1024) and t.device.type=='cpu' and not t.requires_grad
        assert t.dtype==(torch.bool if key in ('terminated','done') else torch.float32) and bool(torch.isfinite(t).all())
    for key in ('actor_advantage','consumed_critic_return','fixed95_actor_advantage'):
        t=x[key];assert t.shape==(used*1024,) and t.dtype==torch.float32 and t.device.type=='cpu' and not t.requires_grad and bool(torch.isfinite(t).all())
    assert not bool((x['terminated']&~x['done']).any())
    logs=x['trace_logratios'].to(device);rho=logs.exp();c=logs.clamp(max=0).exp()
    assert torch.equal(rho,x['raw_rhos'].to(device)) and torch.equal(c,x['capped_cs'].to(device))
    assert torch.equal(rho[incoming:],torch.ones_like(rho[incoming:])) and torch.equal(c[incoming:],torch.ones_like(c[incoming:]))
    xs=[x[k].to(device) for k in keys];primary=primitive('split_tail_trace');actor=primitive('actor_split_tail_trace');signal=primitive('signal_split_tail_trace')
    with torch.no_grad():
        if actual_target_audit:
            for _ in range(3):primary(*xs,.99,.95)
            a95,r95=primary(*xs,.99,.95)
            assert torch.equal(a95[:used].flatten(),x['fixed95_actor_advantage'].to(device)) and torch.equal(r95[:used].flatten(),x['consumed_critic_return'].to(device)),('primary95 consumed replay',l['update'])
        if x['actor_lambda']!=.95:
            for _ in range(3):actor(*xs,.99,.95)
            a,_=actor(*xs,.99,x['actor_lambda'])
            assert torch.equal(a[:used].flatten(),x['actor_advantage'].to(device)),('actual adaptive actor replay',l['update'])
        elif actual_target_audit:
            assert torch.equal(a95[:used].flatten(),x['actor_advantage'].to(device)),('shared actual actor95 replay',l['update'])
        for _ in range(3):signal(*xs,.99,.95)
        a90,_=signal(*xs,.99,.90);a99,_=signal(*xs,.99,.99)
        assert torch.equal(a90,x['advantage90_full'].to(device)) and torch.equal(a99,x['advantage99_full'].to(device)),('native signal endpoint replay',l['update'])
        metrics=signal_reducer()(a90[:used].flatten(),a99[:used].flatten())
    for key,value in metrics.items():exact(value,x[key])
    return metrics,not torch.equal(x['actor_advantage'],x['fixed95_actor_advantage'])

def verify(j):
    p=Path(j['path']);short=bool(j.get('smoke'));budget=SHORT if short else BUDGET;ls=ledger(short);device=f"cuda:{j['gpu']}";torch.cuda.set_device(device)
    c=read(p/'config.json');summary=read(p/'summary.json');assert summary==read(p/'status.json') and summary['state']=='completed' and summary['reload_check']=='passed'
    assert c['algorithm_version']=='swimmer_full_ncs1_accepted_i2_v1' and c['source_sha256']==read(ROOT/'MANIFEST.json')['source_hashes']
    assert c['versions']==read(ROOT/'MANIFEST.json')['runtime_versions'] and c['xml_sha256']==read(ROOT/'MANIFEST.json')['xml_sha256']
    assert c['seed']==j['seed'] and c['device']==device and c['determinism']==DET and c['effective_steps']==c['steps']==summary['steps']==budget
    assert c['stage_switch_steps']==(SHORT_SWITCH if short else SWITCH) and c['retained_tail_steps']==8 and c['fixed_critic_lambda']==.95
    assert c['staged_full'] and c['retained_tail_diagnostics'] and c['retained_tail_correction'] and c['retained_td_unclipped'] and c['save_split_trace_audit']
    assert not(c['adaptive_kl'] or c['readiness_boost'] or c['adaptive_overlap'] or c['force_pae_overlap'])
    for key,value in [('num_envs',1024),('rollout',64),('batch_size',1024),('epochs',10),('eval_envs',32),('eval_every',262144)]:assert c[key]==value
    assert summary['training_transitions']==summary['total_algorithm_transitions']==budget and summary['optimizer_steps']=={'actor':budget//1024*10,'critic':budget//1024*10,'h':0}
    assert c['signal_files']==window_names(short)
    assert {str(v.relative_to(p)) for v in (p/'full_window_audits').glob('*.pt')}==set(window_names(short))
    assert {v.name for v in p.glob('split_trace_audit_*.pt')}==set(legacy_audit_names(short))
    rows=list(csv.DictReader((p/'progress.csv').open()));decisions=jsonl(p/'ncs1_decisions.jsonl');diagnostics=jsonl(p/'retained_tail_diagnostics.jsonl');assert len(rows)==len(decisions)==len(diagnostics)==len(ls)
    control=controller_class()();values=[];reports=[];separated=0
    for l,row,d,diag in zip(ls,rows,decisions,diagnostics):
        u=l['update'];assert d['update']==diag['update']==u and d['steps']==int(row['steps'])==l['steps']
        for key in ('fresh_per_world','used_per_world','retained_per_world'):assert int(row[key])==l[key]
        assert row['overlap_active']==str(l['overlap_active']) and row['stage_boundary_flush']==str(l['stage_boundary_flush'])
        assert float(row['gae_lambda_used'])==float(row['gae_lambda_next'])==.95,'Legacy columns describe primary95'
        x=torch.load(p/window_names(short)[u-1],map_location='cpu',weights_only=False)
        assert not differences(x['controller_before_step'],control.state_dict());delta=control.step(u)
        assert not differences(x['controller_before_observe'],control.state_dict());exact(control.value,x['actor_lambda']);exact(control.value,d['actor_lambda']);exact(delta,d['lambda_delta']);exact(.95,d['critic_lambda'])
        actual_target_audit=u in ([3,4,5,6,9] if short else [3,4,5,87,88,164])
        metrics,effect=replay_window(x,l,device,actual_target_audit);separated+=int(effect)
        for key,value in metrics.items():exact(value,d[key])
        control.observe(metrics['d'])
        for key,value in control.state_dict().items():exact(value,d[key])
        for key in ('value_loss','policy_loss','approx_kl','explained_variance'):assert math.isfinite(float(row[key]))
        assert diag['fresh_actor_correction_nonzero_count']==diag['fresh_critic_correction_nonzero_count']==0
        values.append(control.value);reports.append({'update':u,'actor_lambda':control.value,'critic_lambda':.95,'actual_actor_labels_separated':effect,'primary_actual_target_audit':actual_target_audit,'early_cold_primary_targets_not_warmed_retroactively':u in (1,2),**metrics})
    assert values[:4]==[.95]*4 and max(abs(v-.95) for v in values)>1e-12 and separated>0
    saved=checkpoint(p,budget//1024*10,c);assert saved['ncs1_feedback']==control.state_dict()
    area,initial,ev=auc(p,budget);assert len(ev)==(2 if short else 39)
    threshold=262144;expected=[]
    for l in ls:
        if l['steps']>=threshold or l['steps']==budget:expected.append(l['steps']);threshold=(l['steps']//262144+1)*262144
    assert [e['steps'] for e in ev]==expected
    for e in [initial,*ev,summary['final_eval']]:batch(e,device)
    exact(ev[-1]['mean'],summary['final_eval']['mean'])
    # Accepted I2 stores np.trapz AUC; recomputation uses the original evaluation grid.
    assert math.isclose(area,summary['normalized_return_auc'],rel_tol=0.,abs_tol=1e-12)
    stress=read(p/'stress_evaluation.json');assert [(x['mode'],x['scale']) for x in stress]==list(STRESS)
    for e in stress:batch(e,device)
    side=read(p/'checkpoint_stress_result.json');assert side['state']=='passed' and side['training_transitions']==side['optimizer_steps']==0 and side['model_unchanged'] and side['normalizer_unchanged']
    names=[*BASEFILES,*window_names(short),*legacy_audit_names(short)];assert all((p/name).is_file() for name in names)
    return {'seed':j['seed'],'path':str(p),'final_return':summary['final_eval']['mean'],'auc':area,'initial_return':initial['mean'],'updates':len(ls),'steps':budget,'actor_adam_steps':budget//1024*10,'critic_adam_steps':budget//1024*10,'auxiliary_adam_steps':0,'lambda_min':min(values),'lambda_max':max(values),'maximum_lambda_deviation':max(abs(v-.95) for v in values),'controller_replay':'passed','declared_native_replays':'passed','all_window_signal_controller_replay':'passed','primary_actual_target_audit_updates':[3,4,5,6,9] if short else [3,4,5,87,88,164],'first2_primary_targets_scope':'captured finite native payloads; firstwindow direct I2negativecontrol; no warmedretroactive equality claim','actual_labels_separated_windows':separated,'window_reports':reports,'stress_verified':True,'artifact_hashes':{name:sha(p/name) for name in names}}

def exact_pair(first,second):
    ps=[Path(first),Path(second)];delta=[]
    xs=[torch.load(p/'latest.pt',map_location='cpu',weights_only=False) for p in ps]
    for x in xs:x['config'].pop('out')
    delta+=differences(*xs,path='latest.pt')
    for name in [*window_names(True),*legacy_audit_names(True),'first_window_pre.pt','first_window_post.pt']:
        delta+=differences(*(torch.load(p/name,map_location='cpu',weights_only=False) for p in ps),path=name)
    for name in ('initial_evaluation.json','evaluations.jsonl','ncs1_decisions.jsonl','retained_tail_diagnostics.jsonl','stress_evaluation.json'):
        if (ps[0]/name).read_bytes()!=(ps[1]/name).read_bytes():delta.append(name)
    for name in ('config.json','summary.json','status.json'):
        xs=[read(p/name) for p in ps]
        for x in xs:
            for key in ('out','pid','elapsed_seconds','steps_per_second','peak_torch_memory_bytes'):x.pop(key,None)
        delta+=differences(*xs,path=name)
    rows=[list(csv.DictReader((p/'progress.csv').open())) for p in ps]
    for u,(x,y) in enumerate(zip(*rows),1):delta+=[f'progress.{u}.{k}' for k in x if k not in ('elapsed_seconds','steps_per_second') and x[k]!=y[k]]
    assert not delta,delta
    return {'state':'passed','seed':91087,'gpu':1,'short_windows':9,'model_Adam_normalizers_all_scientific_signal_controller_targets_bytes_exact':True,'scientific_non_timing_logs_exact':True,'named_config_summary_status_operational_exclusions':['out','pid','elapsed_seconds','steps_per_second','peak_torch_memory_bytes'],'named_progress_timing_exclusions':['elapsed_seconds','steps_per_second'],'both_allocator_peaks_preserved_max_used_for_memory':True,'no_tolerance_or_retry':True}

def compare_reference(reference,candidate):
    ps=[Path(reference),Path(candidate)]
    for phase in ('pre','post'):
        xs=[torch.load(p/f'first_window_{phase}.pt',map_location='cpu',weights_only=False) for p in ps]
        assert not differences(*xs,path=phase),('original I2 first-window fixed95 control',phase)
    assert (ps[0]/'initial_evaluation.json').read_bytes()==(ps[1]/'initial_evaluation.json').read_bytes()
    return {'state':'passed','original_I2_used56_first_window_before_auxiliary_warmups_exact':True,'pre_targets_inputs_model_Adam_normalizers_exact':True,'post_PPO_model_Adam_normalizers_exact':True,'same_seed91087_GPU1':True}

def verify_reference_provenance(config,receipt,reference_hashes):
    # The unchanged original trainer records five imported implementation files;
    # the read-only capture receipt independently records all eighteen package files.
    keys=('train_pae_baseline.py','external_baseline_algorithms.py','locomotion_warp.py',
          'train_noisy_warp.py','ant_contact_compat.py')
    assert len(reference_hashes)==18 and all(key in reference_hashes for key in keys)
    assert set(config['source_sha256'])==set(keys)
    assert config['source_sha256']=={key:reference_hashes[key] for key in keys}
    assert receipt['state']=='passed' and receipt['source_hashes']==reference_hashes
    return True

def verify_reference(path):
    p=Path(path);c=read(p/'config.json');summary=read(p/'summary.json')
    assert c['task']=='Swimmer' and c['seed']==91087 and c['device']=='cuda:1'
    assert c['effective_steps']==summary['steps']==SHORT and summary['state']=='completed'
    reference_hashes=read(ROOT/'MANIFEST.json')['reference_i2_hashes']
    verify_reference_provenance(c,read(p/'REFERENCE_CAPTURE_VERIFIED.json'),reference_hashes)
    assert c['determinism']==DET and summary['reload_check']=='passed'
    assert summary['optimizer_steps']=={'actor':5120,'critic':5120,'h':0}
    assert len(list(csv.DictReader((p/'progress.csv').open())))==9
    saved=torch.load(p/'latest.pt',map_location='cpu',weights_only=False)
    assert {float(v['step']) for v in saved['optimizers']['ppo']['state'].values()}=={5120.}
    receipt=read(p/'REFERENCE_CAPTURE_VERIFIED.json')
    assert receipt['state']=='passed' and receipt['source_hashes']==reference_hashes
    assert receipt['original_source_unmodified'] and receipt['f_locals_read_only']
    assert receipt['tracer_numerical_state_assignments']==receipt['extra_model_optimizer_environment_calls']==0
    for phase,digest in receipt['snapshots'].items():assert sha(p/f'first_window_{phase}.pt')==digest
    return {'state':'passed','seed':91087,'gpu':1,'path':str(p),'snapshots':receipt['snapshots'],'primary_analysis_excluded':True}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--operation',choices=['verify','pair','reference','compare-reference'],required=True)
    parser.add_argument('--job-json',type=Path);parser.add_argument('--paths',nargs='+');parser.add_argument('--result',type=Path,required=True)
    args=parser.parse_args();require_runtime();torch.set_num_threads(1);torch.use_deterministic_algorithms(True);torch.cuda.set_device('cuda:1')
    if args.operation=='verify':
        job=read(args.job_json);assert job['gpu']==1;result=verify(job)
    elif args.operation=='pair':result=exact_pair(*args.paths)
    elif args.operation=='reference':result=verify_reference(args.paths[0])
    else:result=compare_reference(*args.paths)
    result['peak_torch_memory_reserved_bytes']=torch.cuda.max_memory_reserved('cuda:1')
    assert not args.result.exists();write(args.result,result)
    print(json.dumps({'state':'passed','operation':args.operation,'result':str(args.result)}))

if __name__=='__main__':main()
