"""One real original-I2 short control, read-only runpy line tracing for first window.
Native parent executes this only after review. Source and f_locals never assigned.
"""
import argparse,json,os,runpy,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    import bundle_contract as r
    r.require_runtime();r.check_manifest();source=ROOT/'reference_i2/train_pae_baseline.py'
    assert not a.out.exists() and a.out.resolve().parent==(ROOT/'runs').resolve()
    import importlib.util
    spec=importlib.util.spec_from_file_location('full_snapshot_capture',ROOT/'source_full/full_capture.py');capture=importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
    lines=source.read_text().splitlines();pre=next(i for i,line in enumerate(lines,1) if line.strip()=='env.check_capacity()');post=next(i for i,line in enumerate(lines,1) if line.strip()=='steps = collected_time * a.num_envs')
    pins=r.read(ROOT/'MANIFEST.json')['reference_i2_hashes']
    for name,digest in pins.items():assert r.sha(ROOT/'reference_i2'/name)==digest
    captured=set()
    def trace(frame,event,arg):
        if frame.f_code.co_filename!=str(source) or frame.f_code.co_name!='main':return None
        if event!='line':return trace
        locals_read_only=frame.f_locals
        if locals_read_only.get('update')!=1:return trace
        phase='pre' if frame.f_lineno==pre else 'post' if frame.f_lineno==post else None
        if phase is None or phase in captured:return trace
        x=locals_read_only;metadata=dict(update=1,steps=x['collected_time']*1024,actor_lambda=.95,critic_lambda=.95)
        if phase=='pre':
            used=x['used'];metadata.update(observation=x['ob'][:used].flatten(0,1).detach().cpu().clone(),action=x['ac'][:used].flatten(0,1).detach().cpu().clone(),behavior_logprob=x['lp'][:used].flatten().detach().cpu().clone(),actor_advantage=x['adv'][:used].flatten().detach().cpu().clone(),consumed_critic_return=x['ret'][:used].flatten().detach().cpu().clone())
        capture.snapshot_state(a.out/f'first_window_{phase}.pt',x['model'],x['optimizers'],x['normal'],x['rnormal'],metadata)
        captured.add(phase)
        if captured=={'pre','post'}:
            sys.settrace(prior);return None
        return trace
    from run_full import reference_command
    command=reference_command(str(a.out))
    sys.path.insert(0,str(ROOT/'reference_i2'));sys.argv=command[1:]
    prior=sys.gettrace();sys.settrace(trace)
    try:runpy.run_path(str(source),run_name='__main__')
    finally:sys.settrace(prior)
    assert captured=={'pre','post'}
    for name,digest in pins.items():assert r.sha(ROOT/'reference_i2'/name)==digest
    receipt={'state':'passed','scope':'one prospective engineering control; no scientific baseline rerun','seed':91087,'gpu':1,'training_transitions':524288,'shared_adam_calls':5120,'windows':9,'source_hashes':pins,'original_source_unmodified':True,'f_locals_read_only':True,'tracer_numerical_state_assignments':0,'extra_model_optimizer_environment_calls':0,'captured_before_extra_auxiliary_warmups':True,'capture_phases':['pre','post'],'snapshots':{phase:r.sha(a.out/f'first_window_{phase}.pt') for phase in ('pre','post')}}
    r.write(a.out/'REFERENCE_CAPTURE_VERIFIED.json',receipt)
if __name__=='__main__':main()
