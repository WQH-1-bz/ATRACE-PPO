"""Standard-library coordinator; trainers, stress and replay are fresh executables."""
import argparse
import importlib.abc
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback
from contracts import BUDGET,SHORT,SWITCH,SHORT_SWITCH,SEEDS
from bundle_contract import ROOT,PYTHON,OLD_ROOT,GPU_UUID,DISK_FLOOR,read,write,sha,child_env,check_manifest,require_launch,gpu_snapshot,verify_historical
from analysis_full import analyze

def command(job):
    short=bool(job.get('smoke'));budget=SHORT if short else BUDGET;cut=SHORT_SWITCH if short else SWITCH
    assert job['gpu']==1
    return [str(PYTHON),str(ROOT/'source_full/train_pae_baseline.py'),'--out',job['path'],
            '--method','pae','--task','Swimmer','--seed',str(job['seed']),'--device','cuda:1',
            '--steps',str(budget),'--num-envs','1024','--rollout','64','--batch-size','1024',
            '--eval-envs','32','--eval-every','262144','--staged-full','--stage-switch-steps',str(cut),
            '--retained-tail-steps','8','--retained-tail-diagnostics','--retained-tail-correction',
            '--retained-td-unclipped','--save-split-trace-audit','--overlap-start-steps','0',
            '--overlap-stop-steps',str(budget)]

def reference_command(path):
    argv=command({'gpu':1,'seed':91087,'smoke':True,'path':path})
    argv[1]=str(ROOT/'reference_i2/train_pae_baseline.py');return argv

def reservation_for_peak(peak):return max(3500,math.ceil(peak)+256)

def fits(snapshot,active,reservation):
    memory=snapshot['gpu1_process_mib']
    initializing=sum(max(0,reservation-memory.get(value['process'].pid,0)) for value in active.values())
    return len(active)<8 and snapshot['cards'][1]['free_mib']-initializing>=reservation+512

class NoScientificImports(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in ('torch','warp','mujoco','mujoco_warp','numpy','scipy','gymnasium'):
            raise ImportError('Scientific package forbidden in stdlib coordinator: '+fullname)
        return None

def new_job(ident,seed,smoke=False):
    return {'id':ident,'seed':seed,'gpu':1,'smoke':smoke,'path':str(ROOT/'runs'/ident),'state':'pending'}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--prepare-only',action='store_true')
    parser.add_argument('--verify-only',action='store_true');args=parser.parse_args()
    sys.meta_path.insert(0,NoScientificImports())
    assert not any(n.split('.')[0] in ('torch','warp','mujoco','numpy') for n in sys.modules)
    require_launch();protected=verify_historical();manifest=check_manifest()
    if args.prepare_only:
        write(ROOT/'PREPARE_PASSED.json',{'state':'passed','protected':protected,'training_started':False});return 0
    if args.verify_only:
        suite=read(ROOT/'suite_status.json');assert suite['state']=='completed' and suite['completed_count']==8
        assert suite['engineering_gate']['state']=='passed' and not suite['active']
        assert analyze(suite['jobs'])==read(ROOT/'ANALYSIS.json')
        for job in suite['jobs']:
            for name,digest in job['metrics']['artifact_hashes'].items():assert sha(Path(job['path'])/name)==digest
        write(ROOT/'PARENT_VERIFIED_terminal8.json',{'state':'passed','all8_retained':True,'analysis_recomputed':True,'protected':protected});return 0
    assert not (ROOT/'suite_status.json').exists(), 'No restart or retry'
    for sub in ('runs','results','cache','cache/warp','cache/cuda','cache/torch','tmp'):(ROOT/sub).mkdir(parents=True,exist_ok=True)
    smokes=[new_job('smoke_Full_'+repeat,91087,True) for repeat in ('a','b')]
    jobs=[new_job('Swimmer__Full_NCS1_I2__seed'+str(seed),seed) for seed in SEEDS]
    reference=new_job('engineering_reference_I2_seed91087',91087,True);reference['reference']=True
    historical=Path('/home/mumu01/ssd3/wch/swimmer_full_ncs1_i2_8seed_20261006/runs/engineering_reference_I2_seed91087')
    capture_names=('first_window_pre.pt','first_window_post.pt','REFERENCE_CAPTURE_VERIFIED.json')
    if all((historical/name).is_file() for name in capture_names):
        reference.update(path=str(historical),state='reference_pending',reused=True)
        reference['protected_reused_files']={p.name:sha(p) for p in historical.iterdir() if p.is_file()}
    else:raise RuntimeError('Pinned completed original-I2 reference capture missing; no repeat authorized')
    assert all(not Path(j['path']).exists() for j in [*smokes,*jobs]+([] if reference['reused'] else [reference]))
    active={};failure=None;gate=None;worker_peak=0;all_peak=0;card_peak=0;reservation=3500;start=time.time()
    pair={'id':'short_pair','state':'pending','gpu':1};latest_snapshot=None
    def status(state):
        write(ROOT/'suite_status.json',{'state':state,'task':'Swimmer','round':'Full_NCS1_I2','total':8,
            'completed_count':sum(j['state']=='completed' for j in jobs),'formal_training_started_count':sum('training_pid' in j for j in jobs),
            'jobs':jobs,'smoke_jobs':smokes,'reference_job':reference,'engineering_gate':gate,
            'active':{k:{'pid':v['process'].pid,'gpu':1,'stage':v['stage'],'command':v['command'],
                         'sampled_peak_mib':v['peak']} for k,v in active.items()},'failure':failure,
            'reservation_mib':reservation,'initializing_workers_charged':True,'headroom_mib':512,'max_per_gpu':8,
            'worker_sampled_or_allocator_peak_mib':worker_peak,'all_children_sampled_or_allocator_peak_mib':all_peak,
            'card_all_process_sampled_peak_mib':card_peak,'latest_gpu_snapshot':latest_snapshot,
            'peak_scope':'Sampled NVML process/card usage and separately reported Torch allocator peaks',
            'coordinator_pid':os.getpid(),'coordinator_cuda_imported':False,'coordinator_command':[str(PYTHON),str(ROOT/'run_full.py')],
            'elapsed_seconds':time.time()-start,'old_coordinator_3836894_untouched':True,'automatic_restart':False})
    def spawn(job,stage):
        nonlocal latest_snapshot
        latest_snapshot=gpu_snapshot()
        if not fits(latest_snapshot,active,reservation):return False
        assert shutil.disk_usage(ROOT).free>=DISK_FLOOR,'10GiB disk reserve reached'
        result=ROOT/'results'/(job['id']+'__'+stage+'.json');assert not result.exists()
        if stage=='training':argv=command(job)
        elif stage=='reference_training':argv=[str(PYTHON),str(ROOT/'reference_negative_control.py'),'--out',job['path']]
        elif stage=='stress':argv=[str(PYTHON),str(ROOT/'stress_checkpoint_gpu1.py'),'--job-path',job['path'],'--device','cuda:1']
        else:
            argv=[str(PYTHON),str(ROOT/'replay_helper.py'),'--operation',stage,'--result',str(result)]
            if stage=='verify':
                job_file=ROOT/'results'/(job['id']+'__input.json');write(job_file,job);argv+=['--job-json',str(job_file)]
            elif stage=='reference':argv+=['--paths',job['path']]
            elif stage=='compare-reference':argv+=['--paths',reference['path'],job['path']]
            else:argv+=['--paths',*[j['path'] for j in smokes]]
        log=ROOT/(job['id']+'__'+stage+'.log');stream=log.open('x')
        try:process=subprocess.Popen(argv,cwd=ROOT,env=child_env(),stdout=stream,stderr=subprocess.STDOUT)
        except BaseException:stream.close();raise
        active[job['id']]={'process':process,'stream':stream,'job':job,'stage':stage,'result':result,'command':argv,'peak':0}
        job['state']=stage+'_running';job['command']=argv;job['pid']=process.pid
        if stage=='training':job['training_pid']=process.pid
        return True
    def done(value):
        nonlocal worker_peak,all_peak,reservation
        job=value['job'];stage=value['stage'];path=Path(job.get('path',ROOT));process=value['process']
        assert process.returncode==0,('child failed',job['id'],stage,process.returncode)
        allocator=0
        if stage in ('training','reference_training'):
            summary=read(path/'summary.json');assert summary['state']=='completed'
            allocator=math.ceil(summary.get('peak_torch_memory_bytes',0)/1048576)
            worker_peak=max(worker_peak,value['peak'],allocator)
            job['state']='reference_pending' if stage=='reference_training' else 'stress_pending'
        elif stage=='stress':
            report=read(path/'checkpoint_stress_result.json');assert report['state']=='passed'
            allocator=math.ceil(report['peak_torch_memory_reserved_bytes']/1048576);job['state']='verify_pending'
        else:
            report=read(value['result']);allocator=math.ceil(report.pop('peak_torch_memory_reserved_bytes')/1048576)
            if stage=='verify':
                job['metrics']=report;job['state']='compare-reference_pending' if job.get('smoke') else 'completed'
            elif stage=='compare-reference':job['reference_comparison']=report;job['state']='completed'
            else:job['metrics']=report;job['state']='completed'
        job.setdefault('process_history',[]).append({'stage':stage,'pid':process.pid,'command':value['command'],
                    'returncode':process.returncode,'sampled_peak_mib':value['peak'],'torch_allocator_peak_mib':allocator})
        all_peak=max(all_peak,value['peak'],allocator);reservation=reservation_for_peak(all_peak)
    try:
        status('engineering_pending')
        while True:
            latest_snapshot=gpu_snapshot();card_peak=max(card_peak,latest_snapshot['cards'][1]['total_mib']-latest_snapshot['cards'][1]['free_mib'])
            for ident,value in list(active.items()):
                value['peak']=max(value['peak'],latest_snapshot['gpu1_process_mib'].get(value['process'].pid,0))
                if value['process'].poll() is not None:
                    value['stream'].close();del active[ident]
                    try:done(value)
                    except BaseException as exc:failure={'id':ident,'stage':value['stage'],'error':repr(exc),'traceback':traceback.format_exc()};value['job']['state']='failed'
            if failure:
                status('failure_active_workers_preserved' if active else 'failed')
                if not active:return 1
            elif gate is None:
                if not active:
                    if reference['state']!='completed':
                        spawn(reference,'reference_training' if reference['state']=='reference_training_pending' else 'reference')
                    else:
                        pending=next((j for j in smokes if j['state']!='completed'),None)
                        if pending:
                            stage='training' if pending['state']=='pending' else pending['state'].removesuffix('_pending');spawn(pending,stage)
                        elif pair['state']!='completed':spawn(pair,'pair')
                        else:
                            check_manifest();verify_historical()
                            if reference['reused']:
                                for name,digest in reference['protected_reused_files'].items():assert sha(Path(reference['path'])/name)==digest
                            gate={'state':'passed','pair':pair['metrics'],'original_I2_control':reference['metrics'],
                                  'original_firstwindow_comparisons':[j['reference_comparison'] for j in smokes],
                                  'new_original_I2_engineering_runs':int(not reference['reused']),
                                  'new_original_I2_engineering_transitions':0 if reference['reused'] else SHORT,
                                  'strict_native_signal_controller_and_declared_target_audits':'passed',
                                  'cold_primary1_2_not_retroactively_warmed':True,'reservation_mib':reservation}
                            write(ROOT/'SMOKE_VERIFIED.json',gate)
                status('engineering_running' if active else 'engineering_waiting_for_gpu_memory')
            elif all(j['state']=='completed' for j in jobs):
                check_manifest();verify_historical();analysis=analyze(jobs)
                analysis['engineering_control_runs']=int(not reference['reused']);analysis['engineering_control_transitions']=0 if reference['reused'] else SHORT
                # Keep the pure all8 recomputation identical in --verify-only.
                write(ROOT/'ENGINEERING_ACCOUNTING.json',{'new_reference_runs':int(not reference['reused']),'new_reference_transitions':0 if reference['reused'] else SHORT,'short_pair_transitions':2*SHORT})
                analysis.pop('engineering_control_runs');analysis.pop('engineering_control_transitions')
                write(ROOT/'ANALYSIS.json',analysis);status('completed');return 0
            else:
                # Queue every formal seed first, then completion helpers; every child shares the cap and reservation.
                for job in jobs:
                    if job['id'] in active or job['state']=='completed':continue
                    stage='training' if job['state']=='pending' else job['state'].removesuffix('_pending')
                    if not spawn(job,stage):break
                status('running' if active else 'waiting_for_gpu_memory')
            time.sleep(2)
    except BaseException as exc:
        failure={'id':'coordinator','error':repr(exc),'traceback':traceback.format_exc()}
        status('failed_active_workers_preserved' if active else 'failed');raise

if __name__=='__main__':sys.exit(main())
