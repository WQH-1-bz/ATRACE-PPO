"""Local stdlib-only final freeze. Never run native commands, imports or training."""
import ast
import hashlib
import json
from pathlib import Path
import sys
from bundle_contract import ROOT,read,sha,write,NATIVE_ROOT,OLD_ROOT,GPU_UUID,UNIT

def main():
    assert str(ROOT).startswith('/home/mumu08/ssd_2/wch/dpo/runs/')
    assert not (ROOT/'MANIFEST.json').exists(), 'Frozen bundle must not be rebuilt'
    from check_source import check
    fixtures=check();write(ROOT/'SOURCE_FIXTURES.json',fixtures)
    origin=ROOT.parent/'walker_full_ncs1_i2_8seed_20261005'
    old=ROOT.parent/'swimmer_innovation12_transfer1_8seed_20261005'
    local_pins={}
    for directory in (origin/'source_full',old/'source_i1',old/'source_i2'):
        for path in directory.iterdir():
            if path.is_file():local_pins[str(path)]=sha(path)
    analysis=Path(read(ROOT/'COMPARISON_REFERENCE.json')['source_analysis_path'])
    local_pins[str(analysis)]=sha(analysis)
    write(ROOT/'LOCAL_PROTECTED_INPUTS.json',{'state':'verified','files':local_pins,'scope':'Only selected recipe source, Swimmer original source and parent terminal endpoint analysis'})
    proof={'state':'passed','selected_recipe':'Walker Full1 NCS1 + accepted I2',
           'source_origin':str(origin/'source_full'),'source_files':21,
           'other20_bytes_exact':True,'only_trainer_task_guard_and_algorithm_version_changed':True,
           'reference_i2_original18_bytes_exact':True,'scientific_delta':None,
           'exact_source_diff_sha256':sha(ROOT/'SOURCE_DIFF.patch'),
           'verified_replay_source_sha256':sha(ROOT/'evidence/WALKER_RUN_FULL.py'),
           'verified_stress_source_sha256':sha(ROOT/'evidence/VERIFIED_SWIMMER_STRESS.py'),
           'stdlib_fixture_sha256':sha(ROOT/'SOURCE_FIXTURES.json'),
           'local_inputs_before_after_identical':all(sha(p)==d for p,d in local_pins.items()),
           'native_actions_executed':False,'scientific_packages_imported':False,
           'parent_independent_review_required_before_deployment':True}
    write(ROOT/'STATIC_SOURCE_PROOF.json',proof)
    old_manifest=read(ROOT/'evidence/ORIGINAL_SWIMMER_MANIFEST.json')
    native_sources={str(OLD_ROOT/sub/name):digest for arm,sub in [('innovation1','source_i1'),('innovation2','source_i2')]
                    for name,digest in old_manifest['source_hashes'][arm].items()}
    source={p.name:sha(p) for p in (ROOT/'source_full').iterdir() if p.is_file()}
    reference={p.name:sha(p) for p in (ROOT/'reference_i2').iterdir() if p.is_file()}
    files={str(p.relative_to(ROOT)):sha(p) for p in ROOT.rglob('*') if p.is_file()}
    manifest={'state':'READY_source_only','task':'Swimmer','round':'Full_NCS1_I2',
              'algorithm_version':'swimmer_full_ncs1_accepted_i2_v1','selected_prior_recipe':'Walker Full1',
              'native_root':str(NATIVE_ROOT),'host':'wch@192.168.5.52','service':UNIT,
              'formal_total':8,'seeds':list(range(21,29)),'gpus':[1],'physical_gpu_uuid':GPU_UUID,
              'CUDA_VISIBLE_DEVICES':None,'max_per_gpu':8,'smoke_seed':91087,
              'formal_budget':10027008,'short_budget':524288,'formal_switch':4980736,'short_switch':262144,
              'formal_windows':164,'short_windows':9,'formal_adam_calls':97920,'short_adam_calls':5120,
              'critic_lambda':.95,'actor_hold_windows':4,'earliest_adaptive_actor_window':5,
              'new_reference_runs_if_capture_missing':0,'reused_completed_reference_root':'/home/mumu01/ssd3/wch/swimmer_full_ncs1_i2_8seed_20261006/runs/engineering_reference_I2_seed91087','new_short_AB_runs':2,
              'all_window_signal_controller_replay':True,
              'formal_primary_target_audit_updates':[3,4,5,87,88,164],
              'short_primary_target_audit_updates':[3,4,5,6,9],
              'cold_primary1_2_scope':'Saved finite; firstwindow originalI2 direct equality; no retrospective warmed replay claim',
              'strict_numeric_tolerance_added':False,'checkpoint_only_stress_conditions':6,'stress_episodes_per_condition':32,
              'source_hashes':source,'reference_i2_hashes':reference,'bundle_hashes':files,
              'protected_native_sources':native_sources,'protected_scoped_comparator_rows':80,
              'runtime_versions':old_manifest['runtime_versions'],'native_python':'3.10.20',
              'xml_sha256':old_manifest['xml_sha256'],'minimum_worker_reservation_mib':3500,
              'peak_safety_mib':256,'card_headroom_mib':512,'initializing_children_charged':True,
              'minimum_disk_free_bytes':10*1024**3,'coordinator_stdlib_only':True,
              'fresh_subprocess_for_every_trainer_stress_replay':True,'base_reruns':0,'external_reruns':0,
              'all8_retained':True,'same_seed_retrospective_subset_sizes':[3,5],
              'selected_subset_significance':False,'all8_Holm_family':20,'independent_confirmation':False,
              'full_training_success':False,'native_actions_executed':False,'native_training_launched':False,
              'Torch_imported_by_builder':False,'old_coordinator_3836894_untouched':True,
              'parent_review_before_deploy':True,'Luna_ACTIVE_initial_snapshot_before_launch':True,
              'automatic_retry_or_sweep':False,'manifest_self_pin':'MANIFEST.sha256'}
    write(ROOT/'MANIFEST.json',manifest)
    (ROOT/'MANIFEST.sha256').write_text(sha(ROOT/'MANIFEST.json')+'\n')
    for p in ROOT.rglob('*'):
        if p.is_file():p.chmod(0o444)
    from bundle_contract import check_manifest
    check_manifest()
    assert all(sha(p)==d for p,d in local_pins.items())
    print(json.dumps({'state':'READY_source_only','root':str(ROOT),'manifest_sha256':sha(ROOT/'MANIFEST.json'),
                      'frozen_files':len(files)+2,'protected_native_sources':len(native_sources),'comparison_rows':80}))

if __name__=='__main__':main()
