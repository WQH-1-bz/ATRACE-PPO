"""Create only new runtime directories; no installation or scientific imports."""
from bundle_contract import ROOT,require_runtime,check_manifest,verify_historical,write

def main():
    require_runtime();manifest=check_manifest();proof=verify_historical()
    assert not (ROOT/'suite_status.json').exists()
    for name in ('runs','results','cache','cache/warp','cache/cuda','cache/torch','tmp'):
        (ROOT/name).mkdir(parents=True,exist_ok=True)
    write(ROOT/'PREPARE_PASSED.json',{'state':'passed','manifest_state':manifest['state'],
                                    'protected':proof,'new_training_transitions':0,'installations':0})

if __name__=='__main__':main()
