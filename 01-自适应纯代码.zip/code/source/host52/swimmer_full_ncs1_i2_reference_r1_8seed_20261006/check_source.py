"""Read-only stdlib fixtures, Python3.10 grammar and frozen bundle validation."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from bundle_contract import ROOT,read,sha
from contracts import ledger,sensitivity,split_reference,SEEDS

def node(tree,name):return next(n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==name)
def ahash(value):return hashlib.sha256(ast.dump(value,include_attributes=False).encode()).hexdigest()

def check():
    source=ROOT/'source_full/train_pae_baseline.py';text=source.read_text()
    inherited=read(ROOT/'evidence/WALKER_FULL1_MANIFEST.json')['source_hashes']
    current={p.name:sha(p) for p in (ROOT/'source_full').iterdir() if p.is_file()}
    assert len(current)==21 and set(current)==set(inherited)
    assert all(current[name]==digest for name,digest in inherited.items() if name!='train_pae_baseline.py')
    reverted=text.replace("assert a.task == 'Swimmer' and a.method == 'pae'","assert a.task == 'Walker2d' and a.method == 'pae'").replace('swimmer_full_ncs1_accepted_i2_v1','walker_full_ncs1_accepted_i2_v1')
    assert hashlib.sha256(reverted.encode()).hexdigest()==inherited['train_pae_baseline.py']
    reference=read(ROOT/'evidence/ORIGINAL_SWIMMER_MANIFEST.json')['source_hashes']['innovation2']
    assert len(reference)==18 and all(sha(ROOT/'reference_i2'/n)==d for n,d in reference.items())
    tree=ast.parse(text);primary=node(tree,'split_tail_trace')
    for name in ('actor_split_tail_trace','signal_split_tail_trace'):
        clone=copy.deepcopy(node(tree,name));clone.name='split_tail_trace';assert ahash(clone)==ahash(primary)
    original=ast.parse((ROOT/'evidence/WALKER_RUN_FULL.py').read_text());helper=ast.parse((ROOT/'replay_helper.py').read_text())
    for name in ('replay_window','checkpoint','differences','exact','batch','auc','primitive','controller_class','signal_reducer'):
        assert ahash(node(original,name))==ahash(node(helper,name)),('verified Full1 replay changed',name)
    provenance=node(helper,'verify_reference_provenance')
    scope={};exec(compile(ast.Module(body=[provenance],type_ignores=[]),'reference_provenance_fixture','exec'),scope)
    hashes=reference;keys=('train_pae_baseline.py','external_baseline_algorithms.py','locomotion_warp.py','train_noisy_warp.py','ant_contact_compat.py')
    config={'source_sha256':{key:hashes[key] for key in keys}};receipt={'state':'passed','source_hashes':hashes}
    assert scope['verify_reference_provenance'](config,receipt,hashes)
    cases=[]
    bad=copy.deepcopy(config);bad['source_sha256'][keys[0]]='0'*64;cases.append((bad,receipt))
    bad=copy.deepcopy(config);bad['source_sha256'].pop(keys[0]);cases.append((bad,receipt))
    bad=copy.deepcopy(config);bad['source_sha256']['extra.py']='0'*64;cases.append((bad,receipt))
    badreceipt=copy.deepcopy(receipt);badreceipt['source_hashes'][next(key for key in hashes if key not in keys)]='0'*64;cases.append((config,badreceipt))
    for config_case,receipt_case in cases:
        try:scope['verify_reference_provenance'](config_case,receipt_case,hashes)
        except AssertionError:pass
        else:raise AssertionError('Mutated provenance accepted')
    formal,short=ledger(),ledger(True)
    assert (len(formal),len(short))==(164,9)
    assert sum(x['used_per_world'] for x in formal)*10==97920
    assert sum(x['used_per_world'] for x in short)*10==5120
    spec=importlib.util.spec_from_file_location('fixture_controller',ROOT/'source_full/lambda_normalized_credit_sensitivity.py')
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    controller=module.NormalizedCreditSensitivity();observations=[.2,.3,.4,.5,.7,.6,.5,.4,.3]
    used=[]
    for update,d in enumerate(observations,1):
        controller.step(update);used.append(controller.value);controller.observe(d)
    assert used[:4]==[.95]*4 and used[4]!=.95 and all(.90<=x<=.99 for x in used)
    assert sensitivity([1.,2.,3.],[2.,4.,6.])<1e-14
    a,r=split_reference([1.,2.],[0.,0.],[0.,0.],[False,True],[False,True],[1.,1.],[1.,1.],.95)
    assert a==r and a[0]==1.+.99*.95*2. and a[1]==2.
    # Coordinator imports its complete graph without importing any scientific package.
    import run_full
    assert not any(n.split('.')[0] in ('torch','warp','numpy','mujoco','scipy','gymnasium') for n in sys.modules)
    assert run_full.command({'gpu':1,'seed':21,'path':'fixture','smoke':False})[run_full.command({'gpu':1,'seed':21,'path':'fixture'}).index('--device')+1]=='cuda:1'
    assert run_full.reservation_for_peak(5000)==5256
    class Process:
        pid=123
    fake={'process':Process()}
    snap={'gpu1_process_mib':{},'cards':{1:{'free_mib':7512}}}
    assert run_full.fits(snap,{'a':fake},3500)
    snap['cards'][1]['free_mib']=7511;assert not run_full.fits(snap,{'a':fake},3500)
    snap['cards'][1]['free_mib']=999999;assert not run_full.fits(snap,{str(i):fake for i in range(8)},3500)
    import analysis_full
    from contracts import REPORT_METHODS
    assert abs(analysis_full.t_probability(2.3646242510102993)-.05)<1e-9
    synthetic=[]
    for method in REPORT_METHODS:
        for seed in SEEDS:
            value=1. if method=='fixed95' else 2. if method=='innovation1' else 3. if method=='innovation2' else 0.
            synthetic.append({'method':method,'seed':seed,'final_return':value,'auc':value})
    prior_controls=analysis_full.controls
    analysis_full.controls=lambda:synthetic
    try:
        fake_jobs=[{'metrics':{'seed':seed,'final_return':4. if seed in (21,23,25) else 0.,
                             'auc':4. if seed in (21,23,25) else 0.,'controller_replay':'passed',
                             'declared_native_replays':'passed','stress_verified':True}} for seed in SEEDS]
        report=analysis_full.analyze(fake_jobs)
        assert report['qualifying_same_seeds']==[21,23,25] and report['retrospective_qualifying_subsets']['3']==[[21,23,25]]
        assert report['new_user_descriptive_gate_passed'] and report['all8_seeds']==list(SEEDS)
        fake_jobs[0]['metrics']['auc']=0.;assert not analysis_full.analyze(fake_jobs)['new_user_descriptive_gate_passed']
        # Complementary seed errors: nobody individually wins, paired means do.
        for row in synthetic:
            if row['seed'] in (21,22,23):
                index=row['seed']-21
                values={'innovation1':(0.,3.,3.),'innovation2':(3.,0.,3.),'pae':(0.,0.,5.)}
                if row['method'] in values:
                    row['final_return']=row['auc']=values[row['method']][index]
        fake_jobs=[{'metrics':{'seed':seed,'final_return':4. if seed in (21,22,23) else 0.,
                             'auc':4. if seed in (21,22,23) else 0.,'controller_replay':'passed',
                             'declared_native_replays':'passed','stress_verified':True}} for seed in SEEDS]
        report=analysis_full.analyze(fake_jobs)
        assert report['qualifying_same_seeds']==[]
        assert [21,22,23] in report['retrospective_qualifying_subsets']['3']
        assert report['new_user_descriptive_gate_passed']
        assert len(report['retrospective_subset_mean_reports']['3'])==56
        assert len(report['retrospective_subset_mean_reports']['5'])==56
        for job in fake_jobs:job['metrics']['auc']=0.
        assert not analysis_full.analyze(fake_jobs)['new_user_descriptive_gate_passed']
    finally:analysis_full.controls=prior_controls
    compiled=[]
    for path in ROOT.rglob('*.py'):
        ast.parse(path.read_text(),filename=str(path),feature_version=(3,10));compile(path.read_text(),str(path),'exec');compiled.append(str(path.relative_to(ROOT)))
    return {'state':'passed','source_files':21,'other20_bytes_exact':True,'trainer_only_taskguard_version_changed':True,
            'reference_i2_18_bytes_exact':True,'reference_exact5_config_and_full18_receipt_scope_fixtures':True,'verified_replay_functions_AST_exact':True,'formal_windows':164,
            'short_windows':9,'formal_shared_Adam':97920,'short_shared_Adam':5120,'actor_first4_fixed95':True,
            'earliest_adaptive_actor_window':5,'initializing_memory_charged':True,'max_children8':True,
            'same_seed_both_endpoint_gate_positive_and_negative_fixtures':True,
            'subset_means_complementary_zero_individual_winner_fixture':True,
            'all56_triples_all56_quintuples_enumerated':True,
            'Python3_10_grammar_and_compile_passed':compiled,'scientific_imports':0,'native_actions':0}

if __name__=='__main__':
    result=check()
    if (ROOT/'MANIFEST.json').exists():
        from bundle_contract import check_manifest
        check_manifest()
    print(json.dumps(result,indent=2))
