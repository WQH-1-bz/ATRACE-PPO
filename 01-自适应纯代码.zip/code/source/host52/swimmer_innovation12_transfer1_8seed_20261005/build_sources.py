"""Local stdlib-only task port and literal inherited-verifier extraction."""
import ast,copy,difflib,hashlib,json,shutil,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
WORK=ROOT.parents[1]
NCS=WORK/'runs/walker_innovation1_ncs1_8seed_20261004'
I2=WORK/'runs/walker_innovation12_transfer1_8seed_20261003'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,text):
    p=ROOT/name;assert not p.exists();p.write_text(text)
def extract(origin,names,header,replacements=()):
    source=origin.read_text();nodes={n.name:n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)}
    chunks=[ast.get_source_segment(source,nodes[name]) for name in names]
    text=header+'\n\n'+'\n\n'.join(chunks)+'\n'
    for before,after in replacements:
        assert before in text,before;text=text.replace(before,after)
    return text
def main():
    assert 'torch' not in sys.modules
    hashes={}
    for arm,origin in [('innovation1',NCS/'source_i1'),('innovation2',I2/'source_i2')]:
        folder=ROOT/('source_i1' if arm=='innovation1' else 'source_i2');folder.mkdir(exist_ok=False)
        for p in origin.iterdir():
            if p.is_file():shutil.copyfile(p,folder/p.name)
        expected=21 if arm=='innovation1' else 18;assert len(list(folder.iterdir()))==expected
        hashes[arm]={p.name:sha(p) for p in folder.iterdir() if p.is_file()}
    trainer=ROOT/'source_i1/train_kl_relative.py';old=trainer.read_text()
    new=old.replace("assert args.task == 'Walker2d' and", "assert args.task == 'Swimmer' and").replace("'walker_i1_normalized_credit_sensitivity1_v1'","'swimmer_i1_normalized_credit_sensitivity1_v1'")
    assert old!=new and new.count("assert args.task == 'Swimmer' and")==1;trainer.write_text(new)
    write('SOURCE_I1_TASK_DIFF.patch',''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='original_Walker_NCS1/train_kl_relative.py',tofile='Swimmer/source_i1/train_kl_relative.py')))
    header='''"""Inherited standalone NCS1 verification; task/schema port only, no launcher."""
import ast,csv,hashlib,importlib.util,json,math,struct,sys,types
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parent
BUDGET,SHORT=10027008,524288
DET={'torch':True,'warp':'run_to_run','warp_max_records':8,'cublas_workspace_config':':4096:8'}
STRESS=(('none',0.),('gaussian',.1),('gaussian',.15),('gaussian',.3),('multiplicative',.2),('multiplicative',.3))
BASEFILES=('config.json','summary.json','status.json','progress.csv','initial_evaluation.json','evaluations.jsonl','latest.pt','stress_evaluation.json')
def controls():return read(ROOT/'COMPARISON_REFERENCE.json')['rows']
'''
    ncsnames=('read','sha','jsonl','exact','differences','batch','auc','controller_class','gae_primitive','ledger','signal_names','audit_names','checkpoint','signal_reducer','sensitivity_signal','target_audits','verify')
    port=(("read(ROOT/'MANIFEST.json')['source_hashes']","read(ROOT/'MANIFEST.json')['source_hashes']['innovation1']"),
          ("read(ROOT/'PROTECTED_INVENTORY.json')['xml_sha256']","read(ROOT/'RUNTIME_REFERENCE.json')['xml_sha256']"),
          ("'walker_i1_normalized_credit_sensitivity1_v1'","'swimmer_i1_normalized_credit_sensitivity1_v1'"),
          ("    if not short:\n        base=next(r for r in controls() if r['method']=='fixed95' and r['seed']==j['seed']);assert (p/'initial_evaluation.json').read_bytes()==(Path(base['path'])/'initial_evaluation.json').read_bytes()\n", "    # Parent prospective rule: retain historical initial scores/provenance; no cross-host byte identity gate.\n"))
    write('ncs1_native_verifier.py',extract(NCS/'run_ncs1.py',ncsnames,header,port))
    i2header='''"""Literal inherited standalone I2 accounting and actual split-target verification."""
import ast,csv,hashlib,json,math,sys,types
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parent
SOURCE_DIRS={'innovation2':ROOT/'source_i2'}
BUDGET,SHORT,SWITCH,SHORT_SWITCH=10027008,524288,4980736,262144
SPLIT_TRACE_REPLAY_WARMUP_COUNT=3
def read(path):return json.loads(path.read_text())
def jsonl(path):return [json.loads(x) for x in path.read_text().splitlines() if x.strip()]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
'''
    i2names=('checkpoint_steps','split_audit_updates','split_audit_names','source_i2_functions','verify_split_trace_audits','verify_i2','verify_split_diagnostics','verify_correction')
    write('i2_native_verifier.py',extract(I2/'run_innovation_transfer_walker1.py',i2names,i2header))
    stress=(I2/'stress_checkpoint_walker1.py').read_text()
    for before,after in [("('cuda:0', 'cuda:1')","('cuda:0', 'cuda:1', 'cuda:2')"),("ROOT / 'LAUNCH_MANIFEST.json'","ROOT / 'MANIFEST.json'"),("'Walker2d'","'Swimmer'"),("ActorCritic(17, 6)","ActorCritic(8, 2)"),("RunningStats((17,),","RunningStats((8,),"),("(32, 17, 6, 1000)","(32, 8, 2, 1000)")]:
        assert before in stress,before;stress=stress.replace(before,after)
    # Extra telemetry is observational and does not alter model/env/optimizer calls.
    stress=stress.replace("**accounting}","'peak_torch_memory_reserved_bytes':torch.cuda.max_memory_reserved(device), **accounting}")
    write('stress_checkpoint.py',stress)
    actual={arm:{p.name:sha(p) for p in (ROOT/('source_i1' if arm=='innovation1' else 'source_i2')).iterdir() if p.is_file()} for arm in hashes}
    for arm in actual:write(('source_i1' if arm=='innovation1' else 'source_i2')+'_hashes.json',json.dumps(actual[arm],indent=2)+'\n')
    assert actual['innovation2']==hashes['innovation2']
    assert {n:v for n,v in actual['innovation1'].items() if n!='train_kl_relative.py'}=={n:v for n,v in hashes['innovation1'].items() if n!='train_kl_relative.py'}
    oldtree=ast.parse(old);newtree=ast.parse(new)
    for tree in (oldtree,newtree):
        for n in ast.walk(tree):
            if isinstance(n,ast.Assert) and ast.get_source_segment(old if tree is oldtree else new,n).startswith('assert args.task'):
                n.test.values[0].comparators[0].value='TASK_PORT'
            if isinstance(n,ast.Assign) and isinstance(n.value,ast.Constant) and n.value.value in ('walker_i1_normalized_credit_sensitivity1_v1','swimmer_i1_normalized_credit_sensitivity1_v1'):n.value.value='VERSION_PORT'
    assert ast.dump(oldtree,include_attributes=False)==ast.dump(newtree,include_attributes=False)
    proof={'state':'built_local_only','Torch_imported':False,'native_actions':0,'original_source_hashes':hashes,'source_hashes':actual,'I1_only_task_guard_and_algorithm_version_changed':True,'I1_remaining_complete_AST_exact':True,'I2_all18_bytes_unchanged':True,'inherited_NCS1_verifier_functions':list(ncsnames),'inherited_I2_verifier_functions':list(i2names),'verifier_extraction_origins':{'innovation1':sha(NCS/'run_ncs1.py'),'innovation2':sha(I2/'run_innovation_transfer_walker1.py')},'crosshost_historical_initial_evaluation_byte_gate_removed_prospectively':True,'crossGPU_samehost_scientific_identity_not_relaxed':True,'stress_task_port':'Swimmer8obs/2actions/GPU0,1,2 only; six frozen-checkpoint conditions unchanged'}
    write('SOURCE_BUILD_MANIFEST.json',json.dumps(proof,indent=2)+'\n');print(json.dumps({'state':'source_built','I1_files':21,'I2_files':18,'Torch_imported':False,'native_actions':0}))
if __name__=='__main__':main()
