"""Reviewable parent-only staged transport/start; builder never invokes native stages."""
import argparse,hashlib,json,shlex,subprocess,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
HOST='wch@192.168.5.52'
NATIVE='/home/mumu01/ssd3/wch/swimmer_innovation12_transfer1_8seed_20261005'
UNIT='dpo-swimmer-innovation12-transfer1-8seed-20261005.service'
STAGING=ROOT.parent/'swimmer_innovation12_parent_20261005/staging'
OUT=ROOT.parent/'swimmer_innovation12_parent_20261005/deployment'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bundle():
    m=json.loads((ROOT/'MANIFEST.json').read_text());ref=json.loads((ROOT/'COMPARISON_REFERENCE.json').read_text());OUT.mkdir(exist_ok=True)
    for name,digest in m['bundle_hashes'].items():assert sha(ROOT/name)==digest and (ROOT/name).stat().st_mode&0o777==0o444
    archive=OUT/'SWIMMER_SOURCE_AND_ORIGINAL64.tar.gz'
    with tarfile.open(archive,'w:gz') as stream:
        for name in m['deployment_files']:stream.add(ROOT/name,arcname=name,recursive=False)
        for native,digest in ref['files'].items():
            relative=Path(native).relative_to(NATIVE);p=STAGING/relative;assert sha(p)==digest;info=stream.gettarinfo(str(p),arcname=str(relative));info.mode=0o444
            with p.open('rb') as source:stream.addfile(info,source)
    (OUT/'PAYLOAD_MANIFEST.json').write_text(json.dumps({'manifest_sha256':sha(ROOT/'MANIFEST.json'),'archive_sha256':sha(archive),'source_files':len(m['deployment_files']),'original_copied_control_files':len(ref['files']),'native_root':NATIVE,'unit':UNIT},indent=2)+'\n');return archive
def ssh(command):return subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',HOST,command],capture_output=True,text=True,timeout=600)
def main():
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=('bundle','deploy','prepare','install-unit','start'),required=True);a=p.parse_args();OUT.mkdir(exist_ok=True);q=shlex.quote
    if a.stage=='bundle':print(json.dumps({'state':'bundle_ready','path':str(bundle()),'native_executed':False}));return
    if a.stage=='deploy':
        archive=bundle();result=ssh('\n'.join(['set -eu','test ! -e '+q(NATIVE),'mkdir '+q(NATIVE)]));assert result.returncode==0,(result.stdout,result.stderr)
        result=subprocess.run(['scp','-q','-o','BatchMode=yes','-o','ConnectTimeout=10',str(archive),HOST+':'+NATIVE+'/SWIMMER_SOURCE_AND_ORIGINAL64.tar.gz'],capture_output=True,text=True,timeout=600);assert result.returncode==0
        result=ssh('tar -xzf '+q(NATIVE+'/SWIMMER_SOURCE_AND_ORIGINAL64.tar.gz')+' -C '+q(NATIVE))
    elif a.stage=='prepare':
        runtime=json.loads((ROOT/'RUNTIME_REFERENCE.json').read_text());env='PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 CUBLAS_WORKSPACE_CONFIG=:4096:8'
        if runtime['analysis_dependencies']:env+=' PYTHONPATH='+q(runtime['analysis_dependencies'])
        result=ssh('\n'.join(['set -eu',env+' '+q(runtime['venv']+'/bin/python')+' '+q(NATIVE+'/prepare_native.py'),env+' '+q(NATIVE+'/.venv/bin/python')+' '+q(NATIVE+'/check_source.py'),env+' '+q(NATIVE+'/.venv/bin/python')+' '+q(NATIVE+'/run_transfer.py')+' --prepare-only']))
    elif a.stage=='install-unit':
        result=ssh('\n'.join(['set -eu','test -e '+q(NATIVE+'/PREPARE_PASSED.json'),'mkdir -p "$HOME/.config/systemd/user"','test ! -e "$HOME/.config/systemd/user/'+UNIT+'"','cp '+q(NATIVE+'/'+UNIT)+' "$HOME/.config/systemd/user/"','systemctl --user daemon-reload','systemctl --user show '+q(UNIT)+' --property=ExecStart,Restart,KillMode,ActiveState']))
    else:
        result=ssh('\n'.join(['set -eu','test -e '+q(NATIVE+'/PARENT_LUNA_PRELAUNCH_VERIFIED.json'),'test -e '+q(NATIVE+'/PARENT_CONTEXT_PROTECTION_VERIFIED.json'),'test -e '+q(NATIVE+'/PREPARE_PASSED.json'),'test ! -e '+q(NATIVE+'/suite_status.json'),'systemctl --user start '+q(UNIT),'systemctl --user show '+q(UNIT)+' --property=ActiveState,SubState,MainPID,Result']))
    receipt={'stage':a.stage,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'native_root':NATIVE,'unit':UNIT};(OUT/(a.stage.upper()+'_RESULT.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));assert result.returncode==0
if __name__=='__main__':main()
