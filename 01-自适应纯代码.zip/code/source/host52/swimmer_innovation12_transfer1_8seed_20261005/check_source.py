"""Meaningful stdlib-only source, schedule, mathematical and CLI fixtures."""
import ast,copy,hashlib,importlib.util,json,math,sys
from pathlib import Path
import contracts as c
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def reject(fn,*args):
    try:fn(*args)
    except (AssertionError,ValueError,OverflowError):return
    raise AssertionError('Invalid fixture accepted')
def main():
    assert 'torch' not in sys.modules
    proof=json.loads((ROOT/'SOURCE_BUILD_MANIFEST.json').read_text());actual={}
    for arm,folder in [('innovation1','source_i1'),('innovation2','source_i2')]:
        actual[arm]={p.name:sha(p) for p in (ROOT/folder).iterdir() if p.is_file()};assert actual[arm]==proof['source_hashes'][arm]
    assert actual['innovation2']==proof['original_source_hashes']['innovation2']
    assert {n:v for n,v in actual['innovation1'].items() if n!='train_kl_relative.py'}=={n:v for n,v in proof['original_source_hashes']['innovation1'].items() if n!='train_kl_relative.py'}
    source=(ROOT/'source_i1/train_kl_relative.py').read_text();origin=source.replace("assert args.task == 'Swimmer' and", "assert args.task == 'Walker2d' and").replace("'swimmer_i1_normalized_credit_sensitivity1_v1'","'walker_i1_normalized_credit_sensitivity1_v1'")
    assert hashlib.sha256(origin.encode()).hexdigest()==proof['original_source_hashes']['innovation1']['train_kl_relative.py']
    for p in ROOT.rglob('*.py'):ast.parse(p.read_text(),feature_version=(3,10));compile(p.read_text(),str(p),'exec')
    tree=ast.parse(source);nodes={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)};clone=copy.deepcopy(nodes['gae_signal']);clone.name='gae';assert ast.dump(clone,include_attributes=False)==ast.dump(nodes['gae'],include_attributes=False)
    spec=importlib.util.spec_from_file_location('stdlib_swimmer_controller',ROOT/'source_i1/lambda_normalized_credit_sensitivity.py');mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
    control=mod.NormalizedCreditSensitivity();sequence=[.2,.3,.4,.5,.6,.7,.8,.9]
    for u,d in enumerate(sequence,1):
        before=control.state_dict();delta=control.step(u)
        if u<=4:assert control.value==.95 and delta==0.
        else:assert control.value==min(.99,max(.90,before['value']+max(-.001,min(.001,.1*(before['target']-before['value'])))))
        actor_lambda=control.value;control.observe(d);assert control.value==actor_lambda
        if u%4==0:assert control.target==min(.99,max(.90,.90+.09*sum(sequence[u-4:u])/4))
    for d in (math.nan,math.inf,-.01,1.01):reject(mod.NormalizedCreditSensitivity().observe,d)
    for arm in c.ARMS:
        for short in (False,True):
            rows=c.ledger(arm,short);assert sum(r['fresh_per_world']*1024 for r in rows)==sum(r['used_per_world']*1024 for r in rows)==(c.SHORT if short else c.BUDGET)
            if arm=='innovation2':
                flush=[r for r in rows if r['stage_boundary_flush']];assert len(flush)==1 and flush[0]['end_per_world']==flush[0]['used_per_world']==(32 if short else 48)
    # Forward expanded TD sum independently checks original backwards split recursion.
    reward=[.2,.4,-.3,.1,.7];value=[.3,.2,.1,.4,.2];nv=[.2,.1,.4,.2,.5];term=[False,False,False,True,False];done=[False,True,False,True,False];rho=[.8,1.6,1.,1.,1.];cap=[min(1.,x) for x in rho]
    endpoints=[]
    for lam in (.90,.95,.99):
        actor,ret=c.expanded_trace(reward,value,nv,term,done,rho,cap,lam);carry=0.;aa=[0.]*len(reward);rr=[0.]*len(reward)
        for i in range(len(reward)-1,-1,-1):
            delta=reward[i]+.99*(not term[i])*nv[i]-value[i];aa[i]=delta+.99*lam*(not done[i])*carry;carry=cap[i]*aa[i]+(rho[i]-cap[i])*delta;rr[i]=value[i]+carry
        assert all(abs(x-y)<1e-12 for xs,ys in ((actor,aa),(ret,rr)) for x,y in zip(xs,ys));endpoints.append(actor)
    a,b=endpoints[0],endpoints[2];d=c.sensitivity(a,b);assert abs(d-c.sensitivity([2*x+3 for x in a],[5*x-7 for x in b]))<1e-12
    assert c.sensitivity(a,a)==0. and abs(c.sensitivity(a,[-x for x in a])-1)<1e-12
    reject(c.sensitivity,[1.,1.],[1.,2.]);reject(c.sensitivity,[1.,math.nan],[1.,2.])
    invalid=term.copy();invalid[0]=True;reject(c.expanded_trace,reward,value,nv,invalid,done,rho,cap,.95)
    driver=ast.parse((ROOT/'run_transfer.py').read_text());command=next(n for n in driver.body if isinstance(n,ast.FunctionDef) and n.name=='command')
    scope={'ROOT':ROOT,'BUDGET':c.BUDGET,'SHORT':c.SHORT,'SWITCH':c.SWITCH,'SHORT_SWITCH':c.SHORT_SWITCH};exec(compile(ast.fix_missing_locations(ast.Module(body=[command],type_ignores=[])),'command_fixture','exec'),scope)
    for arm in c.ARMS:
        for short in (False,True):
            for gpu in range(3):
                cmd=scope['command']({'arm':arm,'smoke':short,'seed':91087 if short else 21,'gpu':gpu,'path':'fixture'});assert cmd[cmd.index('--task')+1]=='Swimmer' and cmd[cmd.index('--device')+1]=='cuda:'+str(gpu)
                if arm=='innovation2':assert cmd[cmd.index('--overlap-start-steps')+1]=='0' and cmd[cmd.index('--overlap-stop-steps')+1]==str(c.SHORT if short else c.BUDGET)
    source=(ROOT/'run_transfer.py').read_text();assert "'--job-path'" in source and "c['versions']" not in source and "summary['physics_device']==summary['device']" in source
    assert 'physics_device' in c.CONFIG_TELEMETRY and 'lambda_design.signal_reduction_device' in source and "d.pop('target_device',None)" in source
    assert "read_bytes()==(Path(base['path'])" not in (ROOT/'ncs1_native_verifier.py').read_text()
    normalize=next(n for n in driver.body if isinstance(n,ast.FunctionDef) and n.name=='normalize_config');scope={'copy':copy,'CONFIG_TELEMETRY':c.CONFIG_TELEMETRY};exec(compile(ast.fix_missing_locations(ast.Module(body=[normalize],type_ignores=[])),'normalize_fixture','exec'),scope)
    aa={'device':'cuda:0','physics_device':'cuda:0','out':'A','lambda_mode':'normalized_credit_sensitivity','lambda_design':{'signal_reduction_device':'cuda:0','tracking_rate':.1},'science':1.}
    bb=copy.deepcopy(aa);bb.update(device='cuda:2',physics_device='cuda:2',out='B');bb['lambda_design']['signal_reduction_device']='cuda:2';assert scope['normalize_config'](aa)==scope['normalize_config'](bb)
    bb['science']=1.00001;assert scope['normalize_config'](aa)!=scope['normalize_config'](bb)
    assert 'torch' not in sys.modules
    output={'state':'passed','scope':'stdlib source/math/CLI only; no native replay or training compatibility claim','Torch_imported':False,'native_actions':0,'source_hashes':actual,'checker_sha256':sha(Path(__file__)),'checks':['I1 only taskguard/version labels','I2 original18 bytes','Python3.10 syntax','isolatedGAE exactbody','causal controller hold/step/observe order','finite/zeroSD/mask rejection','independent expanded splitTDsum','positive shift/scale invariant d','I1 153/8 I2 164/9 transitionsonce/Adam','actual threeGPU CLI/short overlap bounds','actual physicsGPU checked and named exclusions only','scientific config tamper remains visible','crosshost historical initial gate removed prospectively']}
    dest=ROOT/'CPU_SOURCE_FIXTURES_VERIFIED.json'
    if dest.exists() and not(dest.stat().st_mode&0o222):dest=ROOT/'NATIVE_STDLIB_FIXTURES_VERIFIED.json'
    dest.write_text(json.dumps(output,indent=2)+'\n');print(json.dumps({'state':'passed','checks':len(output['checks']),'Torch_imported':False,'native_actions':0}))
if __name__=='__main__':main()
