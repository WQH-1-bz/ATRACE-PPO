"""Parent-owned Swimmer standalone NCS1/I2 queue; one strict six-short admission."""
import argparse,ast,copy,csv,hashlib,importlib.metadata,itertools,json,math,os,statistics,subprocess,sys,time,traceback
from pathlib import Path
sys.dont_write_bytecode=True
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import torch
from scipy import stats
import ncs1_native_verifier as ncs
import i2_native_verifier as i2
from contracts import ARMS,SEEDS,METHODS,BUDGET,SHORT,SWITCH,SHORT_SWITCH,DET,CONFIG_TELEMETRY,PROGRESS_TELEMETRY,ledger
ROOT=Path(__file__).resolve().parent
ENV={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONUNBUFFERED':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','DPO_TORCH_DETERMINISTIC':'1','DPO_WARP_DETERMINISTIC':'run_to_run','DPO_WARP_DETERMINISTIC_MAX_RECORDS':'8','CUBLAS_WORKSPACE_CONFIG':':4096:8','DPO_PPO_GRAPH':'0','XDG_CACHE_HOME':str(ROOT/'cache'),'WARP_CACHE_PATH':str(ROOT/'cache/warp'),'CUDA_CACHE_PATH':str(ROOT/'cache/cuda'),'TORCH_HOME':str(ROOT/'cache/torch'),'TMPDIR':str(ROOT/'tmp')}
STRESS=(('none',0.),('gaussian',.1),('gaussian',.15),('gaussian',.3),('multiplicative',.2),('multiplicative',.3))
read=ncs.read;sha=ncs.sha;jsonl=ncs.jsonl;exact=ncs.exact;differences=ncs.differences;batch=ncs.batch;auc=ncs.auc
def write(path,obj):
    path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n');tmp.replace(path)
def command(j):
    short=bool(j.get('smoke'));budget=SHORT if short else BUDGET
    folder='source_i1' if j['arm']=='innovation1' else 'source_i2';trainer='train_kl_relative.py' if j['arm']=='innovation1' else 'train_pae_baseline.py'
    cmd=[str(ROOT/'.venv/bin/python'),str(ROOT/folder/trainer),'--out',j['path'],'--task','Swimmer','--seed',str(j['seed']),'--device','cuda:'+str(j['gpu']),'--steps',str(budget),'--num-envs','1024','--rollout','64','--batch-size','1024','--eval-envs','32','--eval-every','262144']
    if j['arm']=='innovation1':cmd+=['--epochs','10','--adaptive-start-update','4','--adaptive-start-steps','0','--fixed-critic-lambda','.95','--save-fixed-critic-audit']
    else:cmd+=['--method','pae','--staged-full','--stage-switch-steps',str(SHORT_SWITCH if short else SWITCH),'--overlap-start-steps','0','--overlap-stop-steps',str(budget),'--retained-tail-steps','8','--retained-tail-correction','--retained-tail-diagnostics','--retained-td-unclipped','--save-split-trace-audit']
    return cmd
def controls():
    rows=read(ROOT/'COMPARISON_REFERENCE.json')['rows'];assert len(rows)==64
    assert {(r['method'],r['seed']) for r in rows}=={(m,s) for m in METHODS for s in SEEDS}
    return rows
def check_sources():
    m=read(ROOT/'MANIFEST.json');assert m['state']=='READY_local_only' and m['task']=='Swimmer' and m['formal_total']==16 and m['max_per_gpu']==8
    for name,digest in m['bundle_hashes'].items():assert sha(ROOT/name)==digest and not((ROOT/name).stat().st_mode&0o222),('source mutation',name)
    r=read(ROOT/'RUNTIME_REFERENCE.json');assert r['state']=='verified_actual_host52' and sys.version==r['python']
    for package,version in r['versions'].items():assert importlib.metadata.version(package)==version,(package,version)
    assert importlib.metadata.version('scipy')==r['scipy_version']
    for arm,folder in [('innovation1','source_i1'),('innovation2','source_i2')]:
        expected=m['source_hashes'][arm];assert len(expected)==(21 if arm=='innovation1' else 18)
        assert {p.name for p in (ROOT/folder).iterdir() if p.is_file()}==set(expected)
        assert expected==read(ROOT/(folder+'_hashes.json'))
    t=ast.parse((ROOT/'source_i1/train_kl_relative.py').read_text());nn={n.name:n for n in t.body if isinstance(n,ast.FunctionDef)}
    clone=copy.deepcopy(nn['gae_signal']);clone.name='gae';assert ast.dump(clone,include_attributes=False)==ast.dump(nn['gae'],include_attributes=False)
    assert hashlib.sha256(ast.dump(nn['gae'],include_attributes=False).encode()).hexdigest()==m['primary_GAE_AST_sha256']
    import gymnasium
    xml=Path(gymnasium.__file__).parent/'envs/mujoco/assets/swimmer.xml';assert sha(xml)==r['xml_sha256']
    return m
def verify_protected():
    inventory=read(ROOT/'PROTECTED_INVENTORY.json');assert inventory['state']=='verified' and inventory['files']
    copied=read(ROOT/'COMPARISON_REFERENCE.json')['files']
    for name,digest in inventory['files'].items():
        assert sha(name)==digest,('protected mutation',name)
        if name in copied:assert not(Path(name).stat().st_mode&0o222),('copied control unfrozen',name)
    reports=[]
    for row in controls():
        p=Path(row['path']);c=read(p/'config.json');s=read(p/'summary.json');status=read(p/'status.json');method=row['method']
        assert c['task'].startswith('Swimmer') and c['seed']==row['seed'] and c['determinism']==DET
        assert c['xml_sha256']==read(ROOT/'RUNTIME_REFERENCE.json')['xml_sha256']
        assert s['state']==status['state']=='completed' and s['reload_check']=='passed' and s['steps']==BUDGET
        assert c.get('effective_steps',c.get('steps'))==BUDGET
        for k,v in [('num_envs',1024),('rollout',64),('batch_size',1024),('eval_envs',32),('eval_every',262144)]:assert c[k]==v
        for name,digest in row['artifact_hashes'].items():assert sha(p/name)==digest and inventory['files'][str(p/name)]==digest
        area,initial,ev=auc(p,BUDGET);exact(area,row['auc']);exact(s['final_eval']['mean'],row['final_return']);assert len(ev)==39
        progress=list(csv.DictReader((p/'progress.csv').open()));assert len(progress)==(204 if method=='pae' else 153)
        expected=[];threshold=262144
        for point in progress:
            step=int(point['steps'])
            if step>=threshold or step==BUDGET:expected.append(step);threshold=(step//262144+1)*262144
        assert [v['steps'] for v in ev]==expected
        total=s.get('total_algorithm_transitions',BUDGET);assert total==row['total_algorithm_transitions']
        if method=='reward_profiling':
            decisions=jsonl(p/'profiling_decisions.jsonl');assert len(decisions)==10;extra=physical=0
            for decision in decisions:
                lengths=[decision[k]['lengths'] for k in ('old','new')];assert all(len(xs)==5 and all(type(x) is int and 1<=x<=1000 for x in xs) for xs in lengths)
                valid=sum(lengths[0])+sum(lengths[1]);simulated=5*(max(lengths[0])+max(lengths[1]));assert valid==decision['extra_transitions'] and simulated==decision['simulated_transitions'];extra+=valid;physical+=simulated
            assert total==BUDGET+extra and extra==s['profiling_extra_transitions'] and physical==s['profiling_simulated_transitions']
        else:assert total==BUDGET
        saved=torch.load(p/'latest.pt',map_location='cpu',weights_only=False)
        if method=='gradient_ppo':
            assert set(saved['optimizers'])=={'actor','critic','h'}
            for optimizer in saved['optimizers'].values():assert {float(v['step']) for v in optimizer['state'].values()}=={39168.}
        else:
            optimizer=saved.get('optimizer') or saved['optimizers']['ppo'];values={float(v['step']) for v in optimizer['state'].values()};assert values==({48960.,97920.} if method=='critic_aware' else {97920.})
        reports.append({'method':method,'seed':row['seed'],'original_path':row['original_path'],'copied_path':str(p),'final_return':row['final_return'],'auc':area,'initial_return':initial['mean'],'original_total_algorithm_transitions':total})
    return {'state':'passed','protected_files':len(inventory['files']),'control_rows':64,'original_control_reports':reports,'crosshost_initial_byte_equality_required':False}
def verify_i2(j):
    p=Path(j['path']);short=bool(j.get('smoke'));budget=SHORT if short else BUDGET
    c=read(p/'config.json');s=read(p/'summary.json');assert s==read(p/'status.json') and s['state']=='completed' and s['reload_check']=='passed'
    assert c['task']=='Swimmer' and c['seed']==j['seed'] and c['device']=='cuda:'+str(j['gpu']) and c['determinism']==DET
    # Original accepted I2 config does not record package versions; check_sources pins actual interpreter/runtime globally.
    assert c['xml_sha256']==read(ROOT/'RUNTIME_REFERENCE.json')['xml_sha256']
    assert c['steps']==c['effective_steps']==s['steps']==budget
    for k,v in [('num_envs',1024),('rollout',64),('batch_size',1024),('epochs',10),('eval_envs',32),('eval_every',262144)]:assert c[k]==v
    assert c['method']=='pae' and c['staged_full'] and c['stage_switch_steps']==(SHORT_SWITCH if short else SWITCH)
    assert c['pae_prefix']==56 and c['pae_tail']==c['retained_tail_steps']==8 and c['initial_lambda']==.95
    assert c['retained_tail_correction'] and c['retained_tail_diagnostics'] and c['retained_td_unclipped'] and c['save_split_trace_audit']
    assert not any(c[k] for k in ('adaptive_kl','readiness_boost','adaptive_overlap','force_pae_overlap'))
    for name,digest in c['source_sha256'].items():assert digest==read(ROOT/'MANIFEST.json')['source_hashes']['innovation2'][name]
    assert s['training_transitions']==s['total_algorithm_transitions']==budget and s['optimizer_steps']=={'actor':budget//1024*10,'critic':budget//1024*10,'h':0} and s['pae_retained_per_world']==0
    progress=list(csv.DictReader((p/'progress.csv').open()));_,detail=i2.verify_i2(progress,p,c,short);detail.update(i2.verify_split_trace_audits(j,c,short))
    checkpoint=i2.checkpoint_steps(p,'innovation2',budget//1024*10);assert checkpoint['steps']==budget
    area,initial,ev=auc(p,budget);assert len(ev)==(2 if short else 39)
    expected=[];threshold=262144
    for point in progress:
        step=int(point['steps'])
        if step>=threshold or step==budget:expected.append(step);threshold=(step//262144+1)*262144
    assert [e['steps'] for e in ev]==expected
    for e in [initial,*ev,s['final_eval']]:batch(e,c['device'])
    exact(ev[-1]['mean'],s['final_eval']['mean']);assert ev[-1]['returns']==s['final_eval']['returns']
    if 'normalized_return_auc' in s:assert abs(area-s['normalized_return_auc'])<1e-10
    stress=read(p/'stress_evaluation.json');assert [(r['mode'],r['scale']) for r in stress]==list(STRESS)
    for value in stress:batch(value,c['device'])
    proof=read(p/'checkpoint_stress_result.json');assert proof['state']=='passed' and proof['training_transitions']==proof['optimizer_steps']==proof['optimizer_constructions']==0 and proof['model_unchanged'] and proof['normalizer_unchanged'] and proof['training_files_unchanged']
    assert proof['runtime_versions']==read(ROOT/'RUNTIME_REFERENCE.json')['versions']
    names=['config.json','summary.json','status.json','progress.csv','initial_evaluation.json','evaluations.jsonl','latest.pt','retained_tail_diagnostics.jsonl','stress_evaluation.json','checkpoint_stress_result.json',*i2.split_audit_names(c)]
    return {'seed':j['seed'],'path':j['path'],'final_return':s['final_eval']['mean'],'auc':area,'initial_return':initial['mean'],'updates':len(progress),'steps':budget,'actor_adam_steps':budget//1024*10,'critic_adam_steps':budget//1024*10,'auxiliary_adam_steps':0,'artifact_hashes':{n:sha(p/n) for n in names},**detail}
def verify(j):
    summary=read(Path(j['path'])/'summary.json');assert summary['physics_device']==summary['device']=='cuda:'+str(j['gpu']),('actual physics placement',j['id'])
    result=ncs.verify(j) if j['arm']=='innovation1' else verify_i2(j);return {'arm':j['arm'],**result}
def normalize_config(c):
    c=copy.deepcopy(c)
    for key in CONFIG_TELEMETRY:c.pop(key,None)
    if c.get('lambda_mode')=='normalized_credit_sensitivity':c['lambda_design'].pop('signal_reduction_device')
    return c
def exact_pair(a,b,arm):
    paths=[Path(a),Path(b)];delta=[]
    for name in ('latest.pt','best.pt'):
        present=[(p/name).exists() for p in paths];assert present[0]==present[1]
        if not present[0]:continue
        data=[torch.load(p/name,map_location='cpu',weights_only=False) for p in paths]
        for d in data:d['config']=normalize_config(d['config'])
        delta+=differences(*data,path=name)
    audit_names=[*ncs.signal_names(True),*ncs.audit_names(True)] if arm=='innovation1' else i2.split_audit_names(read(paths[0]/'config.json'))
    for name in audit_names:
        data=[torch.load(p/name,map_location='cpu',weights_only=False) for p in paths]
        for d in data:d.pop('target_device',None)
        delta+=differences(*data,path=name)
    for name in ('config.json','summary.json','status.json'):
        data=[read(p/name) for p in paths]
        data=[normalize_config(d) if name=='config.json' else {k:v for k,v in d.items() if k not in CONFIG_TELEMETRY} for d in data]
        delta+=differences(*data,path=name)
    for name in ('initial_evaluation.json','evaluations.jsonl','stress_evaluation.json','lambda_decisions.jsonl' if arm=='innovation1' else 'retained_tail_diagnostics.jsonl'):
        assert (paths[0]/name).read_bytes()==(paths[1]/name).read_bytes(),name
    rows=[list(csv.DictReader((p/'progress.csv').open())) for p in paths];assert len(rows[0])==len(rows[1])==(8 if arm=='innovation1' else 9)
    for ra,rb in zip(*rows):
        for key in ra:
            if key not in PROGRESS_TELEMETRY:assert ra[key]==rb[key],('progress',key)
    assert not delta,delta
    return {'state':'passed','arm':arm,'all_scientific_tensor_bytes_and_fields_exact':True,'config_summary_status_operational_exclusions':list(CONFIG_TELEMETRY),'nested_config_operational_exclusion':'lambda_design.signal_reduction_device for NCS1 only','saved_payload_operational_exclusion':'target_device only','progress_exclusions':list(PROGRESS_TELEMETRY),'tolerance':0}
def snapshot():
    out=lambda args:subprocess.check_output(args,text=True,timeout=15).strip().splitlines()
    free={int(line.split(',')[0]):int(line.split(',')[1]) for line in out(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'])};mem={}
    for line in out(['nvidia-smi','--query-compute-apps=pid,used_gpu_memory','--format=csv,noheader,nounits']):
        try:pid,used=[int(v.strip()) for v in line.split(',')];mem[pid]=mem.get(pid,0)+used
        except ValueError:pass
    return free,mem
def paired(a,b):
    delta=[x-y for x,y in zip(a,b)];mean=statistics.mean(delta);sd=statistics.stdev(delta);test=stats.ttest_rel(a,b) if sd else None;half=float(stats.t.ppf(.975,7))*sd/math.sqrt(8)
    return {'n':8,'df':7,'mean_difference':mean,'sd_difference':sd,'t':float(test.statistic) if sd else None,'p_two_sided':float(test.pvalue) if sd else (0. if mean else 1.),'constant_difference_t_unavailable':not bool(sd),'degenerate_p_convention':'nonzero constant difference p0; zero difference p1; t unavailable','ci95':[mean-half,mean+half],'exact_sign_flip_p':sum(abs(sum(s*x for s,x in zip(signs,delta))/8)>=abs(mean)-1e-12 for signs in itertools.product((-1,1),repeat=8))/256}
def analyze(jobs):
    assert len(jobs)==16 and all(j['state']=='completed' for j in jobs);rows=[j['metrics'] for j in jobs];reference=controls();tests=[];summary={};passed={}
    for arm in ARMS:
        actual=sorted([r for r in rows if r['arm']==arm],key=lambda r:r['seed']);assert [r['seed'] for r in actual]==list(SEEDS)
        summary[arm]={e:{'mean':statistics.mean(r[e] for r in actual),'sd':statistics.stdev(r[e] for r in actual)} for e in ('final_return','auc')}
        for method in METHODS:
            base=sorted([r for r in reference if r['method']==method],key=lambda r:r['seed'])
            for e in ('final_return','auc'):tests.append({'arm':arm,'method':method,'endpoint':e,**paired([r[e] for r in actual],[r[e] for r in base])})
        base=[r for r in reference if r['method']=='fixed95'];passed[arm]=all(summary[arm][e]['mean']>statistics.mean(r[e] for r in base) for e in ('final_return','auc'))
    assert len(tests)==32
    for key,label in [('p_two_sided','p_Holm32_t'),('exact_sign_flip_p','p_Holm32_exact')]:
        maximum=0.
        for rank,row in enumerate(sorted(tests,key=lambda x:x[key])):maximum=max(maximum,min(1.,row[key]*(32-rank)));row[label]=maximum
    return {'state':'completed','task':'Swimmer','rows':rows,'control_rows':reference,'summary':summary,'paired_tests':tests,'Holm_family':32,'all8_seeds':list(SEEDS),'engineering_passed':True,'all8_Base_both_means_passed_per_arm':passed,'all8_both_arms_passed':all(passed.values()),'crosshost_initial_byte_equality_required':False,'subset_selection_used':False,'automatic_Full_or_tuning':False,'valid_independent_confirmation':False,'base_reruns':0,'external_reruns':0}
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--prepare-only',action='store_true');parser.add_argument('--verify-startup',action='store_true');parser.add_argument('--verify-only',action='store_true');a=parser.parse_args()
    torch.use_deterministic_algorithms(True);torch.set_num_threads(1);check_sources();protected=verify_protected()
    if a.prepare_only:write(ROOT/'PREPARE_PASSED.json',{'state':'passed','protected':protected,'training_launched':False});return
    if a.verify_startup or a.verify_only:
        state=read(ROOT/'suite_status.json');assert state['failure'] is None and state['engineering_gate']
        smokes=state['smoke_jobs'];assert len(smokes)==6 and all(j['state']=='completed' for j in smokes)
        for j in smokes:verify(j)
        for arm in ARMS:
            ss=sorted([j for j in smokes if j['arm']==arm],key=lambda x:x['gpu']);exact_pair(ss[0]['path'],ss[1]['path'],arm);exact_pair(ss[0]['path'],ss[2]['path'],arm)
        jobs=state['jobs'];assert len(jobs)==16 and any(j['state'] in ('running','completed') for j in jobs)
        assert {(j['arm'],j['seed']) for j in jobs}=={(arm,seed) for arm in ARMS for seed in SEEDS}
        running_config_presence={}
        for j in jobs:
            assert j['planned_command']==command(j) and j['state'] in ('pending','running','completed')
            if j['state']=='pending':assert 'pid' not in j;continue
            assert j['command']==command(j)
            if j['state']=='completed':verify(j)
            else:
                assert (Path('/proc')/str(j['pid'])/'cmdline').read_bytes().rstrip(b'\0').split(b'\0')==[v.encode() for v in command(j)]
                config_path=Path(j['path'])/'config.json';running_config_presence[j['id']]=config_path.exists()
                if config_path.exists():
                    config=read(config_path);assert config['task'].startswith('Swimmer') and config['seed']==j['seed'] and config['device']=='cuda:'+str(j['gpu']) and config['determinism']==DET
        if a.verify_only:
            assert state['state']=='completed' and all(j['state']=='completed' for j in jobs);write(ROOT/'PARENT_RECOMPUTED_ANALYSIS.json',analyze(jobs))
        write(ROOT/('NATIVE_VERIFIED_terminal16.json' if a.verify_only else 'NATIVE_VERIFIED_startup.json'),{'state':'passed','source_manifest_sha256':sha(ROOT/'MANIFEST.json'),'protected':protected,'engineering_short_count':6,'formal_jobs':16,'formal_state_counts':{s:sum(j['state']==s for j in jobs) for s in ('pending','running','completed')},'running_config_presence':running_config_presence,'startup_scope':'six strictshorts passed + firstformal admitted, all16 queued; pending/compiling reported honestly'});return
    assert not(ROOT/'suite_status.json').exists() and read(ROOT/'PARENT_LUNA_PRELAUNCH_VERIFIED.json')['state']=='passed'
    assert read(ROOT/'PARENT_CONTEXT_PROTECTION_VERIFIED.json')['state']=='passed'
    jobs=[{'id':arm+'__seed'+str(seed),'arm':arm,'seed':seed,'gpu':(ai*8+si)%3,'path':str(ROOT/'runs'/(arm+'__seed'+str(seed))),'state':'pending'} for ai,arm in enumerate(ARMS) for si,seed in enumerate(SEEDS)]
    smokes=[{'id':'short__'+arm+'__gpu'+str(gpu),'arm':arm,'seed':91087,'gpu':gpu,'path':str(ROOT/'runs'/('short__'+arm+'__gpu'+str(gpu))),'state':'pending','smoke':True} for arm in ARMS for gpu in range(3)]
    for j in jobs+smokes:j['planned_command']=command(j)
    active={};gate=False;failure=None;start=time.time();reservation=3500;peaks={};observer_peak=0;allocator_peak={gpu:0 for gpu in range(3)};card_peak={gpu:0 for gpu in range(3)}
    initial_free,initial_mem=snapshot();total={int(line.split(',')[0]):int(line.split(',')[1]) for line in subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.total','--format=csv,noheader,nounits'],text=True).strip().splitlines()}
    def measure():
        nonlocal observer_peak
        free,mem=snapshot()
        for gpu in range(3):card_peak[gpu]=max(card_peak[gpu],total[gpu]-free[gpu])
        observer_peak=max(observer_peak,mem.get(os.getpid(),0))
        for ident,(proc,stream,j) in active.items():peaks[ident]=max(peaks.get(ident,0),mem.get(proc.pid,0))
        return free,mem
    def status(state):
        write(ROOT/'suite_status.json',{'state':state,'task':'Swimmer','total':16,'completed_count':sum(j['state']=='completed' for j in jobs),'jobs':jobs,'smoke_jobs':smokes,'active':{k:{'pid':v[0].pid,'gpu':v[2]['gpu'],'smoke':bool(v[2].get('smoke'))} for k,v in active.items()},'failure':failure,'engineering_gate':gate,'reservation_mib':reservation,'sampled_process_peak_MiB':peaks,'sampled_coordinator_aggregate_peak_MiB':observer_peak,'coordinator_Torch_allocator_peak_reserved_bytes':allocator_peak,'sampled_card_total_used_peak_MiB':card_peak,'initial_unrelated_compute_process_memory_MiB':initial_mem,'coordinator_pid':os.getpid(),'coordinator_command':[str(ROOT/'.venv/bin/python'),str(ROOT/'run_transfer.py')],'elapsed_seconds':time.time()-start})
    def launch(j):
        stream=(ROOT/(j['id']+'.log')).open('x');cmd=command(j);proc=subprocess.Popen(cmd,stdout=stream,stderr=subprocess.STDOUT,env=ENV,cwd=ROOT);j.update(state='running',pid=proc.pid,command=cmd,log=str(ROOT/(j['id']+'.log')));active[j['id']]=(proc,stream,j)
    def can_admit(j,free,mem):
        gpu=j['gpu'];running=[v for v in active.values() if v[2]['gpu']==gpu]
        return len(running)<8 and free[gpu]>=reservation+512+sum(max(0,reservation-mem.get(v[0].pid,0)) for v in running)
    def stress(j):
        cmd=[str(ROOT/'.venv/bin/python'),str(ROOT/'stress_checkpoint.py'),'--job-path',j['path'],'--device','cuda:'+str(j['gpu'])]
        stream=(ROOT/(j['id']+'.stress.log')).open('x');proc=subprocess.Popen(cmd,stdout=stream,stderr=subprocess.STDOUT,env=ENV,cwd=ROOT)
        write(ROOT/'CHECKPOINT_STRESS_ACTIVE.json',{'state':'running','pid':proc.pid,'gpu':j['gpu'],'job':j['id'],'command':cmd})
        while proc.poll() is None:
            _,mem=measure();peaks[j['id']]=max(peaks.get(j['id'],0),mem.get(proc.pid,0));time.sleep(.5)
        stream.close();write(ROOT/'CHECKPOINT_STRESS_ACTIVE.json',{'state':'completed' if proc.returncode==0 else 'failed','pid':proc.pid,'job':j['id'],'returncode':proc.returncode});assert proc.returncode==0,('checkpoint stress failed',j['id'])
    def reap():
        nonlocal reservation
        for ident,(proc,stream,j) in list(active.items()):
            code=proc.poll()
            if code is None:continue
            stream.close();del active[ident];j['returncode']=code
            if code!=0:j['state']='failed';raise RuntimeError('Worker failed '+ident)
            if j['arm']=='innovation2':stress(j)
            j['metrics']=verify(j);j['state']='completed'
            for gpu in range(3):allocator_peak[gpu]=max(allocator_peak[gpu],torch.cuda.max_memory_reserved(gpu))
            summary=read(Path(j['path'])/'summary.json');worker_alloc=summary.get('peak_torch_memory_bytes',0)/1024**2
            helper_alloc=read(Path(j['path'])/'checkpoint_stress_result.json').get('peak_torch_memory_reserved_bytes',0)/1024**2 if j['arm']=='innovation2' else 0
            reservation=max(reservation,math.ceil(max(peaks.get(ident,0),worker_alloc,helper_alloc)+256))
    try:
        for arm in ARMS:
            cohort=[j for j in smokes if j['arm']==arm]
            while not all(j['state']=='completed' for j in cohort):
                free,mem=measure();reap()
                if all(j['state']=='pending' for j in cohort) and all(can_admit(j,free,mem) for j in cohort):
                    for j in cohort:launch(j)
                status('engineering');time.sleep(1.)
            ordered=sorted(cohort,key=lambda j:j['gpu']);pair=[exact_pair(ordered[0]['path'],ordered[g]['path'],arm) for g in (1,2)];write(ROOT/('SHORT_'+arm+'_VERIFIED.json'),{'state':'passed','three_GPU_jobs':cohort,'pairwise_science':pair,'reservation_mib':reservation,'no_retry':True})
        gate=True;write(ROOT/'SMOKE_VERIFIED.json',{'state':'passed','shorts':6,'seed':91087,'GPUs':[0,1,2],'reservation_mib':reservation,'named_operational_exclusions':list(CONFIG_TELEMETRY),'NCS1_nested_signal_reduction_device_excluded':True,'payload_target_device_excluded':True,'no_tolerance_or_retry':True,'source_manifest_sha256':sha(ROOT/'MANIFEST.json')});verify_protected()
        while not all(j['state']=='completed' for j in jobs):
            free,mem=measure();reap()
            for j in jobs:
                if j['state']=='pending' and can_admit(j,free,mem):launch(j);free,mem=measure()
            status('running');time.sleep(1.)
        verify_protected();write(ROOT/'ANALYSIS.json',analyze(jobs));status('completed')
    except BaseException:
        failure={'state':'failed','traceback':traceback.format_exc(),'new_admissions_stopped':True,'active_workers_preserved':True,'retry':False};write(ROOT/'FAILURE.json',failure);status('failed');raise
if __name__=='__main__':main()
