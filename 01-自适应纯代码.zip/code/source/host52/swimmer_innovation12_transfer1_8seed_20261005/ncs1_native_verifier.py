"""Inherited standalone NCS1 verification; task/schema port only, no launcher."""
import ast,csv,hashlib,importlib.util,json,math,struct,sys,types
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parent
BUDGET,SHORT=10027008,524288
DET={'torch':True,'warp':'run_to_run','warp_max_records':8,'cublas_workspace_config':':4096:8'}
STRESS=(('none',0.),('gaussian',.1),('gaussian',.15),('gaussian',.3),('multiplicative',.2),('multiplicative',.3))
BASEFILES=('config.json','summary.json','status.json','progress.csv','initial_evaluation.json','evaluations.jsonl','latest.pt','stress_evaluation.json')
def controls():return read(ROOT/'COMPARISON_REFERENCE.json')['rows']


def read(p):
    def invalid(value):raise ValueError('Nonfinite JSON constant: '+value)
    return json.loads(Path(p).read_text(),parse_constant=invalid)

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def jsonl(p):return [json.loads(x) for x in Path(p).read_text().splitlines() if x.strip()]

def exact(a,b):assert type(a)==type(b) and (struct.pack('!d',a)==struct.pack('!d',b) if isinstance(a,float) else a==b),(a,b)

def differences(a,b,path=''):
    if isinstance(a,torch.Tensor):
        if not isinstance(b,torch.Tensor) or a.dtype!=b.dtype or a.shape!=b.shape:return [path]
        return [] if torch.equal(a.detach().cpu().contiguous().reshape(-1).view(torch.uint8),b.detach().cpu().contiguous().reshape(-1).view(torch.uint8)) else [path]
    if isinstance(a,dict):
        if not isinstance(b,dict) or a.keys()!=b.keys():return [path+'.keys']
        return [v for k in a for v in differences(a[k],b[k],path+'.'+str(k))]
    if isinstance(a,(list,tuple)):
        if type(a)!=type(b) or len(a)!=len(b):return [path+'.len']
        return [v for i,(x,y) in enumerate(zip(a,b)) for v in differences(x,y,path+'.'+str(i))]
    if type(a)!=type(b):return [path+'.type']
    return [] if (struct.pack('!d',a)==struct.pack('!d',b) if isinstance(a,float) else a==b) else [path]

def batch(e,device=None):
    assert len(e['returns'])==len(e['lengths'])==32 and all(math.isfinite(v) for v in e['returns'])
    assert all(type(v) is int and 1<=v<=1000 for v in e['lengths'])
    assert math.isfinite(e['mean']) and math.isfinite(e['std'])
    if device:
        v=torch.tensor(e['returns'],dtype=torch.float32,device=device);exact(float(v.mean()),e['mean']);exact(float(v.std(unbiased=False)),e['std'])

def auc(p,budget):
    initial=read(p/'initial_evaluation.json');ev=jsonl(p/'evaluations.jsonl')
    for e in [initial,*ev]:batch(e)
    pts=[(0,initial['mean'])]+[(e['steps'],e['mean']) for e in ev]
    assert pts[-1][0]==budget and all(a[0]<b[0] for a,b in zip(pts,pts[1:]))
    return sum((b[0]-a[0])*(a[1]+b[1])/2 for a,b in zip(pts,pts[1:]))/budget,initial,ev

def controller_class():
    name='ncs1_frozen'
    if name not in sys.modules:
        spec=importlib.util.spec_from_file_location(name,ROOT/'source_i1/lambda_normalized_credit_sensitivity.py');module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return sys.modules[name].NormalizedCreditSensitivity

def gae_primitive(function_name='gae',source_override=None):
    name='ncs1_native_replay_'+function_name+('_original' if source_override else '')
    if name not in sys.modules:
        module=types.ModuleType(name);module.torch=torch;sys.modules[name]=module
        source=source_override or ROOT/'source_i1/train_kl_relative.py';nodes=[n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==function_name];assert len(nodes)==1
        exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(source),'exec'),module.__dict__)
    return getattr(sys.modules[name],function_name)

def ledger(short=False):
    budget=SHORT if short else BUDGET;count=budget//65536
    rows=[{'update':u,'steps':u*65536,'prior_collected_steps':(u-1)*65536,'fresh_per_world':64,'used_per_world':64,'retained_per_world':0} for u in range(1,count+1)]
    assert len(rows)==(8 if short else 153) and sum(r['used_per_world']*1024 for r in rows)==budget
    assert count*640==(5120 if short else 97920)
    return rows

def signal_names(short=False):return [f'credit_sensitivity_signals/update_{r["update"]:03d}.pt' for r in ledger(short)]

def audit_names(short=False):return [f'fixed_critic_audit_{u:03d}.pt' for u in (4,5,8 if short else 153)]

def checkpoint(path,expected,config=None):
    x=torch.load(path/'latest.pt',map_location='cpu',weights_only=False);opt=x['optimizer']
    assert x['steps']==(expected//10*1024) and opt['state'] and len(opt['state'])==len(x['model'])
    for d in opt['state'].values():
        assert float(d['step'])==expected
        for k in ('exp_avg','exp_avg_sq'):assert bool(torch.isfinite(d[k]).all())
    assert all(bool(torch.isfinite(v).all()) for v in x['model'].values())
    if config is not None:assert x['config']==config
    return x

def signal_reducer():
    name='ncs1_frozen_reducer'
    if name not in sys.modules:
        spec=importlib.util.spec_from_file_location(name,ROOT/'source_i1/signal_normalized_credit.py');module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return sys.modules[name].normalized_credit_sensitivity

def sensitivity_signal(signal,device):
    for key in ('frozen_values','consumed_fixed95_returns','advantage90','advantage99'):
        v=signal[key];assert isinstance(v,torch.Tensor) and v.shape==(65536,) and v.dtype==torch.float32 and v.device.type=='cpu' and not v.requires_grad and bool(torch.isfinite(v).all())
    keys=('normalized_reward','values','next_values','terminated','done')
    for key in keys:
        v=signal[key];assert v.shape==(64,1024) and v.device.type=='cpu' and not v.requires_grad
        assert v.dtype==(torch.bool if key in ('terminated','done') else torch.float32) and bool(torch.isfinite(v).all())
    assert not bool((signal['terminated']&~signal['done']).any())
    assert not differences(signal['values'].flatten(),signal['frozen_values'])
    xs=[signal[k].to(device) for k in keys];gae=gae_primitive('gae_signal')
    with torch.no_grad():
        for _ in range(3):gae(*xs,.99,.95)
        a90,_=gae(*xs,.99,.90);a99,_=gae(*xs,.99,.99)
    assert torch.equal(a90.flatten(),signal['advantage90'].to(device)) and torch.equal(a99.flatten(),signal['advantage99'].to(device)),('isolated source-native credit replay',signal['update'])
    metrics=signal_reducer()(signal['advantage90'].to(device),signal['advantage99'].to(device))
    for k,value in metrics.items():exact(value,signal[k])
    return metrics

def target_audits(path,short,decisions,device):
    gae=gae_primitive();reports=[];separated=0
    for name in audit_names(short):
        r=torch.load(path/name,map_location='cpu',weights_only=False);u=r['update'];assert name==f'fixed_critic_audit_{u:03d}.pt'
        assert r['steps']==u*65536 and r['prior_collected_steps']==(u-1)*65536 and r['used_per_world']==64
        assert r['gamma']==.99 and r['critic_lambda']==.95 and r['target_device']==device;exact(r['actor_lambda'],decisions[u-1]['lambda_used'])
        keys=('normalized_reward','values','next_values','terminated','done')
        for key in (*keys,'actor_advantage','consumed_critic_return'):
            t=r[key];assert t.shape==(64,1024) and t.device.type=='cpu' and not t.requires_grad
            if key in ('terminated','done'):assert t.dtype==torch.bool
            else:assert t.dtype==torch.float32 and bool(torch.isfinite(t).all())
        assert not bool((r['terminated']&~r['done']).any())
        xs=[r[k].to(device) for k in keys]
        with torch.no_grad():
            for _ in range(3):gae(*xs,.99,.95)
            a,actor_ret=gae(*xs,.99,r['actor_lambda']);fixed_a,fixed_r=gae(*xs,.99,.95)
            assert torch.equal(a,r['actor_advantage'].to(device)) and torch.equal(fixed_r,r['consumed_critic_return'].to(device)),('actual label replay',u)
            effect=not torch.equal(a,fixed_a) and not torch.equal(actor_ret,fixed_r)
            exact(float((actor_ret-fixed_r).square().mean().sqrt()),decisions[u-1]['actor_critic_target_diff_rmse'])
        signal=torch.load(path/f'credit_sensitivity_signals/update_{u:03d}.pt',map_location='cpu',weights_only=False)
        assert not differences(r['values'].flatten(),signal['frozen_values']) and not differences(r['consumed_critic_return'].flatten(),signal['consumed_fixed95_returns'])
        if u==4:assert not effect and r['actor_lambda']==.95
        else:separated+=int(effect)
        reports.append({'update':u,'actor_lambda':r['actor_lambda'],'critic_lambda':.95,'exact_actual_targets_replayed':True,'actor_critic_labels_separated':effect,'sha256':sha(path/name)})
    assert separated>0,'NCS1 never changed actual consumed actor labels'
    return reports

def verify(j,device_override=None):
    p=Path(j['path']);short=bool(j.get('smoke'));budget=SHORT if short else BUDGET;ls=ledger(short)
    c=read(p/'config.json');summary=read(p/'summary.json');assert summary==read(p/'status.json') and summary['state']=='completed' and summary['reload_check']=='passed'
    device=f"cuda:{j['gpu']}";replay=device_override or device
    assert c['seed']==j['seed'] and c['device']==device and c['determinism']==DET and c['effective_steps']==summary['steps']==budget
    assert c['xml_sha256']==read(ROOT/'RUNTIME_REFERENCE.json')['xml_sha256']
    assert c['versions']==read(ROOT/'MANIFEST.json')['runtime_versions']
    assert c['algorithm_version']=='swimmer_i1_normalized_credit_sensitivity1_v1' and c['lambda_mode']=='normalized_credit_sensitivity'
    assert c['fixed_critic_lambda']==.95 and c['adaptive_start_update']==4 and c['adaptive_start_steps']==0 and not c['adaptive_overlap']
    for k,v in [('num_envs',1024),('rollout',64),('batch_size',1024),('epochs',10),('eval_envs',32),('eval_every',262144)]:assert c[k]==v
    assert c['fixed_critic_target_design']['audit_updates']==[4,5,len(ls)] and c['signal_files']==signal_names(short)
    assert c['source_sha256']==read(ROOT/'MANIFEST.json')['source_hashes']['innovation1']
    assert summary['training_transitions']==summary['total_algorithm_transitions']==budget and summary['optimizer_steps']=={'actor':len(ls)*640,'critic':len(ls)*640,'h':0}
    rows=list(csv.DictReader((p/'progress.csv').open()));ds=jsonl(p/'lambda_decisions.jsonl');assert len(rows)==len(ds)==len(ls)
    assert {str(v.relative_to(p)) for v in (p/'credit_sensitivity_signals').glob('*.pt')}==set(signal_names(short))
    assert {v.name for v in p.glob('fixed_critic_audit_*.pt')}==set(audit_names(short))
    control=controller_class()();values=[];signal_reports=[]
    for l,row,d in zip(ls,rows,ds):
        u=l['update'];assert d['update']==u and d['steps']==l['steps'] and d['prior_collected_steps']==l['prior_collected_steps']
        assert int(row['steps'])==l['steps'] and int(row['fresh_steps_per_world'])==int(row['used_steps_per_world'])==64 and row['overlap_active']=='False' and d['overlap_active'] is False
        signal=torch.load(p/signal_names(short)[u-1],map_location='cpu',weights_only=False);assert signal['target_device']==device and signal['signal_version']=='NCS1'
        for k in ('update','steps','prior_collected_steps'):exact(signal[k],l[k])
        assert not differences(signal['controller_before_step'],control.state_dict());delta=control.step(u)
        assert not differences(signal['controller_before_observe'],control.state_dict());exact(control.value,d['lambda_used']);exact(control.value,d['actor_lambda_used']);exact(.95,d['critic_lambda_used']);exact(delta,d['lambda_delta'])
        metrics=sensitivity_signal(signal,replay)
        for k in ('mean90','variance90','mean99','variance99','squared_distance','rms_distance','d'):exact(metrics[k],d[k])
        control.observe(metrics['d'])
        for k,v in control.state_dict().items():exact(v,d[k])
        exact(control.value,float(row['gae_lambda']));exact(delta,float(row['lambda_delta']))
        assert .90<=control.value<=.99 and abs(delta)<=.001+1e-15
        for k in ('value_loss','policy_loss','entropy','approx_kl','clip_fraction','explained_variance','advantage_variance'):assert math.isfinite(float(row[k]))
        values.append(control.value);signal_reports.append({'update':u,**metrics})
    assert values[:4]==[.95]*4 and max(abs(v-.95) for v in values)>1e-12
    saved=checkpoint(p,len(ls)*640,c);assert saved['credit_sensitivity_feedback']==control.state_dict()
    audits=target_audits(p,short,ds,replay)
    area,initial,ev=auc(p,budget);assert len(ev)==(2 if short else 39)
    expected=[u*262144 for u in range(1,budget//262144+1)]+([] if budget%262144==0 else [budget]);assert [e['steps'] for e in ev]==expected
    for e in [initial,*ev,summary['final_eval']]:batch(e,replay)
    exact(ev[-1]['mean'],summary['final_eval']['mean'])
    # Parent prospective rule: retain historical initial scores/provenance; no cross-host byte identity gate.
    stress=read(p/'stress_evaluation.json');assert [(r['mode'],r['scale']) for r in stress]==list(STRESS)
    for r in stress:batch(r,replay)
    names=[*BASEFILES,'lambda_decisions.jsonl',*signal_names(short),*audit_names(short),'best.pt'];assert all((p/n).is_file() for n in names)
    return {'seed':j['seed'],'path':str(p),'final_return':summary['final_eval']['mean'],'auc':area,'initial_return':initial['mean'],'updates':len(ls),'steps':budget,'actor_adam_steps':len(ls)*640,'critic_adam_steps':len(ls)*640,'auxiliary_adam_steps':0,'lambda_min':min(values),'lambda_max':max(values),'lambda_final':values[-1],'maximum_lambda_deviation':max(abs(v-.95) for v in values),'controller_replay':'passed','fixed95_target_replay':'passed','signal_replay':'passed','preoptimizer_credit_sensitivity_rows':signal_reports,'actual_target_audits':audits,'stress_verified':True,'artifact_hashes':{n:sha(p/n) for n in names}}
