"""Parent-only fresh runtime/protection preparation; no training launch or install."""
import json,os,shutil,sys
from pathlib import Path
import run_transfer as r
ROOT=Path(__file__).resolve().parent
def main():
    reference=r.read(ROOT/'RUNTIME_REFERENCE.json')
    assert str(ROOT)==reference['native_root'] and os.geteuid()!=0 and not(ROOT/'REMOTE_PREPARED.json').exists()
    assert not[(p/'AGENTS.md') for p in (ROOT,*ROOT.parents) if (p/'AGENTS.md').exists()],'Parent must review applicable native instructions'
    assert not(Path.home()/'.config/systemd/user/dpo-swimmer-innovation12-transfer1-8seed-20261005.service').exists()
    assert ROOT.stat().st_dev!=Path('/').stat().st_dev and shutil.disk_usage(ROOT).free>=10*1024**3
    r.check_sources();protected=r.verify_protected()
    (ROOT/'.venv').symlink_to(reference['venv'],target_is_directory=True)
    if reference['analysis_dependencies']:(ROOT/'analysis_dependencies').symlink_to(reference['analysis_dependencies'],target_is_directory=True)
    for name in ('runs','cache','tmp'):(ROOT/name).mkdir(exist_ok=False)
    r.write(ROOT/'REMOTE_PREPARED.json',{'state':'prepared','python':sys.version,'venv':reference['venv'],'manifest_sha256':r.sha(ROOT/'MANIFEST.json'),'protected':protected,'training_launched':False,'installation':False,'disk_free_bytes':shutil.disk_usage(ROOT).free})
    print(json.dumps({'state':'prepared','controls':64,'training_launched':False}))
if __name__=='__main__':main()
