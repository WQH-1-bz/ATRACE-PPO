"""Parent one-shot startup/terminal verification, not polling or a launcher."""
import argparse,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
UNIT='dpo-swimmer-innovation12-transfer1-8seed-20261005.service'
def main():
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=('startup','terminal16'),required=True);a=p.parse_args()
    import run_transfer as r
    command=[str(ROOT/'.venv/bin/python'),str(ROOT/'run_transfer.py'),'--verify-startup' if a.phase=='startup' else '--verify-only']
    result=subprocess.run(command,capture_output=True,text=True);assert result.returncode==0,(result.stdout,result.stderr)
    raw=subprocess.check_output(['systemctl','--user','show',UNIT,'--property=ActiveState,SubState,MainPID,Result,ExecMainStatus,Restart,KillMode,ExecStart'],text=True);unit=dict(line.split('=',1) for line in raw.splitlines() if '=' in line)
    state=r.read(ROOT/'suite_status.json');assert state['failure'] is None and unit['Restart']=='no' and unit['KillMode']=='process'
    if a.phase=='startup':
        assert unit['ActiveState']=='active' and int(unit['MainPID'])==state['coordinator_pid']
        assert (Path('/proc')/unit['MainPID']/'cmdline').read_bytes().rstrip(b'\0').split(b'\0')==[x.encode() for x in state['coordinator_command']]
    else:assert unit['Result']=='success' and unit['ExecMainStatus']=='0' and state['state']=='completed' and state['completed_count']==16 and not state['active']
    for name in [j['log'] for j in state['jobs']+state['smoke_jobs'] if 'log' in j]:
        text=Path(name).read_text(errors='replace');assert not any(x in text for x in ('Traceback (most recent call last)','CUDA out of memory','AssertionError'))
    proof={'state':'passed','phase':a.phase,'manifest_sha256':r.sha(ROOT/'MANIFEST.json'),'native_verifier':r.read(ROOT/('NATIVE_VERIFIED_startup.json' if a.phase=='startup' else 'NATIVE_VERIFIED_terminal16.json')),'unit':unit}
    r.write(ROOT/('PARENT_VERIFIED_'+a.phase+'.json'),proof);print(json.dumps({'state':'passed','phase':a.phase}))
if __name__=='__main__':main()
