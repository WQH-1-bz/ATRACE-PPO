"""Finite actual-boundary stand-ins; no native unit or process observation."""
import copy
import json
from pathlib import Path
import tempfile

import completion_contract as c


def rejected(function, *args, **kwargs):
    try:
        function(*args, **kwargs)
    except (AssertionError, PermissionError, FileNotFoundError, RuntimeError):
        return
    raise AssertionError('Lifecycle counterexample accepted')


def run():
    saved_root = c.ROOT
    count = 0
    with tempfile.TemporaryDirectory(prefix='swimmer-lifecycle-fixture-') as temporary:
        root = Path(temporary); c.ROOT = root
        (root / 'MANIFEST.json').write_text('{}')
        (root / 'coordinator.log').write_text('actual fixture healthy log\n')
        for seed in c.NEW_SEEDS:
            (root / ('innovation2__seed' + str(seed) + '.stress.log')).write_text('fixture healthy stress log\n')
        command = c.bootstrap_command([str(c.ORIGINAL_ROOT / '.venv/bin/python'), str(root / 'run_completion.py')])
        coordinator = {'pid': 101, 'start_ticks': '765', 'command': command, 'cuda_visible_devices': None}
        jobs = [{'id': arm + '__seed' + str(seed), 'arm': arm, 'seed': seed, 'gpu': 1,
            'path': str(root / 'runs' / (arm + '__seed' + str(seed))), 'state': 'verifying',
            'clone_required': arm == 'innovation2' and seed in c.NEW_SEEDS}
            for arm in ('innovation1', 'innovation2') for seed in range(21, 29)]
        state = {'state': 'adopting_completed_training', 'completed_count': 0, 'failure': None,
            'source_manifest_sha256': c.sha(root / 'MANIFEST.json'), 'coordinator_identity': coordinator,
            'active_helper': None, 'jobs': jobs}
        unit = {'Restart': 'no', 'KillMode': 'process', 'ExecStart': str(root / 'resource_bootstrap.py') + ' ' + str(root / 'run_completion.py'),
            'ActiveState': 'active', 'SubState': 'running', 'MainPID': '101', 'Result': 'success', 'ExecMainStatus': '0'}
        snapshot = {'cards': {1: {'uuid': c.GPU1_UUID}}, 'allocations': [{'pid': 101, 'gpu_uuid': c.GPU1_UUID, 'used_mib': 586}],
            'gpu1_pid_memory_mib': {101: 586}}
        identities = {101: coordinator}
        def inspect(pid, expected_start_ticks=None):
            identity = identities.get(pid)
            if identity is not None:
                assert str(identity['start_ticks']) == str(expected_start_ticks), 'Fixture PID reuse'
            return identity
        assert c.validate_lifecycle(state, unit, 'startup', snapshot, inspect)['actual_unit_active_running']
        count += 1
        for field, bad in [('ActiveState', 'inactive'), ('SubState', 'dead'), ('MainPID', '102'), ('Restart', 'always'), ('KillMode', 'control-group')]:
            rejected(c.validate_lifecycle, state, {**unit, field: bad}, 'startup', snapshot, inspect); count += 1
        identities[101] = {**coordinator, 'start_ticks': '766'}; rejected(c.validate_lifecycle, state, unit, 'startup', snapshot, inspect); count += 1
        identities[101] = {**coordinator, 'command': ['wrong']}; rejected(c.validate_lifecycle, state, unit, 'startup', snapshot, inspect); count += 1
        identities.clear(); rejected(c.validate_lifecycle, state, unit, 'startup', snapshot, inspect); count += 1
        identities[101] = coordinator
        selected = next(j for j in jobs if j['id'] == 'innovation2__seed21')
        helper_command = c.bootstrap_command([str(c.ORIGINAL_ROOT / '.venv/bin/python'), str(root / 'stress_checkpoint_gpu1.py'),
            '--job-path', selected['path'], '--device', 'cuda:1'])
        helper_identity = {'pid': 102, 'start_ticks': '888', 'command': helper_command, 'cuda_visible_devices': None}
        helper = {**helper_identity, 'job': selected['id'], 'stage': 'checkpoint_only_stress', 'gpu': 1, 'device': 'cuda:1',
            'physical_gpu_uuid': c.GPU1_UUID, 'log': str(root / (selected['id'] + '.stress.log')),
            'in_process_verification': False, 'state': 'running', 'actual_Popen_returncode': None}
        state.update(state='checkpoint_stress', active_helper=helper)
        identities[102] = helper_identity
        snapshot['allocations'].append({'pid': 102, 'gpu_uuid': c.GPU1_UUID, 'used_mib': 1200})
        assert c.validate_lifecycle(state, unit, 'startup', snapshot, inspect)['active_helper']['actual_GPU1_context_present']; count += 1
        for field, bad in [('job', 'foreign'), ('gpu', 0), ('device', 'cuda:0'), ('physical_gpu_uuid', 'WRONG'), ('command', ['wrong']),
            ('stage', 'training'), ('log', str(root / 'other.log')), ('state', 'completed'), ('actual_Popen_returncode', 0), ('in_process_verification', True)]:
            bad_state = copy.deepcopy(state); bad_state['active_helper'][field] = bad
            rejected(c.validate_lifecycle, bad_state, unit, 'startup', snapshot, inspect); count += 1
        rejected(c.validate_lifecycle, {**state, 'active_helper': None}, unit, 'startup', snapshot, inspect); count += 1
        rejected(c.validate_lifecycle, {**state, 'state': 'verifying'}, unit, 'startup', snapshot, inspect); count += 1
        identities.pop(102); rejected(c.validate_lifecycle, state, unit, 'startup', snapshot, inspect); count += 1
        identities[102] = {**helper_identity, 'start_ticks': '889'}; rejected(c.validate_lifecycle, state, unit, 'startup', snapshot, inspect); count += 1
        identities[102] = helper_identity
        snapshot['allocations'][-1]['gpu_uuid'] = 'WRONG'; rejected(c.validate_lifecycle, state, unit, 'startup', snapshot, inspect); count += 1
        snapshot['allocations'].pop(); rejected(c.validate_lifecycle, state, unit, 'startup', snapshot, inspect); count += 1
        inprocess = {**coordinator, 'job': jobs[0]['id'], 'stage': 'source_native_scientific_verification', 'gpu': 1, 'device': 'cuda:1',
            'physical_gpu_uuid': c.GPU1_UUID, 'log': str(root / 'coordinator.log'), 'in_process_verification': True,
            'state': 'verifying', 'actual_Popen_returncode': None}
        state.update(state='verifying', active_helper=inprocess)
        assert c.validate_lifecycle(state, unit, 'startup', snapshot, inspect)['active_helper']['stage'] == 'source_native_scientific_verification'; count += 1
        terminal = copy.deepcopy(state); terminal.update(state='completed', completed_count=16, active_helper=None)
        for j in terminal['jobs']:
            j['state'] = 'completed'
        terminal_unit = {**unit, 'ActiveState': 'inactive', 'SubState': 'dead', 'MainPID': '0'}
        rejected(c.validate_lifecycle, terminal, terminal_unit, 'terminal16', snapshot, inspect); count += 1
        identities.pop(101)
        assert c.validate_lifecycle(terminal, terminal_unit, 'terminal16', snapshot, inspect)['new_coordinator_source_proven_exited']; count += 1
        for field, bad in [('ActiveState', 'active'), ('SubState', 'failed'), ('MainPID', '101'), ('Result', 'exit-code'), ('ExecMainStatus', '1')]:
            rejected(c.validate_lifecycle, terminal, {**terminal_unit, field: bad}, 'terminal16', snapshot, inspect); count += 1
        rejected(c.validate_lifecycle, {**terminal, 'active_helper': inprocess}, terminal_unit, 'terminal16', snapshot, inspect); count += 1
        (root / 'FAILURE.json').write_text('{}'); rejected(c.validate_lifecycle, terminal, terminal_unit, 'terminal16', snapshot, inspect); count += 1
        (root / 'FAILURE.json').unlink()
        (root / 'coordinator.log').write_text('Traceback (most recent call last):\nRuntimeError: fixture fatal\n')
        rejected(c.validate_lifecycle, terminal, terminal_unit, 'terminal16', snapshot, inspect); count += 1
        (root / 'coordinator.log').write_text('healthy\n')
        (root / 'innovation2__seed21.stress.log').write_text('CUDA out of memory\n')
        rejected(c.validate_lifecycle, terminal, terminal_unit, 'terminal16', snapshot, inspect); count += 1
    c.ROOT = saved_root
    return {'state': 'passed_stdlib_lifecycle_fixtures', 'cases': count, 'native_evidence': False,
        'unit_pid_identity_helpers_fatal_logs_and_terminal_zero': True}


if __name__ == '__main__':
    print(json.dumps(run(), indent=2))
