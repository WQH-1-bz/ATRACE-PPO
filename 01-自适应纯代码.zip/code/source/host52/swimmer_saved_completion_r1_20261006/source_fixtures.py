"""Finite stdlib counterexamples; scratch stand-ins are never native evidence."""
import copy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import tempfile
import time

import completion_contract as c


def rejected(function, *args, **kwargs):
    try:
        function(*args, **kwargs)
    except (AssertionError, PermissionError, FileNotFoundError, RuntimeError):
        return
    raise AssertionError('Counterexample was accepted: ' + function.__name__)


def identity_fixtures():
    old = c.frozen_old()
    job = {'id': 'fixture', 'pid': 1234, 'start_ticks': '765', 'original_wrapped_command': ['python', 'immutable.py']}
    def reader(state='S', ticks='765', deny=False):
        def get(name):
            if name == 'stat':
                return ('1234 (python fixture) ' + state + ' ' + ' '.join(['0'] * 18) + ' ' + ticks + ' 0\n').encode()
            if name == 'cmdline':
                return b'python\0immutable.py\0'
            if deny:
                raise PermissionError('fixture access denial')
            return b'OMP_NUM_THREADS=1\0'
        return get
    assert not c.retired(job, reader=reader())
    assert c.retired(job, reader=reader('Z')) and c.retired(job, reader=reader('X'))
    rejected(c.retired, job, reader=reader('Z', '766'))
    rejected(c.retired, job, reader=reader('S', '766'))
    rejected(c.retired, job, reader=reader(deny=True), pause=lambda _: None, clock=iter([0., 2.]).__next__)
    def absent(_):
        raise FileNotFoundError('fixture absent')
    assert c.retired(job, reader=absent)
    changed = reader()
    rejected(old.check_identity, {'id': 'fixture', 'pid': 1234, 'start_ticks': '765', 'command': ['different']},
        old.inspect_identity(1234, reader=changed))
    return 8


def capacity_fixtures():
    old_live, old_observation = c.live_inputs, c.old_operational_observation
    try:
        c.old_operational_observation = lambda: {'coordinator_identity': {'pid': 999}}
        jobs = [{'pid': i} for i in range(1, 7)]
        snap = {'cards': {1: {'uuid': c.GPU1_UUID, 'free_mib': 31501, 'total_mib': 32607}},
            'allocations': [{'pid': 999, 'gpu_uuid': c.GPU1_UUID, 'used_mib': 586}], 'gpu1_pid_memory_mib': {999: 586}}
        c.live_inputs = lambda rows: rows[:5]
        blocked = c.capacity(jobs, snap, 5388)
        assert blocked['required_free_mib'] == 32840 > 32607
        c.live_inputs = lambda rows: []
        admitted = c.capacity(jobs, snap, 5388)
        assert admitted['required_free_mib'] == 5900 and admitted['retired_inputs_excluded'] == 6
        assert admitted['required_free_mib'] <= admitted['free_mib']
        rejected(c.capacity, jobs, snap, 5388, 1024)
        rejected(c.capacity, jobs, snap, 5388, 0)
        c.live_inputs = lambda rows: rows[:1]
        assert c.capacity(jobs, snap, 5388)['required_free_mib'] == 11288
        snap['gpu1_pid_memory_mib'][1] = 500
        assert c.capacity(jobs, snap, 5388)['required_free_mib'] == 10788
        snap['allocations'].append({'pid': 1, 'gpu_uuid': 'WRONG', 'used_mib': 500})
        rejected(c.capacity, jobs, snap, 5388)
        snap['allocations'].pop(); snap['allocations'][0]['gpu_uuid'] = 'WRONG'
        rejected(c.capacity, jobs, snap, 5388)
        assert c.frozen_old().reservation_mib(6000, [7000], [8000]) == 8256
        assert c.frozen_old().reservation_mib(8256, [1], [1]) == 8256
    finally:
        c.live_inputs, c.old_operational_observation = old_live, old_observation
    return 10


def copy_and_guard_fixtures():
    root_before = c.ROOT
    with tempfile.TemporaryDirectory(prefix='swimmer-completion-fixture-') as scratch:
        base = Path(scratch); root = base / 'new'; root.mkdir(); c.ROOT = root
        source = base / 'old'; source.mkdir(); source.chmod(0o750)
        (source / 'config.json').write_bytes(b'{"out":"old/original/path"}\r\n')
        (source / 'latest.pt').write_bytes(b'fixture opaque checkpoint\x00\x01')
        (source / 'config.json').chmod(0o640)
        (root / 'runs').mkdir()
        target = root / 'runs/clone'
        baseline = c.clone_exact(source, target)
        assert c.inventory(source) == c.inventory(target) == baseline
        assert (target / 'config.json').read_bytes() == b'{"out":"old/original/path"}\r\n'
        assert target.stat().st_mode & 0o777 == 0o750
        rejected(c.clone_exact, source, target)
        (source / 'dirlink').symlink_to(base, target_is_directory=True)
        rejected(c.inventory, source); (source / 'dirlink').unlink()
        link = base / 'oldlink'; link.symlink_to(source, target_is_directory=True)
        rejected(c.inventory, link)
        nested = base / 'old/sub'; nested.mkdir()
        rejected(c.inventory, link / 'sub'); nested.rmdir()
        destlink = root / 'runs/link'; destlink.symlink_to(base / 'nonexistent')
        rejected(c.clone_exact, source, destlink)
        jobs, rows = [], []
        for index in range(16):
            src = base / ('old' + str(index)); src.mkdir()
            (src / 'config.json').write_bytes(b'unchanged historical out')
            (src / 'latest.pt').write_bytes(b'checkpoint')
            log = base / ('old' + str(index) + '.log'); log.write_bytes(b'completed training\n')
            dst = root / 'runs' / ('job' + str(index))
            clone = index < 6
            if clone:
                c.clone_exact(src, dst)
            else:
                dst = src
            jobs.append({'id': 'job' + str(index), 'original_path': str(src), 'path': str(dst), 'clone_required': clone, 'original_log': str(log)})
            rows.append({'id': 'job' + str(index), 'original_path': str(src), 'path': str(dst), 'clone_required': clone,
                'original_inventory': c.inventory(src), 'original_log': str(log), 'log_sha256': c.sha(log), 'log_mode': log.stat().st_mode & 0o777})
        (root / 'MANIFEST.json').write_text(json.dumps({'deployment_files': ['MANIFEST.json', 'source.py']}))
        (root / 'source.py').write_text('immutable'); (root / 'source.py').chmod(0o444)
        (root / 'TASK_PLAN.json').write_text(json.dumps({'jobs': jobs}))
        guard = {'state': 'actual_completed_training_baseline', 'source_manifest_sha256': c.sha(root / 'MANIFEST.json'), 'jobs': rows}
        (root / 'COMPLETED_TRAINING_GUARD.json').write_text(json.dumps(guard))
        assert c.verify_inputs_and_clones()['exact_clones'] == 6
        selected = Path(jobs[0]['path']); original = Path(jobs[0]['original_path'])
        for name in c.EXTRAS:
            (selected / name).write_text('{}')
        assert c.verify_inputs_and_clones()['state'] == 'passed'
        (selected / 'unexpected').write_text('extra'); rejected(c.verify_inputs_and_clones); (selected / 'unexpected').unlink()
        saved = (selected / 'config.json').read_bytes()
        (selected / 'config.json').write_bytes(b'rewritten out'); rejected(c.verify_inputs_and_clones); (selected / 'config.json').write_bytes(saved)
        (selected / 'latest.pt').rename(selected / 'missing'); rejected(c.verify_inputs_and_clones); (selected / 'missing').rename(selected / 'latest.pt')
        mode = selected.stat().st_mode & 0o777
        selected.chmod(mode ^ 0o070); rejected(c.verify_inputs_and_clones); selected.chmod(mode)
        mode = (selected / 'latest.pt').stat().st_mode & 0o777
        (selected / 'latest.pt').chmod(0o400); rejected(c.verify_inputs_and_clones); (selected / 'latest.pt').chmod(mode)
        external_link = base / 'hardlink'; os.link(selected / 'latest.pt', external_link)
        rejected(c.verify_inputs_and_clones); external_link.unlink()
        (selected / 'latest.pt').unlink(); os.link(original / 'latest.pt', selected / 'latest.pt')
        rejected(c.verify_inputs_and_clones); (selected / 'latest.pt').unlink()
        import shutil
        shutil.copy2(original / 'latest.pt', selected / 'latest.pt')
        log = Path(jobs[0]['original_log']); saved = log.read_bytes()
        log.write_bytes(saved + b'append'); rejected(c.verify_inputs_and_clones); log.write_bytes(saved)
        (original / 'newdir').mkdir(); rejected(c.verify_inputs_and_clones); (original / 'newdir').rmdir()
        rejected(c.write, root / 'MANIFEST.json', {})
        rejected(c.write, root / 'source.py', {})
        rejected(c.write, selected / 'config.json', {})
        rejected(c.write, base / 'outside.json', {})
        c.write_once(root / 'new_receipt.json', {'actual': 'fixture'})
        rejected(c.write_once, root / 'new_receipt.json', {})
        env = {key: str(root / tail) for key, tail in (('XDG_CACHE_HOME', 'cache'), ('WARP_CACHE_PATH', 'cache/warp'),
            ('CUDA_CACHE_PATH', 'cache/cuda'), ('TORCH_HOME', 'cache/torch'), ('TMPDIR', 'tmp'))}
        c.guard_cache_paths(env, root)
        (root / 'cache').symlink_to(base / 'old', target_is_directory=True)
        rejected(c.guard_cache_paths, env, root); (root / 'cache').unlink()
    c.ROOT = root_before
    return 25


def authorization_fixtures():
    original_root = c.ROOT
    with tempfile.TemporaryDirectory(prefix='swimmer-auth-fixture-') as scratch:
        c.ROOT = Path(scratch)
        root = c.ROOT; (root / 'MANIFEST.json').write_text('{"deployment_files": ["MANIFEST.json"]}'); (root / 'TASK_PLAN.json').write_text('{"jobs": []}')
        now = datetime.now(timezone.utc).isoformat(); epoch = time.time()
        goal = {'goal': {'status': 'ACTIVE', 'threadId': 'actual-fixture-id', 'createdAt': epoch,
            'objective': str(c.NATIVE_ROOT) + ' ' + c.UNIT + ' ' + c.GPU1_UUID + ' physical GPU1 ' + c.sha(root / 'MANIFEST.json') + ' ' + c.sha(root / 'TASK_PLAN.json') + ' two_zero_training_initialization_audits_then_six_checkpoint_stress_only'}}
        initial = {'native_root': str(c.NATIVE_ROOT), 'unit': c.UNIT, 'source_manifest_sha256': c.sha(root / 'MANIFEST.json'),
            'physical_gpus': [1], 'physical_gpu_uuid': c.GPU1_UUID, 'actual_evidence': {'fixture': True},
            'task_plan_sha256': c.sha(root / 'TASK_PLAN.json'), 'checked_utc': now,
            'gate_scope': 'two_zero_training_initialization_audits_then_six_checkpoint_stress_only'}
        def dump(name, value):
            (root / name).write_text(json.dumps(value))
        dump('PARENT_LUNA_RAW_GOAL.json', goal); dump('PARENT_LUNA_RAW_INITIAL_SNAPSHOT.json', initial)
        luna = {'state': 'active', 'source_manifest_sha256': c.sha(root / 'MANIFEST.json'), 'monitor_agent_id': 'fixture',
            'active_goal_id': 'actual-fixture-id', 'initial_snapshot': True, 'checked_utc': now,
            'raw_goal_sha256': c.sha(root / 'PARENT_LUNA_RAW_GOAL.json'), 'raw_initial_snapshot_sha256': c.sha(root / 'PARENT_LUNA_RAW_INITIAL_SNAPSHOT.json')}
        review = {'state': 'approved', 'source_manifest_sha256': c.sha(root / 'MANIFEST.json'), 'independent_source_review_passed': True, 'native_admission_authorized': True}
        dump('PARENT_REVIEW_AUTHORIZATION.json', review); dump('PARENT_LUNA_ACTIVE.json', luna)
        hashes = c.check_new_authorization()
        assert len(hashes) == 4
        for field, bad in [('physical_gpu_uuid', 'WRONG'), ('native_root', '/other'), ('unit', 'old.service'), ('physical_gpus', [0]),
                           ('task_plan_sha256', 'old'), ('source_manifest_sha256', 'old'), ('gate_scope', 'training')]:
            modified = {**initial, field: bad}; dump('PARENT_LUNA_RAW_INITIAL_SNAPSHOT.json', modified)
            dump('PARENT_LUNA_ACTIVE.json', {**luna, 'raw_initial_snapshot_sha256': c.sha(root / 'PARENT_LUNA_RAW_INITIAL_SNAPSHOT.json')})
            rejected(c.check_new_authorization)
        dump('PARENT_LUNA_RAW_INITIAL_SNAPSHOT.json', initial); dump('PARENT_LUNA_ACTIVE.json', luna)
        dump('PARENT_LUNA_RAW_GOAL.json', {'goal': {**goal['goal'], 'status': 'complete'}})
        dump('PARENT_LUNA_ACTIVE.json', {**luna, 'raw_goal_sha256': c.sha(root / 'PARENT_LUNA_RAW_GOAL.json')})
        rejected(c.check_new_authorization)
        dump('PARENT_LUNA_RAW_GOAL.json', goal); dump('PARENT_LUNA_ACTIVE.json', luna)
        c.write_once(root / 'RESOURCE_ADMISSION_STARTED.json', {'state': 'active', 'source_manifest_sha256': c.sha(root / 'MANIFEST.json'),
            'admission_verified_utc': now, 'admission_receipt_hashes': hashes})
        assert c.check_new_authorization(fresh=False) == hashes
        review['native_admission_authorized'] = False; dump('PARENT_REVIEW_AUTHORIZATION.json', review)
        rejected(c.check_new_authorization, fresh=False)
    c.ROOT = original_root
    return 11


def provenance_and_source_mutation_fixtures():
    jobs = c.read(c.ROOT / 'TASK_PLAN.json')['jobs']
    assert c.validate_plan(jobs) == jobs
    tests = [('pid', 1), ('start_ticks', '1'), ('original_log', '/wrong'), ('original_wrapped_command', ['wrong']),
             ('returncode', 0), ('Popen_returncode_known', True), ('path', '/old/path'), ('training_launch_allowed', True)]
    for field, bad in tests:
        changed = copy.deepcopy(jobs); changed[0][field] = bad
        rejected(c.validate_plan, changed)
    changed = copy.deepcopy(jobs)
    unknown = next(j for j in changed if j['clone_required'] and j['seed'] == 21)
    unknown['trainer_exit_provenance']['actual_Popen_returncode'] = 0
    rejected(c.validate_plan, changed)
    changed = copy.deepcopy(jobs)
    known = next(j for j in changed if j['clone_required'] and j['seed'] == 24)
    known['trainer_exit_provenance']['kernel_exit_wait_status'] = 0
    rejected(c.validate_plan, changed)
    old_before = {n: {'sha256': c.sha(c.OLD_ROOT / n), 'mode': (c.OLD_ROOT / n).stat().st_mode & 0o777}
        for n in ('gpu1_contract.py', 'run_gpu1.py', 'stress_checkpoint_gpu1.py', 'MANIFEST.json')}
    with tempfile.TemporaryDirectory(prefix='swimmer-source-fixture-') as scratch:
        source = Path(scratch) / 'frozen.py'; source.write_bytes(b'original source\n'); source.chmod(0o444)
        saved_root = c.ROOT; c.ROOT = Path(scratch)
        hashes = {'frozen.py': c.sha(source)}
        c.verify_bundle_files(hashes); source.chmod(0o644); rejected(c.verify_bundle_files, hashes)
        source.write_bytes(b'mutated source\n'); source.chmod(0o444); rejected(c.verify_bundle_files, hashes)
        source.unlink(); rejected(c.verify_bundle_files, hashes)
        target = Path(scratch) / 'other'; target.write_bytes(b'original source\n'); target.chmod(0o444); source.symlink_to(target); rejected(c.verify_bundle_files, hashes)
        c.ROOT = saved_root
    assert old_before == {n: {'sha256': c.sha(c.OLD_ROOT / n), 'mode': (c.OLD_ROOT / n).stat().st_mode & 0o777} for n in old_before}
    return 14


def run():
    assert not any(name in __import__('sys').modules for name in ('torch', 'warp', 'numpy'))
    results = {'identity': identity_fixtures(), 'capacity': capacity_fixtures(), 'copy_preservation_and_write_scope': copy_and_guard_fixtures(),
        'actual_goal_snapshot_binding': authorization_fixtures(), 'actual_exit_identity_and_source_mutation': provenance_and_source_mutation_fixtures()}
    return {'state': 'passed_stdlib_source_fixtures', 'cases': results, 'total': sum(results.values()),
        'native_evidence': False, 'native_training_or_imports': False}


if __name__ == '__main__':
    print(json.dumps(run(), indent=2))
