"""Completion-only operation allowlist; public WARNING before first wp.init."""
from datetime import datetime, timezone
import importlib.metadata
import os
from pathlib import Path
import runpy
import sys

sys.dont_write_bytecode = True
import completion_contract as c


def enter_original(original, configure, run_path=runpy.run_path):
    """Keep original argv, __file__, __main__ and sibling import resolution."""
    before_argv, before_path = list(sys.argv), list(sys.path)
    try:
        configure()
        sys.argv = list(original[1:])
        sys.path.insert(0, str(Path(original[1]).parent))
        return run_path(original[1], run_name='__main__')
    finally:
        sys.argv, sys.path = before_argv, before_path


def configure_warning():
    import warp as wp
    from warp._src import context
    assert context.runtime is None, 'Public logging setting must precede first wp.init'
    assert importlib.metadata.version('warp-lang') == '1.17.0'
    wp.config.log_level = wp.LOG_WARNING
    assert wp.config.log_level == wp.LOG_WARNING
    return {'setting': 'wp.config.log_level = wp.LOG_WARNING', 'configured_before_first_wp_init': True}


def main():
    assert c.ROOT == c.NATIVE_ROOT and 'CUDA_VISIBLE_DEVICES' not in os.environ
    assert sys.argv[1] == '--' and len(sys.argv) >= 3
    original = [str(c.ORIGINAL_ROOT / '.venv/bin/python'), *sys.argv[2:]]
    target = Path(original[1])
    allowed = {c.ROOT / name for name in ('run_completion.py', 'verify_parent.py', 'resource_init_audit.py', 'stress_checkpoint_gpu1.py')}
    assert target in allowed, 'Completion-only wrapper forbids trainer/original queue targets'
    arguments = original[2:]
    if target.name == 'run_completion.py':
        assert arguments == []
    elif target.name == 'verify_parent.py':
        assert len(arguments) == 2 and arguments[0] == '--phase' and arguments[1] in ('prelaunch', 'startup', 'terminal16')
    elif target.name == 'resource_init_audit.py':
        assert len(arguments) == 2 and arguments[0] == '--case' and arguments[1] in ('i1', 'i2')
    else:
        paths = {str(c.NATIVE_ROOT / 'runs' / ('innovation2__seed' + str(seed))) for seed in c.NEW_SEEDS}
        assert len(arguments) == 4 and arguments[0] == '--job-path' and arguments[1] in paths and arguments[2:] == ['--device', 'cuda:1']
    c.check_manifest(); c.check_old_readonly(); c.old_operational_observation()
    assert os.environ == c.execution_env(), 'Exact deterministic and NEW-root cache environment required'
    old = c.frozen_old(); identity = old.inspect_identity(os.getpid())
    assert old.check_identity({'id': 'completion bootstrap', 'pid': os.getpid(),
        'start_ticks': identity['start_ticks'], 'command': c.bootstrap_command(original)}, identity)
    if target == c.ROOT / 'verify_parent.py' and original[-2:] == ['--phase', 'prelaunch']:
        hashes = c.check_new_authorization()
        c.write_once(c.ROOT / 'RESOURCE_ADMISSION_STARTED.json', {'state': 'active', 'identity': identity,
            'admission_receipt_hashes': hashes, 'admission_verified_utc': datetime.now(timezone.utc).isoformat(),
            'source_manifest_sha256': c.sha(c.ROOT / 'MANIFEST.json')})
    else:
        c.check_new_authorization(fresh=False); c.verify_inputs_and_clones()
        if target == c.ROOT / 'resource_init_audit.py':
            marker = c.read(c.ROOT / 'RESOURCE_ADMISSION_STARTED.json')
            driver = marker['identity']
            assert old.check_identity({'id': 'new admission driver', **driver}, old.inspect_identity(driver['pid'], expected_start_ticks=driver['start_ticks']))
            assert (c.ROOT / 'COMPLETION_RESOURCE_GATE_ATTEMPT.json').is_file()
        else:
            c.require_new_gate()
    folder = c.ROOT / 'bootstrap_receipts'; folder.mkdir(exist_ok=True)
    receipt = folder / (str(os.getpid()) + '.json')
    row = {'state': 'admitted_preimport', 'wrapped_process_identity': identity, 'original_unwrapped_command': original,
        'original_target': str(target), 'source_manifest_sha256': c.sha(c.ROOT / 'MANIFEST.json'),
        'public_setting': 'wp.config.log_level = wp.LOG_WARNING'}
    c.write_once(receipt, row)
    def configure():
        row.update(configure_warning(), state='entered_original')
        c.write(receipt, row)
    try:
        enter_original(original, configure)
    except BaseException as error:
        row.update(state='original_raised', exception_type=type(error).__name__)
        c.write(receipt, row)
        raise
    row['state'] = 'original_returned'; c.write(receipt, row)


if __name__ == '__main__':
    main()
