"""One low-memory import/initialization audit; no environment or training work."""
import argparse
import importlib
import importlib.metadata
import os
from pathlib import Path
import sys

import completion_contract as c


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case', required=True, choices=('i1', 'i2'))
    args = parser.parse_args()
    c.require_bootstrap(Path(__file__))
    manifest = c.check_manifest()
    calls = {}
    def invoke(name, function, *values, **kwargs):
        calls[name] = calls.get(name, 0) + 1
        return function(*values, **kwargs)
    import torch
    import warp as wp
    assert wp.config.log_level == wp.LOG_WARNING
    invoke('torch.cuda.set_device', torch.cuda.set_device, 1)
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    folder = c.ORIGINAL_ROOT / ('source_i1' if args.case == 'i1' else 'source_i2')
    name = 'train_kl_relative' if args.case == 'i1' else 'train_pae_baseline'
    sys.path.insert(0, str(folder))
    module = invoke('import_original_trainer', importlib.import_module, name)
    assert Path(module.__file__).resolve() == folder / (name + '.py')
    invoke('wp.init', wp.init)
    invoke('wp.set_device', wp.set_device, 'cuda:1')
    device = invoke('wp.get_device', wp.get_device, 'cuda:1')
    assert device.ordinal == 1 and device.uuid == c.GPU1_UUID
    assert torch.cuda.current_device() == 1
    value = invoke('torch.empty_one_scalar', torch.empty, (1,), device='cuda:1')
    invoke('wp.synchronize_device', wp.synchronize_device, 'cuda:1')
    invoke('torch.cuda.synchronize', torch.cuda.synchronize, 1)
    snapshot = c.frozen_old().snapshot()
    rows = c.frozen_old().assert_gpu1_allocations([os.getpid()], snapshot, require_context=[os.getpid()])
    versions = c.read(c.ORIGINAL_ROOT / 'RUNTIME_REFERENCE.json')['versions']
    assert {package: importlib.metadata.version(package) for package in versions} == versions
    output = c.ROOT / ('resource_init_audit_' + args.case + '.json')
    assert not output.exists(), 'A resource audit cannot be repeated'
    c.write(output, {'state': 'passed', 'case': args.case, 'source_manifest_sha256': c.sha(c.ROOT / 'MANIFEST.json'),
        'identity': c.frozen_old().inspect_identity(os.getpid()), 'original_import_file': str(module.__file__),
        'backend_device': 'cuda:1', 'backend_uuid': device.uuid, 'runtime_versions': versions,
        'public_log_level': wp.config.log_level, 'actual_GPU_snapshot': snapshot, 'own_allocation_rows': rows,
        'direct_audit_calls': calls, 'call_counter_scope': 'Explicit audit calls only; import-internal library calls are not instrumented',
        'environment_constructions': 0, 'environment_steps': 0, 'training_transitions': 0,
        'evaluation_transitions': 0, 'optimizer_constructions': 0, 'optimizer_steps': 0,
        'model_constructions': 0, 'normalizer_constructions': 0, 'scalar_shape': list(value.shape),
        'peak_torch_reserved_bytes_GPU1': torch.cuda.max_memory_reserved(1),
        'scientific_training_or_policy_equivalence_claim': False})


if __name__ == '__main__':
    main()
