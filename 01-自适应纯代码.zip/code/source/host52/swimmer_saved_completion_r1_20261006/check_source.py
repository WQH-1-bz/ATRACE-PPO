"""Finite source/stdlib checks; --read-only never writes the frozen bundle."""
import argparse
import ast
import copy
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import completion_contract as c
import source_fixtures
import lifecycle_fixtures


def old_inventory():
    rows = {}
    for root in (c.OLD_ROOT, c.OLD_ROOT.parent / c.ORIGINAL_ROOT.name):
        m = c.read(root / 'MANIFEST.json')
        for name, digest in m['bundle_hashes'].items():
            p = root / name
            assert not p.is_symlink() and c.sha(p) == digest and p.stat().st_mode & 0o777 == 0o444
            rows[str(p)] = {'sha256': digest, 'mode': 0o444}
        rows[str(root / 'MANIFEST.json')] = {'sha256': c.sha(root / 'MANIFEST.json'), 'mode': (root / 'MANIFEST.json').stat().st_mode & 0o777}
    assert len(rows) == 72 + 71 + 2
    c.guard_blocked_prototype()
    blocked = c.ROOT / 'inputs/blocked_completion_source' if c.ROOT == c.NATIVE_ROOT else c.ROOT.parent / 'swimmer_saved_completion_20261006'
    protected = c.read(c.ROOT / 'inputs/PARENT_BLOCKED_COMPLETION_SOURCE_VERIFIED.json')['frozen_deployment_files_sha256']
    for name, digest in protected.items():
        p = blocked / name
        assert not p.is_symlink() and c.sha(p) == digest and p.stat().st_mode & 0o777 == 0o444
        rows[str(p)] = {'sha256': digest, 'mode': 0o444}
    return rows


def expected_stress():
    old = (c.OLD_ROOT / 'stress_checkpoint_gpu1.py').read_text()
    result = old.replace("RECOVERY_ROOT = Path('/home/mumu01/ssd3/wch/swimmer_innovation12_gpu1_resume_v3r3_20261006')", "RECOVERY_ROOT = Path('/home/mumu01/ssd3/wch/swimmer_saved_completion_r1_20261006')")
    result = result.replace("    assert path.parent in ((ROOT / 'runs').resolve(), (RECOVERY_ROOT / 'runs').resolve()), ('output root outside explicit allowlist', path)",
        "    import completion_contract as c\n    c.require_bootstrap(Path(__file__))\n    c.check_manifest(); c.check_new_authorization(fresh=False); c.check_old_readonly(); c.require_new_gate()\n    allowed = {RECOVERY_ROOT / 'runs' / ('innovation2__seed' + str(seed)) for seed in c.NEW_SEEDS}\n    assert path in allowed, ('output outside six NEW cloned checkpoints', path)\n    c.verify_inputs_and_clones()")
    return result.replace('        target = ROOT / sub', '        target = RECOVERY_ROOT / sub')


def ast_proof():
    actual = (c.ROOT / 'stress_checkpoint_gpu1.py').read_text()
    expected = expected_stress()
    assert actual == expected, 'Stress changed beyond exact scoped root/allowlist/cache adapter'
    assert ast.dump(ast.parse(actual), include_attributes=False) == ast.dump(ast.parse(expected), include_attributes=False)
    old = (c.OLD_ROOT / 'resource_init_audit.py').read_text()
    expected_audit = old.replace('import gpu1_contract as c','import completion_contract as c').replace('c.load_manifest()', 'c.check_manifest()').replace('c.snapshot()', 'c.frozen_old().snapshot()').replace('c.assert_gpu1_allocations(', 'c.frozen_old().assert_gpu1_allocations(').replace('c.inspect_identity(', 'c.frozen_old().inspect_identity(')
    assert (c.ROOT / 'resource_init_audit.py').read_text() == expected_audit
    old_boot, new_boot = [ast.parse(p.read_text()) for p in (c.OLD_ROOT / 'resource_bootstrap.py', c.ROOT / 'resource_bootstrap.py')]
    for name in ('configure_warning', 'enter_original'):
        nodes = [next(n for n in t.body if getattr(n, 'name', None) == name) for t in (old_boot, new_boot)]
        assert ast.dump(nodes[0], include_attributes=False) == ast.dump(nodes[1], include_attributes=False)
    tree = ast.parse(actual)
    scientific_names = ('validate_stress', 'assert_state', 'source_api_contract')
    oldtree = ast.parse((c.OLD_ROOT / 'stress_checkpoint_gpu1.py').read_text())
    for name in scientific_names:
        pair = [next(n for n in t.body if getattr(n, 'name', None) == name) for t in (oldtree, tree)]
        assert ast.dump(pair[0], include_attributes=False) == ast.dump(pair[1], include_attributes=False)
    original = c.OLD_ROOT.parent / c.ORIGINAL_ROOT.name
    run = ast.parse((original / 'run_transfer.py').read_text())
    verify = next(n for n in run.body if getattr(n, 'name', None) == 'verify_i2')
    assert not any(isinstance(n, ast.Subscript) and isinstance(n.slice, ast.Constant) and n.slice.value == 'out' for n in ast.walk(verify))
    return {'state': 'passed', 'stress_derivative_exact_bytes': True, 'all_unscoped_scientific_AST_unchanged': True,
        'changes': ['RECOVERY_ROOT', 'six_new_clone_operation_allowlist_and_readonly_guards', 'five_cache_targets_RECOVERY_ROOT'],
        'old_stress_sha256': c.sha(c.OLD_ROOT / 'stress_checkpoint_gpu1.py'), 'new_stress_sha256': c.sha(c.ROOT / 'stress_checkpoint_gpu1.py'),
        'original_verify_i2_outpath_not_required': True, 'original_verify_analyze_bytes_preserved': True,
        'zero_init_audit_exact_operational_derivative': True, 'WARNING_and_runpy_AST_exact': True}


def static_contracts():
    for name, digest in c.INPUT_SHA.items():
        assert c.sha(c.ROOT / 'inputs' / name) == digest, ('Pinned parent input changed', name)
    for p in c.ROOT.glob('*.py'):
        ast.parse(p.read_text(), filename=str(p))
    runner = (c.ROOT / 'run_completion.py').read_text(); bootstrap = (c.ROOT / 'resource_bootstrap.py').read_text()
    assert 'r.verify(job)' in runner and 'r.analyze(jobs)' in runner
    assert 'r.main(' not in runner and 'r.command(' not in runner and 'train_pae_baseline.py' not in runner
    assert "('run_completion.py', 'verify_parent.py', 'resource_init_audit.py', 'stress_checkpoint_gpu1.py')" in bootstrap
    assert 'original queue targets' in bootstrap and 'source_i1/train' not in bootstrap and 'source_i2/train' not in bootstrap
    assert 'resources.wait(\'initialization_\' + case)' in runner and "resources.wait('initialization_' + case, 1024)" not in runner
    assert "'active_helper': active_helper" in runner and 'begin_verification, end_verification' in runner
    assert 'c.validate_lifecycle(state, proof[\'unit\'], args.phase)' in (c.ROOT / 'verify_parent.py').read_text()
    unit = (c.ROOT / c.UNIT).read_text()
    assert 'UnsetEnvironment=CUDA_VISIBLE_DEVICES' in unit and 'Restart=no' in unit and 'KillMode=process' in unit
    for key, value in c.FLAGS.items():
        assert key + '=' + value in unit
    for key, tail in (('XDG_CACHE_HOME', 'cache'), ('WARP_CACHE_PATH', 'cache/warp'), ('CUDA_CACHE_PATH', 'cache/cuda'), ('TORCH_HOME', 'cache/torch'), ('TMPDIR', 'tmp')):
        assert key + '=' + str(c.NATIVE_ROOT / tail) in unit
    c.validate_plan(c.read(c.ROOT / 'TASK_PLAN.json')['jobs'])
    return {'state': 'passed', 'only_checkpoint_stress_and_zero_init_Popen_paths': True, 'deterministic_environment': True, 'no_original_main': True}


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--read-only', action='store_true'); args = parser.parse_args()
    before = old_inventory()
    proof = ast_proof(); static = static_contracts(); fixtures = source_fixtures.run(); lifecycle = lifecycle_fixtures.run()
    original_check = subprocess.run([sys.executable, '-B', str(c.OLD_ROOT / 'check_source.py'), '--read-only'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    assert original_check.returncode == 0, original_check.stdout
    assert old_inventory() == before, 'Source checks modified old bytes or modes'
    result = {'state': 'passed_source_only', 'AST_proof': proof, 'static_contracts': static, 'fixtures': fixtures, 'lifecycle_fixtures': lifecycle,
        'old_frozen_source_checks_passed_readonly': True, 'old_sources_preserved': len(before),
        'Torch_Warp_CUDA_imported': False, 'SSH_or_native_actions': False, 'new_training': False}
    if args.read_only:
        c.check_manifest()
    else:
        (c.ROOT / 'AST_SCIENCE_PROOF.json').write_text(json.dumps(proof, indent=2) + '\n')
        (c.ROOT / 'STDLIB_FIXTURES_VERIFIED.json').write_text(json.dumps(result, indent=2) + '\n')
    assert not any(name in sys.modules for name in ('torch', 'warp', 'numpy'))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
