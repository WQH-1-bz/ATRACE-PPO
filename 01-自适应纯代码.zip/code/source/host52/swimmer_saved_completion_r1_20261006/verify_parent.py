"""One-shot new completion admission/startup/terminal checks; no original main."""
import argparse
import os
from pathlib import Path
import subprocess

import completion_contract as c


def unit():
    raw = subprocess.check_output(['systemctl', '--user', 'show', c.UNIT,
        '--property=ActiveState,SubState,MainPID,Result,ExecMainStatus,Restart,KillMode,ExecStart'], text=True, timeout=15)
    row = dict(line.split('=', 1) for line in raw.splitlines() if '=' in line)
    assert row['Restart'] == 'no' and row['KillMode'] == 'process'
    assert str(c.ROOT / 'resource_bootstrap.py') in row['ExecStart'] and str(c.ROOT / 'run_completion.py') in row['ExecStart']
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', required=True, choices=('prelaunch', 'startup', 'terminal16'))
    args = parser.parse_args()
    assert c.ROOT == c.NATIVE_ROOT and 'CUDA_VISIBLE_DEVICES' not in os.environ
    c.require_bootstrap(Path(__file__)); c.check_manifest()
    admission = c.check_new_authorization(fresh=False)
    old = c.check_old_readonly(); historical = c.old_operational_observation()
    plan = c.read(c.ROOT / 'TASK_PLAN.json')['jobs']
    if args.phase == 'prelaunch':
        assert not (c.ROOT / 'suite_status.json').exists()
        c.capture_inputs_and_clones(plan)
        from run_completion import init_gate
        gate = init_gate(plan, admission)
        c.write_once(c.ROOT / 'PARENT_NATIVE_PREFLIGHT_VERIFIED.json', {'state': 'passed', 'phase': 'prelaunch',
            'source_manifest_sha256': c.sha(c.ROOT / 'MANIFEST.json'), 'admission_receipt_hashes': admission,
            'training_guard': c.verify_inputs_and_clones(), 'new_resource_gate_sha256': c.sha(c.ROOT / 'COMPLETION_RESOURCE_GATE_VERIFIED.json'),
            'old_guard': old, 'old_queue': historical, 'training_launches': 0, 'new_initialization_audits': gate['initialization_audits'],
            'scientific_completion_claimed': False, 'old_queue_terminal_completion_claimed': False})
        return
    c.require_new_gate(); guard = c.verify_inputs_and_clones()
    state = c.read(c.ROOT / 'suite_status.json')
    assert state['failure'] is None and state['source_manifest_sha256'] == c.sha(c.ROOT / 'MANIFEST.json')
    assert state['physical_gpus'] == [1] and state['training_launches'] == 0 and state['old_queue_terminal_completion_claimed'] is False
    jobs = state['jobs']; assert len(jobs) == 16
    assert {(j['arm'], j['seed']) for j in jobs} == {(a, s) for a in ('innovation1', 'innovation2') for s in range(21, 29)}
    for j, saved in zip(jobs, plan):
        for key in saved:
            if key != 'state':
                assert j[key] == saved[key], ('completion plan identity changed', j['id'], key)
        assert j['state'] in ('verifying', 'completed') and j['returncode'] is None
        c.complete_training(j)
    proof = {'state': 'passed', 'phase': args.phase, 'source_manifest_sha256': c.sha(c.ROOT / 'MANIFEST.json'),
        'training_guard': guard, 'unit': unit(), 'old_queue': historical, 'training_launches': 0,
        'completed_count': sum(j['state'] == 'completed' for j in jobs), 'old_queue_terminal_completion_claimed': False}
    proof['lifecycle'] = c.validate_lifecycle(state, proof['unit'], args.phase)
    if args.phase == 'terminal16':
        assert state['state'] == 'completed' and proof['completed_count'] == 16
        proof['helper_receipts'] = c.require_helper_history(state['helper_history'])
        r = c.load_original(); r.torch.cuda.set_device(1); r.torch.set_num_threads(1); r.torch.use_deterministic_algorithms(True)
        from run_completion import Resources, verify_with_samples
        resources = Resources(jobs, r.torch)
        for j in jobs:
            metrics = verify_with_samples(r, j, resources)
            comparison = c.frozen_old().compare_saved_metrics(r, metrics, j['metrics'], j['arm'])
            assert comparison['metrics_hard_equal'] is True
        recomputed = r.analyze(jobs)
        assert c.frozen_old().hard_equal(recomputed, c.read(c.ROOT / 'ANALYSIS.json'))
        assert recomputed['Holm_family'] == 32 and len(recomputed['control_rows']) == 64
        c.write_once(c.ROOT / 'PARENT_RECOMPUTED_ANALYSIS.json', recomputed)
        proof.update(all16_original_science_verified=True, all8_seeds=list(range(21, 29)), Holm_family=32, control_rows=64)
    c.check_old_readonly(); c.verify_inputs_and_clones()
    c.write_once(c.ROOT / ('PARENT_NATIVE_' + args.phase + '_VERIFIED.json'), proof)


if __name__ == '__main__':
    main()
