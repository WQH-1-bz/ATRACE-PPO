"""Local SOURCE ONLY one-shot freeze after finite checks; no native action."""
import argparse
from datetime import datetime, timezone
import difflib
import json
from pathlib import Path
import subprocess
import sys

import completion_contract as c


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--freeze', action='store_true', required=True); parser.parse_args()
    assert c.ROOT != c.NATIVE_ROOT and not (c.ROOT / 'MANIFEST.json').exists(), 'Never edit/rebuild a frozen source version'
    result = subprocess.run([sys.executable, '-B', str(c.ROOT / 'check_source.py')], capture_output=True, text=True)
    assert result.returncode == 0, result.stdout + result.stderr
    sources = sorted(p for p in c.ROOT.iterdir() if p.is_file() and (p.suffix in ('.py', '.md', '.service') or p.name == 'TASK_PLAN.json'))
    diff = []
    for p in sources:
        old_name = p.name if p.name in ('stress_checkpoint_gpu1.py', 'resource_init_audit.py', 'resource_bootstrap.py') else None
        before = (c.OLD_ROOT / old_name).read_text().splitlines(keepends=True) if old_name else []
        diff.extend(difflib.unified_diff(before, p.read_text().splitlines(keepends=True),
            fromfile=str(c.OLD_ROOT / old_name) if old_name else '/dev/null', tofile=str(p), n=3))
    (c.ROOT / 'SOURCE_ATOMIC_DIFF.patch').write_text(''.join(diff))
    fixtures = c.read(c.ROOT / 'STDLIB_FIXTURES_VERIFIED.json')
    report = {'state': 'READY_source_only', 'checked_utc': datetime.now(timezone.utc).isoformat(),
        'root': str(c.ROOT), 'native_root': str(c.NATIVE_ROOT), 'unit': c.UNIT, 'physical_gpus': [1], 'physical_gpu_uuid': c.GPU1_UUID,
        'parent_source_preparation_decision_sha256': c.INPUT_SHA['PARENT_COMPLETION_R1_LIFECYCLE_DECISION.json'],
        'blocked_prototype_preserved_source_carried': 23, 'lifecycle_proofs': ['active_helper', 'startup_actual_unit_and_coordinator', 'terminal_successful_unit_and_coordinator_exit'],
        'provisional_lifecycle_review_received_before_freeze': True, 'provisional_review_reported_independent_stdlib_checks': 119,
        'provisional_review_is_not_native_authorization': True,
        'old_manifest_sha256': c.OLD_MANIFEST_SHA, 'old_contract_sha256': c.OLD_CONTRACT_SHA,
        'source_checks': fixtures, 'actual_six_capture_raw_inventory_authority': True,
        'all16_external_unknown_returncodes_preserved_null': True, 'seed24_old_Popen0_separate_provenance': True,
        'old_coordinator_preserved_alive_stalled': True, 'new_gate': 'two_zero_training_initialization_audits_then_six_checkpoint_stress_only',
        'training_launches': 0, 'Torch_Warp_CUDA_imports': 0, 'SSH_or_remote_mutation': False,
        'deployment_or_native_approval': False, 'requires_independent_review_parentapproval_NEW_actual_Luna': True}
    (c.ROOT / 'BUILDER_REPORT.json').write_text(json.dumps(report, indent=2) + '\n')
    files = sorted(p for p in c.ROOT.rglob('*') if p.is_file())
    assert not any(p.is_symlink() for p in c.ROOT.rglob('*'))
    hashes = {str(p.relative_to(c.ROOT)): c.sha(p) for p in files}
    manifest = {'state': 'READY_source_only', 'version': 'swimmer_saved_completion_r1_20261006',
        'native_root': str(c.NATIVE_ROOT), 'service': c.UNIT, 'physical_gpus': [1], 'physical_gpu_uuid': c.GPU1_UUID,
        'old_manifest_sha256': c.OLD_MANIFEST_SHA, 'old_contract_sha256': c.OLD_CONTRACT_SHA,
        'original_manifest_sha256': c.frozen_old().ORIGINAL_MANIFEST_SHA, 'input_hashes': c.INPUT_SHA,
        'bundle_hashes': hashes, 'deployment_files': sorted([*hashes, 'MANIFEST.json', 'MANIFEST.sha256']),
        'deployment_file_mode': '0444', 'stress_adapter_sha256': hashes['stress_checkpoint_gpu1.py'],
        'completed_training_adoptions': 16, 'new_checkpoint_stress_helpers': 6, 'training_launches': 0,
        'new_initialization_audits': 2, 'saved_short_replays': 0, 'parent_owns_native_admission': True}
    (c.ROOT / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
    digest = c.sha(c.ROOT / 'MANIFEST.json'); (c.ROOT / 'MANIFEST.sha256').write_text(digest + '\n')
    for name in manifest['deployment_files']:
        (c.ROOT / name).chmod(0o444)
    c.check_manifest()
    print(json.dumps({'state': 'frozen_source_only', 'manifest_sha256': digest, 'bundle_files': len(hashes), 'deployment_files': len(manifest['deployment_files']), 'mode': '0444'}))


if __name__ == '__main__':
    main()
