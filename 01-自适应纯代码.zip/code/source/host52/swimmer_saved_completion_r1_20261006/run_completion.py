"""Six checkpoint-only stress helpers, original sixteen verification and Holm32."""
import copy
import fcntl
import os
from pathlib import Path
import subprocess
import threading
import time
import traceback

import completion_contract as c


class Resources:
    def __init__(self, jobs, torch=None):
        self.jobs, self.torch = jobs, torch
        self.old = c.frozen_old()
        self.reservation = self.old.reservation_mib(self.old.read(c.OLD_ROOT / 'RESOURCE_GATE_VERIFIED.json')['reservation_mib'])
        self.physical_peaks, self.allocator_peak, self.latest = {}, 0, None
        if (c.ROOT / 'COMPLETION_RESOURCE_GATE_VERIFIED.json').exists():
            self.reservation = max(self.reservation, c.require_new_gate()['reservation_mib'])
        if (c.ROOT / 'suite_status.json').exists():
            saved = c.read(c.ROOT / 'suite_status.json')
            assert saved['source_manifest_sha256'] == c.sha(c.ROOT / 'MANIFEST.json')
            self.reservation = max(self.reservation, saved['reservation_mib'])
            self.physical_peaks = {int(k): v for k, v in saved['sampled_physical_peaks_mib'].items()}
            self.allocator_peak = saved['coordinator_allocator_peak_reserved_bytes_gpu1']

    def sample(self, own_pids=(), require_context=()):
        old_queue = c.old_operational_observation()
        live = c.live_inputs(self.jobs)
        pids = [os.getpid(), old_queue['coordinator_identity']['pid'], *[j['pid'] for j in live], *own_pids]
        self.latest = self.old.snapshot()
        self.old.assert_gpu1_allocations(pids, self.latest, require_context=require_context)
        memory = self.latest['gpu1_pid_memory_mib']
        for pid in [os.getpid(), *own_pids]:
            self.physical_peaks[pid] = max(self.physical_peaks.get(pid, 0), memory.get(pid, 0))
        if self.torch is not None:
            self.allocator_peak = max(self.allocator_peak, self.torch.cuda.max_memory_reserved(1))
        self.reservation = self.old.reservation_mib(self.reservation, self.physical_peaks.values(), [self.allocator_peak / 1024**2])
        return self.latest

    def wait(self, stage, allowance=None):
        deadline = time.monotonic() + 21600
        while True:
            snap = self.sample()
            evidence = c.capacity(self.jobs, snap, self.reservation, allowance)
            evidence.update(driver_pid=os.getpid(), historical_coordinator_pid=c.read(c.ROOT / 'inputs/V3R3_SUITE_STATUS_AT_DEADLOCK.json')['coordinator_pid'],
                historical_coordinator_actual_mib=snap['gpu1_pid_memory_mib'].get(c.read(c.ROOT / 'inputs/V3R3_SUITE_STATUS_AT_DEADLOCK.json')['coordinator_pid'], 0))
            if evidence['free_mib'] >= evidence['required_free_mib']:
                return evidence
            c.write(c.ROOT / 'CAPACITY_PROGRESS.json', {'state': 'waiting_memory', 'stage': stage, **evidence})
            assert time.monotonic() < deadline, 'Bounded six-hour helper capacity wait expired; no retry or process control'
            time.sleep(1)


def init_gate(jobs, admission):
    c.write_once(c.ROOT / 'COMPLETION_RESOURCE_GATE_ATTEMPT.json', {'state': 'started', 'source_manifest_sha256': c.sha(c.ROOT / 'MANIFEST.json'),
        'admission_receipt_hashes': admission, 'new_training_transitions': 0})
    resources = Resources(jobs)
    histories = []
    for case in ('i1', 'i2'):
        evidence = resources.wait('initialization_' + case)
        command = c.bootstrap_command([str(c.ORIGINAL_ROOT / '.venv/bin/python'), str(c.ROOT / 'resource_init_audit.py'), '--case', case])
        log = c.ROOT / ('resource_init_' + case + '.log')
        peak, samples, identity = 0, 0, None
        with log.open('x') as stream:
            process = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT, env=c.execution_env(), cwd=c.ROOT)
            began = time.monotonic()
            while True:
                actual = resources.old.inspect_identity(process.pid, expected_start_ticks=identity['start_ticks'] if identity else None)
                if actual is not None:
                    resources.old.check_identity({'id': 'completion init ' + case, 'pid': process.pid, 'start_ticks': actual['start_ticks'], 'command': command}, actual)
                    identity = actual
                else:
                    assert process.poll() is not None, 'Audit exit needs actual owned Popen returncode'
                snap = resources.sample([process.pid]); samples += 1
                peak = max(peak, snap['gpu1_pid_memory_mib'].get(process.pid, 0))
                assert peak <= 1024, ('zero-training initialization allowance exceeded', case, peak)
                if process.poll() is not None:
                    break
                assert time.monotonic() - began < 300, 'Bounded audit expired; no process control or retry'
                time.sleep(.05)
        assert process.returncode == 0, ('initialization failed', case, process.returncode)
        audit_path = c.ROOT / ('resource_init_audit_' + case + '.json')
        audit = c.read(audit_path)
        assert identity is not None and audit['identity'] == identity
        before = resources.reservation
        resources.reservation = resources.old.reservation_mib(before, [peak], [audit['peak_torch_reserved_bytes_GPU1'] / 1024**2])
        histories.append({'case': case, 'pid': process.pid, 'identity': identity, 'actual_Popen_returncode': process.returncode,
            'sampled_peak_mib': peak, 'NVML_samples': samples, 'admission': evidence, 'receipt_sha256': c.sha(audit_path), 'log': str(log),
            'reservation_before_result_mib': before, 'reservation_after_result_mib': resources.reservation})
    c.check_old_readonly(); c.verify_inputs_and_clones()
    c.write_once(c.ROOT / 'COMPLETION_RESOURCE_GATE_VERIFIED.json', {'state': 'passed', 'source_manifest_sha256': c.sha(c.ROOT / 'MANIFEST.json'),
        'training_guard_sha256': c.sha(c.ROOT / 'COMPLETED_TRAINING_GUARD.json'), 'admission_receipt_hashes': admission,
        'initialization_audits': 2, 'audit_histories': histories, 'reservation_mib': resources.reservation,
        'new_training_transitions': 0, 'new_optimizer_steps': 0, 'saved_short_replays_rerun': 0,
        'old_engineering_gate_reused_readonly': True})
    return c.require_new_gate()


def verify_with_samples(r, job, resources, on_begin=None, on_end=None):
    resources.wait('source_native_scientific_verification_' + job['id'])
    stopped, errors = threading.Event(), []
    def observe():
        try:
            while not stopped.wait(.05):
                resources.sample()
        except BaseException as error:
            errors.append(error)
    resources.sample()
    if on_begin is not None:
        on_begin()
    observer = threading.Thread(target=observe, name='completion-UUID-observer', daemon=True)
    observer.start()
    succeeded = False
    try:
        try:
            result = r.verify(job)
        finally:
            stopped.set(); observer.join(timeout=10)
        assert not observer.is_alive(), 'Bounded verifier sampler did not finish'
        if errors:
            raise errors[0]
        resources.sample()
        succeeded = True
        return result
    finally:
        if on_end is not None:
            on_end(succeeded)


def main():
    assert c.ROOT == c.NATIVE_ROOT and 'CUDA_VISIBLE_DEVICES' not in os.environ
    c.require_bootstrap(Path(__file__)); c.check_manifest(); c.check_new_authorization(fresh=False)
    c.check_old_readonly(); c.require_new_gate(); c.verify_inputs_and_clones()
    lock = (c.ROOT / 'COORDINATOR.lock').open('x')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not (c.ROOT / 'suite_status.json').exists(), 'Completion queue cannot be restarted'
    jobs = copy.deepcopy(c.read(c.ROOT / 'TASK_PLAN.json')['jobs'])
    for j in jobs:
        c.complete_training(j)
    r = c.load_original()
    torch = r.torch
    torch.cuda.set_device(1); torch.use_deterministic_algorithms(True); torch.set_num_threads(1)
    r.check_sources(); before = r.verify_protected()
    resources, history, failure, active_helper = Resources(jobs, torch), [], None, None
    coordinator = c.frozen_old().inspect_identity(os.getpid())
    expected_coordinator_command = c.bootstrap_command([str(c.ORIGINAL_ROOT / '.venv/bin/python'), str(c.ROOT / 'run_completion.py')])
    assert c.frozen_old().check_identity({'id': 'completion coordinator', 'pid': os.getpid(), 'start_ticks': coordinator['start_ticks'], 'command': expected_coordinator_command}, coordinator)
    def status(state):
        c.write(c.ROOT / 'suite_status.json', {'state': state, 'task': 'Swimmer', 'total': 16,
            'completed_count': sum(j['state'] == 'completed' for j in jobs), 'jobs': jobs, 'failure': failure,
            'physical_gpus': [1], 'physical_gpu_uuid': c.GPU1_UUID, 'engineering_gate': True,
            'helper_history': history, 'active_helper': active_helper, 'reservation_mib': resources.reservation, 'headroom_mib': c.HEADROOM_MIB,
            'sampled_physical_peaks_mib': resources.physical_peaks, 'coordinator_allocator_peak_reserved_bytes_gpu1': resources.allocator_peak,
            'latest_gpu_snapshot': resources.latest, 'coordinator_identity': coordinator,
            'source_manifest_sha256': c.sha(c.ROOT / 'MANIFEST.json'), 'training_launches': 0,
            'old_queue': c.old_operational_observation(), 'old_queue_terminal_completion_claimed': False, 'retry': False})
    try:
        resources.sample(); status('adopting_completed_training')
        for job in jobs:
            if job['clone_required']:
                admission = resources.wait('checkpoint_stress_' + job['id'])
                path = Path(job['path'])
                assert not any((path / n).exists() for n in c.EXTRAS), 'Checkpoint stress cannot be repeated'
                command = c.bootstrap_command([str(c.ORIGINAL_ROOT / '.venv/bin/python'), str(c.ROOT / 'stress_checkpoint_gpu1.py'),
                    '--job-path', job['path'], '--device', 'cuda:1'])
                log = c.ROOT / (job['id'] + '.stress.log')
                peak, identity, samples = 0, None, 0
                with log.open('x') as stream:
                    process = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT, env=c.execution_env(), cwd=c.ROOT)
                    began = time.monotonic()
                    identity = c.frozen_old().inspect_identity(process.pid)
                    if identity is None:
                        assert process.poll() is not None, 'Initial stress absence needs actual owned Popen completion'
                    else:
                        c.frozen_old().check_identity({'id': job['id'] + '__stress', 'pid': process.pid, 'start_ticks': identity['start_ticks'], 'command': command}, identity)
                        active_helper = {**identity, 'job': job['id'], 'stage': 'checkpoint_only_stress',
                            'device': 'cuda:1', 'gpu': 1, 'physical_gpu_uuid': c.GPU1_UUID, 'log': str(log),
                            'in_process_verification': False, 'sampled_peak_mib': 0, 'state': 'running', 'actual_Popen_returncode': None}
                        status('checkpoint_stress' if active_helper is not None else 'verifying')
                    while True:
                        actual = c.frozen_old().inspect_identity(process.pid, expected_start_ticks=identity['start_ticks'] if identity else None)
                        if actual is not None:
                            c.frozen_old().check_identity({'id': job['id'] + '__stress', 'pid': process.pid, 'start_ticks': actual['start_ticks'], 'command': command}, actual)
                            identity = actual
                        else:
                            assert process.poll() is not None, 'Stress exit needs actual owned Popen returncode'
                        snap = resources.sample([process.pid]); samples += 1
                        peak = max(peak, snap['gpu1_pid_memory_mib'].get(process.pid, 0))
                        if active_helper is not None:
                            active_helper['sampled_peak_mib'] = peak
                        status('checkpoint_stress' if active_helper is not None else 'verifying')
                        if process.poll() is not None:
                            break
                        assert time.monotonic() - began < 21600, 'Bounded six-hour stress execution expired; no retry or process control'
                        time.sleep(.5)
                receipt = {'job': job['id'], 'state': 'completed' if process.returncode == 0 else 'failed',
                    'stage': 'checkpoint_only_stress', 'actual_Popen_returncode': process.returncode, 'pid': process.pid,
                    'identity': identity, 'command': command, 'admission': admission, 'sampled_peak_mib': peak,
                    'NVML_samples': samples, 'new_training_transitions': 0, 'log': str(log),
                    'source_manifest_sha256': c.sha(c.ROOT / 'MANIFEST.json'), 'new_resource_gate_sha256': c.sha(c.ROOT / 'COMPLETION_RESOURCE_GATE_VERIFIED.json')}
                assert identity is not None, 'Owned stress identity never observed; cannot claim completed helper provenance'
                if process.returncode == 0:
                    report = c.read(path / 'checkpoint_stress_result.json')
                    before_result = resources.reservation
                    resources.reservation = c.frozen_old().reservation_mib(resources.reservation, [peak], [report['peak_torch_memory_reserved_bytes'] / 1024**2])
                    assert report['helper_sha256'] == c.sha(c.ROOT / 'stress_checkpoint_gpu1.py') and report['seed'] == job['seed']
                    receipt.update(result_sha256=c.sha(path / 'checkpoint_stress_result.json'), stress_sha256=c.sha(path / 'stress_evaluation.json'),
                        checkpoint_sha256=c.sha(path / 'latest.pt'), reservation_before_result_mib=before_result,
                        reservation_after_result_mib=resources.reservation)
                history.append(receipt)
                c.write_once(c.ROOT / ('STRESS_HELPER_' + job['id'] + '.json'), receipt)
                active_helper = None
                status('verifying')
                assert process.returncode == 0, ('Checkpoint-only stress failed', job['id'], process.returncode)
            elif job['arm'] == 'innovation2':
                saved = c.frozen_old().validate_completed_stress(job)
                history.append({'job': job['id'], 'reused_historical_stress': True, 'new_helper_execution': False,
                    'historical_helper_returncode': saved['original_helper_returncode'], 'historical_Popen_returncode_known': saved['Popen_returncode_known']})
            def begin_verification():
                nonlocal active_helper
                assert active_helper is None
                active_helper = {**coordinator, 'job': job['id'], 'stage': 'source_native_scientific_verification',
                    'device': 'cuda:1', 'gpu': 1, 'physical_gpu_uuid': c.GPU1_UUID, 'log': str(c.ROOT / 'coordinator.log'),
                    'in_process_verification': True, 'state': 'verifying', 'actual_Popen_returncode': None}
                status('verifying')
            def end_verification(succeeded):
                nonlocal active_helper
                history.append({**active_helper, 'state': 'completed' if succeeded else 'failed',
                    'in_process_verification': True, 'actual_Popen_returncode': None})
                active_helper = None
                status('verifying')
            job['metrics'] = verify_with_samples(r, job, resources, begin_verification, end_verification)
            job['completion_evidence'] = {'source_native_verified': True, 'complete_budget': c.BUDGET,
                'external_trainer_returncode': None, 'exitcode_known_to_completion_coordinator': False}
            job['state'] = 'completed'
            c.check_old_readonly(); c.verify_inputs_and_clones(); r.check_sources(); r.verify_protected()
            status('verifying')
        assert len(jobs) == 16 and all(j['state'] == 'completed' for j in jobs)
        analysis = r.analyze(jobs)
        assert analysis['Holm_family'] == 32 and analysis['all8_seeds'] == list(range(21, 29))
        c.write_once(c.ROOT / 'ANALYSIS.json', analysis)
        c.write_once(c.ROOT / 'PROTECTED_AFTER.json', {'before': before, 'after': r.verify_protected()})
        c.check_old_readonly(); c.verify_inputs_and_clones(); status('completed')
    except BaseException:
        failure = {'state': 'failed', 'traceback': traceback.format_exc(), 'automatic_retry': False,
            'training_launches': 0, 'old_processes_preserved': True}
        c.write(c.ROOT / 'FAILURE.json', failure); status('failed')
        raise


if __name__ == '__main__':
    main()
