"""Cold standard-library contracts; all old scientific ROOTs remain untouched."""
import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
NATIVE_ROOT = Path('/home/mumu01/ssd3/wch/swimmer_saved_completion_r1_20261006')
OLD_NATIVE_ROOT = Path('/home/mumu01/ssd3/wch/swimmer_innovation12_gpu1_resume_v3r3_20261006')
OLD_ROOT = OLD_NATIVE_ROOT if ROOT == NATIVE_ROOT else ROOT.parent / OLD_NATIVE_ROOT.name
ORIGINAL_ROOT = Path('/home/mumu01/ssd3/wch/swimmer_innovation12_transfer1_8seed_20261005')
UNIT = 'dpo-swimmer-saved-completion-r1-20261006.service'
GPU1_UUID = 'GPU-0fbea1d5-c9c9-392e-5241-f31b8aec2518'
OLD_MANIFEST_SHA = 'b2336340472f7e636999c94bb7d4fd69916f3226dd1fe9449889a7eccab7a212'
OLD_CONTRACT_SHA = 'e3c4d92275cee52196a5477c9af6909178452e9c0b6156792773ab7c600ace93'
INPUT_SHA = {
    'PARENT_COMPLETION_ONLY_RECOVERY_DECISION.json': '7e71361dc994ae2cb4e83d612c56491e0be7a32423b65379f3016f6e9917fb4a',
    'PARENT_DEADLOCK_VERIFIED.json': 'aa615fd09cb18dde5d75e49ef2bc555f428c17c0361afa54b19c22c826f354f8',
    'NATIVE_DEADLOCK_CAPTURE.json': '9f3a22d3e7539b43e736f555c07344ce330b8d5b4e56e9dcf610c427faa683c8',
    'V3R3_SUITE_STATUS_AT_DEADLOCK.json': '69b8e05121f94ef58f92c2034acc0ebad4a9a0118f2830ddb0b7dd1147ea3c70',
    'PARENT_CAPTURE_TEXT_SEMANTICS.json': '5a59260cd575ede03b5186f79053b4ee0308f1ee099afdbc8726dcc5bfca1726',
    'PARENT_BLOCKED_COMPLETION_SOURCE_VERIFIED.json': 'fffe5bcaaede2d0a0266f67c0c37aa022b917a8ca0c79ca647c0c018825cdb6c',
    'PARENT_COMPLETION_R1_LIFECYCLE_DECISION.json': '26104c4ddb60505c745ad34addbd18ab6a351d91109a4d43727d8ecef2819b9b',
    'BLOCKED_COMPLETION_REVIEW.json': '5f6aad4b0a7b889678f77414c65a617e9fcfbbf34f28adfe1a083c4f8cf5548b',
    'PARENT_BLOCKED_SOURCE_REVIEW_ACK.json': 'c90a9911b93d29d65bade21cdd38daa733b8429000523c00462f6b6addc1d949',
}
FLOOR_MIB, HEADROOM_MIB, BUDGET = 5388, 512, 10027008
NEW_SEEDS = (21, 22, 24, 25, 27, 28)
EXTRAS = frozenset(('stress_evaluation.json', 'checkpoint_stress_result.json'))
FLAGS = {'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1', 'DPO_TORCH_DETERMINISTIC': '1',
         'DPO_WARP_DETERMINISTIC': 'run_to_run', 'DPO_WARP_DETERMINISTIC_MAX_RECORDS': '8',
         'CUBLAS_WORKSPACE_CONFIG': ':4096:8', 'DPO_PPO_GRAPH': '0',
         'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONUNBUFFERED': '1'}
RECEIPTS = {'review_sha256': 'PARENT_REVIEW_AUTHORIZATION.json',
            'active_luna_sha256': 'PARENT_LUNA_ACTIVE.json', 'raw_goal_sha256': 'PARENT_LUNA_RAW_GOAL.json',
            'raw_initial_snapshot_sha256': 'PARENT_LUNA_RAW_INITIAL_SNAPSHOT.json'}


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def write(path, value):
    path = Path(path)
    safe_ancestry(path.parent)
    assert not path.is_symlink() and path.is_relative_to(ROOT) and path.parent.resolve().is_relative_to(ROOT.resolve()), ('write outside new root', path)
    if (ROOT / 'MANIFEST.json').exists():
        assert str(path.relative_to(ROOT)) not in read(ROOT / 'MANIFEST.json')['deployment_files'], ('write to frozen deployment file', path)
    assert path.name not in RECEIPTS.values() and not path.is_relative_to(ROOT / 'inputs'), ('write to external authorization/input', path)
    assert not path.is_relative_to(ROOT / 'runs'), ('generic receipt writer cannot change cloned science', path)
    temporary = path.with_name(path.name + '.' + str(os.getpid()) + '.tmp')
    with temporary.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def write_once(path, value):
    assert not Path(path).exists() and not Path(path).is_symlink(), ('one-shot receipt exists', path)
    write(path, value)


def frozen_old():
    """Import only the hash-pinned old stdlib contract, never rebind its ROOT."""
    source = OLD_ROOT / 'gpu1_contract.py'
    assert not source.is_symlink() and sha(source) == OLD_CONTRACT_SHA
    assert source.stat().st_mode & 0o777 == 0o444
    name = '_swimmer_v3r3_frozen_contract'
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, source)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    module = sys.modules[name]
    assert module.ROOT == OLD_ROOT and module.NATIVE_ROOT == OLD_NATIVE_ROOT
    assert module.ORIGINAL_ROOT == ORIGINAL_ROOT and module.GPU1_UUID == GPU1_UUID
    return module


def check_manifest(require_frozen=True):
    safe_ancestry(ROOT)
    m = read(ROOT / 'MANIFEST.json')
    assert m['state'] == 'READY_source_only' and m['native_root'] == str(NATIVE_ROOT)
    assert m['service'] == UNIT and m['physical_gpus'] == [1] and m['physical_gpu_uuid'] == GPU1_UUID
    assert m['old_manifest_sha256'] == OLD_MANIFEST_SHA and m['old_contract_sha256'] == OLD_CONTRACT_SHA
    assert m['training_launches'] == 0 and m['completed_training_adoptions'] == 16
    assert m['input_hashes'] == INPUT_SHA
    for name, digest in INPUT_SHA.items():
        assert sha(ROOT / 'inputs' / name) == digest
    decision = read(ROOT / 'inputs/PARENT_COMPLETION_R1_LIFECYCLE_DECISION.json')
    assert decision['state'] == 'authorized_source_preparation_only'
    assert decision['prospective_native_root'] == str(NATIVE_ROOT) and decision['prospective_user_unit'] == UNIT
    assert decision['physical_gpu_index'] == 1 and decision['physical_gpu_uuid'] == GPU1_UUID
    assert decision['new_training_or_shorts_or_optimizer_calls_authorized'] is False
    assert decision['source_lifecycle_repair_only'] is True and decision['blocked_completion_was_never_native_deployed'] is True
    guard_blocked_prototype()
    assert set(m['deployment_files']) == set(m['bundle_hashes']) | {'MANIFEST.json', 'MANIFEST.sha256'}
    verify_bundle_files(m['bundle_hashes'], require_frozen)
    source_inventory = {p.name for p in ROOT.glob('*.py')} | {p.name for p in ROOT.glob('*.service')}
    source_inventory |= {str(p.relative_to(ROOT)) for p in (ROOT / 'inputs').rglob('*') if p.is_file() or p.is_symlink()}
    expected_sources = {n for n in m['bundle_hashes'] if n.endswith(('.py', '.service')) or n.startswith('inputs/')}
    assert source_inventory == expected_sources, 'Unmanifested source/input file'
    if require_frozen:
        assert (ROOT / 'MANIFEST.sha256').read_text().strip() == sha(ROOT / 'MANIFEST.json')
        for name in ('MANIFEST.json', 'MANIFEST.sha256'):
            assert (ROOT / name).stat().st_mode & 0o777 == 0o444
    validate_plan(read(ROOT / 'TASK_PLAN.json')['jobs'])
    return m


def verify_bundle_files(hashes, require_frozen=True):
    for name, digest in hashes.items():
        path = ROOT / name
        safe_ancestry(path.parent)
        assert not path.is_symlink() and path.resolve().is_relative_to(ROOT.resolve())
        assert sha(path) == digest, ('source mutation', name)
        if require_frozen:
            assert path.stat().st_mode & 0o777 == 0o444, ('source mode mutation', name)
    return True


def validate_plan(jobs):
    assert len(jobs) == 16 and {(j['arm'], j['seed']) for j in jobs} == {(a, s) for a in ('innovation1', 'innovation2') for s in range(21, 29)}
    assert len({j['id'] for j in jobs}) == 16
    old_plan = {j['id']: j for j in read(OLD_ROOT / 'TASK_PLAN.json')['jobs']}
    actual_plan = {j['id']: j for j in read(ROOT / 'inputs/V3R3_SUITE_STATUS_AT_DEADLOCK.json')['jobs']}
    captured_six = {r['suite_job']['id']: r for r in read(ROOT / 'inputs/NATIVE_DEADLOCK_CAPTURE.json')['jobs']}
    c = frozen_old()
    for j in jobs:
        old = old_plan[j['id']]
        recorded = actual_plan[j['id']]
        assert j['id'] == j['arm'] + '__seed' + str(j['seed']) and j['gpu'] == 1
        assert j['ownership'] == 'external' and j['training_launch_allowed'] is False
        assert j['state'] == 'verifying' and j['origin'] == 'adopted_completed_training'
        assert str(j['start_ticks']).isdigit() and type(j['pid']) is int
        is_clone = j['arm'] == 'innovation2' and j['seed'] in NEW_SEEDS
        assert j['clone_required'] is is_clone
        assert j['original_path'] == old['path']
        for key in ('pid', 'start_ticks', 'arm', 'seed', 'gpu'):
            assert j[key] == recorded[key], ('Adopted identity differs from actual capture', j['id'], key)
        assert j['original_path'] == recorded['path'] and j['original_log'] == recorded['log']
        assert j['original_wrapped_command'] == recorded['command'] and j['original_command'] == recorded['planned_command']
        assert j['path'] == (str(NATIVE_ROOT / 'runs' / j['id']) if is_clone else old['path'])
        assert j['original_command'] == old['planned_command']
        command_source = ORIGINAL_ROOT / 'run_transfer.py' if ROOT == NATIVE_ROOT else OLD_ROOT.parent / ORIGINAL_ROOT.name / 'run_transfer.py'
        assert j['scientific_command_reference'] == c.original_command(j, command_source)
        assert j['returncode'] is None and j['Popen_returncode_known'] is False
        assert j['trainer_exit_provenance']['external_adoption'] is True
        assert j['trainer_exit_provenance']['actual_Popen_returncode'] == (0 if is_clone and j['seed'] == 24 else None)
        process = captured_six[j['id']]['process'] if is_clone else None
        expected = {'external_adoption': True, 'actual_Popen_returncode': recorded['returncode'] if is_clone else None,
            'kernel_exit_wait_status': process.get('kernel_exit_wait_status') if process else None,
            'captured_process_state': process.get('state', 'absent') if process else 'historical_absent',
            'kernel_status_is_not_Popen': True, 'captured_original_ownership': recorded['ownership']}
        assert j['trainer_exit_provenance'] == expected, ('Exit provenance differs from literal parent capture', j['id'])
    return jobs


def check_old_readonly():
    guard_blocked_prototype()
    c = frozen_old()
    assert sha(OLD_ROOT / 'MANIFEST.json') == OLD_MANIFEST_SHA
    m = c.load_manifest()
    engineering = c.validate_receipts(m)
    c.verify_failed_v1_guard(); c.verify_failed_v2_guard(); c.verify_failed_v3r2_guard()
    c.verify_external_completed_guard()
    gate = c.require_resource_gate()
    admitted = c.check_prelaunch_receipts(fresh=False)
    preflight = c.read(OLD_ROOT / 'PARENT_NATIVE_PREFLIGHT_VERIFIED.json')
    assert preflight['state'] == 'passed' and preflight['source_manifest_sha256'] == OLD_MANIFEST_SHA
    assert preflight['admission_receipt_hashes'] == admitted
    costs = preflight['interrupted_costs']
    c.validate_interrupted_cost_values(costs); c.verify_interrupted_protected(costs)
    c.verify_backend_source_pins()
    verify_captured_six()
    return {'state': 'passed', 'old_gate_sha256': sha(OLD_ROOT / 'RESOURCE_GATE_VERIFIED.json'),
            'old_admission_receipt_hashes': admitted, 'old_reservation_mib': gate['reservation_mib'],
            'interrupted_costs': costs, 'engineering': engineering}


def guard_blocked_prototype():
    for name in ('PARENT_BLOCKED_COMPLETION_SOURCE_VERIFIED.json', 'BLOCKED_COMPLETION_REVIEW.json', 'PARENT_COMPLETION_R1_LIFECYCLE_DECISION.json'):
        assert sha(ROOT / 'inputs' / name) == INPUT_SHA[name]
    receipt = read(ROOT / 'inputs/PARENT_BLOCKED_COMPLETION_SOURCE_VERIFIED.json')
    review = read(ROOT / 'inputs/BLOCKED_COMPLETION_REVIEW.json')
    assert receipt['state'] == 'blocked_source_review_no_native_action' and receipt['native_deployed'] is False
    assert review['state'] == 'BLOCKED_source_review'
    hashes = receipt['frozen_deployment_files_sha256']
    assert len(hashes) == 23 and hashes['MANIFEST.json'] == '68854d09365966d14df8828360f04500b7fe6b83c21cbfc5906f7b8479356c99'
    folder = ROOT / 'inputs/blocked_completion_source'; safe_ancestry(folder)
    assert {str(p.relative_to(folder)) for p in folder.rglob('*') if p.is_file() or p.is_symlink()} == set(hashes)
    for name, digest in hashes.items():
        path = folder / name; safe_ancestry(path.parent)
        assert not path.is_symlink() and sha(path) == digest and path.stat().st_mode & 0o777 == 0o444
    return {'state': 'passed', 'blocked_never_deployed_prototype_files': 23, 'source_carried_only': True}


def old_operational_observation():
    """The historical live queue may refresh telemetry; never label it completed."""
    recorded = read(ROOT / 'inputs/V3R3_SUITE_STATUS_AT_DEADLOCK.json')
    actual = read(OLD_ROOT / 'suite_status.json')
    assert actual['state'] == recorded['state'] == 'waiting_for_helper_memory'
    assert actual['completed_count'] == 10 and actual['failure'] is None
    assert actual['active_helper'] is recorded['active_helper'] is None
    assert actual['source_manifest_sha256'] == OLD_MANIFEST_SHA and actual['physical_gpus'] == [1]
    for key in ('coordinator_pid', 'coordinator_start_ticks', 'coordinator_command'):
        assert actual[key] == recorded[key], ('old coordinator identity changed', key)
    c = frozen_old()
    identity = c.inspect_identity(actual['coordinator_pid'], expected_start_ticks=actual['coordinator_start_ticks'])
    assert c.check_identity({'id': 'historical stalled coordinator', 'pid': actual['coordinator_pid'],
        'start_ticks': actual['coordinator_start_ticks'], 'command': actual['coordinator_command']}, identity)
    telemetry = {'elapsed_seconds', 'latest_gpu_snapshot', 'sampled_process_peak_mib',
        'coordinator_allocator_peak_reserved_bytes_gpu1', 'coordinator_physical_peak_mib_gpu1',
        'reservation_mib', 'initializing_deficit_mib'}
    assert set(actual) == set(recorded), 'Historical suite field inventory changed'
    assert {k: v for k, v in actual.items() if k not in telemetry} == {k: v for k, v in recorded.items() if k not in telemetry}, 'Historical queue semantic state changed'
    assert actual['reservation_mib'] >= recorded['reservation_mib'] >= FLOOR_MIB
    return {'state': actual['state'], 'completed_count': 10, 'operational_observation_only': True,
            'source_manifest_sha256': OLD_MANIFEST_SHA, 'coordinator_identity': identity}


def safe_ancestry(path):
    path = Path(path)
    assert path.is_absolute()
    for parent in (path, *path.parents):
        assert not parent.is_symlink(), ('symlink ancestor', parent)


def inventory(folder):
    """Exact directories/files, modes and bytes; reject symlinks and special nodes."""
    folder = Path(folder)
    safe_ancestry(folder)
    assert folder.is_dir() and not folder.is_symlink()
    rows = {'.': {'kind': 'directory', 'mode': folder.stat().st_mode & 0o777}}
    for p in sorted(folder.rglob('*')):
        assert not p.is_symlink() and p.resolve().is_relative_to(folder.resolve()), ('unsafe tree', p)
        mode = p.stat().st_mode & 0o777
        if p.is_dir():
            rows[str(p.relative_to(folder))] = {'kind': 'directory', 'mode': mode}
        else:
            assert p.is_file(), ('special node', p)
            rows[str(p.relative_to(folder))] = {'kind': 'file', 'mode': mode, 'sha256': sha(p)}
    return rows


def retired(job, reader=None, pause=time.sleep, clock=time.monotonic):
    c = frozen_old()
    actual = c.inspect_identity(job['pid'], reader=reader, pause=pause, clock=clock, expected_start_ticks=job['start_ticks'])
    if actual is not None:
        c.check_identity({'id': job['id'], 'pid': job['pid'], 'start_ticks': job['start_ticks'],
            'command': job['original_wrapped_command']}, actual)
        return False
    return True


def live_inputs(jobs):
    return [j for j in jobs if not retired(j)]


def complete_training(job):
    c = frozen_old()
    assert retired(job), ('completed training input still live', job['id'])
    external = {**job, 'path': job['original_path'], 'returncode': None}
    return c.completion_gate(external)


def verify_captured_six():
    capture = read(ROOT / 'inputs/NATIVE_DEADLOCK_CAPTURE.json')
    assert capture['source_manifest_sha256'] == OLD_MANIFEST_SHA and capture['cold_only'] is True
    assert capture['torch_or_warp_imported'] is False and len(capture['jobs']) == 6
    for row in capture['jobs']:
        j = row['suite_job']; directory = Path(row['training_directory'])
        assert j['arm'] == 'innovation2' and j['seed'] in NEW_SEEDS
        assert directory == OLD_NATIVE_ROOT / 'runs' / j['id']
        actual = inventory(directory)
        files = {n: r for n, r in actual.items() if r['kind'] == 'file'}
        assert set(files) == set(row['training_file_inventory']), ('Captured training inventory changed', j['id'])
        for name, saved in row['training_file_inventory'].items():
            assert files[name]['sha256'] == saved['sha256'] and files[name]['mode'] == saved['mode']
            assert (directory / name).stat().st_size == saved['bytes']
        log = Path(row['log']['path']); safe_ancestry(log.parent)
        assert not log.is_symlink() and sha(log) == row['log']['sha256'] and log.stat().st_mode & 0o777 == row['log']['mode']
    return {'state': 'passed', 'six_captured_completed_training_directories': 6, 'captured_training_files': 66}


def clone_exact(source, target):
    """Copy once; no links and no edits (including historical config.out)."""
    source, target = Path(source), Path(target)
    before = inventory(source)
    assert not EXTRAS & set(before), 'Completed training must not already contain stress outputs'
    assert not target.exists() and not target.is_symlink()
    safe_ancestry(target.parent)
    assert target.parent.resolve().is_relative_to(ROOT.resolve())
    shutil.copytree(source, target, copy_function=shutil.copy2, symlinks=False)
    assert inventory(source) == before and inventory(target) == before
    for name, row in before.items():
        if row['kind'] == 'file':
            a, b = (source / name).stat(), (target / name).stat()
            assert b.st_nlink == 1 and (a.st_dev, a.st_ino) != (b.st_dev, b.st_ino), ('hardlinked input', name)
    return before


def capture_inputs_and_clones(jobs):
    target = ROOT / 'COMPLETED_TRAINING_GUARD.json'
    assert not target.exists(), 'Input baseline and clones cannot be recaptured'
    (ROOT / 'runs').mkdir(exist_ok=True)
    rows = []
    for j in jobs:
        complete_training(j)
        source, log = Path(j['original_path']), Path(j['original_log'])
        safe_ancestry(log.parent)
        assert log.is_file() and not log.is_symlink()
        files = inventory(source)
        if j['clone_required']:
            assert clone_exact(source, Path(j['path'])) == files
        rows.append({'id': j['id'], 'original_path': str(source), 'path': j['path'],
            'clone_required': j['clone_required'], 'original_inventory': files,
            'original_log': str(log), 'log_sha256': sha(log), 'log_mode': log.stat().st_mode & 0o777})
    write_once(target, {'state': 'actual_completed_training_baseline', 'source_manifest_sha256': sha(ROOT / 'MANIFEST.json'),
        'jobs': rows, 'no_training_or_science_claim': True})
    verify_inputs_and_clones()


def verify_inputs_and_clones():
    guard = read(ROOT / 'COMPLETED_TRAINING_GUARD.json')
    assert guard['state'] == 'actual_completed_training_baseline' and guard['source_manifest_sha256'] == sha(ROOT / 'MANIFEST.json')
    plan = {j['id']: j for j in read(ROOT / 'TASK_PLAN.json')['jobs']}
    assert len(guard['jobs']) == 16 and {r['id'] for r in guard['jobs']} == set(plan)
    for row in guard['jobs']:
        j = plan[row['id']]
        assert row['original_path'] == j['original_path'] and row['path'] == j['path'] and row['clone_required'] is j['clone_required']
        assert inventory(Path(row['original_path'])) == row['original_inventory'], ('old training changed', row['id'])
        log = Path(row['original_log'])
        safe_ancestry(log.parent)
        assert str(log) == j['original_log'] and not log.is_symlink()
        assert sha(log) == row['log_sha256'] and log.stat().st_mode & 0o777 == row['log_mode']
        if row['clone_required']:
            actual = inventory(Path(row['path']))
            extra = set(actual) - set(row['original_inventory'])
            assert extra <= EXTRAS, ('unexpected clone output', row['id'], extra)
            assert all(actual[n]['kind'] == 'file' for n in extra), 'Stress output must be a regular file'
            assert {n: r for n, r in actual.items() if n not in EXTRAS} == row['original_inventory']
            for n, r in row['original_inventory'].items():
                if r['kind'] == 'file':
                    a, b = (Path(row['original_path']) / n).stat(), (Path(row['path']) / n).stat()
                    assert b.st_nlink == 1 and (a.st_dev, a.st_ino) != (b.st_dev, b.st_ino), ('hardlink detected', n)
    return {'state': 'passed', 'original_directories': 16, 'original_logs': 16, 'exact_clones': 6,
            'guard_sha256': sha(ROOT / 'COMPLETED_TRAINING_GUARD.json')}


def receipt_binding(hashes):
    assert set(hashes) == set(RECEIPTS)
    for key, name in RECEIPTS.items():
        assert hashes[key] == sha(ROOT / name), ('new admission receipt changed', name)


def check_new_authorization(fresh=True):
    digest = sha(ROOT / 'MANIFEST.json')
    review, luna = read(ROOT / RECEIPTS['review_sha256']), read(ROOT / RECEIPTS['active_luna_sha256'])
    assert review['state'] == 'approved' and review['source_manifest_sha256'] == digest
    assert review['independent_source_review_passed'] is True and review['native_admission_authorized'] is True
    assert luna['state'] == 'active' and luna['source_manifest_sha256'] == digest
    assert luna['monitor_agent_id'] and luna['active_goal_id'] and luna['initial_snapshot']
    assert luna['raw_goal_sha256'] == sha(ROOT / RECEIPTS['raw_goal_sha256'])
    assert luna['raw_initial_snapshot_sha256'] == sha(ROOT / RECEIPTS['raw_initial_snapshot_sha256'])
    goal = read(ROOT / RECEIPTS['raw_goal_sha256'])['goal']
    assert goal['status'].lower() == 'active' and goal['threadId'] == luna['active_goal_id']
    assert str(NATIVE_ROOT) in goal['objective'] and UNIT in goal['objective'] and GPU1_UUID in goal['objective']
    assert digest in goal['objective'] and sha(ROOT / 'TASK_PLAN.json') in goal['objective']
    assert 'physical GPU1' in goal['objective'] and 'two_zero_training_initialization_audits_then_six_checkpoint_stress_only' in goal['objective']
    initial = read(ROOT / RECEIPTS['raw_initial_snapshot_sha256'])
    assert initial['native_root'] == str(NATIVE_ROOT) and initial['unit'] == UNIT
    assert initial['source_manifest_sha256'] == digest and initial['physical_gpus'] == [1]
    assert initial['physical_gpu_uuid'] == GPU1_UUID and initial['actual_evidence']
    assert initial['task_plan_sha256'] == sha(ROOT / 'TASK_PLAN.json')
    assert initial['gate_scope'] == 'two_zero_training_initialization_audits_then_six_checkpoint_stress_only'
    c = frozen_old(); now = datetime.now(timezone.utc).timestamp(); observed = c.timestamp(luna['checked_utc'])
    assert -30 <= observed - c.timestamp(goal['createdAt']) <= 600
    assert abs(observed - c.timestamp(initial['checked_utc'])) <= 600
    if fresh:
        assert 0 <= now - observed <= 600
    else:
        marker = read(ROOT / 'RESOURCE_ADMISSION_STARTED.json')
        assert marker['state'] == 'active' and marker['source_manifest_sha256'] == digest
        receipt_binding(marker['admission_receipt_hashes'])
        assert observed <= c.timestamp(marker['admission_verified_utc']) <= now
        assert c.timestamp(marker['admission_verified_utc']) - observed <= 600
    return {key: sha(ROOT / name) for key, name in RECEIPTS.items()}


def execution_env():
    env = dict(os.environ)
    assert 'CUDA_VISIBLE_DEVICES' not in env
    env.update(FLAGS)
    for key, tail in (('XDG_CACHE_HOME', 'cache'), ('WARP_CACHE_PATH', 'cache/warp'),
                      ('CUDA_CACHE_PATH', 'cache/cuda'), ('TORCH_HOME', 'cache/torch'), ('TMPDIR', 'tmp')):
        env[key] = str(NATIVE_ROOT / tail)
    guard_cache_paths(env)
    return env


def guard_cache_paths(env, root=None):
    root = NATIVE_ROOT if root is None else Path(root)
    safe_ancestry(root)
    for key, tail in (('XDG_CACHE_HOME', 'cache'), ('WARP_CACHE_PATH', 'cache/warp'),
                      ('CUDA_CACHE_PATH', 'cache/cuda'), ('TORCH_HOME', 'cache/torch'), ('TMPDIR', 'tmp')):
        expected = root / tail
        assert env[key] == str(expected), ('cache outside new root', key)
        safe_ancestry(expected)
        if expected.exists():
            assert expected.is_dir(), ('cache is not a directory', key)


def bootstrap_command(target_and_args):
    assert target_and_args[0] == str(ORIGINAL_ROOT / '.venv/bin/python')
    return [target_and_args[0], str(NATIVE_ROOT / 'resource_bootstrap.py'), '--', *target_and_args[1:]]


def require_bootstrap(target):
    row = read(ROOT / 'bootstrap_receipts' / (str(os.getpid()) + '.json'))
    assert row['state'] == 'entered_original' and row['configured_before_first_wp_init'] is True
    assert row['source_manifest_sha256'] == sha(ROOT / 'MANIFEST.json') and row['original_target'] == str(target)
    c = frozen_old(); identity = row['wrapped_process_identity']
    assert c.check_identity({'id': 'completion bootstrap current', **identity}, c.inspect_identity(os.getpid(), expected_start_ticks=identity['start_ticks']))
    return row


def load_original():
    assert ROOT == NATIVE_ROOT and 'CUDA_VISIBLE_DEVICES' not in os.environ
    check_manifest(); check_new_authorization(fresh=False); check_old_readonly(); verify_inputs_and_clones()
    r = frozen_old().load_original()
    assert r.ROOT == ORIGINAL_ROOT and r.ncs.ROOT == r.i2.ROOT == ORIGINAL_ROOT
    return r


def capacity(jobs, snapshot, reservation, allowance=None):
    """Retirement requires source-proven exit; live deficits remain unchanged."""
    c = frozen_old(); live = live_inputs(jobs)
    observation = old_operational_observation()
    c.assert_gpu1_allocations([os.getpid(), observation['coordinator_identity']['pid'], *[j['pid'] for j in live]], snapshot)
    reservation = c.reservation_mib(reservation)
    allowance = reservation if allowance is None else allowance
    assert allowance == reservation, 'All native admissions require full reservation floor; audit1024 is only a sampled-peak cap'
    memory = {int(k): v for k, v in snapshot['gpu1_pid_memory_mib'].items()}
    deficit = c.initializing_deficit(live, memory, reservation)
    card = snapshot['cards'].get(1, snapshot['cards'].get('1'))
    assert card['uuid'] == GPU1_UUID
    required = allowance + HEADROOM_MIB + deficit
    return {'free_mib': card['free_mib'], 'required_free_mib': required, 'reservation_mib': reservation,
            'allowance_mib': allowance, 'headroom_mib': HEADROOM_MIB, 'initializing_deficit_mib': deficit,
            'existing_live_PIDs': [j['pid'] for j in live], 'actual_snapshot': snapshot,
            'retired_inputs_excluded': len(jobs) - len(live)}


def require_new_gate():
    result = read(ROOT / 'COMPLETION_RESOURCE_GATE_VERIFIED.json')
    assert result['state'] == 'passed' and result['source_manifest_sha256'] == sha(ROOT / 'MANIFEST.json')
    assert result['initialization_audits'] == 2 and result['new_training_transitions'] == 0
    assert len(result['audit_histories']) == 2 and {r['case'] for r in result['audit_histories']} == {'i1', 'i2'}
    receipt_binding(result['admission_receipt_hashes'])
    assert result['training_guard_sha256'] == sha(ROOT / 'COMPLETED_TRAINING_GUARD.json')
    c = frozen_old()
    expected_reservation = c.read(OLD_ROOT / 'RESOURCE_GATE_VERIFIED.json')['reservation_mib']
    for row in result['audit_histories']:
        name = 'resource_init_audit_' + row['case'] + '.json'
        assert sha(ROOT / name) == row['receipt_sha256']
        audit = read(ROOT / name)
        assert audit['state'] == 'passed' and audit['case'] == row['case']
        assert audit['source_manifest_sha256'] == result['source_manifest_sha256']
        assert row['actual_Popen_returncode'] == 0 and row['sampled_peak_mib'] <= 1024 and row['NVML_samples'] >= 1
        assert audit['backend_device'] == 'cuda:1' and audit['backend_uuid'] == GPU1_UUID and audit['public_log_level'] == 30
        assert audit['original_import_file'] == str(ORIGINAL_ROOT / ('source_i1/train_kl_relative.py' if row['case'] == 'i1' else 'source_i2/train_pae_baseline.py'))
        assert audit['identity'] == row['identity']
        command = bootstrap_command([str(ORIGINAL_ROOT / '.venv/bin/python'), str(ROOT / 'resource_init_audit.py'), '--case', row['case']])
        assert c.check_identity({'id': 'completion init audit', 'pid': row['pid'], 'start_ticks': row['identity']['start_ticks'], 'command': command}, row['identity'])
        for key in ('environment_constructions', 'environment_steps', 'training_transitions', 'evaluation_transitions',
                    'optimizer_constructions', 'optimizer_steps', 'model_constructions', 'normalizer_constructions'):
            assert type(audit[key]) is int and audit[key] == 0
        c.assert_gpu1_allocations([row['pid']], audit['actual_GPU_snapshot'], require_context=[row['pid']])
        admission = row['admission']
        assert admission['allowance_mib'] == admission['reservation_mib'] and admission['headroom_mib'] == HEADROOM_MIB
        assert admission['reservation_mib'] >= FLOOR_MIB
        assert admission['required_free_mib'] == admission['reservation_mib'] + HEADROOM_MIB + admission['initializing_deficit_mib'] <= admission['free_mib']
        snap = admission['actual_snapshot']
        memory = {int(k): v for k, v in snap['gpu1_pid_memory_mib'].items()}
        pids = admission['existing_live_PIDs']
        assert len(pids) == len(set(pids)) and set(pids) <= {j['pid'] for j in read(ROOT / 'TASK_PLAN.json')['jobs']}
        expected_deficit = c.initializing_deficit([{'pid': p} for p in pids], memory, admission['reservation_mib'])
        assert admission['initializing_deficit_mib'] == expected_deficit
        card = snap['cards'].get(1, snap['cards'].get('1'))
        assert card['uuid'] == GPU1_UUID and card['free_mib'] == admission['free_mib']
        historical = read(ROOT / 'inputs/V3R3_SUITE_STATUS_AT_DEADLOCK.json')['coordinator_pid']
        assert admission['historical_coordinator_pid'] == historical
        assert admission['historical_coordinator_actual_mib'] == memory.get(historical, 0)
        c.assert_gpu1_allocations([admission['driver_pid'], historical, *pids], snap)
        assert row['reservation_before_result_mib'] >= expected_reservation
        raised = c.reservation_mib(row['reservation_before_result_mib'], [row['sampled_peak_mib']], [audit['peak_torch_reserved_bytes_GPU1'] / 1024**2])
        assert row['reservation_after_result_mib'] == raised
        expected_reservation = raised
    assert result['reservation_mib'] == expected_reservation
    verify_inputs_and_clones()
    return result


def require_helper_history(history):
    c = frozen_old(); m = check_manifest()
    jobs = {j['id']: j for j in read(ROOT / 'TASK_PLAN.json')['jobs'] if j['clone_required']}
    rows = [r for r in history if r.get('stage') == 'checkpoint_only_stress']
    assert len(rows) == 6 and {r['job'] for r in rows} == set(jobs)
    for row in rows:
        j = jobs[row['job']]; path = Path(j['path'])
        receipt = ROOT / ('STRESS_HELPER_' + j['id'] + '.json')
        assert read(receipt) == row and row['state'] == 'completed' and row['actual_Popen_returncode'] == 0
        assert row['source_manifest_sha256'] == sha(ROOT / 'MANIFEST.json')
        assert row['new_resource_gate_sha256'] == sha(ROOT / 'COMPLETION_RESOURCE_GATE_VERIFIED.json')
        command = bootstrap_command([str(ORIGINAL_ROOT / '.venv/bin/python'), str(ROOT / 'stress_checkpoint_gpu1.py'),
            '--job-path', j['path'], '--device', 'cuda:1'])
        assert row['command'] == command and row['identity'] is not None
        assert c.check_identity({'id': j['id'] + '__stress', 'pid': row['pid'], 'start_ticks': row['identity']['start_ticks'], 'command': command}, row['identity'])
        assert row['NVML_samples'] >= 1 and row['new_training_transitions'] == 0
        for key, name in (('result_sha256', 'checkpoint_stress_result.json'), ('stress_sha256', 'stress_evaluation.json'), ('checkpoint_sha256', 'latest.pt')):
            assert row[key] == sha(path / name)
        report = read(path / 'checkpoint_stress_result.json')
        assert report['state'] == 'passed' and report['seed'] == j['seed'] and report['task'] == 'Swimmer' and report['device'] == 'cuda:1'
        assert report['helper_sha256'] == m['stress_adapter_sha256'] and report['checkpoint_sha256'] == row['checkpoint_sha256']
        for key in ('training_transitions', 'optimizer_steps', 'optimizer_constructions', 'observation_normalizer_updates', 'reward_normalizer_updates'):
            assert type(report[key]) is int and report[key] == 0
        assert report['model_unchanged'] is report['normalizer_unchanged'] is report['training_files_unchanged'] is True
        assert report['episodes'] == 192 and report['conditions'] == 6 and report['source_api_ast_equal'] is True
        assert report['source_hashes'] == c.read(ORIGINAL_ROOT / 'source_i2_hashes.json')
        assert report['runtime_versions'] == c.read(ORIGINAL_ROOT / 'RUNTIME_REFERENCE.json')['versions']
        admission = row['admission']; snap = admission['actual_snapshot']
        memory = {int(k): v for k, v in snap['gpu1_pid_memory_mib'].items()}
        pids = admission['existing_live_PIDs']; historical = read(ROOT / 'inputs/V3R3_SUITE_STATUS_AT_DEADLOCK.json')['coordinator_pid']
        assert admission['historical_coordinator_pid'] == historical and admission['historical_coordinator_actual_mib'] == memory.get(historical, 0)
        assert admission['reservation_mib'] >= FLOOR_MIB and admission['allowance_mib'] == admission['reservation_mib']
        assert admission['headroom_mib'] == HEADROOM_MIB
        assert admission['initializing_deficit_mib'] == c.initializing_deficit([{'pid': p} for p in pids], memory, admission['reservation_mib'])
        assert admission['required_free_mib'] == admission['allowance_mib'] + HEADROOM_MIB + admission['initializing_deficit_mib'] <= admission['free_mib']
        card = snap['cards'].get(1, snap['cards'].get('1'))
        assert card['uuid'] == GPU1_UUID and card['free_mib'] == admission['free_mib']
        c.assert_gpu1_allocations([admission['driver_pid'], historical, *pids], snap)
        assert row['reservation_before_result_mib'] >= admission['reservation_mib']
        assert row['reservation_after_result_mib'] == c.reservation_mib(row['reservation_before_result_mib'], [row['sampled_peak_mib']], [report['peak_torch_memory_reserved_bytes'] / 1024**2])
    return {'state': 'passed', 'exact_owned_stress_helpers': 6, 'actual_Popen_returncodes': [r['actual_Popen_returncode'] for r in rows]}


def log_health(path):
    path = Path(path); safe_ancestry(path.parent)
    assert path.is_relative_to(ROOT) and path.is_file() and not path.is_symlink(), ('missing/unsafe native log', path)
    raw = path.read_bytes()
    fatal = re.compile(r'Traceback \(most recent call last\):|CUDA out of memory|RuntimeError:|AssertionError:|segmentation fault|illegal memory access|fatal error', re.I)
    assert fatal.search(raw.decode('utf-8', errors='replace')) is None, ('fatal native log', path)
    return {'path': str(path), 'sha256_at_observation': hashlib.sha256(raw).hexdigest(), 'bytes_at_observation': len(raw), 'fatal_found': False}


def validate_lifecycle(state, unit_row, phase, snapshot=None, inspector=None):
    """Finite, fail-closed actual unit/coordinator/helper lifecycle proof."""
    assert phase in ('startup', 'terminal16')
    assert state['failure'] is None and state['source_manifest_sha256'] == sha(ROOT / 'MANIFEST.json')
    assert not (ROOT / 'FAILURE.json').exists(), 'Failure receipt present'
    assert unit_row['Restart'] == 'no' and unit_row['KillMode'] == 'process'
    assert str(ROOT / 'resource_bootstrap.py') in unit_row['ExecStart'] and str(ROOT / 'run_completion.py') in unit_row['ExecStart']
    old = frozen_old(); inspector = old.inspect_identity if inspector is None else inspector
    coordinator = state['coordinator_identity']
    command = bootstrap_command([str(ORIGINAL_ROOT / '.venv/bin/python'), str(ROOT / 'run_completion.py')])
    assert coordinator['command'] == command and coordinator['cuda_visible_devices'] is None
    assert type(coordinator['pid']) is int and coordinator['pid'] > 0 and str(coordinator['start_ticks']).isdigit()
    actual = inspector(coordinator['pid'], expected_start_ticks=coordinator['start_ticks'])
    logs = [log_health(ROOT / 'coordinator.log')]
    helper = state['active_helper']
    if phase == 'terminal16':
        assert state['state'] == 'completed' and state['completed_count'] == 16
        assert len(state['jobs']) == 16 and all(j['state'] == 'completed' for j in state['jobs'])
        assert helper is None, 'Terminal queue has active helper'
        assert unit_row['ActiveState'] == 'inactive' and unit_row['SubState'] == 'dead'
        assert unit_row['MainPID'] == '0' and unit_row['Result'] == 'success' and unit_row['ExecMainStatus'] == '0'
        assert actual is None, 'Completed marker while original coordinator identity is still live'
        for seed in NEW_SEEDS:
            logs.append(log_health(ROOT / ('innovation2__seed' + str(seed) + '.stress.log')))
        return {'state': 'passed', 'phase': phase, 'actual_unit_naturally_exited_zero': True,
            'new_coordinator_source_proven_exited': True, 'active_helper': None, 'logs': logs}
    assert unit_row['ActiveState'] == 'active' and unit_row['SubState'] == 'running'
    assert int(unit_row['MainPID']) == coordinator['pid']
    assert old.check_identity({'id': 'new completion coordinator', **coordinator}, actual), 'Startup coordinator absent/exited'
    assert state['state'] in ('adopting_completed_training', 'checkpoint_stress', 'verifying')
    assert state['state'] != 'checkpoint_stress' or helper is not None, 'Checkpoint-stress phase without actual helper'
    assert len(state['jobs']) == 16 and state['completed_count'] == sum(j['state'] == 'completed' for j in state['jobs'])
    assert all(j['state'] in ('verifying', 'completed') for j in state['jobs'])
    snapshot = old.snapshot() if snapshot is None else snapshot
    card = snapshot['cards'].get(1, snapshot['cards'].get('1'))
    assert card['uuid'] == GPU1_UUID
    pids = [coordinator['pid']]
    helper_proof = None
    if helper is not None:
        jobs = {j['id']: j for j in state['jobs']}
        assert helper['job'] in jobs and jobs[helper['job']]['state'] == 'verifying'
        assert helper['gpu'] == 1 and helper['device'] == 'cuda:1' and helper['physical_gpu_uuid'] == GPU1_UUID
        assert helper['actual_Popen_returncode'] is None, 'Live helper cannot have a terminal Popen result'
        j = jobs[helper['job']]
        if helper['stage'] == 'checkpoint_only_stress':
            assert state['state'] == 'checkpoint_stress' and helper['state'] == 'running'
            assert j['clone_required'] is True and helper['pid'] != coordinator['pid']
            expected = bootstrap_command([str(ORIGINAL_ROOT / '.venv/bin/python'), str(ROOT / 'stress_checkpoint_gpu1.py'),
                '--job-path', j['path'], '--device', 'cuda:1'])
            log = ROOT / (j['id'] + '.stress.log')
            assert helper['in_process_verification'] is False
        else:
            assert helper['stage'] == 'source_native_scientific_verification'
            assert state['state'] == 'verifying' and helper['state'] == 'verifying'
            assert helper['pid'] == coordinator['pid'] and helper['start_ticks'] == coordinator['start_ticks']
            expected, log = command, ROOT / 'coordinator.log'
            assert helper['in_process_verification'] is True
        assert helper['command'] == expected and helper['log'] == str(log)
        live = inspector(helper['pid'], expected_start_ticks=helper['start_ticks'])
        assert old.check_identity({'id': 'active completion helper', **helper}, live), 'Persisted helper exited before boundary; no fake live identity'
        pids.append(helper['pid'])
        old.assert_gpu1_allocations(pids, snapshot, require_context=[helper['pid']])
        logs.append(log_health(log))
        helper_proof = {'identity': live, 'job': helper['job'], 'stage': helper['stage'], 'actual_GPU1_context_present': True}
    old.assert_gpu1_allocations(pids, snapshot)
    return {'state': 'passed', 'phase': phase, 'actual_unit_active_running': True,
        'coordinator_identity': actual, 'active_helper': helper_proof, 'actual_snapshot': snapshot, 'logs': logs}
