"""CPU-only artifact and exact repeat checks for the new-task baseline matrix."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source'
sys.path.insert(0, str(SOURCE))
METHODS = ('fixed90','fixed95','fixed99','linear','critic_aware','gradient_ppo','reward_profiling','pae')
EXTERNAL = ('critic_aware','gradient_ppo','reward_profiling','pae')
DET = {'torch':True,'warp':'run_to_run','warp_max_records':8,'cublas_workspace_config':':4096:8'}


def require(ok, reason):
    if not ok: raise AssertionError(reason)


def read(path):
    def constant(x): raise ValueError('Nonfinite JSON constant: '+x)
    def pairs(items):
        out={}
        for k,v in items:
            if k in out: raise ValueError('Duplicate JSON key: '+k)
            out[k]=v
        return out
    def finite(x):
        y=float(x)
        if not math.isfinite(y): raise ValueError('Nonfinite JSON float')
        return y
    return json.loads(Path(path).read_text(),parse_constant=constant,object_pairs_hook=pairs,parse_float=finite)


def write(path, data):
    path=Path(path); tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n'); tmp.replace(path)


def lines(path):
    return [json.loads(x) for x in Path(path).read_text().splitlines() if x.strip()]


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify(path, method, task, seed, steps, device, manifest_sha):
    p=Path(path); c=read(p/'config.json'); s=read(p/'summary.json'); status=read(p/'status.json')
    require(c['seed']==seed and c['effective_steps']==steps and c['task']==task,'configuration task/seed/budget')
    require(c['determinism']==DET and c['suite_manifest_sha256']==manifest_sha,'determinism/source manifest')
    for k,v in {'num_envs':1024,'rollout':64,'batch_size':1024,'eval_envs':32,'eval_every':262144,'device':device,'epochs':4 if method=='gradient_ppo' else 10,'gamma':.99}.items():
        require(c[k]==v,('configuration',k,c.get(k),v))
    require(c['network']==[64,64],'network')
    meta=c['task_adapter']; horizon=meta['horizon']
    require(type(horizon) is int and horizon in (300,1000),'task horizon')
    require(meta['benchmark_id']==('PointMaze_UMazeDense-v3' if task=='PointMaze' else 'dm_control/cartpole/swingup'),'benchmark ID')
    require(s['state']==status['state']=='completed' and s['reload_check']=='passed','completed/reloaded')
    require(s['steps']==steps and s['physics_device']==device,'physics/fresh budget')
    require((p/'latest.pt').stat().st_size>0,'checkpoint')
    rows=list(csv.DictReader((p/'progress.csv').open()))
    updates=1+math.ceil(max(0,steps//1024-64)/48) if method=='pae' else steps//65536
    require(len(rows)==updates,'actual update count')
    initial=read(p/'initial_evaluation.json'); ev=lines(p/'evaluations.jsonl')
    require(len(ev)==math.ceil(steps/262144),'evaluation count')
    for e in [initial,*ev,s['final_eval']]:
        require(len(e['returns'])==32 and e['lengths']==[horizon]*32,'one complete episode per evaluation world')
        require(all(type(x) in (int,float) and math.isfinite(x) for x in e['returns']),'finite returns')
        require(abs(statistics.mean(e['returns'])-e['mean'])<2e-4,'mean matches actual returns')
    pts=[(0,initial['mean'])]+[(e['steps'],e['mean']) for e in ev]
    require(pts[-1][0]==steps and ev[-1]['mean']==s['final_eval']['mean'],'final checkpoint evaluation')
    require(all(a[0]<b[0] for a,b in zip(pts,pts[1:])),'evaluation chronology')
    auc=sum((b[0]-a[0])*(a[1]+b[1])/2 for a,b in zip(pts,pts[1:]))/steps
    result={'state':'passed','task':task,'method':method,'seed':seed,'device':device,'steps':steps,'updates':updates,
            'final_return':s['final_eval']['mean'],'auc':auc,'initial_return':initial['mean'],
            'elapsed_seconds':s['elapsed_seconds'],'steps_per_second':s['steps_per_second'],'total_algorithm_transitions':steps,
            'benchmark_id':meta['benchmark_id'],'episode_horizon':horizon,'suite_manifest_sha256':manifest_sha}
    import torch
    checkpoint=torch.load(p/'latest.pt',map_location='cpu',weights_only=False)
    if method not in EXTERNAL:
        require(c['noise_mode']=='none' and c['noise_scale']==0,'no extra noise')
        require((p/'best.pt').stat().st_size>0 and (p/'stress_evaluation.json').exists(),'internal original artifacts')
        vals=[float(x['gae_lambda']) for x in rows]
        if method=='linear':
            require(c['lambda_mode']=='linear','linear controller')
            require(all(abs(x-(.90+.09*i/max(1,updates-1)))<1e-12 for i,x in enumerate(vals)),'linear replay')
        else:
            value={'fixed90':.9,'fixed95':.95,'fixed99':.99}[method]
            require(c['lambda_mode']=='fixed' and c['fixed_lambda']==value and all(x==value for x in vals),'fixed lambda')
        opt=checkpoint['optimizer']
        require(len(opt['state'])==len(list(checkpoint['model'])),'all optimizer parameter states')
        expected=updates*10*64
        require(all(int(x['step'])==expected for x in opt['state'].values()),'internal Adam step count')
    else:
        require(c['method']==method and s['training_transitions']==steps,'external config/budget')
        for n,h in c['source_sha256'].items(): require(sha(SOURCE/n)==h,('source',n))
        require(abs(s['normalized_return_auc']-auc)<1e-10,'external AUC')
        vals=[float(x['gae_lambda_used']) for x in rows]; counts=s['optimizer_steps']
        if method=='critic_aware':
            from external_baseline_algorithms import critic_lambda
            decisions=lines(p/'lambda_decisions.jsonl'); require(len(decisions)==updates,'critic decisions')
            value=.95; previous=float('inf')
            for i,(d,row) in enumerate(zip(decisions,rows),1):
                require(d['update']==i and d['used']==value and float(row['gae_lambda_used'])==value,'critic used replay')
                require(d['previous_loss']==(None if math.isinf(previous) else previous),'critic previous loss')
                loss=d['last_minibatch_value_loss']; value=critic_lambda(value,previous,loss,i/updates); previous=loss
                require(abs(d['next']-value)<1e-12 and float(row['gae_lambda_next'])==d['next'],'critic next replay')
            require(counts=={'actor':updates*5*64,'critic':updates*10*64,'h':0},'critic optimizer counts')
            result['controller_replay']='passed'
        elif method=='gradient_ppo':
            require(counts=={'actor':updates*4*64,'critic':updates*4*64,'h':updates*4*64},'gradient optimizer counts')
            require(checkpoint['hnet'] and set(checkpoint['optimizers'])=={'actor','critic','h'},'gradient auxiliary optimizer')
            require(all(x==.95 for x in vals),'gradient fixed trace')
        elif method=='reward_profiling':
            decisions=lines(p/'profiling_decisions.jsonl'); n=min(10,updates)
            require(len(decisions)==n and {r['steps'] for r in decisions}=={math.ceil(k*updates/n)*65536 for k in range(1,n+1)},'profiling boundaries')
            extra=0
            for d in decisions:
                require(d['chosen']==('old' if d['old']['mean']>=d['new']['mean'] else 'new'),'profiling policy selection')
                require(d['old']['lengths']==d['new']['lengths']==[horizon]*5,'profiling complete horizons')
                require(d['extra_transitions']==sum(d['old']['lengths'])+sum(d['new']['lengths']),'profiling actual extra transitions')
                require(d['simulated_transitions']==5*(max(d['old']['lengths'])+max(d['new']['lengths'])),'profiling simulated transitions')
                extra+=d['extra_transitions']
            require(all(x==.95 for x in vals),'profile fixed trace')
            result['profiling_extra_transitions']=extra; result['total_algorithm_transitions']=steps+extra
            require(s['total_algorithm_transitions']==steps+extra,'total profiling budget')
        elif method=='pae':
            require(c['force_pae_overlap'] and c['pae_prefix']==48 and c['pae_tail']==16,'PAE unconditional overlap')
            require(not any(c[k] for k in ('adaptive_kl','readiness_boost','staged_full','adaptive_overlap')),'PAE no ours mechanism')
            require(c['overlap_start_steps']==0 and c['overlap_stop_steps']==steps,'PAE span')
            require(all(r['overlap_active'].lower()=='true' for r in rows) and all(x==.95 for x in vals),'PAE overlap/trace replay')
            require(s['pae_retained_per_world']==0 and counts=={'actor':steps//1024*10,'critic':steps//1024*10,'h':0},'PAE final tail/optimizer counts')
        if method!='reward_profiling': require(s['total_algorithm_transitions']==steps,'external pure training budget')
    result.update(lambda_min=min(vals),lambda_max=max(vals))
    require(math.isfinite(auc) and math.isfinite(result['final_return']),'finite aggregate')
    write(p/'VERIFIED.json',result)
    return result


def differences(a,b,path=''):
    import torch
    if isinstance(a,torch.Tensor): return [] if isinstance(b,torch.Tensor) and a.dtype==b.dtype and a.shape==b.shape and torch.equal(a,b) else [path]
    if isinstance(a,dict):
        if not isinstance(b,dict) or a.keys()!=b.keys(): return [path+'.keys']
        return [d for k in a for d in differences(a[k],b[k],path+'.'+str(k))]
    if isinstance(a,(list,tuple)):
        if type(a)!=type(b) or len(a)!=len(b): return [path+'.length']
        return [d for i,(x,y) in enumerate(zip(a,b)) for d in differences(x,y,path+'.'+str(i))]
    return [] if a==b else [path]


def pair(a,b,method):
    import torch
    a,b=Path(a),Path(b)
    x=torch.load(a/'latest.pt',map_location='cpu',weights_only=False); y=torch.load(b/'latest.pt',map_location='cpu',weights_only=False)
    x.pop('config'); y.pop('config'); errors=differences(x,y)
    files=['initial_evaluation.json','evaluations.jsonl']
    if method=='critic_aware': files+=['lambda_decisions.jsonl']
    if method=='reward_profiling': files+=['profiling_decisions.jsonl']
    for n in files:
        if (a/n).read_bytes()!=(b/n).read_bytes(): errors.append(n)
    xs=list(csv.DictReader((a/'progress.csv').open())); ys=list(csv.DictReader((b/'progress.csv').open()))
    require(len(xs)==len(ys),'repeat progress count')
    for x,y in zip(xs,ys):
        for k in x:
            if k not in ('elapsed_seconds','steps_per_second') and x[k]!=y[k]: errors.append('progress.'+k)
    require(not errors,errors)
    return {'state':'passed','checkpoint_exact':True,'evaluations_and_decisions_exact':True,'non_timing_progress_exact':True}


def aggregate(out,task,manifest_sha):
    out=Path(out); rows=[]
    for method in METHODS:
        for seed in range(21,29):
            row=read(out/'runs'/f'{task}__{method}__seed{seed}'/'VERIFIED.json')
            require(row['state']=='passed' and row['suite_manifest_sha256']==manifest_sha,'all64 verified')
            rows.append(row)
    means=[]
    for method in METHODS:
        subset=[r for r in rows if r['method']==method]
        means.append({'task':task,'method':method,'n':8,'final_mean':statistics.mean(r['final_return'] for r in subset),
                      'final_sd':statistics.stdev(r['final_return'] for r in subset),'auc_mean':statistics.mean(r['auc'] for r in subset),
                      'auc_sd':statistics.stdev(r['auc'] for r in subset),'elapsed_mean_seconds':statistics.mean(r['elapsed_seconds'] for r in subset),
                      'total_algorithm_transitions':sum(r['total_algorithm_transitions'] for r in subset)})
    write(out/'RESULTS.json',{'state':'completed','task':task,'seeds':list(range(21,29)),'base':'fixed95','all_seeds':rows,'means':means,'formal_unique_runs':64,'suite_manifest_sha256':manifest_sha})
    for name,data in [('per_seed.csv',rows),('means.csv',means)]:
        fields=list(dict.fromkeys(k for r in data for k in r))
        with (out/name).open('w') as f:
            w=csv.DictWriter(f,fieldnames=fields); w.writeheader();w.writerows(data)
    return {'state':'completed','rows':64,'task':task}


def main():
    p=argparse.ArgumentParser();p.add_argument('--kind',choices=['run','pair','aggregate'],required=True)
    p.add_argument('--out',type=Path,required=True);p.add_argument('--task',choices=['PointMaze','CartpoleSwingup'],required=True)
    p.add_argument('--method',choices=METHODS);p.add_argument('--seed',type=int);p.add_argument('--steps',type=int);p.add_argument('--device')
    p.add_argument('--manifest-sha',required=True);p.add_argument('--a',type=Path);p.add_argument('--b',type=Path)
    a=p.parse_args()
    if a.kind=='run': result=verify(a.out,a.method,a.task,a.seed,a.steps,a.device,a.manifest_sha)
    elif a.kind=='pair':
        for path in (a.a,a.b):verify(path,a.method,a.task,a.seed,a.steps,a.device,a.manifest_sha)
        result=pair(a.a,a.b,a.method);write(a.out,result)
    else:result=aggregate(a.out,a.task,a.manifest_sha)
    print(json.dumps(result,allow_nan=False),flush=True)

if __name__=='__main__': main()
