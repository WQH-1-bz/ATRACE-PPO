"""Create the deployable source inventory after both owners finish preparation."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def main():
    files=[]
    for folder in ('source','env_source'):
        files += [p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']
    files += [ROOT/n for n in ('run_matrix.py','verify_runs.py','validate_source.py','finalize_source.py','launch_pipeline.py','ANCESTRY.json','SOURCE_CHECKS.json','RUN_INSTRUCTIONS.md')]
    for p in files:
        if p.suffix=='.py': compile(p.read_text(),str(p),'exec')
    assert (ROOT/'env_source/new_tasks_warp.py').is_file() and (ROOT/'env_source/CPU_SEMANTIC_AUDIT.json').is_file()
    obj={'state':'source_ready','methods':['fixed90','fixed95','fixed99','linear','critic_aware','gradient_ppo','reward_profiling','pae'],
         'tasks':['PointMaze','CartpoleSwingup'],'seeds':list(range(21,29)),'base':'fixed95','formal_fresh_budget':10027008,
         'formal_unique_runs':128,'short_budget':131072,'short_seed':91091,'external_scope':'matched-backbone ports; not original paper score reproduction',
         'files':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(files))}}
    target=ROOT/'SOURCE_MANIFEST.json';target.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'source_manifest_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'files':len(obj['files'])}))

if __name__=='__main__':main()
