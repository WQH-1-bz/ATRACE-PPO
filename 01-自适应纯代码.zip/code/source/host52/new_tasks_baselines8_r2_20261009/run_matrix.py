"""Stdlib scheduler: short exact repeats then fresh eight-seed baselines per task."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source'
METHODS=('fixed90','fixed95','fixed99','linear','critic_aware','gradient_ppo','reward_profiling','pae')
EXTERNAL=('critic_aware','gradient_ppo','reward_profiling','pae')
TASKS=('PointMaze','CartpoleSwingup')
BUDGET=10027008
SHORT=131072
SMOKE_SEED=91091


def require(ok,reason):
    if not ok: raise AssertionError(reason)


def strict_read(path):
    def constant(x):raise ValueError('nonfinite JSON '+x)
    def floating(x):
        y=float(x)
        require(math.isfinite(y),'nonfinite JSON float');return y
    def pairs(items):
        out={}
        for k,v in items:
            require(k not in out,'duplicate JSON key '+k);out[k]=v
        return out
    return json.loads(Path(path).read_text(),parse_constant=constant,parse_float=floating,object_pairs_hook=pairs)


def write(path,data):
    path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n');tmp.replace(path)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_manifest(path):
    obj=strict_read(path)
    require(obj['state']=='source_ready' and obj['methods']==list(METHODS),'matrix source inventory')
    for n,h in obj['files'].items():
        p=ROOT/n;require(p.is_file() and sha(p)==h,('source hash',n))
    return sha(path)


def train_command(python,task,method,seed,device,out,steps):
    trainer='train_pae_baseline.py' if method=='pae' else 'train_external_baseline.py' if method in EXTERNAL else 'train_internal_base.py'
    args=[str(python),'-B',str(SOURCE/trainer),'--out',str(out),'--task',task,'--seed',str(seed),'--device',device,
          '--steps',str(steps),'--num-envs','1024','--rollout','64','--batch-size','1024','--eval-envs','32','--eval-every','262144']
    if method in EXTERNAL:args+=['--method',method]
    elif method=='linear':args+=['--epochs','10','--lambda-mode','linear']
    else:args+=['--epochs','10','--lambda-mode','fixed','--fixed-lambda',str({'fixed90':.9,'fixed95':.95,'fixed99':.99}[method])]
    if method=='pae':args+=['--force-pae-overlap','--overlap-start-steps','0','--overlap-stop-steps',str(steps)]
    return args


def verification_command(python,j,manifest_sha):
    return [str(python),'-B',str(ROOT/'verify_runs.py'),'--kind','run','--out',j['path'],'--task',j['task'],'--method',j['method'],
            '--seed',str(j['seed']),'--device',j['device'],'--steps',str(j['steps']),'--manifest-sha',manifest_sha]


def host_memory(pid):
    try:
        fields={}
        for line in (Path('/proc')/str(pid)/'status').read_text().splitlines():
            if line.startswith(('VmRSS:','VmHWM:')):
                key,val=line.split(':',1);fields[key]=int(val.split()[0])*1024
        if set(fields)!= {'VmRSS','VmHWM'}:return None
        return fields
    except FileNotFoundError:return None


def resource_query(gpus):
    free={};usage={}
    for gpu in gpus:
        r=subprocess.run(['nvidia-smi','-i',str(gpu),'--query-gpu=index,memory.free','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=20,check=True)
        values=[line.strip().split(',') for line in r.stdout.splitlines() if line.strip()]
        require(len(values)==1 and int(values[0][0])==gpu,'selected physical GPU query')
        free[gpu]=int(values[0][1])
        q=subprocess.run(['nvidia-smi','-i',str(gpu),'--query-compute-apps=pid,used_gpu_memory','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=20,check=True)
        for line in q.stdout.splitlines():
            if not line.strip():continue
            fields=line.split(',');pid=int(fields[0]);value=fields[1].strip()
            if value.isdigit():usage[(gpu,pid)]=int(value)
    mem={}
    for line in Path('/proc/meminfo').read_text().splitlines():
        key,val=line.split(':',1)
        if key=='MemAvailable':mem[key]=int(val.split()[0])*1024
    return free,usage,mem['MemAvailable']


def make_plan(a,manifest_sha):
    jobs=[];out=a.out
    if a.phase=='smoke':
        for gpu in a.gpus:
            for method in METHODS:
                paths=[];deps=[]
                for rep in ('a','b'):
                    jid=f'smoke__{a.task}__{method}__gpu{gpu}__{rep}';path=out/'runs'/jid
                    j={'id':jid,'kind':'train','task':a.task,'method':method,'seed':SMOKE_SEED,'gpu':gpu,'device':f'cuda:{gpu}',
                       'steps':SHORT,'path':str(path),'dependencies':[],'state':'pending','argv':train_command(a.python,a.task,method,SMOKE_SEED,f'cuda:{gpu}',path,SHORT)}
                    jobs.append(j);paths.append(str(path));deps.append(jid)
                gate=out/'gates'/f'{method}__gpu{gpu}.json'
                jobs.append({'id':f'pair__{method}__gpu{gpu}','kind':'pair','task':a.task,'method':method,'gpu':None,'steps':SHORT,
                             'seed':SMOKE_SEED,'device':f'cuda:{gpu}','paths':paths,'gate_path':str(gate),'dependencies':deps,'state':'pending',
                             'argv':[str(a.python),'-B',str(ROOT/'verify_runs.py'),'--kind','pair','--out',str(gate),'--task',a.task,'--method',method,
                                     '--seed',str(SMOKE_SEED),'--steps',str(SHORT),'--device',f'cuda:{gpu}','--manifest-sha',manifest_sha,'--a',paths[0],'--b',paths[1]]})
    else:
        for seed in range(21,29):
            for method in METHODS:
                jid=f'{a.task}__{method}__seed{seed}';path=out/'runs'/jid
                j={'id':jid,'kind':'train','task':a.task,'method':method,'seed':seed,'gpu':None,'device':None,
                   'steps':BUDGET,'path':str(path),'dependencies':[],'state':'pending','argv':None}
                jobs.append(j)
                jobs.append({'id':'verify__'+jid,'kind':'verify','task':a.task,'method':method,'seed':seed,'gpu':None,'steps':BUDGET,
                             'path':str(path),'train_id':jid,'dependencies':[jid],'state':'pending','argv':None})
        jobs.append({'id':'aggregate','kind':'aggregate','task':a.task,'gpu':None,'dependencies':[j['id'] for j in jobs if j['kind']=='verify'],'state':'pending',
                     'argv':[str(a.python),'-B',str(ROOT/'verify_runs.py'),'--kind','aggregate','--out',str(out),'--task',a.task,'--manifest-sha',manifest_sha]})
    return jobs


def main():
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=['smoke','formal'],required=True)
    p.add_argument('--task',choices=TASKS,required=True);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--python',type=Path,default=Path(sys.executable));p.add_argument('--gpus',type=int,nargs='+',required=True)
    p.add_argument('--manifest',type=Path,default=ROOT/'SOURCE_MANIFEST.json')
    p.add_argument('--smoke-root',type=Path);p.add_argument('--semantic-proof',type=Path,required=True)
    p.add_argument('--bootstrap-mib',type=int,default=3500);p.add_argument('--max-per-gpu',type=int,default=8)
    p.add_argument('--max-cpu-helpers',type=int,default=2);p.add_argument('--host-worker-mib',type=int,default=2048)
    p.add_argument('--disk-floor-gib',type=int,default=5);p.add_argument('--plan-only',action='store_true')
    a=p.parse_args();a.out=a.out.resolve();a.python=a.python.absolute();a.gpus=tuple(a.gpus)
    require(len(a.gpus)==len(set(a.gpus)) and all(type(x) is int and x>=0 for x in a.gpus),'unique selected devices')
    require(min(a.bootstrap_mib,a.max_per_gpu,a.max_cpu_helpers,a.host_worker_mib,a.disk_floor_gib)>0,'positive resources')
    require(a.python.is_file(),'native Python executable')
    require(not any(k in os.environ for k in ('CUDA_VISIBLE_DEVICES','NVIDIA_VISIBLE_DEVICES')),'device masks forbidden')
    manifest_sha=verify_manifest(a.manifest)
    semantics=strict_read(a.semantic_proof);require(semantics['state']=='passed' and semantics['task']==a.task,'task semantics proof')
    # Formal consumes concrete short artifacts on the exact source version.
    reservations={}
    if a.phase=='formal':
        require(a.smoke_root is not None,'formal requires completed short repeat suite')
        smoke=strict_read(a.smoke_root/'SMOKE_RESULTS.json')
        require(smoke['state']=='passed' and smoke['task']==a.task and smoke['suite_manifest_sha256']==manifest_sha,'short suite exact source')
        for gpu in a.gpus:
            for method in METHODS:
                gate=smoke['gates'][f'{method}__gpu{gpu}']
                require(gate['state']=='passed' and gate['checkpoint_exact'] and gate['non_timing_progress_exact'],'all selected-device short repeats')
                require(type(gate['observed_peak_gpu_mib']) is int and gate['observed_peak_gpu_mib']>0,'observed short peak')
                reservations[(gpu,method)]=gate['observed_peak_gpu_mib']+256
    else:
        reservations={(g,m):a.bootstrap_mib for g in a.gpus for m in METHODS}
    jobs=make_plan(a,manifest_sha)
    if a.plan_only:
        print(json.dumps({'task':a.task,'phase':a.phase,'jobs':jobs,'train_runs':sum(j['kind']=='train' for j in jobs),'suite_manifest_sha256':manifest_sha},allow_nan=False));return
    require(not a.out.exists(),'fresh output root required; historical artifacts are never overwritten')
    a.out.mkdir(parents=True)
    for name in ('runs','logs','receipts','gates','cache','tmp'):(a.out/name).mkdir()
    env={**os.environ,'PYTHONUNBUFFERED':'1','PYTHONDONTWRITEBYTECODE':'1','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1',
         'DPO_TORCH_DETERMINISTIC':'1','DPO_WARP_DETERMINISTIC':'run_to_run','DPO_WARP_DETERMINISTIC_MAX_RECORDS':'8',
         'CUBLAS_WORKSPACE_CONFIG':':4096:8','DPO_PPO_GRAPH':'0','DPO_SUITE_MANIFEST_SHA256':manifest_sha,
         'XDG_CACHE_HOME':str(a.out/'cache'),'WARP_CACHE_PATH':str(a.out/'cache/warp'),'CUDA_CACHE_PATH':str(a.out/'cache/cuda'),
         'TORCH_HOME':str(a.out/'cache/torch'),'TMPDIR':str(a.out/'tmp')}
    started=time.time();active={};failure=None;peaks={};host_peaks={};unknown={}
    by_id={j['id']:j for j in jobs}
    write(a.out/'PLAN.json',{'task':a.task,'phase':a.phase,'jobs':jobs,'seeds':list(range(21,29)) if a.phase=='formal' else [SMOKE_SEED],
                            'methods':list(METHODS),'base':'fixed95','formal_budget':BUDGET,'short_budget':SHORT,'allowed_gpus':a.gpus,
                            'source_manifest_sha256':manifest_sha,'semantic_proof_sha256':sha(a.semantic_proof)})

    def status(state):
        write(a.out/'suite_status.json',{'state':state,'task':a.task,'phase':a.phase,'pid':os.getpid(),'completed_count':sum(j['state']=='completed' and j['kind']=='train' for j in jobs),
              'total':sum(j['kind']=='train' for j in jobs),'verified_count':sum(j['state']=='completed' and j['kind'] in ('verify','pair') for j in jobs),
              'active':{jid:{'pid':v['proc'].pid,'gpu':v['job']['gpu'],'kind':v['job']['kind'],'method':v['job'].get('method')} for jid,v in active.items()},
              'jobs':jobs,'failure':failure,'elapsed_seconds':time.time()-started,'unknown_owned_host_telemetry':unknown,
              'reservations_mib':{f'{g}:{m}':v for (g,m),v in reservations.items()},'suite_manifest_sha256':manifest_sha})

    def reap():
        nonlocal failure
        for jid,item in list(active.items()):
            proc=item['proc'];pid,raw,rusage=os.wait4(proc.pid,os.WNOHANG)
            if pid==0:continue
            rc=os.waitstatus_to_exitcode(raw);proc.returncode=rc;item['log'].close();j=item['job']
            host_peaks[jid]=max(host_peaks.get(jid,0),int(rusage.ru_maxrss)*1024)
            receipt={'actual_argv':j['argv'],'actual_pid':pid,'exit_code':rc,'wait_calls':1,'actual_wait4_reaped':True,
                     'elapsed_seconds':time.time()-j['started_epoch'],'observed_peak_gpu_mib':peaks.get(jid,0),'actual_max_hwm_bytes':host_peaks[jid]}
            write(a.out/'receipts'/f'{jid}.json',receipt)
            j.update(state='completed' if rc==0 else 'failed',exit_code=rc,receipt=str(a.out/'receipts'/f'{jid}.json'))
            del active[jid];unknown.pop(jid,None)
            if rc and failure is None:failure={'job_id':jid,'reason':'child nonzero exit','exit_code':rc,'log':str(a.out/'logs'/f'{jid}.log')}
            if rc==0 and j['kind']=='train':
                require(peaks.get(jid,0)>0,('no observed actual training GPU peak',jid))
                reservations[(j['gpu'],j['method'])]=max(reservations[(j['gpu'],j['method'])],peaks[jid]+256)
                if a.phase=='formal':
                    verifier=by_id['verify__'+jid];verifier['device']=j['device'];verifier['argv']=verification_command(a.python,verifier,manifest_sha)

    def launch(j,gpu=None):
        if j['kind']=='train' and a.phase=='formal':
            j.update(gpu=gpu,device=f'cuda:{gpu}')
            j['argv']=train_command(a.python,a.task,j['method'],j['seed'],j['device'],j['path'],BUDGET)
        log=(a.out/'logs'/f'{j["id"]}.log').open('xb',buffering=0)
        try:proc=subprocess.Popen(j['argv'],stdout=log,stderr=subprocess.STDOUT,env=env,cwd=str(ROOT),start_new_session=False)
        except BaseException:log.close();raise
        j.update(state='running',pid=proc.pid,started_epoch=time.time())
        active[j['id']]={'proc':proc,'log':log,'job':j};peaks[j['id']]=0;host_peaks[j['id']]=0
        write(a.out/'receipts'/f'{j["id"]}.started.json',{'actual_argv':j['argv'],'actual_pid':proc.pid,'started_epoch':j['started_epoch']})

    status('running')
    try:
        while True:
            reap()
            if not active and (failure or all(j['state']=='completed' for j in jobs)):break
            free,usage,host_free=resource_query(a.gpus)
            reap()
            now=time.monotonic()
            for jid,item in active.items():
                j=item['job'];pid=item['proc'].pid;h=host_memory(pid)
                if h is None:
                    unknown.setdefault(jid,{'pid':pid,'first_missing_monotonic':now})
                    if now-unknown[jid]['first_missing_monotonic']>=60 and failure is None:
                        failure={'job_id':jid,'reason':'owned host telemetry unavailable for 60 seconds; reservations held, dispatch blocked'}
                else:
                    unknown.pop(jid,None);host_peaks[jid]=max(host_peaks[jid],h['VmHWM'])
                if j['kind']=='train':peaks[jid]=max(peaks[jid],usage.get((j['gpu'],pid),0))
            reap()
            # No new Popen of any kind while any owned telemetry is unresolved.
            if failure is None and not unknown:
                cpu_active=sum(v['job']['kind']!='train' for v in active.values())
                disk=shutil.disk_usage(a.out).free
                ready=[j for j in jobs if j['state']=='pending' and all(by_id[x]['state']=='completed' for x in j['dependencies'])]
                ready.sort(key=lambda j:(j['kind']=='train',j['id']))
                for j in ready:
                    # Existing processes charged for unallocated reservations, including zero-memory launch phase.
                    host_charge=sum(max(0,a.host_worker_mib*1024**2-(host_memory(v['proc'].pid) or {}).get('VmRSS',0)) for v in active.values())
                    if host_free-host_charge<a.host_worker_mib*1024**2+1024**3 or disk<a.disk_floor_gib*1024**3:break
                    if j['kind']!='train':
                        if cpu_active<a.max_cpu_helpers:launch(j);cpu_active+=1
                        continue
                    candidates=[j['gpu']] if a.phase=='smoke' else list(a.gpus)
                    candidates.sort(key=lambda g:free[g],reverse=True)
                    for gpu in candidates:
                        workers=[v for v in active.values() if v['job']['kind']=='train' and v['job']['gpu']==gpu]
                        if len(workers)>=a.max_per_gpu:continue
                        charge=sum(max(0,reservations[(gpu,v['job']['method'])]-usage.get((gpu,v['proc'].pid),0)) for v in workers)
                        reserve=reservations[(gpu,j['method'])]
                        if free[gpu]-charge>=reserve+512:
                            launch(j,gpu);break
            status('failed_draining' if failure else 'running')
            time.sleep(2)
    except BaseException as exc:
        if failure is None:failure={'reason':repr(exc),'traceback':traceback.format_exc()}
        # Preserve every live trainer: drain owned children asynchronously; never kill or retry.
        status('failed_draining')
        while active:
            reap();status('failed_draining');time.sleep(2)
    if failure:
        status('failed');raise RuntimeError(failure)
    if a.phase=='smoke':
        gates={}
        for gpu in a.gpus:
            for method in METHODS:
                gate=strict_read(a.out/'gates'/f'{method}__gpu{gpu}.json')
                pair_jobs=[by_id[f'smoke__{a.task}__{method}__gpu{gpu}__{rep}'] for rep in ('a','b')]
                peak=max(peaks[j['id']] for j in pair_jobs)
                require(peak>0,'actual measured short training GPU peak')
                gate.update(observed_peak_gpu_mib=peak,actual_max_hwm_bytes=max(host_peaks[j['id']] for j in pair_jobs),paths=[j['path'] for j in pair_jobs])
                gates[f'{method}__gpu{gpu}']=gate
        write(a.out/'SMOKE_RESULTS.json',{'state':'passed','task':a.task,'methods':list(METHODS),'gpus':a.gpus,'short_budget':SHORT,
                                         'short_seed':SMOKE_SEED,'gates':gates,'suite_manifest_sha256':manifest_sha,
                                         'training_runs':16*len(a.gpus),'formal_runs':0,'elapsed_seconds':time.time()-started})
    status('completed')
    print(json.dumps({'state':'completed','task':a.task,'phase':a.phase,'training_runs':sum(j['kind']=='train' for j in jobs),'elapsed_seconds':time.time()-started}),flush=True)

if __name__=='__main__':main()
