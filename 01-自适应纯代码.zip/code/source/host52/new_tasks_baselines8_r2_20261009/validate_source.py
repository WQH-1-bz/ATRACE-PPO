"""Local stdlib-only syntax, parser forwarding, and inherited algorithm checks."""
import argparse
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent
ANCESTOR=Path('/home/mumu08/ssd_2/wch/dpo/runs/reacher_baselines8_10m_20261001/source')
SOURCE=ROOT/'source'


def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def ast_text(node):return ast.dump(node,include_attributes=False)

def selected(path,selector):return [ast_text(n) for n in ast.walk(ast.parse(path.read_text())) if selector(n)]


def main():
    checks=[]
    for path in [*SOURCE.glob('*.py'),ROOT/'run_matrix.py',ROOT/'verify_runs.py',ROOT/'validate_source.py']:
        compile(path.read_text(),str(path),'exec');checks.append('compile:'+path.name)
    for n in ['external_baseline_algorithms.py','lambda_kl_relative.py','lambda_control.py','lambda_lookahead.py','lambda_gradient_risk_gr3.py','noisy_observation.py']:
        assert digest(SOURCE/n)==digest(ANCESTOR/n);checks.append('algorithm_exact:'+n)
    for n in ['train_gradient_risk_gr3.py','train_noisy_warp.py','train_external_baseline.py','train_pae_baseline.py']:
        # All optimization epoch bodies preserved verbatim in normalized AST.
        predicate=lambda x:isinstance(x,ast.For) and isinstance(x.target,ast.Name) and x.target.id=='epoch'
        assert selected(SOURCE/n,predicate)==selected(ANCESTOR/n,predicate);checks.append('optimization_body_exact:'+n)
        for name in ['ActorCritic','RunningStats','gae','evaluate']:
            pred=lambda x:isinstance(x,(ast.FunctionDef,ast.ClassDef)) and x.name==name
            assert selected(SOURCE/n,pred)==selected(ANCESTOR/n,pred);checks.append('shared_component_exact:'+n+':'+name)
        text=(SOURCE/n).read_text()
        assert 'torch.manual_seed(' not in text and 'manual_seed_all' not in text and 'get_rng_state_all' not in text
        assert 'torch.cuda.manual_seed(' in text;checks.append('selected_device_seed_only:'+n)
    spec=importlib.util.spec_from_file_location('matrix_local',ROOT/'run_matrix.py');matrix=importlib.util.module_from_spec(spec);spec.loader.exec_module(matrix)
    parser_count=0
    for task in matrix.TASKS:
        for method in matrix.METHODS:
            for budget in [matrix.SHORT,matrix.BUDGET]:
                cmd=matrix.train_command(Path(sys.executable),task,method,21,'cuda:1',Path('/tmp/not_created'),budget)
                script=Path(cmd[2])
                if script.name=='train_internal_base.py':script=SOURCE/'train_gradient_risk_gr3.py'
                tree=ast.parse(script.read_text());main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
                body=[];var=None
                for node in main.body:
                    body.append(node)
                    if isinstance(node,ast.Assign) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and node.value.func.attr=='parse_args':
                        var=node.targets[0].id;break
                assert var;body.append(ast.Return(value=ast.Name(id=var,ctx=ast.Load())))
                minimal=ast.Module(body=[ast.FunctionDef(name='parse_only',args=ast.arguments(posonlyargs=[],args=[],kwonlyargs=[],kw_defaults=[],defaults=[]),body=body,decorator_list=[])],type_ignores=[])
                ast.fix_missing_locations(minimal)
                namespace={'argparse':argparse,'Path':Path,'TASKS':dict.fromkeys(matrix.TASKS)}
                exec(compile(minimal,'<actual trainer parser>','exec'),namespace)
                old=sys.argv;sys.argv=[cmd[2],*cmd[3:]]
                try:a=namespace['parse_only']()
                finally:sys.argv=old
                assert a.task==task and a.seed==21 and a.device=='cuda:1' and a.steps==budget
                if method=='pae':assert a.force_pae_overlap and a.overlap_stop_steps==budget
                parser_count+=1
    checks.append('actual_planned_argv_parsed:'+str(parser_count))
    assert parser_count==32
    print(json.dumps({'state':'source_checks_passed','checks':checks,'actual_planned_commands':parser_count,'native_actions':0,'torch_imports':0,'formal_runs':0},indent=2))

if __name__=='__main__':main()
