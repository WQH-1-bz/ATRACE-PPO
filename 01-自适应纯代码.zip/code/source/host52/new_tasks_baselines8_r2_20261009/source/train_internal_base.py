"""Fixed and linear PPO entry point, unchanged matched backbone."""
from train_gradient_risk_gr3 import main
if __name__ == "__main__":
    main()
