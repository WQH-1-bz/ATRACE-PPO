"""Official-CPU fixture semantic checks; optionally checks live GPU adapters.

Default CPU-only verifies production Torch observation/reward/reset equations
against actual official package outputs. --device cuda:N additionally compares
GPU one-step physics, masks, fresh reset and terminal-observation semantics.
It creates contexts on only the requested GPU. No training is performed.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import numpy as np
import torch
from new_tasks_semantics import (ASSETS,TASK_META,POINT_CENTERS,point_observation,
    point_reward_success,cartpole_observation,cartpole_reward,sample_reset_states)

ROOT=Path(__file__).resolve().parent
FIXTURE=ROOT/'official'/'CPU_REFERENCE_FIXTURES.json'


def close(actual, expected, label, atol=3e-6):
    actual=np.asarray(actual,dtype=float);expected=np.asarray(expected,dtype=float)
    if actual.shape!=expected.shape or not np.allclose(actual,expected,rtol=1e-5,atol=atol):
        difference=float(np.max(np.abs(actual-expected))) if actual.shape==expected.shape else None
        raise AssertionError((label,actual.shape,expected.shape,difference,atol))
    return float(np.max(np.abs(actual-expected))) if actual.size else 0.


def equations(reference):
    rows=0;maximum=0.
    for task,fixtures in reference['fixtures'].items():
        for r in fixtures:
            q=torch.tensor([r.get('after_qpos',r['qpos'])],dtype=torch.float32)
            v=torch.tensor([r.get('after_qvel',r['qvel'])],dtype=torch.float32)
            if task=='PointMaze':
                goal=torch.tensor([r['goal']],dtype=torch.float32)
                obs=point_observation(q,v,goal)
                reward,success=point_reward_success(q,goal)
                assert bool(success[0])==r['success']
                assert r['terminated'] is False
            else:
                xmat=torch.tensor([r['xmat']],dtype=torch.float32)
                control=torch.tensor([r['action']],dtype=torch.float32).clamp(-1.,1.)
                obs=cartpole_observation(q,v,xmat)
                reward=cartpole_reward(q,v,xmat,control)
            maximum=max(maximum,close(obs[0].numpy(),r['obs'],(task,r['kind'],'observation')))
            maximum=max(maximum,close(float(reward[0]),r['reward'],(task,r['kind'],'reward')))
            rows+=1
    return {'state':'passed','rows':rows,'max_abs_error':maximum}


def reset_distribution(reference):
    n=32768;checks={}
    generator=torch.Generator(device='cpu').manual_seed(83114)
    for task in reference['fixtures']:
        q,v,goal=sample_reset_states(task,n,'cpu',generator)
        official=reference['reset_distribution'][task]
        if task=='PointMaze':
            centers=torch.tensor(POINT_CENTERS)
            close(centers.numpy(),official['unique_goal_locations'],'PointMaze official centers',0.)
            qdist=(q[:,None,:]-centers[None,:,:]).abs().amax(-1)
            gdist=(goal[:,None,:]-centers[None,:,:]).abs().amax(-1)
            qi=qdist.argmin(-1);gi=gdist.argmin(-1)
            assert bool((qdist.min(-1).values<=.250001).all())
            assert bool((gdist.min(-1).values<=.250001).all())
            assert bool((qi!=gi).all()) and bool((v==0).all())
            # Uniform distribution over all seven goal cells and other six resets.
            frequencies=torch.bincount(gi,minlength=7).double()/n
            assert bool(((frequencies-1/7).abs()<.012).all())
            pair_counts=torch.bincount(gi*7+qi,minlength=49).reshape(7,7)
            assert bool((pair_counts.diag()==0).all())
            offdiag=pair_counts[~torch.eye(7,dtype=torch.bool)].double()/n
            assert bool(((offdiag-1/42).abs()<.005).all())
            for name,tensor in [('qpos',q),('goal',goal)]:
                close(tensor.mean(0).numpy(),official[name]['mean'],('PointMaze resetmean',name),.08)
            checks[task]={'samples':n,'goal_cell_frequency':frequencies.tolist(),
                         'distinct_cells':True,'velocity_exact_zero':True}
        else:
            centered=q-torch.tensor([0.,math.pi])
            assert bool((centered.mean(0).abs()<.0003).all())
            assert bool((v.mean(0).abs()<.0003).all())
            assert bool(((centered.std(0)-.01).abs()<.0003).all())
            assert bool(((v.std(0)-.01).abs()<.0003).all())
            close(q.mean(0).numpy(),official['qpos']['mean'],'Cartpole official positionmean',.0016)
            close(v.mean(0).numpy(),official['qvel']['mean'],'Cartpole official velocitymean',.0016)
            checks[task]={'samples':n,'centered_qpos_mean':centered.mean(0).tolist(),
                          'qpos_std':centered.std(0).tolist(),'qvel_std':v.std(0).tolist()}
    return {'state':'passed','tasks':checks}


def live_gpu(reference,device):
    # Import GPU physics only in the explicitly requested execution path.
    from new_tasks_warp import NewTasksWarp
    import warp as wp
    results={}
    for task,fixtures in reference['fixtures'].items():
        steps=[r for r in fixtures if r['kind']=='step']
        env=NewTasksWarp(len(steps),device,seed=91084,task=task)
        # At fixed known states compare actual GPU-derived observations and
        # production reward equations separately from physics integration error.
        states=[r for r in fixtures if r['kind']=='state']
        states=[states[i%len(states)] for i in range(len(steps))]
        env.qpos.copy_(torch.tensor([r['qpos'] for r in states],device=device,dtype=torch.float32))
        env.qvel.copy_(torch.tensor([r['qvel'] for r in states],device=device,dtype=torch.float32))
        if task=='PointMaze':
            env.goal.copy_(torch.tensor([r['goal'] for r in states],device=device,dtype=torch.float32))
        else:
            env.ctrl.copy_(torch.tensor([r['action'] for r in states],device=device,dtype=torch.float32).clamp(-1.,1.))
        wp.capture_launch(env.kinematics_graph,stream=env.stream)
        frozen_obs=env.observation()
        if task=='PointMaze':
            frozen_reward,frozen_success=point_reward_success(env.qpos,env.goal)
            assert frozen_success.cpu().tolist()==[r['success'] for r in states]
        else:
            frozen_reward=cartpole_reward(env.qpos,env.qvel,env.xmat,env.ctrl)
        frozen_errors={
            'observation':close(frozen_obs.cpu().numpy(),[r['obs'] for r in states],(task,'GPU frozen observation'),3e-6),
            'reward':close(frozen_reward.cpu().numpy(),[r['reward'] for r in states],(task,'GPU frozen reward'),3e-6)}
        q=torch.tensor([r['qpos'] for r in steps],device=device,dtype=torch.float32)
        v=torch.tensor([r['qvel'] for r in steps],device=device,dtype=torch.float32)
        actions=torch.tensor([r['action'] for r in steps],device=device,dtype=torch.float32)
        env.qpos.copy_(q);env.qvel.copy_(v)
        if task=='PointMaze':env.goal.copy_(torch.tensor([r['goal'] for r in steps],device=device,dtype=torch.float32))
        wp.capture_launch(env.kinematics_graph,stream=env.stream)
        obs,reward,terminated,truncated,info=env.step(actions)
        errors={}
        errors['terminal_observation']=close(info['terminal_observation'].cpu().numpy(),[r['obs'] for r in steps],(task,'GPU obs'),5e-4)
        errors['reward']=close(reward.cpu().numpy(),[r['reward'] for r in steps],(task,'GPU reward'),5e-4)
        errors['qpos']=close(env.qpos.cpu().numpy(),[r['after_qpos'] for r in steps],(task,'GPU qpos'),5e-4)
        errors['qvel']=close(env.qvel.cpu().numpy(),[r['after_qvel'] for r in steps],(task,'GPU qvel'),5e-4)
        assert not bool(terminated.any()) and not bool(truncated.any())
        if task=='PointMaze':
            assert info['success'].cpu().tolist()==[r['success'] for r in steps]
            # Goal is retained even on success under actual default reset_target=False.
            assert torch.equal(env.goal,torch.tensor([r['goal'] for r in steps],device=device,dtype=torch.float32))
        # Masked resets must not reset continuing worlds' state or counters.
        before=[env.qpos.clone(),env.qvel.clone(),env.goal.clone()]
        before_observation=env.observation().clone()
        before_derived=[tensor.clone() for tensor in env.kinematic_tensors]
        env.lengths.fill_(9);env.returns.fill_(3.)
        mask=torch.zeros(env.num_envs,device=device,dtype=torch.bool);mask[0]=True
        env.reset(mask)
        for previous,current in zip(before,(env.qpos,env.qvel,env.goal)):
            assert torch.equal(previous[1:],current[1:])
        assert torch.equal(before_observation[1:],env.observation()[1:])
        for previous,current in zip(before_derived,env.kinematic_tensors):
            assert torch.equal(previous[1:],current[1:])
        assert env.lengths[0]==0 and bool((env.lengths[1:]==9).all())
        assert env.returns[0]==0 and bool((env.returns[1:]==3.).all())
        # TimeLimit maps to truncation, keeps terminal obs before masked autoreset.
        env.lengths.fill_(env.max_steps-1)
        obs,reward,terminated,truncated,info=env.step(torch.zeros_like(actions))
        assert bool(truncated.all()) and not bool(terminated.any())
        assert bool((info['episode_length']==env.max_steps).all())
        assert bool((env.lengths==0).all())
        assert not torch.equal(obs,info['terminal_observation'])
        assert bool(torch.isfinite(obs).all()) and bool(torch.isfinite(reward).all())
        for _ in range(32):env.step(torch.zeros_like(actions))
        env.check_capacity()
        results[task]={'state':'passed','fixture_steps':len(steps),'maximum_errors':errors,'frozen_state_errors':frozen_errors,
            'masked_reset':True,'time_limit_truncation':True,'terminal_observation':True,
            'finite_stepping':32}
    return {'state':'passed','device':device,'tasks':results}


def main():
    p=argparse.ArgumentParser();p.add_argument('--device');p.add_argument('--task',choices=list(TASK_META));p.add_argument('--output',required=True)
    a=p.parse_args();reference=json.loads(FIXTURE.read_text())
    if a.task:
        reference['fixtures']={a.task:reference['fixtures'][a.task]}
    provenance=json.loads((ROOT/'official'/'OFFICIAL_SOURCE_PROVENANCE.json').read_text())
    for package,pin in provenance.items():
        for relative,entry in pin['files'].items():
            actual=hashlib.sha256((ROOT/'official'/package/relative).read_bytes()).hexdigest()
            assert actual==entry['sha256'],(package,relative)
    installed=json.loads((ROOT/'official'/'INSTALLED_REFERENCE_PROVENANCE.json').read_text())
    for relative,entry in installed['files'].items():
        assert hashlib.sha256((ROOT/'official'/'installed_reference'/relative).read_bytes()).hexdigest()==entry['installed_reference_sha256']
    for asset in ('cartpole.xml','common/skybox.xml','common/visual.xml','common/materials.xml'):
        original=ROOT/'official'/'installed_reference'/'dm_control'/'suite'/asset
        assert (ASSETS/asset).read_bytes()==original.read_bytes()
    assert hashlib.sha256((ASSETS/'point_umaze.xml').read_bytes()).hexdigest()==reference['point_xml_sha256']
    result={'state':'passed','task':a.task,'fixture_sha256':hashlib.sha256(FIXTURE.read_bytes()).hexdigest(),
       'task_metadata':TASK_META,'official_reference_packages':reference['reference_packages'],
       'equations':equations(reference),'reset_distribution':reset_distribution(reference),
       'gpu':live_gpu(reference,a.device) if a.device else {'state':'not_requested'}}
    Path(a.output).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'state':result['state'],'rows':result['equations']['rows'],'gpu':result['gpu']['state']}))
if __name__=='__main__':main()
