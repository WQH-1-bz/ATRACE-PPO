"""Task equations and reset distributions, independent of GPU initialization.

Official sources and asset derivations are pinned in official/ and TASK_SEMANTICS.md.
All state tensors below are batch-major, using Torch's selected-device generator.
"""
from pathlib import Path
import copy
import math
import torch

ASSETS = Path(__file__).resolve().parent / 'assets'
TASKS = {'PointMaze': ('point_umaze.xml', 1, .25, 0.),
         'CartpoleSwingup': ('cartpole.xml', 1, .01, 0.)}
TASK_META = {
    'PointMaze': {
        'benchmark_id': 'PointMaze_UMazeDense-v3', 'reference': 'Gymnasium-Robotics 1.4.2',
        'obs_dim': 8, 'action_dim': 2, 'horizon': 300, 'max_episode_steps': 300, 'physics_timestep': .01,
        'frame_skip': 1, 'reward': 'exp(-Euclidean_distance), post-physics',
        'continuing_task': True, 'reset_target': False, 'success_radius': .45,
        'observation_keys': ['achieved_goal', 'desired_goal', 'observation'],
        'velocity_clip_before_physics': [-5., 5.], 'action_bounds': [-1., 1.],
        'reset_goal_cell_rule': 'uniform seven empty cells, different reset cell',
        'reset_position_noise': [-.25, .25],
        'robotics_commit': 'f885d53a8bef8949589038e73a664e427f5ec49f',
    },
    'CartpoleSwingup': {
        'benchmark_id': 'dm_control/cartpole/swingup', 'reference': 'DeepMind Control Suite 1.0.48',
        'obs_dim': 5, 'action_dim': 1, 'horizon': 1000, 'max_episode_steps': 1000, 'physics_timestep': .01,
        'frame_skip': 1, 'reward': 'official dense Balance._get_reward, post-physics',
        'time_limit_seconds': 10., 'legacy_step': True, 'discount_at_time_limit': 1.,
        'observation_keys': ['position', 'velocity'], 'action_bounds': [-1., 1.],
        'reset_position_distribution': 'slider N(0,.01^2), hinge N(pi,.01^2)',
        'reset_velocity_distribution': 'independent N(0,.01^2)',
        'dm_control_commit': 'c22ec28159c541c8c6b6546cd56d41dcaf7fb33b',
    },
}
# row-major free-cell centers produced by Maze.make_maze for U_MAZE, scaling=1.
POINT_CENTERS = ((-1., 1.), (0., 1.), (1., 1.), (1., 0.),
                 (-1., -1.), (0., -1.), (1., -1.))


def get_task_metadata(task):
    return copy.deepcopy(TASK_META[task])


def point_observation(qpos, qvel, goal):
    # Gymnasium spaces.Dict sorts the string keys lexicographically.
    return torch.cat((qpos, goal, qpos, qvel), dim=-1)


def point_reward_success(qpos, goal):
    distance = (qpos - goal).norm(dim=-1)
    return (-distance).exp(), distance <= .45


def cartpole_observation(qpos, qvel, xmat):
    # Official Physics.bounded_position reads zz, xz of pole_1, in this order.
    pole = xmat[:, 2].reshape(-1, 9)
    return torch.cat((qpos[:, :1], pole[:, 8:9], pole[:, 2:3], qvel), dim=-1)


def cartpole_reward(qpos, qvel, xmat, ctrl):
    pole_cos = xmat[:, 2].reshape(-1, 9)[:, 8]
    upright = (pole_cos + 1.) / 2.
    # rewards.tolerance(x,bounds=(0,0), margin, gaussian,value_at_margin=.1)
    centered = (1. + torch.exp(math.log(.1) * (qpos[:, 0] / 2.).square())) / 2.
    # Quadratic tolerance at margin=1,value_at_margin=0; clipped-control value.
    control_tolerance = (1. - ctrl[:, 0].square()).clamp_min(0.)
    small_control = (4. + control_tolerance) / 5.
    small_velocity = (1. + torch.exp(math.log(.1) * (qvel[:, 1] / 5.).square())) / 2.
    return upright * centered * small_control * small_velocity


def sample_reset_states(task, n, device, generator, dtype=torch.float32):
    if task == 'PointMaze':
        centers = torch.tensor(POINT_CENTERS, device=device, dtype=dtype)
        goal_index = torch.randint(7, (n,), device=device, generator=generator)
        # Official reset rejects the selected goal's cell. Noise is <.354 from
        # that center; every other center is >.5 from the noisy goal. Mapping a
        # uniform draw from six values onto the other six cells is therefore
        # exactly the same distribution as the reference rejection sampler.
        reset_index = (goal_index + 1 + torch.randint(6, (n,), device=device, generator=generator)) % 7
        goal = centers[goal_index] + (torch.rand((n, 2), device=device, generator=generator, dtype=dtype) - .5) * .5
        pos = centers[reset_index] + (torch.rand((n, 2), device=device, generator=generator, dtype=dtype) - .5) * .5
        vel = torch.zeros((n, 2), device=device, dtype=dtype)
        return pos, vel, goal
    if task == 'CartpoleSwingup':
        pos = torch.randn((n, 2), device=device, generator=generator, dtype=dtype) * .01
        pos[:, 1].add_(math.pi)
        vel = torch.randn((n, 2), device=device, generator=generator, dtype=dtype) * .01
        return pos, vel, None
    raise ValueError(task)
