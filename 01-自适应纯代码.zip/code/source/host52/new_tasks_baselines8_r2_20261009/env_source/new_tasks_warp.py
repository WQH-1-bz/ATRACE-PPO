"""Deterministic GPU physics adapters for two official, dense-reward tasks.

Physics uses MuJoCo Warp float32. It is not bitwise CPU MuJoCo equivalence.
See TASK_SEMANTICS.md and semantic_audit.py for official semantic verification.
"""
import os
import mujoco
import torch
import warp as wp
from new_tasks_semantics import (ASSETS, TASKS, TASK_META, get_task_metadata,
    point_observation, point_reward_success, cartpole_observation, cartpole_reward,
    sample_reset_states)

_DETERMINISTIC = os.environ.get('DPO_WARP_DETERMINISTIC', '').strip().lower()
if _DETERMINISTIC:
    modes = {'run_to_run': wp.DeterministicMode.RUN_TO_RUN,
             'gpu_to_gpu': wp.DeterministicMode.GPU_TO_GPU}
    if _DETERMINISTIC not in modes:
        raise ValueError(f'Unsupported DPO_WARP_DETERMINISTIC={_DETERMINISTIC!r}')
    wp.config.deterministic = modes[_DETERMINISTIC]
    wp.config.deterministic_max_records = int(os.environ.get('DPO_WARP_DETERMINISTIC_MAX_RECORDS', '64'))
import mujoco_warp as mjw

_STREAMS = {}


class NewTasksWarp:
    def __init__(self, num_envs=1024, device='cuda:0', seed=0, max_steps=1000, task='PointMaze'):
        if task not in TASKS:
            raise ValueError(task)
        self.task, self.num_envs, self.device = task, num_envs, device
        self.metadata = get_task_metadata(task)
        self.max_steps = self.metadata['horizon']
        self.frame_skip = 1
        self.obs_dim, self.action_dim = self.metadata['obs_dim'], self.metadata['action_dim']
        self.xml_path = ASSETS / TASKS[task][0]
        self.rng = torch.Generator(device=device).manual_seed(seed)
        wp.init()
        wp.set_device(device)
        if torch.cuda.current_stream(device).cuda_stream == 0:
            torch.cuda.set_stream(torch.cuda.Stream(device=device))
        self.torch_stream = torch.cuda.current_stream(device)
        key = (device, self.torch_stream.cuda_stream)
        if key not in _STREAMS:
            _STREAMS[key] = (self.torch_stream, wp.stream_from_torch(self.torch_stream))
        self.stream = _STREAMS[key][1]
        wp.set_stream(self.stream)
        self.cpu_model = mujoco.MjModel.from_xml_path(str(self.xml_path))
        if _DETERMINISTIC and self.cpu_model.nsensor == 0:
            self.cpu_model.opt.disableflags |= int(mujoco.mjtDisableBit.mjDSBL_SENSOR)
        if _DETERMINISTIC and task == 'CartpoleSwingup':
            # Official Cartpole enables diagnostic energy, unused by dynamics,
            # observation and reward. Its shared sensor module includes a
            # tactile kernel unsupported by deterministic Warp code generation.
            self.cpu_model.opt.enableflags &= ~int(mujoco.mjtEnableBit.mjENBL_ENERGY)
        assert self.cpu_model.nq == self.cpu_model.nv == 2
        assert self.cpu_model.nu == self.action_dim
        self.dt = float(self.cpu_model.opt.timestep)
        assert abs(self.dt - .01) < 1e-12
        self.model = mjw.put_model(self.cpu_model)
        self.data = mjw.make_data(self.cpu_model, nworld=num_envs, nconmax=128, njmax=256)
        self.qpos, self.qvel, self.ctrl = (wp.to_torch(getattr(self.data, k)) for k in ('qpos', 'qvel', 'ctrl'))
        self.xmat = wp.to_torch(self.data.xmat)
        self.kinematic_tensors = [wp.to_torch(getattr(self.data, name)) for name in (
            'xpos', 'xquat', 'xanchor', 'xaxis', 'xmat', 'xipos', 'ximat',
            'geom_xpos', 'geom_xmat', 'site_xpos', 'site_xmat')]
        self.goal = torch.zeros((num_envs, 2), device=device)
        self.lengths = torch.zeros(num_envs, device=device, dtype=torch.long)
        self.returns = torch.zeros(num_envs, device=device)
        self.reset_mask = torch.ones(num_envs, device=device, dtype=torch.bool)
        self.wp_reset_mask = wp.from_torch(self.reset_mask)
        self.overflow_seen = torch.zeros((), device=device, dtype=torch.bool)
        self.nonfinite_seen = torch.zeros((), device=device, dtype=torch.bool)
        self.ctrl.zero_()
        print(f'Compiling {self.metadata["benchmark_id"]} for {num_envs} worlds on {device}...', flush=True)
        mjw.step(self.model, self.data)
        mjw.reset_data(self.model, self.data, self.wp_reset_mask)
        mjw.kinematics(self.model, self.data)
        wp.synchronize_device(device)
        with wp.ScopedCapture(stream=self.stream) as cap:
            mjw.step(self.model, self.data)
            if task == 'CartpoleSwingup':
                # DMC legacy_step RK4 calls mj_step then mj_step1. Observation
                # and reward need only refreshed body rotations, qpos/qvel/ctrl;
                # kinematics gives precisely those mj_step1 position fields.
                mjw.kinematics(self.model, self.data)
        self.physics_graph = cap.graph
        with wp.ScopedCapture(stream=self.stream) as cap:
            mjw.reset_data(self.model, self.data, self.wp_reset_mask)
        self.reset_graph = cap.graph
        with wp.ScopedCapture(stream=self.stream) as cap:
            mjw.kinematics(self.model, self.data)
        self.kinematics_graph = cap.graph
        self.reset()
        print('Physics ready.', flush=True)

    def observation(self):
        if self.task == 'PointMaze':
            return point_observation(self.qpos, self.qvel, self.goal)
        return cartpole_observation(self.qpos, self.qvel, self.xmat)

    def reset(self, mask=None):
        if mask is None:
            self.reset_mask.fill_(True)
        else:
            self.reset_mask.copy_(mask)
        previous_kinematics = [tensor.clone() for tensor in self.kinematic_tensors]
        wp.capture_launch(self.reset_graph, stream=self.stream)
        pos, vel, goal = sample_reset_states(self.task, self.num_envs, self.device, self.rng)
        self.qpos.copy_(torch.where(self.reset_mask[:, None], pos, self.qpos))
        self.qvel.copy_(torch.where(self.reset_mask[:, None], vel, self.qvel))
        if goal is not None:
            self.goal.copy_(torch.where(self.reset_mask[:, None], goal, self.goal))
        self.lengths.masked_fill_(self.reset_mask, 0)
        self.returns.masked_fill_(self.reset_mask, 0)
        # Refresh reset worlds' position fields just as the references'
        # set_state/reset_context does; preserve every continuing world's
        # pre-reset derived bytes, including Euler's last-stage geometry.
        wp.capture_launch(self.kinematics_graph, stream=self.stream)
        for tensor, previous in zip(self.kinematic_tensors, previous_kinematics):
            mask_shape = (self.num_envs,) + (1,) * (tensor.ndim - 1)
            tensor.copy_(torch.where(self.reset_mask.view(mask_shape), tensor, previous))
        return self.observation()

    @torch.no_grad()
    def step(self, actions):
        if self.task == 'PointMaze':
            # Official PointEnv clips velocities BEFORE physics, not afterward.
            self.qvel.clamp_(-5., 5.)
        self.ctrl.copy_(actions.clamp(-1., 1.))
        wp.capture_launch(self.physics_graph, stream=self.stream)
        if hasattr(self.data, 'overflow'):
            self.overflow_seen.logical_or_(wp.to_torch(self.data.overflow).ne(0).any())
        self.nonfinite_seen.logical_or_(~(torch.isfinite(self.qpos).all() & torch.isfinite(self.qvel).all()))
        terminal_obs = self.observation()
        if self.task == 'PointMaze':
            reward, success = point_reward_success(self.qpos, self.goal)
        else:
            reward = cartpole_reward(self.qpos, self.qvel, self.xmat, self.ctrl)
            success = None
        # Official default PointMaze is continuing, and Cartpole has no task
        # termination. Both limits truncate and keep value bootstrapping.
        terminated = torch.zeros(self.num_envs, device=self.device, dtype=torch.bool)
        self.lengths.add_(1)
        self.returns.add_(reward)
        truncated = self.lengths >= self.max_steps
        done = terminated | truncated
        info = {'terminal_observation': terminal_obs,
                'episode_done': done, 'episode_return': self.returns.clone(),
                'episode_length': self.lengths.clone()}
        if success is not None:
            info['success'] = success
        obs = self.reset(done)
        return obs, reward, terminated, truncated, info

    def check_capacity(self):
        if bool(self.overflow_seen):
            raise RuntimeError('MuJoCo Warp contact/constraint capacity overflow')
        if bool(self.nonfinite_seen):
            raise RuntimeError('Non-finite GPU physics state')


LocomotionWarp = NewTasksWarp
