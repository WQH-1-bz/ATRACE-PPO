"""Archive exact official installed reference source, separately from Git pins."""
from pathlib import Path
import importlib.metadata as md
import hashlib
import json
import ast
import gymnasium_robotics
import dm_control
ROOT=Path(__file__).resolve().parent
sources={'gymnasium_robotics':(Path(gymnasium_robotics.__file__).parent,[
 '__init__.py','envs/maze/point_maze.py','envs/maze/maze_v4.py','envs/maze/point.py','envs/maze/maps.py','envs/assets/point/point.xml']),
 'dm_control':(Path(dm_control.__file__).parent,['suite/cartpole.py','suite/cartpole.xml','suite/common/skybox.xml','suite/common/visual.xml','suite/common/materials.xml','mujoco/engine.py','rl/control.py','suite/base.py','utils/rewards.py'])}
provenance={'packages':{'gymnasium_robotics':md.version('gymnasium-robotics'),'dm_control':md.version('dm-control')},'files':{},'physics':'mujoco '+md.version('mujoco')}
for package,(root,files) in sources.items():
 for name in files:
  raw=(root/name).read_bytes();dest=ROOT/'official'/'installed_reference'/package/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
  key=f'{package}/{name}'
  frozen=ROOT/'official'/package/package/name
  provenance['files'][key]={'installed_reference_sha256':hashlib.sha256(raw).hexdigest(),
    'installed_original_path':str(root/name),
    'downloaded_git_source_sha256':hashlib.sha256(frozen.read_bytes()).hexdigest() if frozen.exists() else None,
    'byte_equal_to_downloaded_git_source':frozen.exists() and raw==frozen.read_bytes()}
(ROOT/'official'/'INSTALLED_REFERENCE_PROVENANCE.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(json.dumps({'files':len(provenance['files']), 'byte_equal_to_git':sum(x['byte_equal_to_downloaded_git_source'] for x in provenance['files'].values())}))
