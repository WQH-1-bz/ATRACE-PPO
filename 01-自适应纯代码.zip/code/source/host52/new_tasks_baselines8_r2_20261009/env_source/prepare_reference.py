"""Run in an isolated CPU-only official reference environment; no Torch/GPU.

Writes official XML, known-state/reset/step fixtures and reference provenance.
These fixtures let the production pinned runtime audit semantics without adding
Gymnasium-Robotics or dm_control to any shared package installation.
"""
import os
os.environ['MUJOCO_GL'] = 'egl'
import json
import hashlib
import importlib.metadata as md
from pathlib import Path
import numpy as np
import gymnasium as gym
import gymnasium_robotics
from dm_control import suite
from dm_control.suite import cartpole

ROOT = Path(__file__).resolve().parent

def flatten(obs):
    if 'achieved_goal' in obs:
        return np.concatenate([obs[k] for k in ('achieved_goal', 'desired_goal', 'observation')]).tolist()
    return np.concatenate([obs[k] for k in ('position', 'velocity')]).tolist()

def stats(a):
    a = np.asarray(a)
    return dict(count=len(a), mean=a.mean(0).tolist(), std=a.std(0).tolist(),
                min=a.min(0).tolist(), max=a.max(0).tolist())

def main():
    gym.register_envs(gymnasium_robotics)
    pm = gym.make('PointMaze_UMazeDense-v3')
    p = pm.unwrapped
    point_xml = Path(p.tmp_xml_file_path).read_bytes()
    (ROOT / 'assets' / 'point_umaze.xml').write_bytes(point_xml)
    assert p.continuing_task is True and p.reset_target is False
    assert pm.spec.max_episode_steps == 300 and p.point_env.frame_skip == 1
    assert list(p.observation_space.spaces) == ['achieved_goal', 'desired_goal', 'observation']
    fixture = {'PointMaze': [], 'CartpoleSwingup': []}
    # Open cells, goal success boundary, and excessive velocity (pre-step clip).
    for pos, vel, goal in [([-1,1],[0,0],[1,-1]), ([0,1],[.3,-.2],[0,1]),
            ([1,0],[6,-7],[1,-1]), ([.54,1],[0,0],[1,1]),
            ([.56,1],[0,0],[1,1]), ([1,-1],[2,1],[-1,1])]:
        pm.reset(seed=21)
        p.point_env.set_state(np.array(pos,dtype=float), np.array(vel,dtype=float))
        p.goal = np.array(goal,dtype=float)
        p.update_target_site_pos()
        raw = np.concatenate((pos,vel))
        obs = p._get_obs(raw)
        fixture['PointMaze'].append({'kind': 'state', 'qpos': pos, 'qvel': vel, 'goal': goal,
                'obs': flatten(obs), 'reward': float(p.compute_reward(obs['achieved_goal'],p.goal,{})),
                'terminated': bool(p.compute_terminated(obs['achieved_goal'],p.goal,{})),
                'success': bool(np.linalg.norm(np.array(pos)-goal)<=.45)})
        for act in ([0.,0.], [.4,-.7], [2.,-2.]):
            p.point_env.set_state(np.array(pos,dtype=float), np.array(vel,dtype=float))
            obs,r,term,trunc,info=pm.step(np.array(act))
            fixture['PointMaze'].append({'kind':'step','qpos':pos,'qvel':vel,'goal':goal,'action':act,
                'after_qpos':p.data.qpos.tolist(),'after_qvel':p.data.qvel.tolist(),
                'obs':flatten(obs),'reward':float(r),'terminated':bool(term),
                'truncated':bool(trunc),'success':bool(info['success'])})
    dmc = suite.load('cartpole','swingup',task_kwargs={'random':21})
    cp = dmc.physics
    assert dmc.control_timestep() == .01 and dmc._step_limit == 1000
    for pos,vel in [([0,np.pi],[0,0]),([0,0],[0,0]),([.5,.3],[.2,2]),
                    ([-1.6,2.],[.1,-6.]),([1.,-.7],[-.3,3.])]:
        for act in ([0.],[.5],[1.],[2.]):
            dmc.reset()
            with cp.reset_context():
                cp.data.qpos[:]=pos;cp.data.qvel[:]=vel;cp.data.ctrl[:]=act
            fixture['CartpoleSwingup'].append({'kind':'state','qpos':pos,'qvel':vel,'action':act,
                'xmat':cp.data.xmat.copy().reshape(-1,3,3).tolist(),
                'obs':flatten(dmc.task.get_observation(cp)), 'reward':float(dmc.task.get_reward(cp))})
            ts=dmc.step(np.array(act))
            fixture['CartpoleSwingup'].append({'kind':'step','qpos':pos,'qvel':vel,'action':act,
                'after_qpos':cp.data.qpos.tolist(),'after_qvel':cp.data.qvel.tolist(),
                'xmat':cp.data.xmat.copy().reshape(-1,3,3).tolist(),
                'obs':flatten(ts.observation),'reward':float(ts.reward),
                'terminated':False,'truncated':bool(ts.last())})
    point_pos=[];point_goal=[];cart_pos=[];cart_vel=[]
    for i in range(2048):
        obs,_=pm.reset(seed=i+1000)
        point_pos.append(obs['achieved_goal']);point_goal.append(obs['desired_goal'])
        dmc.reset();cart_pos.append(cp.data.qpos.copy());cart_vel.append(cp.data.qvel.copy())
    resets={'PointMaze':{'qpos':stats(point_pos),'goal':stats(point_goal),
        'unique_goal_locations':np.array(p.maze.unique_goal_locations).tolist(),
        'unique_reset_locations':np.array(p.maze.unique_reset_locations).tolist()},
        'CartpoleSwingup':{'qpos':stats(cart_pos),'qvel':stats(cart_vel)}}
    # Real time-limit and success semantics, not inferred from documentation.
    pm.reset(seed=41)
    pm.unwrapped.goal=pm.unwrapped.data.qpos[:2].copy()
    goal_before=pm.unwrapped.goal.copy()
    first=pm.step(np.zeros(2))
    assert first[2] is False and first[4]['success'] is True
    assert np.array_equal(goal_before,pm.unwrapped.goal)
    last=first
    for _ in range(299):last=pm.step(np.zeros(2))
    assert last[2] is False and last[3] is True
    dmc.reset();ts=None
    for _ in range(1000):ts=dmc.step(np.zeros(1))
    assert ts.last() and ts.discount == 1.
    refs={}
    for name, mod in [('robotics_point_maze',__import__('gymnasium_robotics.envs.maze.point_maze',fromlist=[''])),
            ('robotics_maze',__import__('gymnasium_robotics.envs.maze.maze_v4',fromlist=[''])),
            ('robotics_point',__import__('gymnasium_robotics.envs.maze.point',fromlist=[''])),
            ('dmc_cartpole',cartpole)]:
        f=Path(mod.__file__);refs[name]={'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
    output={'reference_packages':{x:md.version(x) for x in ['gymnasium-robotics','gymnasium','dm-control','mujoco','numpy']},
       'official_reference_files':refs,'fixtures':fixture,'reset_distribution':resets,
       'time_limits':{'PointMaze':{'steps':300,'terminated':False,'truncated':True,'reset_target_on_success':False},
                      'CartpoleSwingup':{'steps':1000,'last':True,'discount':1.}},
       'point_xml_sha256':hashlib.sha256(point_xml).hexdigest()}
    (ROOT/'official'/'CPU_REFERENCE_FIXTURES.json').write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')
    pm.close();cp.free()
    print(json.dumps({'state':'passed','known_state_and_step_rows':{k:len(v) for k,v in fixture.items()},
          'reset_samples_per_task':2048,'packages':output['reference_packages'],
          'point_xml_sha256':output['point_xml_sha256']}))
if __name__=='__main__':main()
