"""Run real task semantics, deterministic method repeats, then the full matrix."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import traceback

ROOT = Path(__file__).resolve().parent


def write(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--task', choices=['PointMaze', 'CartpoleSwingup'], required=True)
    parser.add_argument('--python', required=True)
    parser.add_argument('--gpus', nargs='+', type=int, required=True)
    parser.add_argument('--max-per-gpu', type=int, default=8)
    args = parser.parse_args()
    assert len(set(args.gpus)) == len(args.gpus) and all(g >= 0 for g in args.gpus)
    assert all(os.environ.get(k) in (None, '') for k in ('CUDA_VISIBLE_DEVICES', 'NVIDIA_VISIBLE_DEVICES'))
    status_path = ROOT / 'pipeline_status.json'
    assert not status_path.exists(), 'Fresh pipeline only; preserve existing outputs'
    started = time.time()
    manifest_sha = hashlib.sha256((ROOT / 'SOURCE_MANIFEST.json').read_bytes()).hexdigest()
    stages = []

    def status(state, phase, pid=None, error=None):
        write(status_path, {'state': state, 'phase': phase, 'task': args.task,
              'pipeline_pid': os.getpid(), 'active_child_pid': pid, 'gpus': args.gpus,
              'formal_expected_training_runs': 64, 'started_at_unix': started,
              'updated_at_unix': time.time(), 'source_manifest_sha256': manifest_sha,
              'stages': stages, 'error': error, 'elapsed_seconds': time.time() - started})

    def run(phase, argv):
        log_path = ROOT / (phase + '.pipeline.log')
        log = log_path.open('xb', buffering=0)
        phase_start = time.time()
        child = subprocess.Popen(argv, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        status('running', phase, child.pid)
        try:
            rc = child.wait()
        finally:
            log.close()
        receipt = {'phase': phase, 'actual_argv': argv, 'actual_pid': child.pid,
                   'exit_code': rc, 'actual_wait_reaped': True,
                   'started_at_unix': phase_start, 'finished_at_unix': time.time(),
                   'log': str(log_path), 'automatic_retry': False}
        write(ROOT / (phase + '.execution.json'), receipt)
        stages.append(receipt)
        if rc:
            raise RuntimeError({'phase': phase, 'exit_code': rc, 'log': str(log_path)})

    semantic = ROOT / ('SEMANTIC_' + args.task + '.json')
    smoke = ROOT / ('smoke_' + args.task)
    formal = ROOT / ('formal_' + args.task)
    try:
        run('semantic', [args.python, '-B', str(ROOT / 'env_source/semantic_audit.py'),
             '--task', args.task, '--device', 'cuda:' + str(args.gpus[0]), '--output', str(semantic)])
        proof = json.loads(semantic.read_text())
        assert proof['state'] == 'passed' and proof['task'] == args.task
        assert proof['gpu']['state'] == 'passed'
        common = ['--task', args.task, '--python', args.python, '--gpus', *map(str, args.gpus),
                  '--semantic-proof', str(semantic), '--max-per-gpu', str(args.max_per_gpu)]
        run('smoke', [args.python, '-B', str(ROOT / 'run_matrix.py'), '--phase', 'smoke',
             '--out', str(smoke), *common])
        gates = json.loads((smoke / 'SMOKE_RESULTS.json').read_text())
        assert gates['state'] == 'passed' and gates['training_runs'] == 16 * len(args.gpus)
        run('formal', [args.python, '-B', str(ROOT / 'run_matrix.py'), '--phase', 'formal',
             '--out', str(formal), '--smoke-root', str(smoke), *common])
        status('completed', 'terminal')
    except BaseException as exc:
        status('failed', stages[-1]['phase'] if stages else 'semantic',
               error={'reason': repr(exc), 'traceback': traceback.format_exc()})
        raise


if __name__ == '__main__':
    main()
