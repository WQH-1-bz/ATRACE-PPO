"""Native single-GPU operational recovery; never calls original queue main."""
import copy
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

import gpu1_contract as c


def main():
    assert c.ROOT == c.NATIVE_ROOT and 'CUDA_VISIBLE_DEVICES' not in os.environ
    lock = (c.ROOT / 'COORDINATOR.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not (c.ROOT / 'suite_status.json').exists(), 'existing queue may not be restarted'
    manifest = c.load_manifest()
    engineering = c.validate_receipts(manifest)
    receipt_hashes = c.check_prelaunch_receipts()
    c.verify_failed_v1_guard(require_initial=True)
    preflight = c.read(c.ROOT / 'PARENT_NATIVE_PREFLIGHT_VERIFIED.json')
    assert preflight['state'] == 'passed' and preflight['source_manifest_sha256'] == c.sha(c.ROOT / 'MANIFEST.json')
    assert preflight['admission_receipt_hashes'] == receipt_hashes
    costs = preflight['interrupted_costs']
    c.verify_interrupted_protected(costs)
    jobs = copy.deepcopy(c.read(c.ROOT / 'TASK_PLAN.json')['jobs'])
    r = c.load_original()
    torch = r.torch
    torch.cuda.set_device(1)
    torch.use_deterministic_algorithms(True)
    torch.set_num_threads(1)
    r.check_sources()
    before = r.verify_protected()
    env = dict(r.ENV)
    assert 'CUDA_VISIBLE_DEVICES' not in env
    for job in jobs:
        assert r.command(job) == job['planned_command']
    coordinator = c.inspect_identity(os.getpid())
    assert coordinator is not None and coordinator['cuda_visible_devices'] is None
    expected_command = [str(c.ORIGINAL_ROOT / '.venv/bin/python'), str(c.ROOT / 'run_gpu1.py')]
    assert coordinator['command'] == expected_command
    active, peaks = {}, {}
    reservation, allocator_peak, coordinator_physical_peak = c.FLOOR_MIB, 0, 0
    active_helper, failure, started = None, None, time.time()
    latest_snapshot = c.snapshot()
    helper_history = []
    initial_allocations = latest_snapshot['allocations']

    def running_jobs():
        return [j for j in jobs if j['state'] == 'running']

    def measure():
        nonlocal reservation, allocator_peak, coordinator_physical_peak, latest_snapshot
        latest_snapshot = c.snapshot()
        running = running_jobs()
        pids = [j['pid'] for j in running] + [os.getpid()]
        if active_helper is not None:
            pids.append(active_helper['pid'])
        c.assert_gpu1_allocations(pids, latest_snapshot)
        memory = latest_snapshot['gpu1_pid_memory_mib']
        for j in running:
            c.check_identity(j, c.inspect_identity(j['pid'], expected_start_ticks=j['start_ticks']))
            peaks[j['id']] = max(peaks.get(j['id'], 0), memory.get(j['pid'], 0))
        if active_helper is not None:
            active_helper['sampled_peak_mib'] = max(active_helper.get('sampled_peak_mib', 0), memory.get(active_helper['pid'], 0))
        coordinator_physical_peak = max(coordinator_physical_peak, memory.get(os.getpid(), 0))
        allocator_peak = max(allocator_peak, torch.cuda.max_memory_reserved(1))
        reservation = c.reservation_mib(reservation, peaks.values(), [allocator_peak / 1024**2])
        return latest_snapshot['cards'][1]['free_mib'], memory

    def status(state):
        running = running_jobs()
        memory = latest_snapshot['gpu1_pid_memory_mib']
        value = {'state': state, 'task': 'Swimmer', 'total': 16, 'physical_gpus': [1],
                 'completed_count': sum(j['state'] == 'completed' for j in jobs),
                 'pending_count': sum(j['state'] == 'pending' for j in jobs),
                 'jobs': jobs, 'failure': failure, 'engineering_gate': engineering,
                 'active': {j['id']: {'pid': j['pid'], 'start_ticks': j['start_ticks'],
                                     'ownership': j['ownership'], 'gpu': 1} for j in running},
                 'active_helper': active_helper, 'helper_history': helper_history,
                 'reservation_mib': reservation, 'headroom_mib': c.HEADROOM_MIB,
                 'initializing_deficit_mib': c.initializing_deficit(running, memory, reservation),
                 'sampled_process_peak_mib': peaks,
                 'coordinator_allocator_peak_reserved_bytes_gpu1': allocator_peak,
                 'coordinator_physical_peak_mib_gpu1': coordinator_physical_peak,
                 'latest_gpu_snapshot': latest_snapshot, 'initial_allocations': initial_allocations,
                 'coordinator_pid': coordinator['pid'], 'coordinator_start_ticks': coordinator['start_ticks'],
                 'coordinator_command': coordinator['command'], 'elapsed_seconds': time.time() - started,
                 'source_manifest_sha256': c.sha(c.ROOT / 'MANIFEST.json'),
                 'interrupted_costs_sha256': c.sha(c.ROOT / 'INTERRUPTED_OPERATIONAL_COSTS.json'),
                 'partial_scores_in_final_analysis': False, 'retry': False}
        c.validate_state(value)
        c.write(c.ROOT / 'suite_status.json', value)

    def wait_helper_capacity():
        while True:
            free, memory = measure()
            deficit = c.initializing_deficit(running_jobs(), memory, reservation)
            if free >= reservation + c.HEADROOM_MIB + deficit:
                return
            status('waiting_for_helper_memory')
            time.sleep(1)

    def checkpoint_stress(job):
        nonlocal active_helper, reservation
        wait_helper_capacity()
        command = [str(c.ORIGINAL_ROOT / '.venv/bin/python'), str(c.ROOT / 'stress_checkpoint_gpu1.py'),
                   '--job-path', job['path'], '--device', 'cuda:1']
        log = c.ROOT / (job['id'] + '.stress.log')
        with log.open('x') as stream:
            process = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT, env=env, cwd=c.ROOT)
            identity = c.inspect_identity(process.pid)
            if identity is None:
                assert process.poll() is not None, 'Initial helper exit needs actual owned Popen returncode'
                identity = {'pid': process.pid, 'start_ticks': None, 'command': command, 'cuda_visible_devices': None, 'identity_scope': 'Owned helper exited before first identity sample; actual Popen returncode required'}
            active_helper = {**identity, 'device': 'cuda:1', 'gpu': 1, 'job': job['id'],
                             'stage': 'checkpoint_only_stress', 'log': str(log), 'sampled_peak_mib': 0}
            if identity['start_ticks'] is not None:
                c.check_identity({'id': job['id'] + '__stress', 'pid': process.pid,
                                  'start_ticks': identity['start_ticks'], 'command': command}, identity)
            status('verifying')
            while process.poll() is None:
                identity = c.inspect_identity(process.pid, expected_start_ticks=active_helper['start_ticks'])
                if identity is None:
                    assert process.poll() is not None, 'Helper exit observed without actual Popen completion'
                if identity is not None:
                    c.check_identity({'id': job['id'] + '__stress', 'pid': process.pid,
                                      'start_ticks': active_helper['start_ticks'], 'command': command}, identity)
                measure()
                status('verifying')
                time.sleep(.5)
        active_helper.update(returncode=process.returncode, state='completed' if process.returncode == 0 else 'failed')
        helper_history.append(dict(active_helper))
        reservation = c.reservation_mib(reservation, [active_helper['sampled_peak_mib']])
        active_helper = None
        assert process.returncode == 0, ('checkpoint stress failed', job['id'], process.returncode)

    def finish(job):
        nonlocal active_helper, reservation
        job['state'] = 'verifying'
        status('verifying')
        summary = c.completion_gate(job)
        if job['arm'] == 'innovation2':
            action = c.stress_action(job)
            if action == 'reuse_completed_V1':
                c.validate_completed_v1_stress(job)
                helper_history.append({'job': job['id'], 'stage': 'checkpoint_only_stress', 'device': 'cuda:1', 'gpu': 1, 'state': 'completed', 'reused_completed_V1_stress': True, 'original_helper_pid': 2309666, 'returncode': None, 'Popen_returncode_known': False, 'completion_basis': 'Pinned actual passed side artifacts and original source-native verification; no V1 helper returncode inferred'})
            else:
                assert action == 'new_once'
                checkpoint_stress(job)
        wait_helper_capacity()
        active_helper = {**coordinator, 'device': 'cuda:1', 'gpu': 1, 'job': job['id'],
                         'stage': 'source_native_scientific_verification', 'sampled_peak_mib': 0}
        status('verifying')
        job['metrics'] = r.verify(job)
        measure()
        helper_history.append({**active_helper, 'state': 'completed', 'returncode': None,
                               'in_process_verification': True})
        active_helper = None
        worker_alloc = summary.get('peak_torch_memory_bytes', 0) / 1024**2
        stress_alloc = (c.read(Path(job['path']) / 'checkpoint_stress_result.json').get('peak_torch_memory_reserved_bytes', 0) / 1024**2
                        if job['arm'] == 'innovation2' else 0)
        reservation = c.reservation_mib(reservation, peaks.values(), [worker_alloc, stress_alloc, allocator_peak / 1024**2])
        job['completion_evidence'] = {'source_native_verified': True, 'complete_budget': c.BUDGET,
                                      'trainer_pid_not_live': c.inspect_identity(job['pid'], expected_start_ticks=job['start_ticks']) is None,
                                      'exitcode_known': job['ownership'] == 'own'}
        job['state'] = 'completed'
        r.check_sources()
        r.verify_protected()
        c.verify_interrupted_protected(costs)
        c.verify_failed_v1_guard()

    def reap():
        for job in jobs:
            if job['state'] != 'running':
                continue
            if job['ownership'] == 'external':
                actual = c.inspect_identity(job['pid'], expected_start_ticks=job['start_ticks'])
                if c.check_identity(job, actual):
                    continue
                # No Popen/returncode is fabricated for adopted external workers.
                assert job['returncode'] is None
                finish(job)
            else:
                process, stream = active[job['id']]
                code = process.poll()
                if code is None:
                    c.check_identity(job, c.inspect_identity(job['pid'], expected_start_ticks=job['start_ticks']))
                    continue
                stream.close()
                del active[job['id']]
                job['returncode'] = code
                if code != 0:
                    job['state'] = 'failed'
                    raise RuntimeError('Worker failed ' + job['id'] + ': ' + str(code))
                finish(job)

    def launch(job):
        free = latest_snapshot['cards'][1]['free_mib']
        memory = latest_snapshot['gpu1_pid_memory_mib']
        job['admission_evidence'] = {'physical_gpu': 1, 'free_mib': free, 'reservation_mib': reservation,
                                     'headroom_mib': c.HEADROOM_MIB, 'running_count_before': len(running_jobs()),
                                     'initializing_deficit_mib': c.initializing_deficit(running_jobs(), memory, reservation),
                                     'gpu_snapshot': latest_snapshot, 'no_duplicate_output': not Path(job['path']).exists()}
        assert free >= reservation + c.HEADROOM_MIB + job['admission_evidence']['initializing_deficit_mib']
        c.claim_start(job, output_exists=Path(job['path']).exists())
        # Persist the claimed identity before Popen; a failed launch cannot be retried.
        status('running')
        stream = (c.ROOT / (job['id'] + '.log')).open('x')
        command = r.command(job)
        process = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT, env=env, cwd=c.ORIGINAL_ROOT)
        identity = c.inspect_identity(process.pid)
        assert identity is not None, ('trainer exited during startup', job['id'], process.poll())
        job.update(state='running', pid=process.pid, start_ticks=identity['start_ticks'], command=command,
                   returncode=None, log=str(c.ROOT / (job['id'] + '.log')))
        active[job['id']] = (process, stream)
        c.check_identity(job, identity)
        status('running')

    try:
        c.write(c.ROOT / 'INTERRUPTED_OPERATIONAL_COSTS.json', costs)
        (c.ROOT / 'runs').mkdir(exist_ok=True)
        # Record all sixteen identities and provenance before any new worker launch.
        status('adopting')
        for job in jobs:
            if job['ownership'] == 'external':
                actual = c.inspect_identity(job['pid'], expected_start_ticks=job['start_ticks'])
                if actual is not None:
                    c.check_identity(job, actual)
                else:
                    finish(job)
        measure()
        status('running')
        while not all(j['state'] == 'completed' for j in jobs):
            reap()
            free, memory = measure()
            for job in jobs:
                if job['ownership'] == 'own' and c.can_admit(job, running_jobs(), free, memory, reservation):
                    launch(job)
                    free, memory = measure()
            status('running')
            time.sleep(1)
        r.check_sources()
        protected = r.verify_protected()
        c.verify_interrupted_protected(costs)
        c.verify_failed_v1_guard()
        c.write(c.ROOT / 'ANALYSIS.json', r.analyze(jobs))
        c.write(c.ROOT / 'PROTECTED_AFTER.json', {'before': before, 'after': protected})
        status('completed')
    except BaseException:
        failure = {'state': 'failed', 'traceback': traceback.format_exc(), 'new_admissions_stopped': True,
                   'active_workers_preserved': True, 'retry': False}
        c.write(c.ROOT / 'FAILURE.json', failure)
        status('failed')
        raise


if __name__ == '__main__':
    main()
