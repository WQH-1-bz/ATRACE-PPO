"""Standard-library queue contracts. Importing this file never imports Torch."""
import ast
import copy
import csv
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
from datetime import datetime, timezone

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
NATIVE_ROOT = Path('/home/mumu01/ssd3/wch/swimmer_innovation12_gpu1_resume_v2_20261005')
ORIGINAL_ROOT = Path('/home/mumu01/ssd3/wch/swimmer_innovation12_transfer1_8seed_20261005')
FAILED_V1_ROOT = Path('/home/mumu01/ssd3/wch/swimmer_innovation12_gpu1_resume_20261005')
FAILED_V1_MANIFEST_SHA = '3957d0f695f621bf4d29cdbd12406ae6ccc952489a2346a3f79345893637f288'
V1_PRESERVATION_SHA = '514994e3b24b0679a63589a940a7ece2714951703bb9daacc97f0ad567c816b9'
ORIGINAL_MANIFEST_SHA = 'fa783d7f6780ef946eae6295a9da151cd6dad560c48b9d8357aaea03f316fad5'
GPU1_UUID = 'GPU-0fbea1d5-c9c9-392e-5241-f31b8aec2518'
UNIT = 'dpo-swimmer-innovation12-gpu1-resume-v2-20261005.service'
BUDGET = 10027008
ARMS = ('innovation1', 'innovation2')
SEEDS = tuple(range(21, 29))
FLOOR_MIB, SAFETY_MIB, HEADROOM_MIB, MAX_TRAINERS = 5388, 256, 512, 8
INPUT_SHA = {
    'RESTRICTION_REQUEST.json': 'ae991def823968ef0bcf4ed4bf73994767fd05b7f813623114276878436c3ef1',
    'RESTRICTION_APPLIED.json': '5567e34188fd5e0d16f1994a1075723fd75af51b69c6c96b302847aefb50c0e4',
    'ORIGINAL_SUITE_BEFORE_RESTRICTION.json': 'd9dec528f87a15212e3e88af97d39ae1f26e0cda7ff9967f8aeb43c6467fec8d',
}


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            digest.update(chunk)
    return digest.hexdigest()


def write(path, obj):
    path = Path(path)
    tmp = path.with_name(path.name + '.' + str(os.getpid()) + '.tmp')
    with tmp.open('w') as stream:
        stream.write(json.dumps(obj, indent=2, allow_nan=False) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    tmp.replace(path)


def original_command(job, source_path):
    """Execute only the immutable pure command AST; no runtime imports."""
    tree = ast.parse(Path(source_path).read_text())
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'command')
    namespace = {'ROOT': ORIGINAL_ROOT, 'BUDGET': BUDGET, 'SHORT': 524288,
                 'SWITCH': 4980736, 'SHORT_SWITCH': 262144}
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(source_path), 'exec'), namespace)
    return namespace['command'](job)


def validate_plan(jobs):
    assert len(jobs) == 16
    assert len({j['id'] for j in jobs}) == 16
    assert {(j['arm'], j['seed']) for j in jobs} == {(a, s) for a in ARMS for s in SEEDS}
    adopted = {1215403, 1215462, 1215488, 1215504, 1215566}
    assert {j['pid'] for j in jobs if j['ownership'] == 'external'} == adopted
    assert sum(j['origin'] == 'interrupted_restart_from_zero' for j in jobs) == 10
    assert sum(j['origin'] == 'original_unstarted' for j in jobs) == 1
    for j in jobs:
        assert j['id'] == j['arm'] + '__seed' + str(j['seed']) and j['gpu'] == 1
        cmd = j['planned_command']
        assert cmd[cmd.index('--device') + 1] == 'cuda:1'
        assert cmd[cmd.index('--out') + 1] == j['path']
        assert cmd[cmd.index('--steps') + 1] == str(BUDGET)
        if j['ownership'] == 'external':
            assert j['origin'] == 'adopted_without_restart' and j['returncode'] is None
            assert j['path'] == str(ORIGINAL_ROOT / 'runs' / j['id'])
            assert j['command'] == cmd and str(j['start_ticks']).isdigit()
        else:
            assert j['ownership'] == 'own' and j['path'] == str(NATIVE_ROOT / 'runs' / j['id'])
            if j['origin'] == 'interrupted_restart_from_zero':
                assert j['interrupted_attempt']['gpu'] in (0, 2)
                assert j['interrupted_attempt']['exact_resume_possible'] is False
    return jobs


def load_manifest(require_frozen=True):
    manifest = read(ROOT / 'MANIFEST.json')
    assert manifest['state'] == 'READY_source_only' and manifest['physical_gpus'] == [1]
    assert manifest['original_manifest_sha256'] == ORIGINAL_MANIFEST_SHA
    assert manifest['native_root'] == str(NATIVE_ROOT) and manifest['service'] == UNIT
    assert manifest['failed_V1_manifest_sha256'] == FAILED_V1_MANIFEST_SHA
    assert manifest['failed_V1_preservation_receipt_sha256'] == V1_PRESERVATION_SHA
    assert manifest['native_training_launched_by_builder'] is False
    for name, digest in manifest['bundle_hashes'].items():
        path = ROOT / name
        assert sha(path) == digest, ('bundle mutation', name)
        if require_frozen:
            assert not (path.stat().st_mode & 0o222), ('bundle not frozen', name)
    if require_frozen:
        assert (ROOT / 'MANIFEST.sha256').read_text().strip() == sha(ROOT / 'MANIFEST.json')
        assert not ((ROOT / 'MANIFEST.json').stat().st_mode & 0o222)
    validate_plan(read(ROOT / 'TASK_PLAN.json')['jobs'])
    return manifest


def validate_receipts(manifest):
    for name, digest in INPUT_SHA.items():
        assert sha(ROOT / 'inputs' / name) == digest
    for name, digest in manifest['input_hashes'].items():
        assert sha(ROOT / name) == digest
    request = read(ROOT / 'inputs/RESTRICTION_REQUEST.json')
    applied = read(ROOT / 'inputs/RESTRICTION_APPLIED.json')
    old = read(ROOT / 'inputs/ORIGINAL_SUITE_BEFORE_RESTRICTION.json')
    assert request['original_suite_sha256'] == INPUT_SHA['ORIGINAL_SUITE_BEFORE_RESTRICTION.json']
    assert applied['state'] == 'restriction_applied' and applied['coordinator_stopped']
    assert applied['workers_stopped_count'] == 10 and applied['preserved_gpu1_workers_count'] == 5
    assert applied['targeted_live_workers_after'] == [] and applied['files_deleted'] == 0
    assert not applied['original_sources_edited'] and old['engineering_gate']
    assert old['reservation_mib'] == FLOOR_MIB
    proof = read(ROOT / 'inputs/PARENT_FORMAL_STARTUP_VERIFIED.json')
    assert proof['state'] == 'passed' and proof['manifest_sha256'] == ORIGINAL_MANIFEST_SHA
    assert proof['strict_shorts_completed'] == 6 and proof['formal_total'] == 16
    for name, digest in proof['archived_proofs'].items():
        assert sha(ROOT / 'inputs/native_startup' / name) == digest
    parent = read(ROOT / 'inputs/native_startup/PARENT_VERIFIED_startup.json')
    native = read(ROOT / 'inputs/native_startup/NATIVE_VERIFIED_startup.json')
    startup = read(ROOT / 'inputs/native_startup/suite_status.json')
    assert parent['state'] == native['state'] == 'passed'
    assert parent['manifest_sha256'] == native['source_manifest_sha256'] == ORIGINAL_MANIFEST_SHA
    assert native['engineering_short_count'] == 6 and startup['engineering_gate']
    assert len(startup['smoke_jobs']) == 6 and all(j['state'] == 'completed' for j in startup['smoke_jobs'])
    return {'state': 'passed', 'reused_engineering_shorts': 6, 'fresh_short_execution': False,
            'original_manifest_sha256': ORIGINAL_MANIFEST_SHA,
            'parent_formal_startup_sha256': sha(ROOT / 'inputs/PARENT_FORMAL_STARTUP_VERIFIED.json')}


def load_original():
    """Native-only import; preserve every original module ROOT and function."""
    assert ROOT == NATIVE_ROOT, ('native root required', ROOT)
    assert sha(ORIGINAL_ROOT / 'MANIFEST.json') == ORIGINAL_MANIFEST_SHA
    sys.path.insert(0, str(ORIGINAL_ROOT))
    module = importlib.import_module('run_transfer')
    assert module.ROOT == ORIGINAL_ROOT and module.ncs.ROOT == ORIGINAL_ROOT and module.i2.ROOT == ORIGINAL_ROOT
    return module


class IdentityUnavailable(RuntimeError):
    pass


def inspect_identity(pid, reader=None, pause=time.sleep, clock=time.monotonic, expected_start_ticks=None):
    """Read-only identity observation; exit evidence differs from live access failure."""
    assert type(pid) is int and pid > 0
    folder = Path('/proc') / str(pid)
    if reader is None:
        reader = lambda name: (folder / name).read_bytes()
    expected_ticks = str(expected_start_ticks) if expected_start_ticks is not None else None
    assert expected_ticks is None or expected_ticks.isdigit()
    deadline, expected_command = clock() + .99, None

    def stat():
        raw = reader('stat').decode()
        fields = raw[raw.rfind(')') + 2:].split()
        assert len(fields) >= 20 and fields[19].isdigit(), 'Malformed /proc/stat'
        return fields[0], fields[19]

    def same_process(state, ticks):
        if expected_ticks is not None:
            assert ticks == expected_ticks, ('PID reuse during identity observation', pid)
        return state in ('Z', 'X')

    def argv():
        raw = reader('cmdline').rstrip(b'\0')
        return [part.decode() for part in raw.split(b'\0')] if raw else []

    while True:
        try:
            state, ticks = stat()
            if same_process(state, ticks):
                return None
            if expected_ticks is None:
                expected_ticks = ticks
            command = argv()
            if not command:
                raise IdentityUnavailable('Live process has empty argv; exit not proven')
            if expected_command is not None:
                assert command == expected_command, ('argv mutation during identity observation', pid)
            expected_command = command
            env = reader('environ').split(b'\0')
            state, ticks = stat()
            if same_process(state, ticks):
                return None
            final_command = argv()
            if not final_command:
                raise IdentityUnavailable('Empty final argv; exit not proven')
            assert final_command == expected_command, ('argv mutation during identity observation', pid)
            state, ticks = stat()
            if same_process(state, ticks):
                return None
            return {'pid': pid, 'start_ticks': ticks, 'command': command,
                    'cuda_visible_devices': next((v.split(b'=', 1)[1].decode() for v in env
                                                  if v.startswith(b'CUDA_VISIBLE_DEVICES=')), None)}
        except (PermissionError, FileNotFoundError, ProcessLookupError, IdentityUnavailable) as error:
            # /proc/environ can become unreadable while the same child exits.
            # Re-read state/starttick/argv; never equate a live denial with exit.
            try:
                state, ticks = stat()
            except (FileNotFoundError, ProcessLookupError):
                return None
            except PermissionError:
                pass  # Nothing proves exit; bounded retry then hard failure.
            else:
                if same_process(state, ticks):
                    return None
                if expected_ticks is None:
                    expected_ticks = ticks
                try:
                    command = argv()
                except (PermissionError, FileNotFoundError, ProcessLookupError):
                    command = None
                if command:
                    if expected_command is not None:
                        assert command == expected_command, ('argv mutation after access failure', pid)
                    expected_command = command
            if clock() >= deadline:
                raise error
            pause(.03)


def check_identity(job, actual):
    if actual is None:
        return False
    assert actual['pid'] == job['pid'] and str(actual['start_ticks']) == str(job['start_ticks']), ('PID reuse', job['id'])
    expected_command = job['command'] if 'command' in job else job['planned_command']
    assert actual['command'] == expected_command, ('argv mutation', job['id'])
    assert actual['cuda_visible_devices'] is None, ('GPU masking forbidden', job['id'])
    return True


def snapshot():
    raw = subprocess.check_output(['nvidia-smi', '--query-gpu=index,uuid,memory.free,memory.total',
                                   '--format=csv,noheader,nounits'], text=True, timeout=15)
    cards = {}
    for line in raw.strip().splitlines():
        index, uuid, free, total = [v.strip() for v in line.split(',')]
        cards[int(index)] = {'uuid': uuid, 'free_mib': int(free), 'total_mib': int(total)}
    assert cards[1]['uuid'] == GPU1_UUID
    raw = subprocess.check_output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid,used_gpu_memory',
                                   '--format=csv,noheader,nounits'], text=True, timeout=15)
    allocations = []
    for line in raw.strip().splitlines():
        if not line.strip():
            continue
        uuid, pid, used = [v.strip() for v in line.split(',')]
        allocations.append({'gpu_uuid': uuid, 'pid': int(pid), 'used_mib': int(used)})
    return {'cards': cards, 'allocations': allocations,
            'gpu1_pid_memory_mib': {row['pid']: row['used_mib'] for row in allocations if row['gpu_uuid'] == GPU1_UUID}}


def assert_gpu1_allocations(pids, snap, require_context=()):
    selected = [row for row in snap['allocations'] if row['pid'] in set(pids)]
    assert all(row['gpu_uuid'] == GPU1_UUID for row in selected), ('owned allocation on prohibited GPU', selected)
    present = {row['pid'] for row in selected}
    assert set(require_context) <= present, ('required GPU1 context missing', set(require_context) - present)
    return selected


def reservation_mib(current, physical_peaks=(), allocator_peaks=()):
    return max(FLOOR_MIB, current, math.ceil(max([0, *physical_peaks, *allocator_peaks]) + SAFETY_MIB))


def initializing_deficit(running, memory, reservation):
    return sum(max(0, reservation - memory.get(j['pid'], 0)) for j in running)


def can_admit(job, running, free_mib, memory, reservation):
    assert job['gpu'] == 1 and job['ownership'] == 'own'
    return (job['state'] == 'pending' and len(running) < MAX_TRAINERS
            and free_mib >= reservation + HEADROOM_MIB + initializing_deficit(running, memory, reservation))


def claim_start(job, output_exists=False):
    assert job['ownership'] == 'own' and job['state'] == 'pending'
    assert 'pid' not in job and not output_exists, ('duplicate start', job['id'])
    job['state'] = 'launching'


def completion_gate(job):
    p = Path(job['path'])
    summary, status, config = [read(p / name) for name in ('summary.json', 'status.json', 'config.json')]
    assert summary == status and summary['state'] == 'completed' and summary['reload_check'] == 'passed'
    assert summary['steps'] == BUDGET and config['steps'] == config['effective_steps'] == BUDGET
    assert config['seed'] == job['seed'] and config['task'].startswith('Swimmer')
    assert config['device'] == summary['device'] == summary['physics_device'] == 'cuda:1'
    assert (p / 'latest.pt').is_file()
    if job['ownership'] == 'external':
        assert job['returncode'] is None
        assert inspect_identity(job['pid'], expected_start_ticks=job['start_ticks']) is None, ('external trainer still live or PID reused', job['id'])
    else:
        assert job['returncode'] == 0
    return summary


def validate_state(state):
    jobs = state['jobs']
    validate_plan(jobs)
    assert state['total'] == 16 and state['physical_gpus'] == [1]
    assert state['completed_count'] == sum(j['state'] == 'completed' for j in jobs)
    assert state['pending_count'] == sum(j['state'] == 'pending' for j in jobs)
    assert state['reservation_mib'] >= FLOOR_MIB
    for j in jobs:
        assert j['state'] in ('pending', 'launching', 'running', 'verifying', 'completed', 'failed')
        if j['ownership'] == 'external':
            assert j['returncode'] is None
        if j['state'] == 'pending':
            assert j['ownership'] == 'own' and 'pid' not in j
        if j['state'] in ('running', 'verifying', 'completed'):
            assert 'pid' in j and 'start_ticks' in j and j['command'] == j['planned_command']
        if j['state'] == 'completed':
            assert j['metrics']['steps'] == BUDGET
            if j['ownership'] == 'own':
                assert j['returncode'] == 0
        if 'admission_evidence' in j:
            evidence = j['admission_evidence']
            assert j['ownership'] == 'own' and evidence['physical_gpu'] == 1
            assert evidence['reservation_mib'] >= FLOOR_MIB and evidence['headroom_mib'] == HEADROOM_MIB
            assert evidence['running_count_before'] < MAX_TRAINERS and evidence['no_duplicate_output']
            assert evidence['free_mib'] >= evidence['reservation_mib'] + HEADROOM_MIB + evidence['initializing_deficit_mib']
    assert len([j for j in jobs if j['state'] in ('launching', 'running')]) <= MAX_TRAINERS
    assert state['active_helper'] is None or state['active_helper']['device'] == 'cuda:1'
    if 'latest_gpu_snapshot' in state:
        memory = {int(pid): used for pid, used in state['latest_gpu_snapshot']['gpu1_pid_memory_mib'].items()}
        running = [j for j in jobs if j['state'] == 'running']
        assert state['initializing_deficit_mib'] == initializing_deficit(running, memory, state['reservation_mib'])
        assert state['reservation_mib'] >= reservation_mib(
            FLOOR_MIB, state['sampled_process_peak_mib'].values(),
            [state['coordinator_allocator_peak_reserved_bytes_gpu1'] / 1024**2])
    return state


def timestamp(value):
    """Accept the actual get_goal epoch schema and timezone-aware ISO receipts."""
    if type(value) in (int, float):
        assert math.isfinite(value) and value > 0
        return float(value) / 1000 if value > 100000000000 else float(value)
    assert isinstance(value, str)
    moment = datetime.fromisoformat(value.replace('Z', '+00:00'))
    assert moment.tzinfo is not None
    return moment.timestamp()


def check_prelaunch_receipts(max_age_seconds=600):
    digest = sha(ROOT / 'MANIFEST.json')
    review = read(ROOT / 'PARENT_REVIEW_AUTHORIZATION.json')
    assert review['state'] == 'approved' and review['source_manifest_sha256'] == digest
    assert review['independent_source_review_passed'] and review['native_admission_authorized']
    luna = read(ROOT / 'PARENT_LUNA_ACTIVE.json')
    assert luna['state'] == 'active' and luna['source_manifest_sha256'] == digest
    assert luna['monitor_agent_id'] and luna['active_goal_id'] and luna['initial_snapshot']
    assert luna['raw_goal_sha256'] == sha(ROOT / 'PARENT_LUNA_RAW_GOAL.json')
    assert luna['raw_initial_snapshot_sha256'] == sha(ROOT / 'PARENT_LUNA_RAW_INITIAL_SNAPSHOT.json')
    goal = read(ROOT / 'PARENT_LUNA_RAW_GOAL.json')['goal']
    assert goal['status'].lower() == 'active' and goal['threadId'] == luna['active_goal_id']
    assert str(NATIVE_ROOT) in goal['objective'] and UNIT in goal['objective']
    initial = read(ROOT / 'PARENT_LUNA_RAW_INITIAL_SNAPSHOT.json')
    assert initial['native_root'] == str(NATIVE_ROOT) and initial['unit'] == UNIT
    assert initial['source_manifest_sha256'] == digest and initial['physical_gpus'] == [1]
    assert initial['actual_evidence']
    moment = timestamp(luna['checked_utc'])
    assert 0 <= datetime.now(timezone.utc).timestamp() - moment <= max_age_seconds
    created, observed = timestamp(goal['createdAt']), timestamp(initial['checked_utc'])
    assert -30 <= moment - created <= max_age_seconds
    assert abs(moment - observed) <= max_age_seconds
    return {'review_sha256': sha(ROOT / 'PARENT_REVIEW_AUTHORIZATION.json'),
            'active_luna_sha256': sha(ROOT / 'PARENT_LUNA_ACTIVE.json'),
            'raw_goal_sha256': sha(ROOT / 'PARENT_LUNA_RAW_GOAL.json'),
            'raw_initial_snapshot_sha256': sha(ROOT / 'PARENT_LUNA_RAW_INITIAL_SNAPSHOT.json')}


def v1_preservation():
    path = ROOT / 'inputs/PARENT_V1_PRESERVATION_AND_STRESS.json'
    assert sha(path) == V1_PRESERVATION_SHA
    record = read(path)
    assert record['state'] == 'recorded_failed_v1_preserved_actual_side_artifacts'
    assert record['v1_root'] == str(FAILED_V1_ROOT) and record['v1_manifest_sha256'] == FAILED_V1_MANIFEST_SHA
    assert record['v1_new_training_jobs_started'] == 0 and record['old5_training_paths_preserved'] is True
    assert len(record['v1_file_hashes']) == 33
    return record


def verify_admission_binding(hashes):
    """Preserve admitted receipts without re-aging a legitimate long queue."""
    names = {'review_sha256': 'PARENT_REVIEW_AUTHORIZATION.json',
             'active_luna_sha256': 'PARENT_LUNA_ACTIVE.json',
             'raw_goal_sha256': 'PARENT_LUNA_RAW_GOAL.json',
             'raw_initial_snapshot_sha256': 'PARENT_LUNA_RAW_INITIAL_SNAPSHOT.json'}
    assert set(hashes) == set(names)
    for key, name in names.items():
        assert hashes[key] == sha(ROOT / name), ('Admission evidence changed', name)


def validate_stress_reuse_values(job, record, stress, result):
    """Strict stdlib saved-output schema; original r.verify remains native proof."""
    assert job['id'] == 'innovation2__seed23' and job['ownership'] == 'external'
    expected = record['stress']['23']
    assert job['path'] == expected['path'] == str(ORIGINAL_ROOT / 'runs/innovation2__seed23')
    assert stress == expected['files']['stress_evaluation.json']['value']
    assert result == expected['files']['checkpoint_stress_result.json']['value']
    conditions = [('none', 0.), ('gaussian', .1), ('gaussian', .15), ('gaussian', .3),
                  ('multiplicative', .2), ('multiplicative', .3)]
    assert len(stress) == 6 and [(row['mode'], row['scale']) for row in stress] == conditions
    for row in stress:
        assert set(row) == {'mode', 'scale', 'returns', 'lengths', 'mean', 'std'}
        assert len(row['returns']) == len(row['lengths']) == 32
        assert all(type(v) in (int, float) and math.isfinite(v) for v in row['returns'])
        assert all(type(v) is int and 1 <= v <= 1000 for v in row['lengths'])
        assert math.isfinite(row['mean']) and math.isfinite(row['std']) and row['std'] >= 0
    assert result['state'] == 'passed' and result['task'] == 'Swimmer' and result['seed'] == 23
    assert result['device'] == 'cuda:1' and result['conditions'] == 6 and result['episodes'] == 192
    for key in ('training_transitions', 'optimizer_steps', 'optimizer_constructions',
                'observation_normalizer_updates', 'reward_normalizer_updates'):
        assert type(result[key]) is int and result[key] == 0
    assert all(result[key] is True for key in ('model_unchanged', 'normalizer_unchanged',
        'training_files_unchanged', 'source_api_ast_equal'))
    original = read(ROOT / 'inputs/V1_MANIFEST.json')
    assert result['helper_sha256'] == record['helper_sha256'] == original['stress_adapter_sha256']
    assert result['checkpoint_sha256'] == expected['checkpoint_sha256'] == result['protected_training_artifacts']['latest.pt']
    assert result['stress_sha256'] == expected['files']['stress_evaluation.json']['sha256']
    assert len(result['source_hashes']) == 18 and result['source_hashes'] == original['unchanged_original_source_hashes']['innovation2']
    assert result['evaluation_transitions'] == sum(sum(row['lengths']) for row in stress)
    return {'state': 'passed_saved_V1_stress', 'job': job['id'], 'reused': True,
            'original_helper_returncode': None, 'Popen_returncode_known': False,
            'new_stress_execution': False, 'episodes': 192}


def validate_completed_v1_stress(job):
    record = v1_preservation()
    expected = record['stress']['23'];path = Path(job['path'])
    for name, info in expected['files'].items():
        assert info['exists'] is True and sha(path / name) == info['sha256']
    result = read(path / 'checkpoint_stress_result.json')
    output = validate_stress_reuse_values(job, record, read(path / 'stress_evaluation.json'), result)
    for name, digest in result['protected_training_artifacts'].items():
        assert Path(name).name == name and sha(path / name) == digest
    for name, digest in result['source_hashes'].items():
        assert sha(ORIGINAL_ROOT / 'source_i2' / name) == digest
    return output


def stress_action(job, presence=None):
    present = presence if presence is not None else tuple((Path(job['path']) / name).exists()
        for name in ('stress_evaluation.json', 'checkpoint_stress_result.json'))
    assert len(present) == 2
    if any(present):
        assert all(present), ('Partial stress cannot be overwritten/retried', job['id'])
        assert job['id'] == 'innovation2__seed23' and job['ownership'] == 'external', ('Unexpected existing stress', job['id'])
        return 'reuse_completed_V1'
    assert job['id'] != 'innovation2__seed23', 'Pinned completed V1 stress is missing; no automatic retry'
    return 'new_once'


def verify_failed_v1_guard(require_initial=False):
    record = v1_preservation()
    assert sha(FAILED_V1_ROOT / 'MANIFEST.json') == FAILED_V1_MANIFEST_SHA
    assert {str(path) for path in FAILED_V1_ROOT.rglob('*') if path.is_file()} == set(record['v1_file_hashes'])
    for path, digest in record['v1_file_hashes'].items():
        assert Path(path).is_relative_to(FAILED_V1_ROOT) and sha(path) == digest
    old = read(FAILED_V1_ROOT / 'suite_status.json')
    assert old['state'] == 'failed' and old['failure'] and old['pending_count'] == 11
    assert inspect_identity(2308199, expected_start_ticks=old['coordinator_start_ticks']) is None
    assert inspect_identity(2309666, expected_start_ticks='175184544') is None
    for job in read(FAILED_V1_ROOT / 'TASK_PLAN.json')['jobs']:
        if job['ownership'] == 'own':
            assert not Path(job['path']).exists(), ('V1 new training unexpectedly started', job['id'])
    for job in old['jobs']:
        if job['state'] == 'completed':
            assert job['arm'] == 'innovation1' and job['metrics']['steps'] == BUDGET
            for name, digest in job['metrics']['artifact_hashes'].items():
                assert sha(Path(job['path']) / name) == digest
    plan = read(ROOT / 'TASK_PLAN.json')['jobs']
    job23 = next(job for job in plan if job['id'] == 'innovation2__seed23')
    validate_completed_v1_stress(job23)
    assert sha(Path(record['stress']['26']['path']) / 'latest.pt') == record['stress']['26']['checkpoint_sha256']
    if require_initial:
        for name, info in record['stress']['26']['files'].items():
            assert info == {'exists': False, 'sha256': None, 'value': None}
            assert not (Path(record['stress']['26']['path']) / name).exists()
    return {'state': 'passed', 'failed_V1_files_preserved': 33, 'V1_new_training_jobs': 0,
            'V1_stress23_reuse': True, 'V1_helper_returncode': None,
            'stress26_absence_checked_at_intake_only': require_initial}


def capture_interrupted_costs(jobs):
    rows, protected = [], {}
    for j in jobs:
        if j['origin'] != 'interrupted_restart_from_zero':
            continue
        previous = j['interrupted_attempt']
        assert inspect_identity(previous['pid'], expected_start_ticks=previous.get('start_ticks')) is None, ('stopped PID still present/reused', previous)
        path = Path(previous['path'])
        inventory = {str(p): sha(p) for p in sorted(path.rglob('*')) if p.is_file()}
        assert inventory
        protected.update(inventory)
        status = read(path / 'status.json') if (path / 'status.json').exists() else None
        progress = list(csv.DictReader((path / 'progress.csv').open())) if (path / 'progress.csv').exists() else []
        last = progress[-1] if progress else None
        steps = int(last['steps']) if last is not None else (status.get('steps') if status else None)
        elapsed = float(last['elapsed_seconds']) if last is not None and last.get('elapsed_seconds') else None
        rows.append({'id': j['id'], 'original_path': str(path), 'original_pid': previous['pid'],
                     'status_at_recovery': status, 'artifact_hashes': inventory,
                     'last_recorded_training_steps': steps, 'last_recorded_elapsed_seconds': elapsed,
                     'last_progress_row': last, 'work_observation_is_lower_bound': True,
                     'cost_is_operational_only': True, 'included_in_final_scores': False,
                     'exact_resume_possible': False})
    return {'state': 'captured', 'attempt_count': 10, 'rows': rows, 'protected_files': protected,
            'sum_recorded_interrupted_steps': sum(row['last_recorded_training_steps'] or 0 for row in rows),
            'sum_recorded_interrupted_elapsed_seconds': sum(row['last_recorded_elapsed_seconds'] or 0 for row in rows),
            'partial_scores_in_final_analysis': False}


def verify_interrupted_protected(costs):
    for path, digest in costs['protected_files'].items():
        assert sha(path) == digest, ('interrupted artifact mutation', path)
    return len(costs['protected_files'])
