"""Native parent-owned one-shot admission/startup/terminal verification."""
import argparse
import copy
import json
import os
from pathlib import Path
import subprocess

import gpu1_contract as c


def systemd_unit():
    raw = subprocess.check_output(['systemctl', '--user', 'show', c.UNIT,
                                  '--property=ActiveState,SubState,MainPID,Result,ExecMainStatus,Restart,KillMode,ExecStart'],
                                 text=True, timeout=15)
    value = dict(line.split('=', 1) for line in raw.splitlines() if '=' in line)
    assert value['Restart'] == 'no' and value['KillMode'] == 'process'
    assert str(c.ROOT / 'run_gpu1.py') in value['ExecStart']
    return value


def running_config(job, r):
    path = Path(job['path']) / 'config.json'
    if not path.exists():
        return None
    config = c.read(path)
    assert config['seed'] == job['seed'] and config['device'] == 'cuda:1'
    assert config['determinism'] == r.DET and config['task'].startswith('Swimmer')
    assert config['steps'] == config['effective_steps'] == c.BUDGET
    assert config['xml_sha256'] == r.read(c.ORIGINAL_ROOT / 'RUNTIME_REFERENCE.json')['xml_sha256']
    for key, value in [('num_envs', 1024), ('rollout', 64), ('batch_size', 1024), ('epochs', 10),
                       ('eval_envs', 32), ('eval_every', 262144)]:
        assert config[key] == value
    original_manifest = r.read(c.ORIGINAL_ROOT / 'MANIFEST.json')
    if job['arm'] == 'innovation1':
        assert config['versions'] == original_manifest['runtime_versions']
        assert config['source_sha256'] == original_manifest['source_hashes']['innovation1']
        assert config['algorithm_version'] == 'swimmer_i1_normalized_credit_sensitivity1_v1'
        assert config['lambda_mode'] == 'normalized_credit_sensitivity'
        assert config['fixed_critic_lambda'] == .95 and config['adaptive_start_update'] == 4
        assert config['adaptive_start_steps'] == 0 and not config['adaptive_overlap']
        assert config['fixed_critic_target_design']['audit_updates'] == [4, 5, 153]
        assert config['signal_files'] == r.ncs.signal_names(False)
    else:
        for name, digest in config['source_sha256'].items():
            assert digest == original_manifest['source_hashes']['innovation2'][name]
        assert config['method'] == 'pae' and config['staged_full'] and config['stage_switch_steps'] == 4980736
        assert config['pae_prefix'] == 56 and config['pae_tail'] == config['retained_tail_steps'] == 8
        assert config['initial_lambda'] == .95
        assert config['retained_tail_correction'] and config['retained_tail_diagnostics']
        assert config['retained_td_unclipped'] and config['save_split_trace_audit']
        assert not any(config[key] for key in ('adaptive_kl', 'readiness_boost', 'adaptive_overlap', 'force_pae_overlap'))
    return config


def verify_job_runtime(job, r, completed_numerical=True):
    actual = c.inspect_identity(job['pid'], expected_start_ticks=job['start_ticks'])
    if job['state'] == 'running':
        if actual is None:
            # A legitimate worker may have finished since the last atomic status.
            evidence = c.completion_gate(job) if job['ownership'] == 'external' else None
            assert evidence is not None, ('owned worker exited before status update; rerun one-shot', job['id'])
            return {'state': 'completed_since_snapshot', 'identity': None, 'summary_steps': evidence['steps']}
        c.check_identity(job, actual)
        config = running_config(job, r)
        return {'state': 'running', 'identity': actual, 'config_present': config is not None}
    assert actual is None, ('non-running original PID present/reused', job['id'])
    if job['state'] == 'completed':
        c.completion_gate(job)
        metrics = r.verify(job) if completed_numerical else job['metrics']
        assert metrics == job['metrics'], ('metrics/source-native mismatch', job['id'])
        return {'state': 'completed', 'identity': None, 'actual_returncode': job['returncode'], 'metrics': metrics}
    assert job['state'] == 'verifying'
    c.completion_gate(job)
    return {'state': 'verifying', 'identity': None, 'actual_returncode': job['returncode']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', required=True, choices=('prelaunch', 'startup', 'terminal16'))
    args = parser.parse_args()
    assert c.ROOT == c.NATIVE_ROOT and 'CUDA_VISIBLE_DEVICES' not in os.environ
    manifest = c.load_manifest()
    engineering = c.validate_receipts(manifest)
    admission = c.check_prelaunch_receipts() if args.phase == 'prelaunch' else None
    v1_guard = c.verify_failed_v1_guard(require_initial=args.phase == 'prelaunch')
    r = c.load_original()
    r.torch.cuda.set_device(1)
    r.torch.use_deterministic_algorithms(True)
    r.torch.set_num_threads(1)
    r.check_sources()
    protected_before = r.verify_protected()  # CPU-only control checkpoint/auc path.
    plan = c.read(c.ROOT / 'TASK_PLAN.json')['jobs']
    for job in plan:
        assert job['planned_command'] == r.command(job)
    snap = c.snapshot()
    proof = {'state': 'passed', 'phase': args.phase, 'source_manifest_sha256': c.sha(c.ROOT / 'MANIFEST.json'),
             'original_manifest_sha256': c.ORIGINAL_MANIFEST_SHA, 'reused_engineering_proof': engineering,
             'fresh_short_execution': False, 'physical_gpus': [1], 'actual_snapshot': snap,
             'verifier_pid': os.getpid(), 'verifier_identity': c.inspect_identity(os.getpid())}
    if args.phase == 'prelaunch':
        assert not (c.ROOT / 'suite_status.json').exists(), 'queue already exists'
        old = c.read(c.ROOT / 'inputs/RESTRICTION_REQUEST.json')
        assert c.inspect_identity(old['coordinator_pid']) is None, 'original coordinator still present/reused'
        adopted = {}
        live = []
        for job in plan:
            if job['ownership'] == 'external':
                actual = c.inspect_identity(job['pid'], expected_start_ticks=job['start_ticks'])
                if actual is not None:
                    c.check_identity(job, actual)
                    assert running_config(job, r) is not None, ('adopted config missing', job['id'])
                    live.append(job['pid'])
                    adopted[job['id']] = {'state': 'running', 'identity': actual, 'returncode': None}
                else:
                    summary = c.completion_gate(job)
                    adopted[job['id']] = {'state': 'completed_before_adoption', 'identity': None,
                                           'returncode': None, 'summary_steps': summary['steps']}
            else:
                assert not Path(job['path']).exists() and not (c.ROOT / (job['id'] + '.log')).exists()
        snap = c.snapshot()
        c.assert_gpu1_allocations([*live, os.getpid()], snap, require_context=live)
        costs = c.capture_interrupted_costs(plan)
        proof.update(admission_receipt_hashes=admission, adopted_identities=adopted,
                     interrupted_costs=costs, actual_snapshot=snap,
                     prelaunch_scope='no training launched; source/control CPU checks + owned GPU1 context identity')
        output = c.ROOT / 'PARENT_NATIVE_PREFLIGHT_VERIFIED.json'
    else:
        state = c.validate_state(c.read(c.ROOT / 'suite_status.json'))
        assert state['failure'] is None and state['source_manifest_sha256'] == proof['source_manifest_sha256']
        preflight = c.read(c.ROOT / 'PARENT_NATIVE_PREFLIGHT_VERIFIED.json')
        assert preflight['state'] == 'passed' and preflight['source_manifest_sha256'] == proof['source_manifest_sha256']
        c.verify_admission_binding(preflight['admission_receipt_hashes'])
        c.verify_interrupted_protected(preflight['interrupted_costs'])
        unit = systemd_unit()
        coordinator = {'id': 'coordinator', 'pid': state['coordinator_pid'],
                       'start_ticks': state['coordinator_start_ticks'], 'command': state['coordinator_command']}
        if args.phase == 'startup':
            assert unit['ActiveState'] == 'active' and int(unit['MainPID']) == coordinator['pid']
            assert c.check_identity(coordinator, c.inspect_identity(coordinator['pid'], expected_start_ticks=coordinator['start_ticks']))
        else:
            assert state['state'] == 'completed' and state['completed_count'] == 16
            assert not state['active'] and state['active_helper'] is None
            assert unit['Result'] == 'success' and unit['ExecMainStatus'] == '0'
            assert c.inspect_identity(coordinator['pid'], expected_start_ticks=coordinator['start_ticks']) is None
        identities = {}
        for job in state['jobs']:
            frozen = next(j for j in plan if j['id'] == job['id'])
            for key in ('id', 'arm', 'seed', 'gpu', 'path', 'ownership', 'origin', 'planned_command'):
                assert job[key] == frozen[key], ('task plan mutation', job['id'], key)
            if job['ownership'] == 'external':
                assert job['pid'] == frozen['pid'] and job['start_ticks'] == frozen['start_ticks']
            if job['state'] == 'pending':
                assert args.phase == 'startup' and 'pid' not in job and not Path(job['path']).exists()
                identities[job['id']] = {'state': 'pending'}
            elif job['state'] == 'launching':
                assert args.phase == 'startup' and 'pid' not in job
                identities[job['id']] = {'state': 'launching', 'pid_unavailable': True}
            else:
                identities[job['id']] = verify_job_runtime(job, r)
        helper = state['active_helper']
        helper_pid = []
        if helper is not None:
            assert helper['device'] == 'cuda:1' and helper['gpu'] == 1
            actual = c.inspect_identity(helper['pid'], expected_start_ticks=helper['start_ticks'])
            assert c.check_identity({'id': 'active helper', **helper}, actual)
            assert helper['stage'] in ('checkpoint_only_stress', 'source_native_scientific_verification')
            if helper['stage'] == 'checkpoint_only_stress':
                assert helper['command'][helper['command'].index('--device') + 1] == 'cuda:1'
                assert helper['command'][1] == str(c.ROOT / 'stress_checkpoint_gpu1.py')
            else:
                assert helper['pid'] == coordinator['pid']
            helper_pid = [helper['pid']]
        live_pids = [row['identity']['pid'] for row in identities.values() if row.get('identity')]
        snap = c.snapshot()
        c.assert_gpu1_allocations([*live_pids, *helper_pid, coordinator['pid'], os.getpid()], snap)
        logs = [j['log'] for j in state['jobs'] if 'log' in j] + [h['log'] for h in state['helper_history'] if 'log' in h]
        if helper is not None and 'log' in helper:
            logs.append(helper['log'])
        for name in logs:
            text = Path(name).read_text(errors='replace')
            assert not any(value in text for value in ('Traceback (most recent call last)', 'CUDA out of memory', 'AssertionError')), ('log error', name)
        if args.phase == 'terminal16':
            analysis = r.analyze(state['jobs'])
            assert analysis == c.read(c.ROOT / 'ANALYSIS.json')
            c.write(c.ROOT / 'PARENT_RECOMPUTED_ANALYSIS.json', analysis)
            assert all(j['returncode'] is None for j in state['jobs'] if j['ownership'] == 'external')
            assert all(j['returncode'] == 0 for j in state['jobs'] if j['ownership'] == 'own')
        proof.update(unit=unit, job_identity_verification=identities, active_helper=helper,
                     actual_snapshot=snap, formal_jobs=16,
                     formal_state_counts={s: sum(j['state'] == s for j in state['jobs'])
                                          for s in ('pending', 'launching', 'running', 'verifying', 'completed')},
                     adopted_exitcodes_null=True)
        output = c.ROOT / ('PARENT_VERIFIED_' + args.phase + '.json')
    c.verify_failed_v1_guard()
    r.check_sources()
    proof['protected_before'] = protected_before
    proof['failed_V1_preservation_guard'] = v1_guard
    proof['protected_after'] = r.verify_protected()
    proof['verifier_allocator_peak_reserved_bytes_gpu1'] = r.torch.cuda.max_memory_reserved(1)
    c.assert_gpu1_allocations([os.getpid()], c.snapshot())
    c.write(output, proof)
    print(json.dumps({'state': 'passed', 'phase': args.phase, 'receipt': str(output)}))


if __name__ == '__main__':
    main()
