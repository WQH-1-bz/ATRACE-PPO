"""Source-only input/plan manifest builder; no native imports or actions."""
import argparse
import copy
import difflib
import json
from pathlib import Path
import shutil
import sys

sys.dont_write_bytecode = True
import gpu1_contract as c


def prepare():
    assert not (c.ROOT / 'MANIFEST.json').exists(), 'Frozen version cannot be rebuilt'
    parent = c.ROOT.parent / 'swimmer_gpu1_parent_20261005'
    old_parent = c.ROOT.parent / 'swimmer_innovation12_parent_20261005'
    original = c.ROOT.parent / 'swimmer_innovation12_transfer1_8seed_20261005'
    failed = c.ROOT.parent / 'swimmer_innovation12_gpu1_resume_20261005'
    assert c.sha(original / 'MANIFEST.json') == c.ORIGINAL_MANIFEST_SHA
    assert c.sha(failed / 'MANIFEST.json') == c.FAILED_V1_MANIFEST_SHA
    failed_manifest = c.read(failed / 'MANIFEST.json')
    assert len(failed_manifest['deployment_files']) == 23
    for name in failed_manifest['deployment_files']:
        assert not ((failed / name).stat().st_mode & 0o222)
    for name, digest in failed_manifest['bundle_hashes'].items():
        assert c.sha(failed / name) == digest, ('Immutable V1 source changed', name)
    assert c.sha(parent / 'PARENT_V1_PRESERVATION_AND_STRESS.json') == c.V1_PRESERVATION_SHA
    inputs = c.ROOT / 'inputs'
    inputs.mkdir(exist_ok=True)
    shutil.copyfile(failed / 'MANIFEST.json', inputs / 'V1_MANIFEST.json')
    for name in ('PARENT_V1_PRESERVATION_AND_STRESS.json', 'NATIVE_STARTUP_FAILURE_EVIDENCE.json',
                 'STARTUP_ONESHOT_FAILURE.txt'):
        shutil.copyfile(parent / name, inputs / name)
    c.v1_preservation()
    for name, digest in c.INPUT_SHA.items():
        assert c.sha(parent / name) == digest
        shutil.copyfile(parent / name, inputs / name)
    shutil.copyfile(parent / 'SOURCE_PREPARATION_TASK.md', inputs / 'SOURCE_PREPARATION_TASK.md')
    shutil.copyfile(old_parent / 'PARENT_FORMAL_STARTUP_VERIFIED.json', inputs / 'PARENT_FORMAL_STARTUP_VERIFIED.json')
    (inputs / 'native_startup').mkdir(exist_ok=True)
    for name in ('PARENT_VERIFIED_startup.json', 'NATIVE_VERIFIED_startup.json', 'suite_status.json'):
        shutil.copyfile(old_parent / 'native_startup' / name, inputs / 'native_startup' / name)
    request = c.read(inputs / 'RESTRICTION_REQUEST.json')
    old = c.read(inputs / 'ORIGINAL_SUITE_BEFORE_RESTRICTION.json')
    adopted = {j['id']: j for j in request['preserved_gpu1_workers']}
    stopped = {j['id']: j for j in request['targeted_workers']}
    jobs = []
    for previous in old['jobs']:
        ident = previous['id']
        job = {'id': ident, 'arm': previous['arm'], 'seed': previous['seed'], 'gpu': 1}
        if ident in adopted:
            record = adopted[ident]
            job.update(ownership='external', origin='adopted_without_restart', state='running',
                       path=record['path'], pid=record['pid'], start_ticks=record['start_ticks'],
                       command=record['command'], returncode=None, log=previous['log'],
                       original_identity=copy.deepcopy(record))
        else:
            job.update(ownership='own', state='pending', path=str(c.NATIVE_ROOT / 'runs' / ident))
            if ident in stopped:
                provenance = copy.deepcopy(stopped[ident])
                provenance.update(original_state=previous['state'], interrupted=True,
                                  exact_resume_possible=False, partial_is_scientific_success=False,
                                  partial_scores_in_final_analysis=False, original_log=previous['log'])
                job.update(origin='interrupted_restart_from_zero', interrupted_attempt=provenance)
            else:
                assert ident == 'innovation2__seed28' and previous['state'] == 'pending'
                job.update(origin='original_unstarted', original_pending_path=previous['path'])
        job['planned_command'] = c.original_command(job, original / 'run_transfer.py')
        if ident in adopted:
            assert job['planned_command'] == job['command']
        jobs.append(job)
    c.validate_plan(jobs)
    c.write(c.ROOT / 'TASK_PLAN.json', {'state': 'prospective_source_only', 'jobs': jobs,
                                     'formal_total': 16, 'fresh_output_count': 11, 'adopted_count': 5,
                                     'partial_checkpoints_resumed': False,
                                     'V1_new_training_started': 0, 'old_five_completed_budget_before_V2': True,
                                     'reused_completed_V1_stress': 'innovation2__seed23',
                                     'original_V1_helper_returncode': None})
    c.write(c.ROOT / 'INPUT_HASHES.json', {str(p.relative_to(c.ROOT)): c.sha(p)
                                         for p in sorted(inputs.rglob('*')) if p.is_file()})
    old_source = (original / 'stress_checkpoint.py').read_text().splitlines(keepends=True)
    adapter = (c.ROOT / 'stress_checkpoint_gpu1.py').read_text().splitlines(keepends=True)
    (c.ROOT / 'STRESS_OPERATIONAL_ADAPTER.patch').write_text(''.join(difflib.unified_diff(
        old_source, adapter, fromfile='immutable_original/stress_checkpoint.py', tofile='stress_checkpoint_gpu1.py')))


def freeze():
    assert not (c.ROOT / 'MANIFEST.json').exists(), 'Frozen version cannot be overwritten'
    original = c.ROOT.parent / 'swimmer_innovation12_transfer1_8seed_20261005'
    fixtures = c.read(c.ROOT / 'STDLIB_FIXTURES_VERIFIED.json')
    assert fixtures['state'] == 'passed' and fixtures['native_executed'] is False and fixtures['Torch_imported'] is False
    for name, digest in fixtures['source_hashes'].items():
        assert c.sha(c.ROOT / name) == digest
    files = [p for p in sorted(c.ROOT.rglob('*')) if p.is_file()
             and p.name not in ('MANIFEST.json', 'MANIFEST.sha256') and '__pycache__' not in p.parts]
    manifest = {'state': 'READY_source_only', 'task': 'Swimmer', 'host': 'wch@192.168.5.52',
                'local_root': str(c.ROOT), 'native_root': str(c.NATIVE_ROOT), 'original_root': str(c.ORIGINAL_ROOT),
                'service': c.UNIT, 'physical_gpus': [1], 'CUDA_VISIBLE_DEVICES': 'unset',
                'formal_total': 16, 'arms': list(c.ARMS), 'seeds': list(c.SEEDS), 'formal_budget': c.BUDGET,
                'adopted_count': 5, 'new_count': 11, 'interrupted_zero_restart_count': 10,
                'original_unstarted_count': 1, 'original_manifest_sha256': c.ORIGINAL_MANIFEST_SHA,
                'version': 'operational_recovery_v2', 'failed_V1_root': str(c.FAILED_V1_ROOT),
                'failed_V1_manifest_sha256': c.FAILED_V1_MANIFEST_SHA,
                'failed_V1_preservation_receipt_sha256': c.V1_PRESERVATION_SHA,
                'failed_V1_preserved_file_count': 33, 'failed_V1_fresh_training_started': 0,
                'identity_retry_interval_seconds': .03, 'identity_retry_deadline_seconds': .99,
                'exit_proof': 'same-starttick Z/X or disappeared process; persistent live access failure is fatal',
                'completed_V1_stress_reused_once': 'innovation2__seed23',
                'completed_V1_stress_helper_returncode': None,
                'old_I2_seed26_stress': 'new_once_on_cuda1',
                'unchanged_original_source_hashes': c.read(original / 'MANIFEST.json')['source_hashes'],
                'reservation_floor_mib': c.FLOOR_MIB, 'measured_peak_safety_mib': c.SAFETY_MIB,
                'card_headroom_mib': c.HEADROOM_MIB, 'max_physical_gpu1_trainers': c.MAX_TRAINERS,
                'all_initializing_deficits_charged': True, 'coordinator_verifier_memory_in_actual_free': True,
                'stress_adapter_sha256': c.sha(c.ROOT / 'stress_checkpoint_gpu1.py'),
                'original_stress_helper_sha256': c.sha(original / 'stress_checkpoint.py'),
                'stress_adapter_difference': 'operational old/new output-root allowlist, explicit cuda1 guard, immutable original ROOT, new self-hash binding only',
                'stress_adapter_AST_proof': fixtures['adapter_ast_proof'],
                'source_native_verifier_reused': True, 'source_native_analyze_reused': True,
                'original_main_invoked': False, 'new_engineering_shorts': 0, 'original_engineering_shorts_reused': 6,
                'adopted_exitcodes': None, 'own_exitcodes_actual_Popen': True,
                'all8_paired_seeds_per_arm': True, 'original_control_rows': 64,
                'partial_scores_in_final_analysis': False, 'parameter_or_algorithm_change': False,
                'automatic_retry': False, 'Restart': 'no', 'KillMode': 'process',
                'native_training_launched_by_builder': False, 'Torch_imported_by_builder': False,
                'native_compatibility_claim': False, 'parent_independent_review_authorization_required': True,
                'parent_native_preflight_before_any_admission': True, 'active_Luna_receipt_before_launch': True,
                'input_hashes': c.read(c.ROOT / 'INPUT_HASHES.json'),
                'bundle_hashes': {str(p.relative_to(c.ROOT)): c.sha(p) for p in files},
                'deployment_files': [str(p.relative_to(c.ROOT)) for p in files] + ['MANIFEST.json', 'MANIFEST.sha256'],
                'runtime_receipts_unfrozen': True, 'Walker_frozen_bundles_preserved': True}
    c.write(c.ROOT / 'MANIFEST.json', manifest)
    (c.ROOT / 'MANIFEST.sha256').write_text(c.sha(c.ROOT / 'MANIFEST.json') + '\n')
    for path in [*files, c.ROOT / 'MANIFEST.json', c.ROOT / 'MANIFEST.sha256']:
        path.chmod(0o444)
    c.load_manifest()
    c.validate_receipts(manifest)
    print(json.dumps({'state': 'READY_source_only', 'manifest_sha256': c.sha(c.ROOT / 'MANIFEST.json'),
                      'files': len(manifest['deployment_files']), 'native_executed': False}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--freeze', action='store_true')
    args = parser.parse_args()
    freeze() if args.freeze else prepare()
