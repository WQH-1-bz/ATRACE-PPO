"""Bounded stdlib observer, saved-stress and real-admission schema fixtures."""
import copy
from datetime import datetime, timezone
from pathlib import Path
import tempfile

import gpu1_contract as c


def reject(action, exceptions=(AssertionError,)):
    try:
        action()
    except exceptions:
        return
    raise AssertionError('Invalid operational evidence was accepted')


def stat(state='R', ticks='123'):
    return ('42 (fixture worker) ' + ' '.join([state, *['0'] * 18, ticks]) + '\n').encode()


class Reader:
    def __init__(self, **events):
        self.events = {'stat': [stat()], 'cmdline': [b'python\0worker.py\0--device\0cuda:1\0'],
                       'environ': [b'OMP_NUM_THREADS=1\0']}
        self.events.update(events)
        self.counts, self.elapsed = {}, 0.

    def __call__(self, name):
        index = self.counts.get(name, 0)
        self.counts[name] = index + 1
        value = self.events[name][min(index, len(self.events[name]) - 1)]
        if isinstance(value, BaseException):
            raise value
        return value

    def pause(self, seconds):
        assert seconds == .03
        self.elapsed += seconds

    def observe(self, ticks='123'):
        return c.inspect_identity(42, reader=self, pause=self.pause, clock=lambda: self.elapsed,
                                  expected_start_ticks=ticks)


def identity_checks():
    checks = []
    reader = Reader()
    value = reader.observe()
    assert value['start_ticks'] == '123' and value['cuda_visible_devices'] is None
    assert reader.counts == {'stat': 3, 'cmdline': 2, 'environ': 1}
    checks.append('successful_identity_has_three_stable_stat_and_two_argv_reads')
    for final in (stat('Z'), stat('X'), FileNotFoundError('fixture exited')):
        reader = Reader(stat=[stat(), final], environ=[PermissionError('exit race')])
        assert reader.observe() is None and reader.elapsed == 0
    checks.append('environ_denial_returns_None_only_after_same_tick_Z_X_or_gone')
    reader = Reader(environ=[PermissionError('transient'), b'OMP_NUM_THREADS=1\0'])
    assert reader.observe() == value and reader.elapsed == .03
    checks.append('transient_live_denial_retries_complete_unmasked_identity')
    for reader in (Reader(environ=[PermissionError('live')]),
                   Reader(stat=[PermissionError('unknown')]), Reader(cmdline=[b''])):
        reject(reader.observe, (PermissionError, c.IdentityUnavailable))
        assert .99 <= reader.elapsed <= 1.05 and sum(reader.counts.values()) <= 300
    checks.append('persistent_live_unknown_denial_or_empty_argv_fails_with_bounded_retry')
    for reader in (Reader(stat=[stat('Z', '124')]), Reader(stat=[stat(), stat('R', '124')]),
                   Reader(stat=[stat(), stat(), stat('R', '124')]),
                   Reader(cmdline=[b'python\0worker.py\0', b'python\0different.py\0']),
                   Reader(stat=[stat(), stat('R', '124')], environ=[PermissionError('race')])):
        reject(reader.observe)
    checks.append('initial_exit_retry_and_final_read_PID_reuse_or_argv_mutation_rejected')
    reader = Reader(environ=[b'CUDA_VISIBLE_DEVICES=1\0'])
    masked = reader.observe()
    reject(lambda: c.check_identity({'id': 'fixture', 'pid': 42, 'start_ticks': '123',
                                     'command': masked['command']}, masked))
    reject(Reader(stat=[b'malformed']).observe)
    checks.append('readable_mask_and_malformed_stat_hard_rejected')
    return checks


def stress_checks(jobs):
    checks = []
    record = c.v1_preservation()
    job = next(job for job in jobs if job['id'] == 'innovation2__seed23')
    other = next(job for job in jobs if job['id'] == 'innovation2__seed26')
    saved = record['stress']['23']['files']
    stress, result = saved['stress_evaluation.json']['value'], saved['checkpoint_stress_result.json']['value']
    proof = c.validate_stress_reuse_values(job, record, stress, result)
    assert proof['reused'] and proof['original_helper_returncode'] is None
    assert proof['Popen_returncode_known'] is False and proof['new_stress_execution'] is False
    assert c.stress_action(job, (True, True)) == 'reuse_completed_V1'
    assert c.stress_action(other, (False, False)) == 'new_once'
    for presence in ((True, False), (False, True), (False, False)):
        reject(lambda presence=presence: c.stress_action(job, presence))
    reject(lambda: c.stress_action(other, (True, True)))
    checks.append('pinned_complete_stress_reused_unknown_rc_partial_missing_or_duplicate_fails')
    # Mutate the expected copied body too, to exercise schema independently of
    # the first deep-equality guard. The real input receipt remains hash-pinned.
    for key, bad in [('seed', 26), ('device', 'cuda:0'), ('training_transitions', 1),
                     ('optimizer_steps', 1), ('optimizer_constructions', 1),
                     ('observation_normalizer_updates', 1), ('reward_normalizer_updates', 1),
                     ('helper_sha256', '0' * 64), ('checkpoint_sha256', '0' * 64),
                     ('episodes', 191), ('conditions', 5), ('source_hashes', {}),
                     ('model_unchanged', False), ('normalizer_unchanged', False),
                     ('training_files_unchanged', False), ('source_api_ast_equal', False),
                     ('evaluation_transitions', 0)]:
        altered, expected = copy.deepcopy(result), copy.deepcopy(record)
        altered[key] = bad
        expected['stress']['23']['files']['checkpoint_stress_result.json']['value'] = altered
        reject(lambda: c.validate_stress_reuse_values(job, expected, stress, altered))
    checks.append('saved_stress_seed_device_zero_accounting_source_checkpoint_helper_isolation_rejected')
    for change in ('mode', 'count', 'returns', 'lengths'):
        altered, expected = copy.deepcopy(stress), copy.deepcopy(record)
        if change == 'mode': altered[0]['mode'] = 'gaussian'
        if change == 'count': altered.pop()
        if change == 'returns': altered[0]['returns'].pop()
        if change == 'lengths': altered[0]['lengths'][0] = 1001
        expected['stress']['23']['files']['stress_evaluation.json']['value'] = altered
        reject(lambda: c.validate_stress_reuse_values(job, expected, altered, result))
    checks.append('all_six_conditions_and_exact_32_return_length_batches_required')
    return checks


def admission_checks():
    checks = []
    now = datetime.now(timezone.utc)
    assert c.timestamp(now.timestamp()) == c.timestamp(now.timestamp() * 1000)
    assert c.timestamp(now.isoformat()) == now.timestamp()
    for invalid in (True, float('nan'), float('inf'), '2026-10-05T00:00:00'):
        reject(lambda invalid=invalid: c.timestamp(invalid))
    with tempfile.TemporaryDirectory(prefix='swimmer_gpu1_admission_fixture_') as directory:
        original_root = c.ROOT
        try:
            c.ROOT = Path(directory)
            c.write(c.ROOT / 'MANIFEST.json', {'fixture': True})
            digest = c.sha(c.ROOT / 'MANIFEST.json')
            review = {'state': 'approved', 'source_manifest_sha256': digest,
                      'independent_source_review_passed': True, 'native_admission_authorized': True}
            goal = {'goal': {'threadId': 'actual-schema-fixture', 'status': 'active',
                            'objective': str(c.NATIVE_ROOT) + ' ' + c.UNIT,
                            'createdAt': (now.timestamp() - 2) * 1000}}
            snapshot = {'native_root': str(c.NATIVE_ROOT), 'unit': c.UNIT,
                        'source_manifest_sha256': digest, 'physical_gpus': [1],
                        'actual_evidence': {'fixture_only': 'not native evidence'}, 'checked_utc': now.isoformat()}
            luna = {'state': 'active', 'source_manifest_sha256': digest,
                    'monitor_agent_id': 'fixture', 'active_goal_id': 'actual-schema-fixture',
                    'initial_snapshot': {'fixture': True}, 'checked_utc': now.isoformat()}

            def populate(review_body=review, goal_body=goal, snapshot_body=snapshot, luna_body=luna):
                c.write(c.ROOT / 'PARENT_REVIEW_AUTHORIZATION.json', review_body)
                c.write(c.ROOT / 'PARENT_LUNA_RAW_GOAL.json', goal_body)
                c.write(c.ROOT / 'PARENT_LUNA_RAW_INITIAL_SNAPSHOT.json', snapshot_body)
                c.write(c.ROOT / 'PARENT_LUNA_ACTIVE.json', {**luna_body,
                    'raw_goal_sha256': c.sha(c.ROOT / 'PARENT_LUNA_RAW_GOAL.json'),
                    'raw_initial_snapshot_sha256': c.sha(c.ROOT / 'PARENT_LUNA_RAW_INITIAL_SNAPSHOT.json')})
            populate()
            assert len(c.check_prelaunch_receipts()) == 4
            for target, key, bad in [('review', 'state', 'pending'),
                                     ('review', 'source_manifest_sha256', '0' * 64),
                                     ('goal', 'status', 'completed'), ('goal', 'threadId', 'wrong'),
                                     ('goal', 'objective', 'old scope'),
                                     ('goal', 'createdAt', (now.timestamp() - 601) * 1000),
                                     ('goal', 'createdAt', (now.timestamp() + 31) * 1000),
                                     ('snapshot', 'native_root', str(c.FAILED_V1_ROOT)),
                                     ('snapshot', 'unit', 'old.service'),
                                     ('snapshot', 'source_manifest_sha256', '0' * 64),
                                     ('snapshot', 'physical_gpus', [0, 1, 2]),
                                     ('snapshot', 'actual_evidence', {}),
                                     ('snapshot', 'checked_utc', '2025-10-05T00:00:00Z'),
                                     ('luna', 'checked_utc', '2025-10-05T00:00:00Z')]:
                bodies = {'review': copy.deepcopy(review), 'goal': copy.deepcopy(goal),
                          'snapshot': copy.deepcopy(snapshot), 'luna': copy.deepcopy(luna)}
                changed = bodies[target]['goal'] if target == 'goal' else bodies[target]
                changed[key] = bad
                populate(bodies['review'], bodies['goal'], bodies['snapshot'], bodies['luna'])
                reject(c.check_prelaunch_receipts)
            populate()
            c.write(c.ROOT / 'PARENT_LUNA_RAW_GOAL.json', {'tampered': True})
            reject(c.check_prelaunch_receipts)
        finally:
            c.ROOT = original_root
    checks.append('literal_raw_goal_numeric_epoch_fresh_ACTIVE_scope_snapshot_and_hash_guards')
    return checks
