"""Meaningful stdlib source fixtures; no claim of native compatibility."""
import ast
import copy
import json
from pathlib import Path
import sys
import tempfile

sys.dont_write_bytecode = True
import gpu1_contract as c
import operational_fixtures as operational


def rejected(action, exceptions=(AssertionError,)):
    try:
        action()
    except exceptions:
        return
    raise AssertionError('negative fixture unexpectedly accepted')


def adapter_ast_proof(original_path, adapter_path):
    original = ast.parse(Path(original_path).read_text())
    adapter = ast.parse(Path(adapter_path).read_text())
    original_root = next(n for n in original.body if isinstance(n, ast.Assign)
                         and any(isinstance(t, ast.Name) and t.id == 'ROOT' for t in n.targets))
    adapter.body = [n for n in adapter.body if not (isinstance(n, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == 'RECOVERY_ROOT' for t in n.targets))]
    for index, node in enumerate(adapter.body):
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'ROOT' for t in node.targets):
            adapter.body[index] = copy.deepcopy(original_root)
    old_run = next(n for n in original.body if isinstance(n, ast.FunctionDef) and n.name == 'run')
    new_run = next(n for n in adapter.body if isinstance(n, ast.FunctionDef) and n.name == 'run')
    # Only the output allowlist, one-GPU guard and self-source-hash gate change.
    for index in (1, 2, 6):
        new_run.body[index] = copy.deepcopy(old_run.body[index])
    assert ast.dump(original, include_attributes=False) == ast.dump(adapter, include_attributes=False)
    return {'state': 'passed', 'whole_helper_AST_equal_after_restoring_declared_operational_nodes': True,
            'original_helper_sha256': c.sha(original_path), 'adapter_sha256': c.sha(adapter_path),
            'adapter_is_byte_identical': False,
            'changed_run_body_indices_zero_based': [1, 2, 6],
            'unchanged_scientific_call_sequence': True}


def main():
    local_original = c.ROOT.parent / 'swimmer_innovation12_transfer1_8seed_20261005'
    assert c.sha(local_original / 'MANIFEST.json') == c.ORIGINAL_MANIFEST_SHA
    original_manifest = c.read(local_original / 'MANIFEST.json')
    for name, digest in original_manifest['bundle_hashes'].items():
        assert c.sha(local_original / name) == digest, ('original source changed', name)
    for arm, folder in [('innovation1', 'source_i1'), ('innovation2', 'source_i2')]:
        expected = original_manifest['source_hashes'][arm]
        assert len(expected) == (21 if arm == 'innovation1' else 18)
        assert {p.name for p in (local_original / folder).iterdir() if p.is_file()} == set(expected)
    jobs = c.read(c.ROOT / 'TASK_PLAN.json')['jobs']
    c.validate_plan(jobs)
    for j in jobs:
        assert j['planned_command'] == c.original_command(j, local_original / 'run_transfer.py')
        assert j['planned_command'][j['planned_command'].index('--device') + 1] == 'cuda:1'
    receipts = c.validate_receipts({'input_hashes': c.read(c.ROOT / 'INPUT_HASHES.json')})
    checks = ['all16_exact_science_commands_gpu1_only', 'five_adopted_ten_zero_restarts_one_unstarted',
              'original_source21_source18_and_bundle_hashes', 'reused_six_short_receipt_hash_bindings']
    failed = c.ROOT.parent / 'swimmer_innovation12_gpu1_resume_20261005'
    assert c.sha(failed / 'MANIFEST.json') == c.FAILED_V1_MANIFEST_SHA
    assert c.sha(c.ROOT / 'inputs/V1_MANIFEST.json') == c.FAILED_V1_MANIFEST_SHA
    for name, digest in c.read(failed / 'MANIFEST.json')['bundle_hashes'].items():
        assert c.sha(failed / name) == digest
    preserved = c.v1_preservation()
    assert preserved['helper_sha256'] == c.read(c.ROOT / 'inputs/V1_MANIFEST.json')['stress_adapter_sha256']
    assert 'PermissionError' in c.read(c.ROOT / 'inputs/NATIVE_STARTUP_FAILURE_EVIDENCE.json')['failure']['traceback']
    checks.append('actual_V1_failure_33_file_receipt_and_immutable_23_source_bindings')
    checks.extend(operational.identity_checks())
    checks.extend(operational.stress_checks(jobs))
    checks.extend(operational.admission_checks())
    adopted = copy.deepcopy(next(j for j in jobs if j['ownership'] == 'external'))
    identity = {'pid': adopted['pid'], 'start_ticks': adopted['start_ticks'],
                'command': adopted['command'], 'cuda_visible_devices': None}
    assert c.check_identity(adopted, identity)
    assert c.check_identity(adopted, None) is False
    rejected(lambda: c.check_identity(adopted, {**identity, 'start_ticks': str(int(adopted['start_ticks']) + 1)}))
    rejected(lambda: c.check_identity(adopted, {**identity, 'command': [*identity['command'], '--resume']}))
    rejected(lambda: c.check_identity(adopted, {**identity, 'cuda_visible_devices': '1'}))
    checks.append('adopted_PID_reuse_argv_change_and_GPU_mask_rejected')
    state = {'jobs': copy.deepcopy(jobs), 'total': 16, 'physical_gpus': [1],
             'completed_count': 0, 'pending_count': 11, 'reservation_mib': c.FLOOR_MIB, 'active_helper': None}
    c.validate_state(state)
    bad = copy.deepcopy(state)
    next(j for j in bad['jobs'] if j['ownership'] == 'external')['returncode'] = 0
    rejected(lambda: c.validate_state(bad))
    checks.append('adopted_unknown_exitcode_must_remain_null')
    pending = copy.deepcopy(next(j for j in jobs if j['ownership'] == 'own'))
    rejected(lambda: c.claim_start(copy.deepcopy(pending), output_exists=True))
    c.claim_start(pending)
    rejected(lambda: c.claim_start(pending))
    rejected(lambda: c.claim_start(adopted))
    checks.append('duplicate_start_and_adopted_restart_prevention')
    running = [{'pid': pid} for pid in (101, 102, 103, 104, 105)]
    memory = {j['pid']: 5130 for j in running}
    deficit = c.initializing_deficit(running, memory, 5388)
    assert deficit == 5 * 258
    pending = next(j for j in jobs if j['ownership'] == 'own')
    threshold = 5388 + 512 + deficit
    assert c.can_admit(pending, running, threshold, memory, 5388)
    assert not c.can_admit(pending, running, threshold - 1, memory, 5388)
    initializing = [*running, {'pid': 106}, {'pid': 107}]
    assert c.initializing_deficit(initializing, memory, 5388) == deficit + 2 * 5388
    assert not c.can_admit(pending, initializing, threshold + 5388, memory, 5388)
    assert not c.can_admit(pending, [*initializing, {'pid': 108}], 999999, memory, 5388)
    assert c.reservation_mib(5388, [6000], [5900]) == 6256
    assert c.reservation_mib(6256, [5000], [5000]) == 6256
    checks.append('eight_trainer_cap_all_initializing_deficits_and_monotonic_reservation')
    snap = {'allocations': [{'pid': 101, 'gpu_uuid': c.GPU1_UUID, 'used_mib': 5130},
                            {'pid': 999, 'gpu_uuid': 'unrelated-GPU0', 'used_mib': 2000}]}
    c.assert_gpu1_allocations([101], snap, require_context=[101])
    rejected(lambda: c.assert_gpu1_allocations([101, 999], snap))
    rejected(lambda: c.assert_gpu1_allocations([102], snap, require_context=[102]))
    checks.append('owned_physical_GPU_UUID_only1_unrelated_processes_ignored')
    with tempfile.TemporaryDirectory(prefix='swimmer_gpu1_fixture_') as directory:
        p = Path(directory)
        fake = {**adopted, 'path': str(p), 'pid': 2147483647}
        rejected(lambda: c.completion_gate(fake), (FileNotFoundError,))
        config = {'task': 'Swimmer', 'seed': fake['seed'], 'device': 'cuda:1',
                  'steps': c.BUDGET, 'effective_steps': c.BUDGET}
        summary = {'state': 'completed', 'reload_check': 'passed', 'steps': c.BUDGET,
                   'device': 'cuda:1', 'physics_device': 'cuda:1'}
        c.write(p / 'config.json', config)
        c.write(p / 'summary.json', summary)
        c.write(p / 'status.json', summary)
        (p / 'latest.pt').write_bytes(b'fixture only, never numerical proof')
        assert c.completion_gate(fake)['steps'] == c.BUDGET
        bad = {**summary, 'steps': c.BUDGET - 65536}
        c.write(p / 'summary.json', bad)
        c.write(p / 'status.json', bad)
        rejected(lambda: c.completion_gate(fake))
        c.write(p / 'summary.json', summary)
        c.write(p / 'status.json', summary)
        (p / 'latest.pt').unlink()
        rejected(lambda: c.completion_gate(fake))
    checks.append('missing_incomplete_summary_and_missing_checkpoint_rejected')
    for path in c.ROOT.rglob('*.py'):
        tree = ast.parse(path.read_text())
        compile(tree, str(path), 'exec')
    contract_tree = ast.parse((c.ROOT / 'gpu1_contract.py').read_text())
    source_calls = {(n.func.value.id, n.func.attr): n for n in ast.walk(ast.parse((local_original / 'run_transfer.py').read_text()))
                    if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and isinstance(n.func.value, ast.Name)}
    protected = next(n for n in ast.parse((local_original / 'run_transfer.py').read_text()).body
                     if isinstance(n, ast.FunctionDef) and n.name == 'verify_protected')
    loads = [n for n in ast.walk(protected) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
             and isinstance(n.func.value, ast.Name) and n.func.value.id == 'torch' and n.func.attr == 'load']
    assert len(loads) == 1 and any(k.arg == 'map_location' and isinstance(k.value, ast.Constant)
                                 and k.value.value == 'cpu' for k in loads[0].keywords)
    assert not any(isinstance(n, ast.Attribute) and n.attr == 'cuda' for n in ast.walk(protected))
    run_tree = ast.parse((c.ROOT / 'run_gpu1.py').read_text())
    assert "assert process.poll() is not None" in (c.ROOT / 'run_gpu1.py').read_text()
    assert "assert process.returncode == 0" in (c.ROOT / 'run_gpu1.py').read_text()
    handlers = [n for n in ast.walk(run_tree) if isinstance(n, ast.ExceptHandler)]
    assert any('new_admissions_stopped' in ast.unparse(n) and 'active_workers_preserved' in ast.unparse(n)
               and any(isinstance(child, ast.Raise) for child in ast.walk(n)) for n in handlers)
    checks.append('owned_helper_actual_Popen_completion_and_existing_failstop_preserved')
    for node in ast.walk(run_tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr in ('set_device', 'max_memory_reserved'):
            assert len(node.args) == 1 and isinstance(node.args[0], ast.Constant) and node.args[0].value == 1
    adapter = adapter_ast_proof(local_original / 'stress_checkpoint.py', c.ROOT / 'stress_checkpoint_gpu1.py')
    checks.extend(['CPU_only_original_protection_source_inspection', 'new_coordinator_GPU_calls_explicit_1_only',
                   'stress_adapter_AST_restoration_exact'])
    assert 'torch' not in sys.modules and 'scipy' not in sys.modules
    receipt = {'state': 'passed', 'scope': 'stdlib source fixtures only; not native compatibility',
               'fixture_count': len(checks), 'checks': checks, 'adapter_ast_proof': adapter,
               'reused_engineering_receipts': receipts, 'Torch_imported': False,
               'native_executed': False, 'training_launched': False,
               'source_hashes': {name: c.sha(c.ROOT / name) for name in
                                 ('gpu1_contract.py', 'run_gpu1.py', 'verify_parent.py', 'stress_checkpoint_gpu1.py',
                                  'operational_fixtures.py', 'check_source.py', 'build_source_bundle.py', 'TASK_PLAN.json')}}
    c.write(c.ROOT / 'STDLIB_FIXTURES_VERIFIED.json', receipt)
    print(json.dumps({'state': 'passed', 'fixtures': checks, 'native_compatibility_claim': False}))


if __name__ == '__main__':
    main()
