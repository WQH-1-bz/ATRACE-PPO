"""Complete I2 stress from its frozen checkpoint without changing training files."""
import argparse
import ast
import hashlib
import importlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path('/home/mumu01/ssd3/wch/swimmer_innovation12_transfer1_8seed_20261005')
RECOVERY_ROOT = Path('/home/mumu01/ssd3/wch/swimmer_innovation12_gpu1_resume_v2_20261005')
CONDITIONS = (('none', 0.), ('gaussian', .10), ('gaussian', .15),
              ('gaussian', .30), ('multiplicative', .20), ('multiplicative', .30))
FLAGS = {'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1',
         'DPO_TORCH_DETERMINISTIC': '1', 'DPO_WARP_DETERMINISTIC': 'run_to_run',
         'DPO_WARP_DETERMINISTIC_MAX_RECORDS': '8', 'CUBLAS_WORKSPACE_CONFIG': ':4096:8',
         'DPO_PPO_GRAPH': '0', 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONUNBUFFERED': '1'}
DET = {'torch': True, 'warp': 'run_to_run', 'warp_max_records': 8,
       'cublas_workspace_config': ':4096:8'}


def read(path):
    return json.loads(path.read_text())


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            digest.update(chunk)
    return digest.hexdigest()


def write_new(path, value):
    assert not path.exists(), ('output already exists', path)
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def validate_stress(value, torch_module=None, device=None):
    assert isinstance(value, list) and len(value) == 6
    for row, condition in zip(value, CONDITIONS):
        assert set(row) == {'mode', 'scale', 'mean', 'std', 'returns', 'lengths'}
        assert (row['mode'], row['scale']) == condition
        assert len(row['returns']) == len(row['lengths']) == 32
        assert all(type(v) in (int, float) and math.isfinite(v) for v in row['returns'])
        assert all(type(v) is int and 1 <= v <= 1000 for v in row['lengths'])
        assert type(row['mean']) in (int, float) and math.isfinite(row['mean'])
        assert type(row['std']) in (int, float) and math.isfinite(row['std']) and row['std'] >= 0
        if torch_module is not None:
            returns = torch_module.tensor(row['returns'], device=device, dtype=torch_module.float32)
            assert row['mean'] == returns.mean().item()
            assert row['std'] == returns.std(unbiased=False).item()
    return {'conditions': 6, 'episodes': 192,
            'evaluation_transitions': sum(sum(row['lengths']) for row in value)}


def assert_state(torch_module, actual, expected):
    assert actual.keys() == expected.keys()
    for key in expected:
        a, b = actual[key], expected[key]
        assert a.dtype == b.dtype and a.shape == b.shape and torch_module.equal(a, b), key


def source_api_contract():
    trees = [ast.parse((ROOT / source / file).read_text()) for source, file in
             [('source_i1', 'train_kl_relative.py'), ('source_i2', 'train_noisy_warp.py')]]
    for name in ('ActorCritic', 'RunningStats', 'evaluate'):
        nodes = [next(node for node in tree.body if getattr(node, 'name', None) == name) for tree in trees]
        assert ast.dump(nodes[0], include_attributes=False) == ast.dump(nodes[1], include_attributes=False), name
    return True


def run(path, device):
    path = path.resolve()
    assert path.parent in ((ROOT / 'runs').resolve(), (RECOVERY_ROOT / 'runs').resolve()), ('output root outside explicit allowlist', path)
    assert device == 'cuda:1'
    assert not (path / 'stress_evaluation.json').exists()
    assert not (path / 'checkpoint_stress_result.json').exists()
    launch = read(ROOT / 'MANIFEST.json')
    assert sha(Path(__file__)) == read(RECOVERY_ROOT / 'MANIFEST.json')['stress_adapter_sha256']
    source_dir = ROOT / 'source_i2'
    hashes = read(ROOT / 'source_i2_hashes.json')
    assert len(hashes) == 18 and hashes == launch['source_hashes']['innovation2']
    for name, digest in hashes.items():
        assert sha(source_dir / name) == digest
    original = {p.name: sha(p) for p in path.iterdir() if p.is_file()}
    config = read(path / 'config.json')
    assert config['task'] == 'Swimmer' and config['device'] == device
    assert config['effective_steps'] == config['steps'] in (524288, 10027008)
    assert config['eval_envs'] == 32 and config['determinism'] == DET
    assert read(path / 'summary.json')['reload_check'] == 'passed'
    for key, value in FLAGS.items():
        assert os.environ.get(key, value) == value, (key, os.environ.get(key))
        os.environ[key] = value
    for key, sub in [('XDG_CACHE_HOME', 'cache'), ('WARP_CACHE_PATH', 'cache/warp'),
                     ('CUDA_CACHE_PATH', 'cache/cuda'), ('TORCH_HOME', 'cache/torch'), ('TMPDIR', 'tmp')]:
        target = ROOT / sub
        target.mkdir(parents=True, exist_ok=True)
        os.environ[key] = str(target)
    source_api_contract()
    sys.path.insert(0, str(source_dir))
    import torch
    import numpy as np
    helper = importlib.import_module('train_noisy_warp')
    physics = importlib.import_module('locomotion_warp')
    noise = importlib.import_module('noisy_observation')
    for module in (helper, physics, noise):
        assert Path(module.__file__).resolve() == (source_dir / (module.__name__ + '.py')).resolve()
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    assert torch.cuda.is_available()
    torch.cuda.set_device(device)
    torch.manual_seed(config['seed'])
    np.random.seed(config['seed'])
    saved = torch.load(path / 'latest.pt', map_location='cpu', weights_only=False)
    assert saved['steps'] == config['steps'] and saved['config'] == config
    baseline_model = {key: value.clone() for key, value in saved['model'].items()}
    baseline_stats = {key: value.clone() for key, value in saved['obs_stats'].items()}
    model = helper.ActorCritic(8, 2).to(device)
    model.load_state_dict(saved['model'], strict=True)
    model.eval()
    normalizer = helper.RunningStats((8,), device)
    normalizer.load_state_dict(saved['obs_stats'], strict=True)
    normalizer.eval()
    assert_state(torch, {k: v.detach().cpu() for k, v in model.state_dict().items()}, baseline_model)
    assert_state(torch, {k: v.detach().cpu() for k, v in normalizer.state_dict().items()}, baseline_stats)
    assert all(bool(torch.isfinite(v).all()) for v in [*baseline_model.values(), *baseline_stats.values()])
    assert sha(physics.ASSETS / physics.TASKS['Swimmer'][0]) == config['xml_sha256']
    env = noise.NoisyObservation(physics.LocomotionWarp(32, device, config['seed'] + 10000, task='Swimmer'),
                                 'none', 0., config['seed'] + 300000)
    assert (env.num_envs, env.obs_dim, env.action_dim, env.max_steps) == (32, 8, 2, 1000)
    stress = []
    for mode, scale in CONDITIONS:
        env.env.rng.manual_seed(config['seed'] + 400000)
        env.configure(mode, scale, config['seed'] + 500000)
        stress.append({'mode': mode, 'scale': scale, **helper.evaluate(model, normalizer, env)})
        assert_state(torch, {k: v.detach().cpu() for k, v in model.state_dict().items()}, baseline_model)
        assert_state(torch, {k: v.detach().cpu() for k, v in normalizer.state_dict().items()}, baseline_stats)
        assert_state(torch, saved['model'], baseline_model)
        assert_state(torch, saved['obs_stats'], baseline_stats)
    accounting = validate_stress(stress, torch, device)
    for name, digest in hashes.items():
        assert sha(source_dir / name) == digest
    for name, digest in original.items():
        assert sha(path / name) == digest, ('training artifact changed', name)
    write_new(path / 'stress_evaluation.json', stress)
    report = {'state': 'passed', 'task': 'Swimmer', 'seed': config['seed'], 'device': device,
              'training_transitions': 0, 'optimizer_steps': 0, 'optimizer_constructions': 0,
              'observation_normalizer_updates': 0, 'reward_normalizer_updates': 0,
              'model_unchanged': True, 'normalizer_unchanged': True, 'training_files_unchanged': True,
              'checkpoint_sha256': original['latest.pt'], 'helper_sha256': sha(Path(__file__)),
              'source_hashes': hashes, 'protected_training_artifacts': original,
              'stress_sha256': sha(path / 'stress_evaluation.json'), 'source_api_ast_equal': True,
              'runtime_versions': {package: importlib.metadata.version(package) for package in
                                   ('torch', 'mujoco', 'mujoco-warp', 'warp-lang', 'gymnasium', 'numpy')},
              'peak_torch_memory_reserved_bytes':torch.cuda.max_memory_reserved(device), **accounting}
    write_new(path / 'checkpoint_stress_result.json', report)
    print(json.dumps({key: report[key] for key in ('state', 'seed', 'training_transitions', 'optimizer_steps', 'episodes')}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--job-path', type=Path, required=True)
    parser.add_argument('--device', required=True)
    args = parser.parse_args()
    run(args.job_path, args.device)
