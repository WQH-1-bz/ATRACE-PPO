import ast,csv,hashlib,importlib.util,json,math,os,sys,types
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parent
SOURCE_DIRS={'innovation1':ROOT/'source_i1','innovation2':ROOT/'source_i2'}
BUDGET,SHORT,SWITCH,SHORT_SWITCH=10027008,524288,4980736,262144
FIXED_CRITIC_REPLAY_WARMUP_COUNT=SPLIT_TRACE_REPLAY_WARMUP_COUNT=3
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def same(a, b):
    assert abs(float(a) - float(b)) < 1e-10, (a, b)

def jsonl(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]

def controller_class():
    name = 'hc_r4_frozen_kl_feedback'
    if name not in sys.modules:
        spec = importlib.util.spec_from_file_location(name, SOURCE_DIRS['innovation1'] / 'lambda_kl_relative.py')
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
    return sys.modules[name].KLFeedback

def checkpoint_steps(path, arm, expected):
    checkpoint = torch.load(path / 'latest.pt', map_location='cpu', weights_only=False)
    optimizers = {'ppo': checkpoint['optimizer']} if arm == 'innovation1' else checkpoint['optimizers']
    assert set(optimizers) == {'ppo'}
    for optimizer in optimizers.values():
        assert optimizer['state']
        for state in optimizer['state'].values():
            step = state['step'].item() if isinstance(state['step'], torch.Tensor) else state['step']
            assert step == expected, ('Adam steps', step, expected)
            for key in ('exp_avg', 'exp_avg_sq'):
                assert bool(torch.isfinite(state[key]).all()), ('nonfinite optimizer', key)
    assert all(bool(torch.isfinite(value).all()) for value in checkpoint['model'].values())
    assert checkpoint['config'] == read(path / 'config.json')
    return checkpoint

def fixed_audit_updates(config):
    return [4, 5, 8] if config['effective_steps'] == SHORT else [76, 77, 153]

def fixed_audit_names(config):
    return [f'fixed_critic_audit_{update:03d}.pt' for update in fixed_audit_updates(config)]

def split_audit_updates(config):
    return [3, 4, 9] if config['effective_steps'] == SHORT else [3, 100, 178]

def split_audit_names(config):
    return [f'split_trace_audit_{update:03d}.pt' for update in split_audit_updates(config)]

def source_i2_functions():
    """Load only frozen target functions, without importing physics or trainers."""
    torch.use_deterministic_algorithms(True)
    torch.set_num_threads(1)
    name = 'hc_r4_frozen_split_trace_replay'
    if name not in sys.modules:
        module = types.ModuleType(name)
        module.torch = torch
        sys.modules[name] = module
        for filename, names in [('train_pae_baseline.py', ('split_tail_trace', 'capped_tail_trace')),
                                ('train_noisy_warp.py', ('gae',))]:
            source = SOURCE_DIRS['innovation2'] / filename
            nodes = [node for node in ast.parse(source.read_text()).body
                     if isinstance(node, ast.FunctionDef) and node.name in names]
            assert {node.name for node in nodes} == set(names)
            for node in nodes:
                assert len(node.decorator_list) == 1
                decorator = node.decorator_list[0]
                assert isinstance(decorator, ast.Attribute) and decorator.attr == 'script'
                assert isinstance(decorator.value, ast.Attribute) and decorator.value.attr == 'jit'
                assert isinstance(decorator.value.value, ast.Name) and decorator.value.value.id == 'torch'
            module.__file__ = str(source)
            program = ast.Module(body=nodes, type_ignores=[])
            exec(compile(ast.fix_missing_locations(program), str(source), 'exec'), module.__dict__)
    return sys.modules[name]

def verify_split_trace_audits(job, config, short=False):
    path = Path(job['path'])
    progress = list(csv.DictReader((path / 'progress.csv').open()))
    diagnostics = jsonl(path / 'retained_tail_diagnostics.jsonl')
    functions = source_i2_functions()
    rows, changed_from_capped = [], 0
    input_float_keys = ('normalized_reward', 'values', 'next_values', 'trace_logratios', 'raw_rhos', 'capped_cs')
    target_keys = ('actor_advantage', 'consumed_critic_return')
    for update, name in zip(split_audit_updates(config), split_audit_names(config)):
        record = torch.load(path / name, map_location='cpu', weights_only=False)
        critic_lam=.99 if record['steps']<=config['stage_switch_steps'] else .95
        row, diagnostic = progress[update - 1], diagnostics[update - 1]
        incoming, used = (16, 48) if update != len(progress) else (0, 64)
        assert record['update'] == update and record['steps'] == int(row['steps'])
        prior = 0 if update == 1 else int(progress[update - 2]['steps'])
        assert record['prior_collected_steps'] == prior
        assert record['end_per_world'] == 64 and record['used_per_world'] == used == int(row['used_per_world'])
        assert record['retained_per_world'] == incoming == diagnostic['retained_per_world']
        assert record['gamma'] == .99 and .90<=record['actor_lambda']<=.99 and record['critic_lambda']==critic_lam
        assert record['target_device'] == config['device']
        for key in (*input_float_keys, *target_keys, 'terminated', 'done'):
            expected_shape = (used, 1024) if key in target_keys else (64, 1024)
            tensor = record[key]
            assert isinstance(tensor, torch.Tensor) and tensor.shape == expected_shape, (name, key)
            assert tensor.device.type == 'cpu' and not tensor.requires_grad
            if key in ('terminated', 'done'):
                assert tensor.dtype == torch.bool
            else:
                assert tensor.dtype == torch.float32 and bool(torch.isfinite(tensor).all()), (name, key)
        assert not bool((record['terminated'] & ~record['done']).any())
        device = torch.device(record['target_device'])
        if device.type == 'cuda':
            assert torch.cuda.is_available() and device == torch.device(job.get('device', f"cuda:{job['gpu']}"))
        inputs = [record[key].to(device) for key in ('normalized_reward', 'values', 'next_values', 'terminated', 'done')]
        logs, rhos, cs = [record[key].to(device) for key in ('trace_logratios', 'raw_rhos', 'capped_cs')]
        with torch.no_grad():
            assert torch.equal(rhos, logs.exp()), ('raw rho construction', name)
            assert torch.equal(cs, logs.clamp(max=0).exp()), ('continuation weight construction', name)
            assert bool((logs[incoming:] == 0).all())
            assert bool((rhos[incoming:] == 1).all()) and bool((cs[incoming:] == 1).all())
            assert bool((rhos >= 0).all()) and bool(((cs >= 0) & (cs <= 1)).all())
            if not rows:
                # Fixed warmup for the consumed-target function and two references.
                # Outputs are discarded; no comparison controls the call count.
                for _ in range(SPLIT_TRACE_REPLAY_WARMUP_COUNT):
                    functions.split_tail_trace(*inputs, rhos, cs, .99, critic_lam)
                    functions.capped_tail_trace(*inputs, cs, .99, critic_lam)
                    functions.gae(*inputs, .99, critic_lam)
            actor, adaptive_return = functions.split_tail_trace(*inputs, rhos, cs, .99, record['actor_lambda'])
            _, critic_return = functions.split_tail_trace(*inputs, rhos, cs, .99, critic_lam)
            capped_actor, _ = functions.capped_tail_trace(*inputs, cs, .99, record['actor_lambda'])
            _, capped_return = functions.capped_tail_trace(*inputs, cs, .99, critic_lam)
            gae_actor, _ = functions.gae(*inputs, .99, record['actor_lambda'])
            _, gae_return = functions.gae(*inputs, .99, critic_lam)
            assert torch.equal(actor[:used], record['actor_advantage'].to(device)), ('split actor target replay', name)
            assert torch.equal(critic_return[:used], record['consumed_critic_return'].to(device)), ('split critic target replay', name)
            assert torch.equal(actor[incoming:], gae_actor[incoming:]), ('fresh actor GAE', name)
            assert torch.equal(critic_return[incoming:], gae_return[incoming:]), ('fresh critic GAE', name)
            above = int((rhos[:incoming] > 1).sum())
            actor_changed = int(torch.count_nonzero(actor[:incoming] - capped_actor[:incoming]))
            critic_changed = int(torch.count_nonzero(critic_return[:incoming] - capped_return[:incoming]))
            assert above == diagnostic['td_rho_above_one_count']
            assert actor_changed == diagnostic['split_vs_capped_actor_nonzero_count']
            assert critic_changed == diagnostic['split_vs_capped_critic_nonzero_count']
            if incoming:
                changed_from_capped += int(above > 0 and actor_changed > 0 and critic_changed > 0)
            else:
                assert above == actor_changed == critic_changed == 0
        rows.append({'update': update, 'steps': record['steps'], 'incoming_retained_per_world': incoming,
                     'used_per_world': used, 'replay_device': str(device), 'raw_rhos_above_one_count': above,
                     'actor_changed_from_capped_count': actor_changed, 'critic_changed_from_capped_count': critic_changed,
                     'artifact_sha256': sha(path / name)})
        del inputs, logs, rhos, cs, actor, critic_return, capped_actor, capped_return, gae_actor, gae_return, record
    assert changed_from_capped > 0, 'Saved split-TD targets never differed from original capped targets'
    return {'split_trace_target_replay': 'passed', 'split_trace_audit_count': 3, 'split_trace_audits': rows,
            'split_trace_audits_with_measured_split_effect': changed_from_capped,
            'split_trace_replay_warmup_count': SPLIT_TRACE_REPLAY_WARMUP_COUNT,
            'split_trace_replay_runtime': {'torch_version': torch.__version__, 'num_threads': torch.get_num_threads(),
                'deterministic_algorithms': torch.are_deterministic_algorithms_enabled(), 'comparison': 'torch.equal',
                'warmup_gamma': .99, 'warmup_lambda': .99, 'warmup_shape': [64, 1024], 'warmup_device': config['device'],
                'warmup_inputs': 'actual first saved window including raw rho and capped c',
                'reference_warmup_count_each': SPLIT_TRACE_REPLAY_WARMUP_COUNT, 'warmup_count_fixed': True}}

def source_gae():
    """Compile only the frozen source GAE function; no environment/model imports."""
    torch.use_deterministic_algorithms(True)
    torch.set_num_threads(1)
    name = 'hc_r4_frozen_source_gae_replay'
    if name not in sys.modules:
        source = SOURCE_DIRS['innovation1'] / 'train_kl_relative.py'
        tree = ast.parse(source.read_text())
        functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'gae']
        assert len(functions) == 1
        function = functions[0]
        assert len(function.decorator_list) == 1
        decorator = function.decorator_list[0]
        assert isinstance(decorator, ast.Attribute) and decorator.attr == 'script'
        assert isinstance(decorator.value, ast.Attribute) and decorator.value.attr == 'jit'
        assert isinstance(decorator.value.value, ast.Name) and decorator.value.value.id == 'torch'
        module = types.ModuleType(name)
        module.__file__, module.torch = str(source), torch
        sys.modules[name] = module
        # Retained source positions let torch.jit inspect the real frozen function.
        program = ast.Module(body=[function], type_ignores=[])
        exec(compile(ast.fix_missing_locations(program), str(source), 'exec'), module.__dict__)
    return sys.modules[name].gae

def verify_fixed_critic_audits(job, config, short=False):
    path = Path(job['path'])
    decisions = {row['update']: row for row in jsonl(path / 'lambda_decisions.jsonl')}
    replay = source_gae()
    names, held = fixed_audit_names(config), 4 if short else 76
    rows, separated = [], 0
    float_keys = ('normalized_reward', 'values', 'next_values', 'actor_advantage', 'consumed_critic_return')
    for update, name in zip(fixed_audit_updates(config), names):
        record = torch.load(path / name, map_location='cpu', weights_only=False)
        assert record['update'] == update and record['steps'] == update * 65536
        assert record['prior_collected_steps'] == (update - 1) * 65536
        assert record['used_per_world'] == 64 and record['gamma'] == .99
        assert record['target_device'] == config['device']
        same(record['actor_lambda'], decisions[update]['actor_lambda_used'])
        same(record['actor_lambda'], decisions[update]['lambda_used'])
        assert record['critic_lambda'] == config['fixed_critic_lambda'] == .95
        for key in (*float_keys, 'terminated', 'done'):
            assert isinstance(record[key], torch.Tensor) and record[key].shape == (64, 1024), (name, key)
            assert record[key].device.type == 'cpu' and not record[key].requires_grad
            if key in float_keys:
                assert record[key].dtype == torch.float32 and bool(torch.isfinite(record[key]).all()), (name, key)
            else:
                assert record[key].dtype == torch.bool, (name, key)
        assert not bool((record['terminated'] & ~record['done']).any())
        device = torch.device(record['target_device'])
        if device.type == 'cuda':
            assert torch.cuda.is_available() and device == torch.device(job.get('device', f"cuda:{job['gpu']}"))
        inputs = [record[key].to(device) for key in ('normalized_reward', 'values', 'next_values', 'terminated', 'done')]
        with torch.no_grad():
            if not rows:
                # The trainer has already warmed GAE by its first saved update.
                # Use exactly three discarded calls, independent of comparisons.
                for _ in range(FIXED_CRITIC_REPLAY_WARMUP_COUNT):
                    replay(*inputs, .99, .95)
            actor, adaptive_return = replay(*inputs, .99, record['actor_lambda'])
            fixed_advantage, fixed_return = replay(*inputs, .99, .95)
            assert torch.equal(actor, record['actor_advantage'].to(device)), ('actor target replay', name)
            assert torch.equal(fixed_return, record['consumed_critic_return'].to(device)), ('critic target replay', name)
            differs = not torch.equal(actor, fixed_advantage)
            if update == held:
                assert record['actor_lambda'] == .95 and not differs
                assert torch.equal(adaptive_return, fixed_return)
            else:
                separated += int(differs and not torch.equal(adaptive_return, fixed_return))
        rows.append({'update': update, 'steps': record['steps'], 'actor_lambda': record['actor_lambda'],
                     'critic_lambda': .95, 'replay_device': str(device), 'actor_critic_targets_differ': differs,
                     'artifact_sha256': sha(path / name)})
        del inputs, actor, adaptive_return, fixed_advantage, fixed_return, record
    assert separated > 0, 'Saved post-activation actor and critic targets never separated'
    return {'fixed_critic_target_replay': 'passed', 'fixed_critic_audit_count': 3,
            'fixed_critic_audits': rows, 'post_activation_audits_with_separated_targets': separated,
            'fixed_critic_replay_warmup_count': FIXED_CRITIC_REPLAY_WARMUP_COUNT,
            'fixed_critic_replay_runtime': {
                'torch_version': torch.__version__, 'num_threads': torch.get_num_threads(),
                'deterministic_algorithms': torch.are_deterministic_algorithms_enabled(),
                'comparison': 'torch.equal', 'warmup_gamma': .99, 'warmup_lambda': .95,
                'warmup_shape': [64, 1024], 'warmup_device': config['device'],
                'warmup_before': 'first saved-target comparison', 'warmup_count_fixed': True}}

def verify_i1(progress, path, config, short):
    decisions = jsonl(path / 'lambda_decisions.jsonl')
    count, hold = (8, 4) if short else (153, 76)
    assert len(progress) == len(decisions) == count
    controller = controller_class()()
    lambdas, ready_updates = [], []
    for update, (decision, row) in enumerate(zip(decisions, progress), 1):
        prior = (update - 1) * 65536
        ready = prior >= config['adaptive_start_steps']
        assert decision['update'] == update and decision['prior_collected_steps'] == prior
        assert decision['adaptive_start_steps'] == config['adaptive_start_steps']
        assert decision['adaptive_steps_ready'] is ready
        assert int(row['steps']) == decision['steps'] == update * 65536
        assert int(row['fresh_steps_per_world']) == int(row['used_steps_per_world']) == 64
        delta = controller.step(update) if ready else 0.
        same(controller.value, decision['lambda_used'])
        same(decision['actor_lambda_used'], controller.value)
        same(decision['critic_lambda_used'], .95)
        assert math.isfinite(decision['actor_critic_target_diff_rmse']) and decision['actor_critic_target_diff_rmse'] >= 0
        if not ready:
            assert decision['actor_critic_target_diff_rmse'] == 0.
        same(row['gae_lambda'], controller.value)
        same(row['lambda_delta'], delta)
        controller.observe(decision['realized_kl'])
        for key, expected in controller.state_dict().items():
            same(expected, decision[key])
        assert not decision['overlap_active'] and row['overlap_active'].lower() == 'false'
        assert decision['headroom_gain'] == 1. and not decision['early_target_unlocked']
        assert not decision['critic_ready_latched']
        lambdas.append(decision['lambda_used'])
        if ready:
            ready_updates.append(update)
    assert lambdas[:hold] == [.95] * hold and ready_updates[0] == hold + 1
    assert controller.observations == count
    changed = sum(abs(value - .95) > 1e-12 for value in lambdas)
    assert changed > 0, 'Adaptive lambda never changed after activation'
    assert any(decision['actor_critic_target_diff_rmse'] > 0 for decision in decisions[hold:]), 'Actor and fixed critic targets never separated'
    return lambdas, {'controller_replay': 'passed', 'controller_observations': count,
                     'hold_updates': hold, 'first_adaptive_update': ready_updates[0],
                     'adaptive_ready_updates': len(ready_updates), 'changed_updates': changed,
                     'trained_transitions': count * 65536}

def verify_i2(progress, path, config, short):
    budget, switch = (SHORT, SHORT_SWITCH) if short else (BUDGET, SWITCH)
    tail, prefix = config['pae_tail'], config['pae_prefix']
    assert (tail, prefix) == (16, 48)
    assert len(progress) == (9 if short else 178)
    previous = trained = retained = flushes = early = 0
    incoming = []
    for row in progress:
        step, fresh, used = (int(row[key]) for key in ('steps', 'fresh_per_world', 'used_per_world'))
        overlap = row['overlap_active'].lower() == 'true'
        flush = row['stage_boundary_flush'].lower() == 'true'
        assert overlap == (previous < switch)
        incoming.append(retained)
        expected_fresh = min(64 - retained, (budget - previous) // 1024)
        if overlap:
            expected_fresh = min(expected_fresh, (switch - previous) // 1024)
        end = retained + expected_fresh
        assert fresh == expected_fresh and step - previous == fresh * 1024
        assert flush == (overlap and step == switch)
        assert used == (end if flush or not overlap or step == budget else min(prefix, end))
        assert int(row['retained_per_world']) == end - used
        assert .90<=float(row['gae_lambda_used'])<=.99 and .90<=float(row['gae_lambda_next'])<=.99
        retained, previous = end - used, step
        trained += used * 1024
        flushes += int(flush)
        early += int(overlap)
    assert previous == trained == budget and retained == 0 and flushes == 1
    assert early == (5 if short else 101)
    assert int(next(row for row in progress if row['stage_boundary_flush'].lower() == 'true')['used_per_world']) == 64
    diagnostics = jsonl(path / 'retained_tail_diagnostics.jsonl')
    assert len(diagnostics) == len(progress)
    for update, (diag, row, count) in enumerate(zip(diagnostics, progress, incoming), 1):
        assert diag['update'] == update and diag['steps'] == int(row['steps'])
        assert diag['retained_per_world'] == count and count in (0, tail)
        assert diag['retained_count'] == 1024 * count
        for key in ('fresh_per_world', 'used_per_world', 'stage_boundary_flush'):
            expected = row[key].lower() == 'true' if key == 'stage_boundary_flush' else int(row[key])
            assert diag[key] == expected
        assert diag['retained_out_per_world'] == int(row['retained_per_world'])
        for key in ('logprob_finite_count', 'value_finite_count', 'advantage_finite_count'):
            assert diag[key] == diag['retained_count'], (key, diag[key], diag['retained_count'])
        if count:
            assert 0 <= diag['importance_ratio_outside_clip_fraction'] <= 1
            for key in ('current_behavior_logprob_mean_abs_drift', 'refreshed_minus_stored_value_rmse',
                        'extended_refreshed_retained_advantage_mean_abs_drift',
                        'extended_refreshed_retained_advantage_rmse'):
                assert diag[key] is not None and diag[key] >= 0
        for key, value in diag.items():
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                assert math.isfinite(value), (key, value)
    correction = verify_correction(diagnostics, incoming, config)
    assert correction['active_correction_updates'] == (4 if short else 100)
    split = verify_split_diagnostics(diagnostics, incoming)
    return [float(row['gae_lambda_used']) for row in progress], {'stage_replay': 'passed', 'diagnostic_batches': len(diagnostics),
        'early_updates': early, 'late_updates': len(progress) - early, 'boundary_flushes': flushes,
        'trained_transitions': trained, **correction, **split}

def verify_split_diagnostics(diagnostics, incoming):
    active = effects = above_total = weighted_td_nonzero = actor_nonzero = critic_nonzero = 0
    maximum_rho = maximum_weighted_td_abs = maximum_weighted_td_std = 0.
    for diagnostic, retained in zip(diagnostics, incoming):
        count, fresh = retained * 1024, diagnostic['fresh_per_world'] * 1024
        assert diagnostic['td_weight_policy'] == 'unclipped_current_over_behavior' and diagnostic['td_ratio_cap'] is None
        assert diagnostic['continuation_ratio_cap'] == 1. and diagnostic['td_rho_stats_scope'] == 'retained_rows'
        assert diagnostic['td_rho_finite_count'] == count and diagnostic['td_rho_nonfinite_count'] == 0
        above, below, equal = [diagnostic[f'td_rho_{key}_count'] for key in ('above_one', 'below_one', 'equal_one')]
        assert all(0 <= value <= count for value in (above, below, equal)) and above + below + equal == count
        assert diagnostic['fresh_td_rho_equal_one_count'] == fresh
        assert 0 <= diagnostic['td_delta_weight_change_nonzero_count'] <= above
        assert diagnostic['td_delta_weight_change_rmse'] >= 0
        assert diagnostic['split_td_active'] is bool(above)
        changes = []
        for kind in ('actor', 'critic'):
            changed = diagnostic[f'split_vs_capped_{kind}_nonzero_count']
            assert 0 <= changed <= count and diagnostic[f'split_vs_capped_{kind}_rmse'] >= 0
            assert diagnostic[f'fresh_split_vs_capped_{kind}_nonzero_count'] == 0
            assert diagnostic[f'fresh_split_vs_capped_{kind}_max_abs'] == 0.
            changes.append(changed)
        assert diagnostic['split_td_target_effect'] is bool(any(changes))
        for prefix in ('td_rho', 'td_delta_unweighted', 'td_delta_weighted'):
            values = {key: diagnostic[f'{prefix}_{key}'] for key in ('min', 'max', 'mean', 'std', 'max_abs')}
            if count:
                assert all(value is not None and math.isfinite(value) for value in values.values())
                assert values['min'] <= values['mean'] <= values['max'] and values['std'] >= 0 and values['max_abs'] >= 0
            else:
                assert all(value is None for value in values.values())
        if count:
            assert diagnostic['td_rho_min'] >= 0 and (diagnostic['td_rho_max'] > 1) is bool(above)
            maximum_rho = max(maximum_rho, diagnostic['td_rho_max'])
            maximum_weighted_td_abs = max(maximum_weighted_td_abs, diagnostic['td_delta_weighted_max_abs'])
            maximum_weighted_td_std = max(maximum_weighted_td_std, diagnostic['td_delta_weighted_std'])
        else:
            assert changes == [0, 0] and diagnostic['td_delta_weight_change_rmse'] == 0.
        active += int(diagnostic['split_td_active'])
        effects += int(diagnostic['split_td_target_effect'])
        above_total += above
        weighted_td_nonzero += diagnostic['td_delta_weight_change_nonzero_count']
        actor_nonzero += changes[0]
        critic_nonzero += changes[1]
    assert active > 0 and effects > 0 and weighted_td_nonzero > 0 and actor_nonzero > 0 and critic_nonzero > 0
    return {'split_td_activity_checks': 'passed', 'split_td_active_updates': active,
            'split_td_target_effect_updates': effects, 'td_rho_above_one_total': above_total,
            'td_delta_weight_change_nonzero_total': weighted_td_nonzero,
            'split_vs_capped_actor_nonzero_total': actor_nonzero, 'split_vs_capped_critic_nonzero_total': critic_nonzero,
            'maximum_actual_td_rho': maximum_rho, 'maximum_rho_weighted_td_abs': maximum_weighted_td_abs,
            'maximum_rho_weighted_td_std': maximum_weighted_td_std,
            'fresh_and_late_split_vs_capped_exactly_zero': True}

def verify_correction(diagnostics, incoming, config):
    """Replay correction activity/count constraints; fresh and late targets stay exact."""
    active = actor_nonzero = critic_nonzero = raw_nonfinite = capped_below_one = 0
    actor_rmse, critic_rmse = [], []
    for diag, retained in zip(diagnostics, incoming):
        retained_count = retained * 1024
        fresh_count = diag['fresh_per_world'] * 1024
        total_count = retained_count + fresh_count
        assert diag['trace_correction_enabled'] is True
        assert diag['trace_correction_version'] == config['retained_tail_trace_design']['version']
        assert .90<=diag['trace_lambda']<=.99 and diag['critic_trace_lambda']==(.99 if diag['steps']<=config['stage_switch_steps'] else .95) and diag['trace_ratio_cap']==1.
        for key in ('logratio_finite_count', 'capped_ratio_finite_count',
                    'actor_correction_finite_count', 'critic_correction_finite_count'):
            assert diag[key] == total_count, (key, diag[key], total_count)
        assert diag['fresh_capped_ratio_equal_one_count'] == fresh_count
        for kind in ('actor', 'critic'):
            assert diag[f'fresh_{kind}_correction_finite_count'] == fresh_count
            assert diag[f'fresh_{kind}_correction_nonzero_count'] == 0
            assert diag[f'fresh_{kind}_correction_max_abs'] == 0.
            assert 0 <= diag[f'{kind}_correction_nonzero_count'] <= retained_count
            assert diag[f'{kind}_correction_rmse'] is not None and diag[f'{kind}_correction_rmse'] >= 0
        finite = diag['importance_ratio_finite_count']
        nonfinite = diag['importance_ratio_nonfinite_count']
        assert 0 <= finite <= retained_count and 0 <= nonfinite <= retained_count
        assert finite + nonfinite == retained_count
        assert 0 <= diag['capped_ratio_min'] <= diag['capped_ratio_mean'] <= diag['capped_ratio_max'] == 1.
        below = diag['capped_ratio_below_one_count']
        assert 0 <= below <= retained_count
        assert diag['active_correction'] is bool(below)
        assert (diag['capped_ratio_min'] < 1.) == bool(below)
        if retained:
            assert diag['logratio_min'] <= diag['logratio_max']
        else:
            assert diag['logratio_min'] is None and diag['logratio_max'] is None
            assert diag['actor_correction_rmse'] == diag['critic_correction_rmse'] == 0.
            assert diag['actor_correction_nonzero_count'] == diag['critic_correction_nonzero_count'] == below == 0
        if finite:
            assert 0 <= diag['importance_ratio_min'] <= diag['importance_ratio_mean'] <= diag['importance_ratio_max']
            assert diag['importance_ratio_std'] >= 0
        else:
            assert all(diag[f'importance_ratio_{key}'] is None for key in ('min', 'max', 'mean', 'std'))
        active += int(diag['active_correction'])
        actor_nonzero += diag['actor_correction_nonzero_count']
        critic_nonzero += diag['critic_correction_nonzero_count']
        raw_nonfinite += nonfinite
        capped_below_one += below
        actor_rmse.append(diag['actor_correction_rmse'])
        critic_rmse.append(diag['critic_correction_rmse'])
    assert active > 0 and actor_nonzero > 0 and critic_nonzero > 0, 'Correction had no measured target effect'
    return {'correction_activity_checks': 'passed', 'active_correction_updates': active,
            'capped_ratio_below_one_total': capped_below_one,
            'actor_correction_nonzero_total': actor_nonzero, 'critic_correction_nonzero_total': critic_nonzero,
            'raw_importance_ratio_nonfinite_total': raw_nonfinite,
            'maximum_actor_correction_rmse': max(actor_rmse), 'maximum_critic_correction_rmse': max(critic_rmse),
            'fresh_and_late_correction_exactly_zero': True}

def differences(a, b, path=''):
    if isinstance(a, torch.Tensor):
        return [] if isinstance(b, torch.Tensor) and a.dtype == b.dtype and a.shape == b.shape and torch.equal(a, b) else [path]
    if isinstance(a, dict):
        if not isinstance(b, dict) or a.keys() != b.keys():
            return [path + '.keys']
        return [d for key in a for d in differences(a[key], b[key], path + '.' + str(key))]
    if isinstance(a, (list, tuple)):
        if type(a) != type(b) or len(a) != len(b):
            return [path + '.length']
        return [d for i, (x, y) in enumerate(zip(a, b)) for d in differences(x, y, path + '.' + str(i))]
    return [] if a == b else [path]
