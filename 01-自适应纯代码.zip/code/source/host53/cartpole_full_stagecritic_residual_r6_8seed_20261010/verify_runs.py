"""Native exact mechanism replay plus complete-cohort descriptive comparisons."""
import argparse,csv,hashlib,itertools,json,math,os,statistics
from pathlib import Path
import torch
from scientific_replay import (verify_i1,verify_i2,verify_fixed_critic_audits,
    verify_split_trace_audits,checkpoint_steps,fixed_audit_names,split_audit_names,differences)

ROOT=Path(__file__).resolve().parent
METHODS=('full',)
DET={'torch':True,'warp':'run_to_run','warp_max_records':8,'cublas_workspace_config':':4096:8'}
def require(x,why):
    if not x:raise AssertionError(why)
def read(p):return json.loads(Path(p).read_text())
def lines(p):return [json.loads(s) for s in Path(p).read_text().splitlines() if s.strip()]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
    p=Path(p);t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n');t.replace(p)
def verify_manifest(expected):
    p=ROOT/'SOURCE_MANIFEST.json';require(sha(p)==expected,'manifest identity')
    for n,h in read(p)['files'].items():require(sha(ROOT/n)==h,('source',n))

def verify(path,method,task,seed,steps,device,manifest_sha):
    verify_manifest(manifest_sha)
    p=Path(path);c=read(p/'config.json');s=read(p/'summary.json')
    require(s==read(p/'status.json') and s['state']=='completed' and s['reload_check']=='passed','terminal reload')
    require(c['task']==task and c['seed']==seed and c['effective_steps']==s['steps']==steps,'task/seed/fresh budget')
    require(c['determinism']==DET and c['suite_manifest_sha256']==manifest_sha,'determinism/exact source')
    for k,v in dict(num_envs=1024,rollout=64,batch_size=1024,epochs=10,eval_envs=32,eval_every=262144,device=device,gamma=.99,network=[64,64]).items():
        require(c[k]==v,('config',k))
    horizon={'PointMaze':300,'CartpoleSwingup':1000}[task]
    require(c['task_adapter']['horizon']==horizon,'same environment horizon')
    rows=list(csv.DictReader((p/'progress.csv').open()));job={'path':str(p),'arm':method,'device':device,'gpu':int(device.split(':')[1])}
    torch.set_num_threads(1);torch.cuda.set_device(device);torch.use_deterministic_algorithms(True)
    short=steps==524288
    require(c['adaptive_kl'] and c['staged_full'] and c['retained_td_unclipped'] and c['save_split_trace_audit'],'Full composition')
    require(c['full_composition']['critic_lambda']=='stage99to95' and c['full_composition']['staged_lambda_hold'] is False,'fixed critic / early actor adaptation')
    require(c['stage_switch_steps']==(262144 if short else 4980736),'I2 stage cutoff')
    require(s['training_transitions']==s['total_algorithm_transitions']==steps,'no extra interactions')
    require(s['optimizer_steps']=={'actor':steps//1024*10,'critic':steps//1024*10,'h':0},'optimizer budgets')
    vals,detail=verify_i2(rows,p,c,short);detail.update(verify_split_trace_audits(job,c,short))
    from scientific_replay import controller_class
    controller=controller_class()();decisions=lines(p/'lambda_decisions.jsonl');require(len(decisions)==len(rows),'every update controller')
    changed=0
    row_steps=[d["steps"] for d in decisions]
    for u,(row,d) in enumerate(zip(rows,decisions),1):
        require(d['update']==u and d['steps']==int(row['steps']) and d['used']==controller.value==float(row['gae_lambda_used']),'causal actor lambda')
        require(d['critic_lambda']==(.99 if d['steps']<=c['stage_switch_steps'] else .95) and not d['readiness_active'],'fixed critic, no readiness')
        require(math.isfinite(d['explained_variance']),'finite residual observer')
        residual=math.sqrt(min(1.,max(0.,1.-d['explained_variance'])))
        require(d['relative_value_residual']==residual and d['controller_signal']=='normalized_value_residual','exact observer scalar')
        controller.observe(residual);controller.step(u+1)
        require(d['next']==controller.value==float(row['gae_lambda_next']),'controller next')
        for k,v in controller.state_dict().items():require(d[k]==v,('exact controller',k))
        changed+=int(abs(d['used']-.99)>1e-12)
    require(changed>0 and [d['used'] for d in decisions[:8]]==[.99]*8,'actual warm-reference adaptation')
    require(c['initial_lambda']==.99 and c['full_composition']['target_anchor']==.98,'high trace prior config')
    require(any(d['used']<.99 for d in decisions),'entirely fixed99 is not adaptive success')
    detail.update(controller_replay='passed',changed_updates=changed,changed_updates_reference=.99,controller_observations=len(decisions),critic_lambda='stage99to95',critic_early_observations=sum(d['critic_lambda']==.99 for d in decisions),critic_late_observations=sum(d['critic_lambda']==.95 for d in decisions))
    separated=0
    from scientific_replay import source_i2_functions,split_audit_names
    fun=source_i2_functions()
    for name in split_audit_names(c):
        a=torch.load(p/name,map_location='cpu',weights_only=False)
        rr=a['consumed_critic_return'].to(device).flatten();vv=a['values'][:a['used_per_world']].to(device).flatten()
        ev_actual=float(1-(rr-vv).var(unbiased=False)/(rr.var(unbiased=False)+1e-8))
        require(ev_actual==decisions[a['update']-1]['explained_variance'],'actual frozen target/value residual native replay')
        if a['actor_lambda']!=a['critic_lambda']:
            inp=[a[k].to(device) for k in ['normalized_reward','values','next_values','terminated','done']]
            _,adaptive_ret=fun.split_tail_trace(*inp,a['raw_rhos'].to(device),a['capped_cs'].to(device),.99,a['actor_lambda'])
            separated+=int(not torch.equal(adaptive_ret[:a['used_per_world']],a['consumed_critic_return'].to(device)))
    require(separated>0,'actor adaptive versus fixed critic targets must separate')
    detail['separated_target_audits']=separated
    for name,h in c['source_sha256'].items():require(sha(ROOT/'source_i2'/name)==h,('trainer source',name))
    ck=checkpoint_steps(p,method,steps//1024*10);require(ck['steps']==steps,'checkpoint steps')
    initial=read(p/'initial_evaluation.json');ev=lines(p/'evaluations.jsonl')
    require(len(ev)==(2 if short else 39),'full evaluation schedule')
    for e in [initial,*ev]:
        require(len(e['returns'])==32 and e['lengths']==[horizon]*32,'complete fixed-horizon episodes')
        require(all(math.isfinite(x) for x in e['returns']),'finite return')
        require(abs(statistics.mean(e['returns'])-e['mean'])<2e-4,'reported episode mean')
    require(ev[-1]['steps']==steps and ev[-1]['returns']==s['final_eval']['returns'],'final evaluation')
    expected=[];nxt=262144
    for row in rows:
        k=int(row['steps'])
        if k>=nxt or k==steps:expected.append(k);nxt=(k//262144+1)*262144
    require([e['steps'] for e in ev]==expected,'evaluations tied to actual fresh budget')
    pts=[(0,initial['mean'])]+[(e['steps'],e['mean']) for e in ev]
    require(all(a[0]<b[0] for a,b in zip(pts,pts[1:])),'chronology')
    auc=sum((b[0]-a[0])*(a[1]+b[1])/2 for a,b in zip(pts,pts[1:]))/steps
    if 'normalized_return_auc' in s:require(abs(auc-s['normalized_return_auc'])<1e-10,'AUC replay')
    baseline=ROOT/'references'/f'{task}_fixed95_initial_seed{seed}.json'
    if not short:require(initial==read(baseline),'same-seed baseline initialization/evaluation')
    result=dict(state='passed',task=task,method=method,seed=seed,device=device,steps=steps,updates=len(rows),
        final_return=ev[-1]['mean'],auc=auc,initial_return=initial['mean'],elapsed_seconds=s['elapsed_seconds'],
        total_algorithm_transitions=steps,lambda_min=min(vals),lambda_max=max(vals),suite_manifest_sha256=manifest_sha,**detail)
    write(p/'VERIFIED.json',result);return result

def pair(a,b,method):
    a,b=Path(a),Path(b);cks=[torch.load(p/'latest.pt',map_location='cpu',weights_only=False) for p in (a,b)]
    for ck in cks:ck['config'].pop('out');ck['config'].pop('device')
    errors=differences(*cks)
    for name in ['initial_evaluation.json','evaluations.jsonl', 'retained_tail_diagnostics.jsonl','lambda_decisions.jsonl']:
        if (a/name).read_bytes()!=(b/name).read_bytes():errors.append(name)
    names=(fixed_audit_names if method=='innovation1' else split_audit_names)(cks[0]['config'])
    for name in names:
        records=[torch.load(p/name,map_location='cpu',weights_only=False) for p in (a,b)]
        errors.extend(differences(*records,path=name))
    if method=='innovation1':require(read(a/'stress_evaluation.json')==read(b/'stress_evaluation.json'),'repeat stress')
    xs=list(csv.DictReader((a/'progress.csv').open()));ys=list(csv.DictReader((b/'progress.csv').open()))
    require(len(xs)==len(ys),'repeat count')
    for x,y in zip(xs,ys):
        for k in x:
            if k not in ('elapsed_seconds','steps_per_second') and x[k]!=y[k]:errors.append('progress.'+k)
    require(not errors,errors)
    return dict(state='passed',checkpoint_exact=True,evaluations_and_decisions_exact=True,non_timing_progress_exact=True,target_audits_exact=True)

def aggregate(out,task,manifest_sha):
    out=Path(out);rows=[read(out/'runs'/f'{task}__{m}__seed{s}'/'VERIFIED.json') for m in METHODS for s in range(21,29)]
    require(len(rows)==8 and all(r['state']=='passed' and r['suite_manifest_sha256']==manifest_sha for r in rows),'all16 exact verified')
    means=[]
    for method in METHODS:
        rs=[r for r in rows if r['method']==method]
        means.append(dict(method=method,n=8,final_mean=statistics.mean(r['final_return'] for r in rs),final_sd=statistics.stdev(r['final_return'] for r in rs),auc_mean=statistics.mean(r['auc'] for r in rs),auc_sd=statistics.stdev(r['auc'] for r in rs)))
    refs=read(ROOT/'references'/f'{task}_baseline_rows.json');base={r['seed']:r for r in refs if r['method']=='fixed95'}
    require(set(base)==set(range(21,29)),'all8 fixed95 controls')
    standalone=read(ROOT/'references'/f'{task}_standalone_rows.json')
    require(len(refs)==64 and {(r['method'],r['seed']) for r in refs}=={(m,k) for m in ('fixed90','fixed95','fixed99','linear','critic_aware','gradient_ppo','reward_profiling','pae') for k in range(21,29)},'complete all64 baseline coverage before comparisons')
    by={(r['method'],r['seed']):r for r in refs+standalone+rows};groups={}
    for size in (3,5):
        passed=[]
        for group in itertools.combinations(range(21,29),size):
            if all(statistics.mean(by[m,s][ep]-base[s][ep] for s in group)>0 for m in ('innovation1','innovation2') for ep in ('final_return','auc')) and all(statistics.mean(by['full',s][ep]-by[m,s][ep] for s in group)>0 for m in ('innovation1','innovation2','fixed90','fixed95','fixed99','linear','critic_aware','gradient_ppo','reward_profiling','pae') for ep in ('final_return','auc')):passed.append(list(group))
        groups[str(size)]={'complete_joint_order_count':len(passed),'passing_seed_groups':passed}
    paired=[dict(method=r['method'],seed=r['seed'],final_difference=r['final_return']-base[r['seed']]['final_return'],auc_difference=r['auc']-base[r['seed']]['auc']) for r in rows]
    write(out/'RESULTS.json',dict(state='completed',task=task,seeds=list(range(21,29)),formal_unique_runs=8,all_seeds=rows,means=means,paired_base=paired,common_groups=groups,
          interpretation='Outcome-selected common subsets are exploratory development comparisons, not confirmatory significance. Full8 and all failures retained. All internal/external controls and standalone arms compared using identical seeds.',suite_manifest_sha256=manifest_sha))
    for name,data in [('per_seed.csv',rows),('means.csv',means),('paired_base.csv',paired)]:
        fields=list(dict.fromkeys(k for r in data for k in r if not isinstance(r[k],(dict,list))))
        with (out/name).open('w') as f:w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(data)
    return dict(state='completed',rows=8,task=task,means=means,common_group_counts={k:v['complete_joint_order_count'] for k,v in groups.items()})

def main():
    p=argparse.ArgumentParser();p.add_argument('--kind',choices=['run','pair','aggregate'],required=True);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--task',choices=['PointMaze','CartpoleSwingup'],required=True);p.add_argument('--method',choices=METHODS)
    p.add_argument('--seed',type=int);p.add_argument('--steps',type=int);p.add_argument('--device');p.add_argument('--manifest-sha',required=True);p.add_argument('--a',type=Path);p.add_argument('--b',type=Path)
    a=p.parse_args()
    if a.kind=='run':v=verify(a.out,a.method,a.task,a.seed,a.steps,a.device,a.manifest_sha)
    elif a.kind=='pair':
        for path in (a.a,a.b):verify(path,a.method,a.task,a.seed,a.steps,a.device,a.manifest_sha)
        v=pair(a.a,a.b,a.method);write(a.out,v)
    else:v=aggregate(a.out,a.task,a.manifest_sha)
    print(json.dumps(v,allow_nan=False),flush=True)
if __name__=='__main__':main()
