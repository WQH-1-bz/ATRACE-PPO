"""GPU MuJoCo matched-backbone ports; not original-paper score reproductions."""
import argparse
import copy
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import time
os.environ.setdefault('OMP_NUM_THREADS', '1')
os.environ.setdefault('MKL_NUM_THREADS', '1')
if os.environ.get('DPO_TORCH_DETERMINISTIC') == '1':
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import numpy as np
import torch
from torch import nn
from train_noisy_warp import ActorCritic, RunningStats, gae, evaluate, write_json
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "env_source"))
from new_tasks_warp import LocomotionWarp, ASSETS, TASKS, TASK_META
from external_baseline_algorithms import critic_lambda, tdrc_losses, copy_policy, restore_lookback, step_loss
from lambda_kl_relative import KLFeedback

if os.environ.get('DPO_TORCH_DETERMINISTIC') == '1':
    torch.use_deterministic_algorithms(True)


def append_json(path, data):
    with path.open('a') as f:
        f.write(json.dumps(data, allow_nan=False) + '\n')


def finite_drift_metrics(delta):
    """Descriptive retained-sample drift; filter nonfinite values explicitly."""
    values = delta.detach().double()
    values = values[torch.isfinite(values)]
    if not values.numel():
        return {'finite_count': 0, 'mean_abs': None, 'rmse': None}
    return {'finite_count': values.numel(), 'mean_abs': float(values.abs().mean()),
            'rmse': float(values.square().mean().sqrt())}


@torch.jit.script
def capped_tail_trace(rewards, values, next_values, terminated, done, capped_ratios,
                      gamma: float = .99, lam: float = .95):
    """Capped future-action trace: actor excludes its own action weight.

    D_t = b_t A_t, A_t = delta_t + gamma*lambda*(1-done_t)*D_(t+1).
    Critic targets are V_t + D_t.  This is a lambda-GAE-compatible
    V-trace variant, not the original IMPALA actor or an unbiased target.
    """
    advantages = torch.zeros_like(rewards)
    corrections = torch.zeros_like(rewards)
    carry = torch.zeros_like(rewards[0])
    for t in range(rewards.shape[0] - 1, -1, -1):
        delta = rewards[t] + gamma * (~terminated[t]).float() * next_values[t] - values[t]
        actor_advantage = delta + gamma * lam * (~done[t]).float() * carry
        advantages[t] = actor_advantage
        carry = capped_ratios[t] * actor_advantage
        corrections[t] = carry
    return advantages, corrections + values


@torch.jit.script
def split_tail_trace(rewards, values, next_values, terminated, done, raw_rhos, capped_cs,
                     gamma: float = .99, lam: float = .95):
    """Unclipped own-TD density weight and capped continuation; PPO owns own ratio."""
    advantages = torch.zeros_like(rewards)
    corrections = torch.zeros_like(rewards)
    carry = torch.zeros_like(rewards[0])
    for t in range(rewards.shape[0] - 1, -1, -1):
        delta = rewards[t] + gamma * (~terminated[t]).float() * next_values[t] - values[t]
        actor_advantage = delta + gamma * lam * (~done[t]).float() * carry
        advantages[t] = actor_advantage
        # rho*delta + gamma*lambda*c*D_next; preserve the old all-one path.
        carry = capped_cs[t] * actor_advantage + (raw_rhos[t] - capped_cs[t]) * delta
        corrections[t] = carry
    return advantages, corrections + values


def split_td_diagnostics(raw_rhos, capped_cs, delta, split_actor_delta, split_critic_delta,
                         retained_per_world):
    rho = raw_rhos[:retained_per_world].detach().double()
    td = delta[:retained_per_world].detach().double()
    weighted = rho * td
    change = (rho - capped_cs[:retained_per_world].detach().double()) * td
    fresh_rho = raw_rhos[retained_per_world:]
    result = {
        'td_weight_policy': 'unclipped_current_over_behavior', 'td_ratio_cap': None,
        'continuation_ratio_cap': 1.0, 'td_rho_stats_scope': 'retained_rows',
        'td_rho_finite_count': int(torch.isfinite(rho).sum()),
        'td_rho_nonfinite_count': int((~torch.isfinite(rho)).sum()),
        'td_rho_above_one_count': int((rho > 1).sum()),
        'td_rho_below_one_count': int((rho < 1).sum()),
        'td_rho_equal_one_count': int((rho == 1).sum()),
        'fresh_td_rho_equal_one_count': int((fresh_rho == 1).sum()),
        'td_delta_weight_change_nonzero_count': int(torch.count_nonzero(change)),
        'td_delta_weight_change_rmse': float(change.square().mean().sqrt()) if change.numel() else 0.0,
    }
    for name, tensor in [('td_rho', rho), ('td_delta_unweighted', td), ('td_delta_weighted', weighted)]:
        result[name + '_mean'] = float(tensor.mean()) if tensor.numel() else None
        result[name + '_std'] = float(tensor.std(unbiased=False)) if tensor.numel() else None
        result[name + '_min'] = float(tensor.min()) if tensor.numel() else None
        result[name + '_max'] = float(tensor.max()) if tensor.numel() else None
        result[name + '_max_abs'] = float(tensor.abs().max()) if tensor.numel() else None
    for name, tensor in [('actor', split_actor_delta), ('critic', split_critic_delta)]:
        result[f'split_vs_capped_{name}_rmse'] = finite_drift_metrics(tensor)['rmse']
        result[f'split_vs_capped_{name}_nonzero_count'] = int(torch.count_nonzero(tensor))
        fresh = tensor[retained_per_world:]
        result[f'fresh_split_vs_capped_{name}_nonzero_count'] = int(torch.count_nonzero(fresh))
        result[f'fresh_split_vs_capped_{name}_max_abs'] = float(fresh.abs().max()) if fresh.numel() else 0.0
    result['split_td_active'] = result['td_rho_above_one_count'] > 0
    result['split_td_target_effect'] = bool(result['split_vs_capped_actor_nonzero_count'] or
                                           result['split_vs_capped_critic_nonzero_count'])
    return result


def save_split_trace_audit(path, rewards, values, next_values, terminated, done, trace_logratios,
                           raw_rhos, capped_cs, flat_actor_advantage, flat_critic_return,
                           used_lambda, update, steps, prior_collected_steps, used_per_world,
                           retained_per_world, critic_lambda):
    """Capture frozen inputs and the actual flat targets passed to PPO losses."""
    tensors = {
        'normalized_reward': rewards, 'values': values, 'next_values': next_values,
        'terminated': terminated, 'done': done, 'trace_logratios': trace_logratios,
        'raw_rhos': raw_rhos, 'capped_cs': capped_cs,
        'actor_advantage': flat_actor_advantage.reshape(used_per_world, rewards.shape[1]),
        'consumed_critic_return': flat_critic_return.reshape(used_per_world, rewards.shape[1]),
    }
    record = {key: value.detach().cpu().clone() for key, value in tensors.items()}
    record.update(actor_lambda=used_lambda, critic_lambda=critic_lambda, gamma=.99,
                  update=update, steps=steps, prior_collected_steps=prior_collected_steps,
                  used_per_world=used_per_world, retained_per_world=retained_per_world,
                  end_per_world=rewards.shape[0], target_device=str(rewards.device))
    torch.save(record, path)


def trace_correction_diagnostics(logratios, capped_ratios, actor_delta, critic_delta,
                                 retained_per_world, used_lambda):
    """Frozen-target measurements only; no sampling or training feedback."""
    retained = logratios[:retained_per_world].detach().double()
    raw_ratios = retained.exp()
    finite_raw_ratios = raw_ratios[torch.isfinite(raw_ratios)]
    ratio_scale = finite_raw_ratios.max() if finite_raw_ratios.numel() else None
    scaled_ratios = finite_raw_ratios / ratio_scale if ratio_scale is not None and ratio_scale > 0 else finite_raw_ratios
    capped = capped_ratios.detach().double()
    actor = finite_drift_metrics(actor_delta)
    critic = finite_drift_metrics(critic_delta)
    fresh_actor = actor_delta[retained_per_world:]
    fresh_critic = critic_delta[retained_per_world:]
    return {
        'trace_correction_version': 'capped_future_action_trace_v1',
        'trace_correction_enabled': True,
        'trace_lambda': used_lambda,
        'trace_ratio_cap': 1.0,
        'active_correction': bool((capped < 1).any()),
        'logratio_min': float(retained.min()) if retained.numel() else None,
        'logratio_max': float(retained.max()) if retained.numel() else None,
        'importance_ratio_min': float(finite_raw_ratios.min()) if finite_raw_ratios.numel() else None,
        'importance_ratio_max': float(finite_raw_ratios.max()) if finite_raw_ratios.numel() else None,
        'importance_ratio_mean': float(ratio_scale * scaled_ratios.mean()) if finite_raw_ratios.numel() else None,
        'importance_ratio_std': float(ratio_scale * scaled_ratios.std(unbiased=False)) if finite_raw_ratios.numel() else None,
        'importance_ratio_finite_count': finite_raw_ratios.numel(),
        'importance_ratio_nonfinite_count': raw_ratios.numel() - finite_raw_ratios.numel(),
        'capped_ratio_min': float(capped.min()),
        'capped_ratio_max': float(capped.max()),
        'capped_ratio_mean': float(capped.mean()),
        'capped_ratio_below_one_count': int((capped < 1).sum()),
        'capped_ratio_finite_count': int(torch.isfinite(capped).sum()),
        'fresh_capped_ratio_equal_one_count': int((capped[retained_per_world:] == 1).sum()),
        'logratio_finite_count': int(torch.isfinite(logratios).sum()),
        'actor_correction_rmse': actor['rmse'],
        'critic_correction_rmse': critic['rmse'],
        'actor_correction_finite_count': actor['finite_count'],
        'critic_correction_finite_count': critic['finite_count'],
        'actor_correction_nonzero_count': int(torch.count_nonzero(actor_delta)),
        'critic_correction_nonzero_count': int(torch.count_nonzero(critic_delta)),
        'fresh_actor_correction_nonzero_count': int(torch.count_nonzero(fresh_actor)),
        'fresh_critic_correction_nonzero_count': int(torch.count_nonzero(fresh_critic)),
        'fresh_actor_correction_max_abs': float(fresh_actor.abs().max()) if fresh_actor.numel() else 0.0,
        'fresh_critic_correction_max_abs': float(fresh_critic.abs().max()) if fresh_critic.numel() else 0.0,
        'fresh_actor_correction_finite_count': int(torch.isfinite(fresh_actor).sum()),
        'fresh_critic_correction_finite_count': int(torch.isfinite(fresh_critic).sum()),
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--method', choices=['pae'], required=True)
    p.add_argument('--task', choices=list(TASKS), required=True)
    p.add_argument('--seed', type=int, required=True)
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--steps', type=int, default=10027008)
    p.add_argument('--num-envs', type=int, default=1024)
    p.add_argument('--rollout', type=int, default=64)
    p.add_argument('--batch-size', type=int, default=1024)
    p.add_argument('--eval-envs', type=int, default=32)
    p.add_argument('--eval-every', type=int, default=262144)
    p.add_argument('--profile-chunks', type=int, default=10)
    p.add_argument('--adaptive-kl', action='store_true')
    p.add_argument('--readiness-boost', action='store_true')
    p.add_argument('--staged-full', action='store_true')
    p.add_argument('--stage-switch-steps', type=int, default=1048576)
    p.add_argument('--retained-tail-steps', type=int, default=16)
    p.add_argument('--retained-tail-diagnostics', action='store_true')
    p.add_argument('--retained-tail-correction', action='store_true')
    p.add_argument('--retained-td-unclipped', action='store_true')
    p.add_argument('--save-split-trace-audit', action='store_true')
    p.add_argument('--adaptive-overlap', action='store_true')
    p.add_argument('--force-pae-overlap', action='store_true')
    p.add_argument('--overlap-lambda-threshold', type=float, default=.964)
    p.add_argument('--overlap-start-steps', type=int, default=1572864)
    p.add_argument('--overlap-stop-steps', type=int, default=8388608)
    a = p.parse_args()
    assert min(a.steps, a.num_envs, a.rollout, a.batch_size, a.eval_envs, a.eval_every, a.profile_chunks) > 0
    assert a.stage_switch_steps > 0 and a.stage_switch_steps % a.num_envs == 0
    assert 0 <= a.retained_tail_steps < a.rollout
    if a.retained_tail_correction:
        assert a.retained_tail_diagnostics, 'Trace correction requires retained-tail diagnostics on every window'
        assert a.staged_full and a.rollout == 64 and a.retained_tail_steps == 16
        assert a.adaptive_kl and not (a.readiness_boost or a.adaptive_overlap or a.force_pae_overlap), 'Full uses warm-reference adaptive actor, fixed99 critic and I2 staged windows'
    if a.retained_td_unclipped:
        assert a.retained_tail_correction and a.retained_tail_diagnostics and a.staged_full and a.retained_tail_steps == 16
    if a.save_split_trace_audit:
        assert a.retained_td_unclipped, 'Split-trace audit requires --retained-td-unclipped'
    assert .90 <= a.overlap_lambda_threshold <= .99
    assert a.rollout % 32 == 0 and a.batch_size % 32 == 0
    assert torch.cuda.is_available() and a.device.startswith('cuda:')
    a.out.mkdir(parents=True, exist_ok=False)
    torch.set_num_threads(1)
    torch.cuda.set_device(a.device)
    torch.random.default_generator.manual_seed(a.seed)
    torch.cuda.manual_seed(a.seed)
    np.random.seed(a.seed)
    size = a.rollout * a.num_envs
    effective_steps = math.ceil(a.steps / a.num_envs) * a.num_envs
    assert 0 <= a.overlap_start_steps < a.overlap_stop_steps <= effective_steps
    tail = a.retained_tail_steps
    prefix = a.rollout - tail
    total_time = effective_steps // a.num_envs
    stage_switch_time = a.stage_switch_steps // a.num_envs
    updates = 1 + math.ceil(max(0, total_time - a.rollout) / prefix)
    if a.staged_full:
        assert a.rollout <= stage_switch_time < total_time
        early_updates = 1 + math.ceil(max(0, stage_switch_time - a.rollout) / prefix)
        updates = early_updates + math.ceil((total_time - stage_switch_time) / a.rollout)
    split_trace_audit_updates = [3, early_updates - 1, updates] if a.save_split_trace_audit else []
    if a.save_split_trace_audit:
        assert len(set(split_trace_audit_updates)) == 3 and early_updates > 4
    collected_time = 0
    filled = 0
    epochs = 4 if a.method == 'gradient_ppo' else 10
    config = {**vars(a), 'out': str(a.out), 'effective_steps': effective_steps, 'pae_prefix': prefix, 'pae_tail': tail, 'pae_ratio': prefix / a.rollout,
              'epochs': epochs, 'gamma': .99, 'initial_lambda': .99,
              'backend': 'GPU MuJoCo Warp, official new-task semantics',
              'task_adapter': TASK_META[a.task], 'suite_manifest_sha256': os.environ.get('DPO_SUITE_MANIFEST_SHA256'),
              'normalization': 'running observation and discounted-return reward normalization',
              'network': [64, 64], 'clip': .2, 'grad_clip': .5, 'adam_eps': 1e-5,
              'actor_lr': 3e-4, 'critic_lr': .003 if a.method == 'gradient_ppo' else .0003,
              'anneal_lr': a.method == 'critic_aware',
              'method_spec': 'EXTERNAL_BASELINE_PROTOCOL.md',
              'determinism': {'torch': torch.are_deterministic_algorithms_enabled(),
                  'warp': os.environ.get('DPO_WARP_DETERMINISTIC', 'not_guaranteed'),
                  'warp_max_records': int(os.environ.get('DPO_WARP_DETERMINISTIC_MAX_RECORDS', '0')),
                  'cublas_workspace_config': os.environ.get('CUBLAS_WORKSPACE_CONFIG')},
              'xml_sha256': hashlib.sha256((ASSETS / TASKS[a.task][0]).read_bytes()).hexdigest(),
              'source_sha256': {f: hashlib.sha256((Path(__file__).parent / f).read_bytes()).hexdigest()
                                for f in ['train_pae_baseline.py', 'external_baseline_algorithms.py', '../env_source/new_tasks_warp.py', 'train_noisy_warp.py', 'ant_contact_compat.py']}}
    config['full_composition'] = {'actor_lambda': 'normalized_value_residual_dual_time_scale', 'critic_lambda': 'stage99to95', 'critic_early_lambda': .99, 'critic_late_lambda': .95, 'initial_statistics': 'arithmetic_mean_first4_relative_value_residuals', 'adaptive_clock': 'actual_optimizer_windows', 'staged_lambda_hold': False, 'target_amplitude': 0.01, 'target_anchor': 0.98, 'initial_actor_lambda': 0.99}
    config['adaptive_lambda_design'] = {'enabled': a.adaptive_kl, 'version': 'high_trace_normalized_value_residual_v1',
        'readiness_enabled': a.readiness_boost, 'readiness_signal': 'previous-window explained variance',
        'readiness_threshold': .45, 'readiness_until_update': 16, 'readiness_target': .99,
        'readiness_max_step': .02, 'kl_fast_alpha': .1, 'kl_slow_alpha': .01,
        'lambda_bounds': [.98,.99], 'controller_input':'sqrt(clip(1-explained_variance,0,1))', 'extra_environment_steps': 0}
    config['staged_full_design'] = {'enabled':a.staged_full,'switch_steps':a.stage_switch_steps,
        'early_stage':f'PAE prefix={prefix} tail={tail}',
        'late_stage':'standard non-overlap rollout=64 with KLF2' if a.adaptive_kl else 'standard non-overlap rollout=64, fixed lambda=0.99',
        'boundary_policy':'train the complete final early-stage window before switching',
        'advantage_std_unbiased':False,
        'switch_signal':'cumulative training transitions only','evaluation_return_used':False}
    config['adaptive_overlap_design'] = {'enabled':a.adaptive_overlap,
        'lambda_threshold':a.overlap_lambda_threshold,'start_steps':a.overlap_start_steps,
        'stop_steps':a.overlap_stop_steps,
        'rule':f'reuse a {tail}-step tail only while the causal KLF2 lambda state is at or above the threshold',
        'evaluation_return_used':False,'extra_environment_steps':0}
    config['retained_tail_trace_design'] = {
        'enabled': a.retained_tail_correction, 'version': 'capped_future_action_trace_v1',
        'label': 'capped future-action trace / lambda-GAE-compatible V-trace variant',
        'fixed_lambda': None, 'actor_lambda':'adaptive', 'critic_lambda':'stage99to95', 'ratio_cap': 1.0, 'lower_ratio_clip': None,
        'ratio_definition': 'exp(current frozen Gaussian latent-action logdensity minus original behavior logdensity)',
        'fresh_ratio': 'exactly 1 at frozen-target construction',
        'capped_ratio': 'exp(min(logratio, 0))',
        'delta': 'reward + gamma*(1-terminated)*next_value - value',
        'critic_correction': 'D_t = b_t*(delta_t + gamma*lambda*(1-done_t)*D_next)',
        'actor_advantage': 'A_t = delta_t + gamma*lambda*(1-done_t)*D_next; own b_t excluded',
        'critic_return': 'value_t + D_t', 'ppo_ratio': 'epoch policy / original behavior; unchanged',
        'horizon_correction': 0.0, 'truncation_bootstrap': 'stored final observation; stop trace at done',
        'targets_frozen_before_epochs': True, 'unbiased_claim': False,
        'original_impala_actor': False, 'evaluation_return_used': False,
        'diagnostics_control_training': False, 'extra_environment_steps': 0,
        'extra_optimizer_steps': 0}
    if a.retained_td_unclipped:
        config['retained_tail_trace_design'].update(
            version='split_td_continuation_trace_v1',
            label='unclipped TD density weight / capped continuation lambda trace',
            td_weight_policy='unclipped_current_over_behavior',
            continuation_weight_policy='min(1,current_over_behavior)',
            td_ratio_cap=None, trace_ratio_cap=1.0,
            critic_correction='D_t = rho_t*delta_t + gamma*lambda*(1-done_t)*c_t*D_next',
            numeric_recurrence='D_t = c_t*A_t + (rho_t-c_t)*delta_t',
            scope='change own TD coefficient only; c_t remains capped at 1; actor excludes own rho because PPO retains its outer ratio',
            actual_weight_finite_guard=True, targets_consumed_by_ppo=True,
            audit_enabled=a.save_split_trace_audit, audit_updates=split_trace_audit_updates,
            audit_files=[f'split_trace_audit_{u:03d}.pt' for u in split_trace_audit_updates],
            weighted_td_variance_warning='Old aggregate ratio moments do not bound rho-weighted TD variance or future policy ratio tails')
    write_json(a.out / 'config.json', config)
    write_json(a.out / 'status.json', {'state': 'compiling', 'pid': os.getpid(), 'device': a.device})
    try:
        started = time.monotonic()
        if a.task == 'Ant':
            from ant_contact_compat import install
            install()
        env = LocomotionWarp(a.num_envs, a.device, a.seed, task=a.task)
        ev = LocomotionWarp(a.eval_envs, a.device, a.seed + 10000, task=a.task)
        pe = LocomotionWarp(5, a.device, a.seed + 20000, task=a.task) if a.method == 'reward_profiling' else None
        model = ActorCritic(env.obs_dim, env.action_dim).to(a.device)
        normal = RunningStats((env.obs_dim,), a.device)
        rnormal = RunningStats((), a.device)
        optimizer = torch.optim.Adam(model.parameters(), lr=3e-4, eps=1e-5)
        optimizers = {'ppo': optimizer}
        actor_params = list(model.actor.parameters()) + [model.log_std]
        hnet = None
        if a.method == 'gradient_ppo':
            hnet = ActorCritic(env.obs_dim, env.action_dim).to(a.device).critic
            # Independently initialized auxiliary network, as in the author implementation.
            ao = torch.optim.Adam(actor_params, lr=3e-4, eps=1e-5)
            co = torch.optim.Adam(model.critic.parameters(), lr=.003, eps=1e-5)
            ho = torch.optim.Adam(hnet.parameters(), lr=.003, eps=1e-5)
            optimizers = {'actor': ao, 'critic': co, 'h': ho}
        raw = env.reset()
        normal.update(raw)
        obs = normal.normalize(raw)
        initial = evaluate(model, normal, ev)
        write_json(a.out / 'initial_evaluation.json', initial)
        shape = (a.rollout, a.num_envs)
        ob = torch.empty((*shape, env.obs_dim), device=a.device)
        nb = torch.empty_like(ob)
        ac = torch.empty((*shape, env.action_dim), device=a.device)
        lp, rw, va, nv = [torch.empty(shape, device=a.device) for _ in range(4)]
        te, dn = [torch.empty(shape, device=a.device, dtype=torch.bool) for _ in range(2)]
        discounted = torch.zeros(a.num_envs, device=a.device)
        lam, prev_loss, extra_valid, extra_simulated = .99, float('inf'), 0, 0
        feedback = KLFeedback()
        counts = {'actor': 0, 'critic': 0, 'h': 0}
        latest, next_eval, history = initial, a.eval_every, [(0, initial['mean'])]
        boundaries = set(math.ceil(k * updates / min(a.profile_chunks, updates)) for k in range(1, min(a.profile_chunks, updates) + 1))
        old = None
        previous_tail_adv = None
        fields = ['steps', 'elapsed_seconds', 'steps_per_second', 'eval_mean', 'gae_lambda_used', 'gae_lambda_next', 'overlap_active',
                  'value_loss', 'policy_loss', 'approx_kl', 'explained_variance', 'profiling_extra_transitions', 'profiling_simulated_transitions',
                  'fresh_per_world', 'used_per_world', 'retained_per_world', 'stage_boundary_flush']
        with (a.out / 'progress.csv').open('w', buffering=1) as f:
            writer = csv.DictWriter(f, fieldnames=fields)
            writer.writeheader()
            for update in range(1, updates + 1):
                current_steps = collected_time * a.num_envs
                staged_overlap = a.staged_full and collected_time < stage_switch_time
                adaptive_overlap = (a.adaptive_overlap and a.overlap_start_steps <= current_steps < a.overlap_stop_steps
                                    and lam >= a.overlap_lambda_threshold)
                # The default PAE setting reuses the final 16 steps of each
                # 64-step window.  Adaptive/staged experiments opt into
                # their own conditional schedules instead.
                overlap_active = a.force_pae_overlap or staged_overlap or adaptive_overlap
                critic_lam = .99 if staged_overlap else .95
                if not overlap_active and filled:
                    filled = 0
                    previous_tail_adv = None
                if collected_time >= total_time and not filled:
                    break
                active_prefix = prefix if overlap_active else a.rollout
                if a.method == 'reward_profiling' and old is None:
                    old = copy_policy(model)
                if a.method == 'critic_aware':
                    optimizer.param_groups[0]['lr'] = 3e-4 * (1 - (update - 1) / updates)
                used_lambda = lam
                with torch.no_grad():
                    fresh = min(a.rollout - filled, total_time - collected_time)
                    if staged_overlap:
                        fresh = min(fresh, stage_switch_time - collected_time)
                    end = filled + fresh
                    for t in range(filled, end):
                        ob[t].copy_(obs)
                        dist = model.distribution(obs)
                        actions = dist.sample()
                        ac[t].copy_(actions)
                        lp[t].copy_(dist.log_prob(actions).sum(-1))
                        va[t].copy_(model.value(obs))
                        raw, reward, term, trunc, info = env.step(actions)
                        done = term | trunc
                        nb[t].copy_(normal.normalize(info['terminal_observation']))
                        nv[t].copy_(model.value(nb[t]))
                        discounted.mul_(.99).add_(reward)
                        rnormal.update(discounted)
                        rw[t].copy_((reward / (rnormal.var + 1e-8).sqrt()).clamp(-10, 10))
                        discounted.masked_fill_(done, 0)
                        te[t].copy_(term)
                        dn[t].copy_(done)
                        normal.update(raw)
                        obs = normal.normalize(raw)
                    collected_time += fresh
                    stored_retained_values = va[:filled].clone() if a.retained_tail_diagnostics and filled else None
                    # Author code recomputes current values on the entire overlap window.
                    va[:end].copy_(model.value(ob[:end]))
                    nv[:end].copy_(model.value(nb[:end]))
                    adv, ret = gae(rw[:end], va[:end], nv[:end], te[:end], dn[:end], .99, used_lambda)
                    # I1 isolates the critic labels from actor lambda.
                    _, ret = gae(rw[:end], va[:end], nv[:end], te[:end], dn[:end], .99, critic_lam)
                    trace_logratios = None
                    if a.retained_tail_correction:
                        # New rows were sampled by this frozen current actor.  Only
                        # incoming old rows require a behavior-density correction.
                        trace_logratios = torch.zeros_like(lp[:end])
                        if filled:
                            trace_logratios[:filled].copy_(
                                model.distribution(ob[:filled]).log_prob(ac[:filled]).sum(-1) - lp[:filled])
                        if not torch.isfinite(trace_logratios).all():
                            raise RuntimeError('Nonfinite retained current/behavior logdensity ratio')
                        capped_ratios = trace_logratios.clamp(max=0).exp()
                        uncorrected_adv, uncorrected_ret = adv, ret
                        if a.retained_td_unclipped:
                            raw_rhos = trace_logratios.exp()
                            if not torch.isfinite(raw_rhos).all() or not torch.isfinite(capped_ratios).all():
                                raise RuntimeError('Nonfinite actual split-trace density weight')
                            if not torch.equal(raw_rhos[filled:], torch.ones_like(raw_rhos[filled:])):
                                raise RuntimeError('Fresh split-trace TD density weights must equal one')
                            if not torch.equal(capped_ratios[filled:], torch.ones_like(capped_ratios[filled:])):
                                raise RuntimeError('Fresh split-trace continuation weights must equal one')
                            adv, adaptive_ret = split_tail_trace(rw[:end], va[:end], nv[:end], te[:end], dn[:end],
                                                        raw_rhos, capped_ratios, .99, used_lambda)
                            _, ret = split_tail_trace(rw[:end], va[:end], nv[:end], te[:end], dn[:end], raw_rhos, capped_ratios, .99, critic_lam)
                            if not torch.isfinite(adv).all() or not torch.isfinite(ret).all():
                                raise RuntimeError('Nonfinite split-trace consumed target')
                            old_capped_adv, old_capped_ret = capped_tail_trace(
                                rw[:end], va[:end], nv[:end], te[:end], dn[:end], capped_ratios, .99, used_lambda)
                            _, old_capped_ret = capped_tail_trace(rw[:end], va[:end], nv[:end], te[:end], dn[:end], capped_ratios, .99, critic_lam)
                            split_actor_delta, split_critic_delta = adv - old_capped_adv, ret - old_capped_ret
                        else:
                            adv, adaptive_ret = capped_tail_trace(rw[:end], va[:end], nv[:end], te[:end], dn[:end],
                                                         capped_ratios, .99, used_lambda)
                            _, ret = capped_tail_trace(rw[:end], va[:end], nv[:end], te[:end], dn[:end], capped_ratios, .99, critic_lam)
                        actor_delta, critic_delta = adv - uncorrected_adv, ret - uncorrected_ret
                        # Future-only correction cannot affect the fresh suffix,
                        # including every complete late-stage window after flush.
                        if torch.count_nonzero(actor_delta[filled:]) or torch.count_nonzero(critic_delta[filled:]):
                            raise RuntimeError('Trace correction changed a fresh-row GAE target')
                    stage_boundary_flush = bool(staged_overlap and collected_time >= stage_switch_time)
                    used = end if collected_time == total_time or stage_boundary_flush else min(active_prefix, end)
                    if a.retained_tail_diagnostics:
                        diagnostic = {'update': update, 'steps': collected_time * a.num_envs,
                            'critic_trace_lambda':critic_lam, 'retained_count': filled * a.num_envs, 'retained_per_world': filled,
                            'fresh_per_world': fresh, 'used_per_world': used,
                            'retained_out_per_world': end - used, 'stage_boundary_flush': stage_boundary_flush,
                            'current_behavior_logprob_mean_abs_drift': None,
                            'importance_ratio_outside_clip_fraction': None,
                            'refreshed_minus_stored_value_rmse': None,
                            'extended_refreshed_retained_advantage_mean_abs_drift': None,
                            'extended_refreshed_retained_advantage_rmse': None,
                            'logprob_finite_count': 0, 'value_finite_count': 0, 'advantage_finite_count': 0}
                        if a.retained_tail_correction:
                            diagnostic.update(trace_correction_diagnostics(trace_logratios, capped_ratios,
                                actor_delta, critic_delta, filled, used_lambda))
                        if a.retained_td_unclipped:
                            diagnostic['trace_correction_version'] = 'split_td_continuation_trace_v1'
                            delta = rw[:end] + .99 * (~te[:end]).float() * nv[:end] - va[:end]
                            diagnostic.update(split_td_diagnostics(raw_rhos, capped_ratios, delta,
                                split_actor_delta, split_critic_delta, filled))
                        if filled:
                            logratio = (trace_logratios[:filled] if trace_logratios is not None else
                                model.distribution(ob[:filled]).log_prob(ac[:filled]).sum(-1) - lp[:filled])
                            policy_drift = finite_drift_metrics(logratio)
                            finite_logratio = logratio[torch.isfinite(logratio)]
                            diagnostic['current_behavior_logprob_mean_abs_drift'] = policy_drift['mean_abs']
                            diagnostic['logprob_finite_count'] = policy_drift['finite_count']
                            if finite_logratio.numel():
                                diagnostic['importance_ratio_outside_clip_fraction'] = float(
                                    ((finite_logratio < math.log(.8)) | (finite_logratio > math.log(1.2))).double().mean())
                            value_drift = finite_drift_metrics(va[:filled] - stored_retained_values)
                            diagnostic['refreshed_minus_stored_value_rmse'] = value_drift['rmse']
                            diagnostic['value_finite_count'] = value_drift['finite_count']
                            if previous_tail_adv is not None:
                                advantage_drift = finite_drift_metrics(adv[:filled] - previous_tail_adv)
                                diagnostic['extended_refreshed_retained_advantage_mean_abs_drift'] = advantage_drift['mean_abs']
                                diagnostic['extended_refreshed_retained_advantage_rmse'] = advantage_drift['rmse']
                                diagnostic['advantage_finite_count'] = advantage_drift['finite_count']
                        # Descriptive replay drift combines critic refresh and new GAE context.
                        # It is not a true-advantage error and never controls training.
                        append_json(a.out / 'retained_tail_diagnostics.jsonl', diagnostic)
                env.check_capacity()
                fo, fa, fl, fad, fr, fv = ob[:used].flatten(0, 1), ac[:used].flatten(0, 1), lp[:used].flatten(), adv[:used].flatten(), ret[:used].flatten(), va[:used].flatten()
                if a.save_split_trace_audit and update in split_trace_audit_updates:
                    assert end == 64, 'Split-trace audit requires a complete frozen window'
                    save_split_trace_audit(a.out / f'split_trace_audit_{update:03d}.pt',
                        rw[:end], va[:end], nv[:end], te[:end], dn[:end], trace_logratios,
                        raw_rhos, capped_ratios, fad, fr, used_lambda, update, collected_time * a.num_envs,
                        current_steps, used, filled, critic_lam)
                train_size = used * a.num_envs
                if a.adaptive_kl:
                    with torch.no_grad():
                        old_dist = model.distribution(fo)
                        old_mean = old_dist.loc.detach().clone()
                        old_scale = old_dist.scale.detach().clone()
                metrics = []
                if a.method == 'gradient_ppo':
                    # Each row indexes exactly 32 consecutive times of ONE world.
                    sequence_ids = torch.arange(size, device=a.device).reshape(a.rollout, a.num_envs).T.reshape(-1, 32)
                for epoch in range(epochs):
                    if a.method == 'gradient_ppo':
                        groups = sequence_ids[torch.randperm(len(sequence_ids), device=a.device)].split(a.batch_size // 32)
                    else:
                        groups = torch.randperm(train_size, device=a.device).split(a.batch_size)
                    for group in groups:
                        idx = group.flatten()
                        dist = model.distribution(fo[idx])
                        logratio = dist.log_prob(fa[idx]).sum(-1) - fl[idx]
                        ratio = logratio.exp()
                        ba = fad[idx]
                        ba = (ba - ba.mean()) / (ba.std(unbiased=False) + 1e-8)
                        pg = torch.maximum(-ba * ratio, -ba * ratio.clamp(.8, 1.2)).mean()
                        if a.method == 'gradient_ppo':
                            # Use all32 transitions with stored terminal next-observations;
                            # unlike author array slicing, no transition lost at each sequence end.
                            tids = group.T
                            values = model.value(fo[tids])
                            next_values = model.value(nb.flatten(0, 1)[tids])
                            hv = hnet(fo[tids]).squeeze(-1)
                            cl, hl, dl = tdrc_losses(values, next_values, rw.flatten()[tids], te.flatten()[tids], dn.flatten()[tids], hv, list(hnet.parameters()))
                            vl = .5 * dl.detach().square().mean()
                            step_loss(pg, ao, actor_params)
                            # These losses have disjoint parameter graphs and share PRE-update values.
                            co.zero_grad(set_to_none=True)
                            ho.zero_grad(set_to_none=True)
                            cl.backward()
                            hl.backward()
                            nn.utils.clip_grad_norm_(model.critic.parameters(), .5, error_if_nonfinite=True)
                            nn.utils.clip_grad_norm_(hnet.parameters(), .5, error_if_nonfinite=True)
                            co.step()
                            ho.step()
                            counts['actor'] += 1; counts['critic'] += 1; counts['h'] += 1
                        elif a.method == 'critic_aware':
                            value = model.value(fo[idx])
                            clipped = fv[idx] + (value - fv[idx]).clamp(-.2, .2)
                            vl = .5 * torch.maximum((value - fr[idx]).square(), (clipped - fr[idx]).square()).mean()
                            if epoch % 2 == 0:
                                step_loss(pg, optimizer, list(model.parameters()))
                                counts['actor'] += 1
                            step_loss(vl, optimizer, list(model.parameters()))
                            counts['critic'] += 1
                        else:
                            vl = .5 * (model.value(fo[idx]) - fr[idx]).square().mean()
                            step_loss(pg + vl, optimizer, list(model.parameters()))
                            counts['actor'] += 1; counts['critic'] += 1
                        metrics.append(torch.stack((vl.detach(), pg.detach(), ((ratio - 1) - logratio).mean().detach())))
                stats = torch.stack(metrics).mean(0).cpu().tolist()
                if not all(math.isfinite(v) for v in stats):
                    raise RuntimeError('Nonfinite optimization metrics')
                steps = collected_time * a.num_envs
                ev_score = float(1 - (fr - fv).var(unbiased=False) / (fr.var(unbiased=False) + 1e-8))
                if a.adaptive_kl:
                    with torch.no_grad():
                        old_policy=torch.distributions.Normal(old_mean,old_scale,validate_args=False)
                        realized_kl=float(torch.distributions.kl_divergence(old_policy,model.distribution(fo)).sum(-1).mean())
                    if not math.isfinite(ev_score):raise RuntimeError("Nonfinite value residual observer")
                    relative_value_residual=math.sqrt(min(1.,max(0.,1.-ev_score)))
                    feedback.observe(relative_value_residual)
                    readiness_active=(a.readiness_boost and update<16 and ev_score>=.45)
                    if readiness_active:
                        feedback.value=min(.99,feedback.value+.02)
                    else:
                        feedback.step(update+1)
                    lam=feedback.value
                    append_json(a.out/'lambda_decisions.jsonl',{'update':update,'steps':steps,'used':used_lambda,
                        'critic_lambda':critic_lam,'next':lam,'relative_value_residual':relative_value_residual,'controller_signal':'normalized_value_residual','realized_kl':realized_kl,'explained_variance':ev_score,
                        'readiness_active':readiness_active,'overlap_active':overlap_active,**feedback.state_dict()})
                if a.method == 'critic_aware':
                    last_loss = float(vl.detach())
                    lam = critic_lambda(lam, prev_loss, last_loss, steps / (effective_steps))
                    append_json(a.out / 'lambda_decisions.jsonl', {'update': update, 'used': used_lambda, 'next': lam, 'last_minibatch_value_loss': last_loss, 'previous_loss': prev_loss if math.isfinite(prev_loss) else None})
                    prev_loss = last_loss
                if a.method == 'reward_profiling' and update in boundaries:
                    new = copy_policy(model)
                    # Common current normalizer, independent profiling resets and training RNG.
                    # Report-evaluation environment is NEVER used for policy selection.
                    model.load_state_dict(old)
                    old_eval = evaluate(model, normal, pe)
                    model.load_state_dict(new)
                    new_eval = evaluate(model, normal, pe)
                    chosen = restore_lookback(model, old, new, old_eval['mean'], new_eval['mean'])
                    valid = sum(old_eval['lengths']) + sum(new_eval['lengths'])
                    simulated = 5 * (max(old_eval['lengths']) + max(new_eval['lengths']))
                    extra_valid += valid; extra_simulated += simulated
                    append_json(a.out / 'profiling_decisions.jsonl', {'steps': steps, 'chosen': chosen, 'old': old_eval, 'new': new_eval, 'extra_transitions': valid, 'simulated_transitions': simulated, 'optimizer': 'kept current', 'normalizer': 'shared current frozen stats for both candidates'})
                    old = None
                evaluated = steps >= next_eval or steps >= effective_steps or update == updates
                if evaluated:
                    latest = evaluate(model, normal, ev)
                    append_json(a.out / 'evaluations.jsonl', {'steps': steps, **latest})
                    history.append((steps, latest['mean']))
                    state = {'model': model.state_dict(), 'obs_stats': normal.state_dict(), 'reward_stats': rnormal.state_dict(),
                             'optimizers': {k: v.state_dict() for k, v in optimizers.items()},
                             'hnet': hnet.state_dict() if hnet is not None else None,
                             'lambda_next': lam, 'previous_value_loss': prev_loss, 'steps': steps, 'config': config,
                             'profiling_old': old, 'optimizer_steps': counts.copy(),
                             'kl_feedback': feedback.state_dict() if a.adaptive_kl else None}
                    torch.save(state, a.out / 'latest.tmp')
                    (a.out / 'latest.tmp').replace(a.out / 'latest.pt')
                    next_eval = (steps // a.eval_every + 1) * a.eval_every
                torch.cuda.synchronize()
                elapsed = time.monotonic() - started
                row = dict(zip(fields, [steps, elapsed, steps / elapsed, latest['mean'] if evaluated else None,
                                       used_lambda, lam, overlap_active, *stats, ev_score, extra_valid, extra_simulated,
                                       fresh, used, end - used, stage_boundary_flush]))
                writer.writerow(row)
                status = {**row, 'pae_retained_per_world': end - used, 'pae_fresh_per_world': fresh, 'pae_used_per_world': used, 'state': 'running', 'pid': os.getpid(), 'device': a.device, 'physics_device': str(env.qpos.device),
                          'budget': effective_steps, 'optimizer_steps': counts.copy(), 'peak_torch_memory_bytes': torch.cuda.max_memory_reserved()}
                write_json(a.out / 'status.json', status)
                print(f'{steps}/{effective_steps} | {steps / elapsed:.0f} steps/s | lambda={lam:.4f} | eval={row["eval_mean"]}', flush=True)
                # Reuse tail transitions and their original behavior log-probabilities.
                filled = end - used
                if a.retained_tail_diagnostics:
                    previous_tail_adv = adv[used:end].clone() if filled else None
                if filled:
                    for buf in [ob, nb, ac, lp, rw, va, nv, te, dn]:
                        buf[:filled].copy_(buf[used:end].clone())

        # Reload the exact final checkpoint, including the normalizer used in evaluations.
        saved = torch.load(a.out / 'latest.pt', weights_only=False)
        restored = ActorCritic(env.obs_dim, env.action_dim).to(a.device)
        restored.load_state_dict(saved['model'])
        restored_stats = RunningStats((env.obs_dim,), a.device)
        restored_stats.load_state_dict(saved['obs_stats'])
        with torch.no_grad():
            torch.testing.assert_close(restored.actor(restored_stats.normalize(raw)), model.actor(normal.normalize(raw)), rtol=0, atol=0)
            torch.testing.assert_close(restored.value(obs), model.value(obs), rtol=0, atol=0)
        auc = float(np.trapz([x[1] for x in history], [x[0] for x in history]) / (effective_steps))
        summary = {**status, 'state': 'completed', 'final_eval': latest, 'initial_eval': initial, 'normalized_return_auc': auc,
                   'reload_check': 'passed', 'training_transitions': effective_steps,
                   'total_algorithm_transitions': effective_steps + extra_valid,
                   'note': 'Matched GPU backbone port with declared deviations; not original-paper numerical reproduction.'}
        write_json(a.out / 'summary.json', summary)
        write_json(a.out / 'status.json', summary)
    except BaseException as exc:
        write_json(a.out / 'status.json', {'state': 'failed', 'pid': os.getpid(), 'error': repr(exc)})
        raise

if __name__ == '__main__':
    main()
