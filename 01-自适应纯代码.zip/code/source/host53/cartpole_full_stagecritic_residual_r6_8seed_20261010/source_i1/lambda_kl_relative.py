"""Causal dual-time-scale normalized critic-residual trace controller.

Legacy KLFeedback export supports the existing trainer interface; KL is NOT input.
The residual is a same-rollout centered target-prediction proxy, not true error.
"""
import math
from dataclasses import dataclass,asdict
@dataclass
class KLFeedback:
    value:float=.99
    ema:float=0.
    reference:float=0.
    target:float=.99
    observations:int=0
    fast_alpha:float=.1
    slow_alpha:float=.01
    deadband_log_ratio:float=0.
    lower_bound:float=.98
    upper_bound:float=.99
    def observe(self,relative_value_residual):
        x=relative_value_residual
        if not math.isfinite(x) or not 0.<=x<=1.:raise ValueError('Invalid normalized value residual')
        self.observations+=1
        if self.observations<=4:
            self.ema+=(x-self.ema)/self.observations
            self.reference=self.ema
        else:
            self.ema=(1-self.fast_alpha)*self.ema+self.fast_alpha*x
            self.reference=(1-self.slow_alpha)*self.reference+self.slow_alpha*x
        if self.observations>4 and self.observations%4==0:
            self.target=min(self.upper_bound,max(self.lower_bound,.98+.01*.5*(self.ema+self.reference)))
    def step(self,update):
        old=self.value
        if update>4:self.value=min(self.upper_bound,max(self.lower_bound,old+max(-.001,min(.001,.1*(self.target-old)))))
        return self.value-old
    def state_dict(self):return asdict(self)
