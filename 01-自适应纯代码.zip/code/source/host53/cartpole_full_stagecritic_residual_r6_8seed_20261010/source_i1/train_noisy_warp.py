"""PPO with fixed GAE lambda and CUDA-resident rollout/physics/optimization."""
import argparse
from collections import deque
import csv
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import time

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
import numpy as np
import torch
from torch import nn
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "env_source"))
from new_tasks_warp import LocomotionWarp, ASSETS, TASKS, TASK_META
from noisy_observation import NoisyObservation
from lambda_control import LambdaControl
from lambda_lookahead import choose_direction


def write_json(path, data):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")
    tmp.replace(path)


class RunningStats(nn.Module):
    def __init__(self, shape, device):
        super().__init__()
        self.register_buffer("mean", torch.zeros(shape, device=device))
        self.register_buffer("var", torch.ones(shape, device=device))
        self.register_buffer("count", torch.tensor(1e-4, device=device))

    @torch.no_grad()
    def update(self, x):
        mean = x.mean(0)
        var = x.var(0, unbiased=False)
        count = x.shape[0]
        delta, total = mean - self.mean, self.count + count
        new_var = (self.var * self.count + var * count + delta.square() * self.count * count / total) / total
        self.mean.add_(delta * count / total)
        self.var.copy_(new_var)
        self.count.copy_(total)

    def normalize(self, x):
        return ((x - self.mean) / (self.var + 1e-8).sqrt()).clamp(-10, 10)


class ActorCritic(nn.Module):
    def __init__(self, obs_dim=11, action_dim=3):
        super().__init__()
        def mlp(out, gain):
            layers = []
            for i, (nin, nout) in enumerate([(obs_dim, 64), (64, 64), (64, out)]):
                layer = nn.Linear(nin, nout)
                nn.init.orthogonal_(layer.weight, gain=gain if i == 2 else math.sqrt(2))
                nn.init.zeros_(layer.bias)
                layers.append(layer)
                if i != 2:
                    layers.append(nn.Tanh())
            return nn.Sequential(*layers)
        self.actor, self.critic = mlp(action_dim, .01), mlp(1, 1)
        self.log_std = nn.Parameter(torch.zeros(action_dim))

    def distribution(self, obs):
        return torch.distributions.Normal(self.actor(obs), self.log_std.exp(), validate_args=False)

    def value(self, obs):
        return self.critic(obs).squeeze(-1)


@torch.jit.script
def gae(rewards, values, next_values, terminated, done, gamma: float = .99, lam: float = .95):
    advantages = torch.zeros_like(rewards)
    carry = torch.zeros_like(rewards[0])
    for t in range(rewards.shape[0] - 1, -1, -1):
        delta = rewards[t] + gamma * (~terminated[t]).float() * next_values[t] - values[t]
        carry = delta + gamma * lam * (~done[t]).float() * carry
        advantages[t] = carry
    return advantages, advantages + values


@torch.no_grad()
def evaluate(model, stats, env):
    obs = env.reset()
    active = torch.ones(env.num_envs, device=env.device, dtype=torch.bool)
    returns = torch.zeros(env.num_envs, device=env.device)
    lengths = torch.zeros(env.num_envs, device=env.device, dtype=torch.long)
    # Exactly one complete episode per world; do not favor quickly ending episodes.
    for _ in range(env.max_steps):
        actions = model.actor(stats.normalize(obs))
        obs, reward, term, trunc, _info = env.step(actions)
        returns.add_(reward * active)
        lengths.add_(active.long())
        active &= ~(term | trunc)
        if not bool(active.any()):
            break
    env.check_capacity()
    if not bool(torch.isfinite(returns).all()):
        raise RuntimeError("Non-finite evaluation return")
    return {"mean": returns.mean().item(), "std": returns.std(unbiased=False).item(),
            "returns": returns.cpu().tolist(), "lengths": lengths.cpu().tolist()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=1_000_000)
    parser.add_argument("--num-envs", type=int, default=1024)
    parser.add_argument("--rollout", type=int, default=64)
    parser.add_argument("--batch-size", type=int, default=1024)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--eval-every", type=int, default=1_000_000)
    parser.add_argument("--eval-envs", type=int, default=32)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--lambda-mode", choices=["fixed", "linear", "minimal", "lookahead"], default="fixed")
    parser.add_argument("--fixed-lambda", type=float, default=.95)
    parser.add_argument("--initial-lambda", type=float, default=.95)
    parser.add_argument('--task',choices=list(TASKS),default='Hopper')
    parser.add_argument('--noise-mode',choices=['none','gaussian','multiplicative'],default='none')
    parser.add_argument('--noise-scale',type=float,default=0.)
    args = parser.parse_args()
    if not math.isfinite(args.noise_scale) or args.noise_scale < 0:
        parser.error('noise scale must be finite and nonnegative')
    obs_dim,action_dim={'Hopper':(11,3),'Walker2d':(17,6),'HalfCheetah':(17,6),'Ant':(27,8),'InvertedDoublePendulum':(11,1)}[args.task]
    XML_PATH=ASSETS/TASKS[args.task][0]
    if not 0 <= args.fixed_lambda <= 1:
        parser.error("--fixed-lambda must be in [0,1]")
    if not .85 <= args.initial_lambda <= .99:
        parser.error("--initial-lambda must be in [.85,.99]")
    if min(args.steps, args.num_envs, args.rollout, args.batch_size, args.epochs, args.eval_every, args.eval_envs) <= 0:
        parser.error("All sizes must be positive")
    if torch.device(args.device).type != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for both physics and PPO")
    args.out.mkdir(parents=True, exist_ok=False)
    torch.set_num_threads(1)
    torch.cuda.set_device(args.device)
    torch.random.default_generator.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)
    np.random.seed(args.seed)
    size = args.num_envs * args.rollout
    updates = math.ceil(args.steps / size)
    config = {**vars(args), "out": str(args.out), "effective_steps": updates * size,
              "backend": "MuJoCo Warp", "task": args.task, "task_adapter": TASK_META[args.task], "suite_manifest_sha256": os.environ.get("DPO_SUITE_MANIFEST_SHA256"),
              "gae_lambda": args.fixed_lambda if args.lambda_mode == "fixed" else (.90 if args.lambda_mode == "linear" else args.initial_lambda), "gamma": .99, "learning_rate": 3e-4,
              "lambda_design": {"fixed": args.fixed_lambda, "linear_start": .90, "linear_end": .99,
                  "minimal_init": args.initial_lambda, "bounds": [.85, .99], "entropy_window": 8,
                  "direction_interval": 4, "normalized_trend_deadband": .5,
                  "max_step": .003, "td_reference_ema_alpha": .1},
              "lookahead_design": {"candidate_offset": .02, "reference_lambda": 1.,
                  "split": "even/odd environment IDs", "virtual_epochs": 1,
                  "direction_interval": 4, "first_decision_update": 8,
                  "margin_rule": "paired world mean delta > max(1e-6,2*SE)"},
              "clip_range": .2, "value_coef": .5, "entropy_coef": 0., "max_grad_norm": .5,
              "network": [64, 64], "optimizer_eps": 1e-5, "additional_noise": {"mode":args.noise_mode,"scale":args.noise_scale,"location":"raw observation before running normalization","train_and_primary_eval":True,"reward_and_physics":"unmodified"},
              "reward_normalization": True, "observation_normalization": True,
              "xml_sha256": hashlib.sha256(XML_PATH.read_bytes()).hexdigest(),
              "gpu": torch.cuda.get_device_name(),
              "versions": {p: importlib.metadata.version(p) for p in
                           ["torch", "mujoco", "mujoco-warp", "warp-lang", "gymnasium", "numpy"]}}
    write_json(args.out / "config.json", config)
    write_json(args.out / "status.json", {"state": "compiling", "pid": os.getpid()})
    try:
        env = NoisyObservation(LocomotionWarp(args.num_envs, args.device, args.seed, task=args.task),args.noise_mode,args.noise_scale,args.seed+200000)
        eval_env = NoisyObservation(LocomotionWarp(args.eval_envs, args.device, args.seed + 10000,task=args.task),args.noise_mode,args.noise_scale,args.seed+300000)
        model = ActorCritic(obs_dim,action_dim).to(args.device)
        optimizer = torch.optim.Adam(model.parameters(), lr=3e-4, eps=1e-5)
        obs_stats = RunningStats((obs_dim,), args.device)
        reward_stats = RunningStats((), args.device)
        raw_obs = env.reset()
        obs_stats.update(raw_obs)
        obs = obs_stats.normalize(raw_obs)
        initial = evaluate(model, obs_stats, eval_env)
        write_json(args.out / "initial_evaluation.json", initial)
        print(f"Initial GPU evaluation: {initial['mean']:.1f}", flush=True)
        shape = (args.rollout, args.num_envs)
        obuf = torch.empty((*shape, obs_dim), device=args.device)
        abuf = torch.empty((*shape, action_dim), device=args.device)
        logbuf, rbuf, vbuf, nvbuf = [torch.empty(shape, device=args.device) for _ in range(4)]
        tbuf, dbuf = [torch.empty(shape, dtype=torch.bool, device=args.device) for _ in range(2)]
        discounted_return = torch.zeros(args.num_envs, device=args.device)
        recent = deque(maxlen=100)
        latest_eval, best = initial, -float("inf")
        next_eval = args.eval_every
        controller = LambdaControl(args.lambda_mode, fixed_value=args.fixed_lambda,
                                   value=args.fixed_lambda if args.lambda_mode == "fixed" else (.90 if args.lambda_mode == "linear" else args.initial_lambda))
        started = time.monotonic()
        fields = ["steps", "elapsed_seconds", "steps_per_second", "train_return_last_100",
                  "value_loss", "policy_loss", "entropy", "approx_kl", "clip_fraction",
                  "explained_variance", "eval_mean", "gae_lambda"]
        fields += ["lambda_delta", "lambda_direction", "lambda_step_size", "entropy_trend_score",
                   "signal_entropy", "td_abs_q90", "td_reference", "advantage_variance"]
        with (args.out / "progress.csv").open("w", buffering=1) as logfile:
            writer = csv.DictWriter(logfile, fieldnames=fields)
            writer.writeheader()
            for update in range(1, updates + 1):
                episode_values = []
                with torch.no_grad():
                    for t in range(args.rollout):
                        obuf[t].copy_(obs)
                        dist = model.distribution(obs)
                        actions = dist.sample()
                        abuf[t].copy_(actions)
                        logbuf[t].copy_(dist.log_prob(actions).sum(-1))
                        vbuf[t].copy_(model.value(obs))
                        raw_obs, reward, term, trunc, info = env.step(actions)
                        done = term | trunc
                        # Bootstrap time limits from terminal observations, never reset observations.
                        nvbuf[t].copy_(model.value(obs_stats.normalize(info["terminal_observation"])))
                        discounted_return.mul_(.99).add_(reward)
                        reward_stats.update(discounted_return)
                        rbuf[t].copy_((reward / (reward_stats.var + 1e-8).sqrt()).clamp(-10, 10))
                        discounted_return.masked_fill_(done, 0)
                        tbuf[t].copy_(term)
                        dbuf[t].copy_(done)
                        episode_values.append(torch.where(done, info["episode_return"], torch.nan))
                        obs_stats.update(raw_obs)
                        obs = obs_stats.normalize(raw_obs)
                    td = rbuf + .99 * (~tbuf).float() * nvbuf - vbuf
                    signal_entropy = float((model.log_std + .5 * (1 + math.log(2 * math.pi))).sum())
                    if args.lambda_mode == "lookahead" and update >= 8 and update % 4 == 0:
                        controller.direction, decision = choose_direction(
                            model,optimizer,obuf,abuf,logbuf,rbuf,vbuf,nvbuf,tbuf,dbuf,
                            controller.value,gae,args.batch_size)
                        with (args.out / "lambda_decisions.jsonl").open("a") as f:
                            f.write(json.dumps({"update":update,"steps":update*size,**decision})+"\n")
                    control = controller.step(update, updates, signal_entropy,
                                              float(torch.quantile(td.abs().flatten(), .9)))
                    advantages, returns = gae(rbuf, vbuf, nvbuf, tbuf, dbuf, .99, controller.value)
                    advantage_variance = float(advantages.var(unbiased=False))
                    recent_values = torch.stack(episode_values).flatten()
                    recent.extend(recent_values[torch.isfinite(recent_values)].cpu().tolist())
                env.check_capacity()
                flat_obs, flat_actions = obuf.flatten(0, 1), abuf.flatten(0, 1)
                flat_log, flat_adv, flat_ret = logbuf.flatten(), advantages.flatten(), returns.flatten()
                metrics = []
                for epoch in range(args.epochs):
                    permutation = torch.randperm(size, device=args.device)
                    for idx in permutation.split(args.batch_size):
                        dist = model.distribution(flat_obs[idx])
                        new_log = dist.log_prob(flat_actions[idx]).sum(-1)
                        log_ratio = new_log - flat_log[idx]
                        ratio = log_ratio.exp()
                        adv = flat_adv[idx]
                        adv = (adv - adv.mean()) / (adv.std(unbiased=False) + 1e-8)
                        pg = torch.maximum(-adv * ratio, -adv * ratio.clamp(.8, 1.2)).mean()
                        vl = (model.value(flat_obs[idx]) - flat_ret[idx]).square().mean()
                        entropy = dist.entropy().sum(-1).mean()
                        loss = pg + .5 * vl
                        optimizer.zero_grad(set_to_none=True)
                        loss.backward()
                        nn.utils.clip_grad_norm_(model.parameters(), .5)
                        optimizer.step()
                        with torch.no_grad():
                            metrics.append(torch.stack((vl, pg, entropy,
                                ((ratio - 1) - log_ratio).mean(), ((ratio - 1).abs() > .2).float().mean())))
                stats = torch.stack(metrics).mean(0).detach().cpu().tolist()
                if not all(math.isfinite(v) for v in stats):
                    raise RuntimeError("Non-finite PPO optimization metrics")
                steps = update * size
                evaluated = steps >= next_eval or update == updates
                if evaluated:
                    latest_eval = evaluate(model, obs_stats, eval_env)
                    with (args.out / "evaluations.jsonl").open("a") as f:
                        f.write(json.dumps({"steps": steps, **latest_eval}) + "\n")
                    checkpoint = {"model": model.state_dict(), "optimizer": optimizer.state_dict(),
                                  "obs_stats": obs_stats.state_dict(), "reward_stats": reward_stats.state_dict(),
                                  "steps": steps, "config": config}
                    checkpoint["lambda_controller"] = controller.state_dict()
                    torch.save(checkpoint, args.out / "latest.pt")
                    if latest_eval["mean"] > best:
                        best = latest_eval["mean"]
                        torch.save(checkpoint, args.out / "best.pt")
                    next_eval = (steps // args.eval_every + 1) * args.eval_every
                torch.cuda.synchronize()
                elapsed = time.monotonic() - started
                ret_var = flat_ret.var(unbiased=False)
                ev = (1 - (flat_ret - vbuf.flatten()).var(unbiased=False) / (ret_var + 1e-8)).item()
                row = dict(zip(fields, [steps, elapsed, steps / elapsed,
                    float(np.mean(recent)) if recent else None, *stats, ev,
                    latest_eval["mean"] if evaluated else None, controller.value]))
                row.update(control)
                row["advantage_variance"] = advantage_variance
                writer.writerow(row)
                status = {**row, "state": "running", "pid": os.getpid(), "device": args.device,
                          "physics_device": str(env.qpos.device), "num_envs": args.num_envs,
                          "budget": updates * size, "eta_seconds": (updates * size - steps) / (steps / elapsed)}
                write_json(args.out / "status.json", status)
                print(f"{steps}/{updates * size} | {steps / elapsed:.0f} steps/s | train={row['train_return_last_100']} | eval={row['eval_mean']}", flush=True)
        # Check that the saved model reloads exactly for a fixed observation batch.
        restored = ActorCritic(obs_dim,action_dim).to(args.device)
        restored.load_state_dict(torch.load(args.out / "latest.pt", weights_only=False)["model"])
        with torch.no_grad():
            torch.testing.assert_close(restored.actor(obs), model.actor(obs), rtol=0, atol=0)
        summary = {**status, "state": "completed", "initial_eval": initial,
                   "final_eval": latest_eval, "best_eval_mean": best, "reload_check": "passed",
                   "note": "GPU backend pilot; one seed; no convergence or cross-backend equivalence claim."}
        # Final-checkpoint stress curve, independent resets/noise and frozen normalizer.
        stress=[]
        for mode,scale in [('none',0.),('gaussian',.10),('gaussian',.15),('gaussian',.30),('multiplicative',.20),('multiplicative',.30)]:
            eval_env.env.rng.manual_seed(args.seed+400000)
            eval_env.configure(mode,scale,args.seed+500000)
            result=evaluate(model,obs_stats,eval_env)
            stress.append({'mode':mode,'scale':scale,**result})
        write_json(args.out / 'stress_evaluation.json',stress)
        summary['stress_evaluation']='stress_evaluation.json'
        summary['note']='Frozen lambda algorithm across tasks; paired seed is the training replicate; GPU v4-semantics adaptation, not a paper reproduction.'
        write_json(args.out / "summary.json", summary)
        write_json(args.out / "status.json", summary)
    except BaseException as exc:
        write_json(args.out / "status.json", {"state": "failed", "error": repr(exc), "pid": os.getpid()})
        raise


if __name__ == "__main__":
    main()
