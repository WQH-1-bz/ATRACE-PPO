"""Sequential task cohorts; each task admits all16 after strict native repeats."""
import argparse,hashlib,json,os,subprocess,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def write(p,v):
    t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n');t.replace(p)
def main():
    p=argparse.ArgumentParser();p.add_argument('--python',required=True);a=p.parse_args()
    status=ROOT/'pipeline_status.json';assert not status.exists(),'fresh pipeline only'
    stages=[];started=time.time();task=phase=None
    def snapshot(state,pid=None,error=None):write(status,dict(state=state,task=task,phase=phase,pipeline_pid=os.getpid(),active_child_pid=pid,expected_formal=8,stages=stages,elapsed_seconds=time.time()-started,error=error))
    def run(argv):
        path=ROOT/f'{task}_{phase}.log';log=path.open('xb',buffering=0);t=time.time()
        c=subprocess.Popen(argv,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT);snapshot('running',c.pid)
        rc=c.wait();log.close();r=dict(task=task,phase=phase,argv=argv,actual_pid=c.pid,exit_code=rc,actual_wait_reaped=True,started_epoch=t,finished_epoch=time.time(),log=str(path))
        write(ROOT/f'{task}_{phase}.execution.json',r);stages.append(r)
        if rc:raise RuntimeError(r)
    try:
        for task in ('CartpoleSwingup',):
            phase='semantic';semantic=ROOT/f'SEMANTIC_{task}.json'
            run([a.python,'-B',str(ROOT/'env_source/semantic_audit.py'),'--task',task,'--device','cuda:0','--output',str(semantic)])
            assert json.loads(semantic.read_text())['state']=='passed'
            common=['--task',task,'--python',a.python,'--gpus','0','1','--max-per-gpu','4','--semantic-proof',str(semantic)]
            phase='smoke';smoke=ROOT/f'smoke_{task}'
            run([a.python,'-B',str(ROOT/'run_matrix.py'),'--phase','smoke','--out',str(smoke),*common])
            gates=json.loads((smoke/'SMOKE_RESULTS.json').read_text());assert gates['state']=='passed' and gates['training_runs']==4
            phase='formal'
            run([a.python,'-B',str(ROOT/'run_matrix.py'),'--phase','formal','--out',str(ROOT/f'formal_{task}'),'--smoke-root',str(smoke),*common])
        phase='terminal';snapshot('completed')
    except BaseException as e:snapshot('failed',error=dict(reason=repr(e),traceback=traceback.format_exc()));raise
if __name__=='__main__':main()
