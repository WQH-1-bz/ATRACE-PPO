"""Independent event-driven verification of completed Both runs; no polling."""
import datetime
from pathlib import Path
import run_both as r

r.torch.set_num_threads(1)
r.torch.use_deterministic_algorithms(True)
r.check_sources()
protected=r.protected()
suite=r.read(r.ROOT/'suite_status.json')
assert suite['failure'] is None and suite['engineering_gate']['state']=='passed'
completed=[j for j in suite['jobs'] if j['state']=='completed']
assert len(completed)==suite['completed_count']>=4
assert len(suite['jobs'])==8 and {j['seed'] for j in suite['jobs']}==set(r.SEEDS)
rows=[]
for job in completed:
 actual=r.verify(job)
 assert actual==job['metrics'],('native artifact replay mismatch',job['seed'])
 rows.append(actual)
report={'state':'passed','timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'suite_state_observed':suite['state'],'completed_count_verified':len(completed),'verified_seeds':[j['seed'] for j in completed],
 'active_at_read':suite['active'],'total':8,'all8_results_reverified':len(completed)==8,
 'mechanisms_native_reverified':True,'controller_replay':'passed','sample_ledger':'passed',
 'dual_target_replay':'passed','rows':rows,'parent_routine_polling':False,**protected}
if suite['state']=='completed':
 assert len(completed)==8 and not suite['active']
 assert r.analysis(suite['jobs'])==r.read(r.ROOT/'ANALYSIS.json')
 report['analysis_recomputed_exact']=True
r.write(r.ROOT/'PARENT_VERIFIED_first4.json',report)
print(r.json.dumps({k:v for k,v in report.items() if k!='rows'}))
