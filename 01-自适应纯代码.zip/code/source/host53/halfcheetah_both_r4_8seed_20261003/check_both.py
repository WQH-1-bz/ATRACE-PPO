"""Independent dual-trace formula and direct-once sample-accounting checks."""
import ast
import hashlib
import json
import math
from pathlib import Path
import sys
import types
import torch

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'halfcheetah_innovation12_r4_8seed_20261003'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def function(path,name):
    tree=ast.parse(path.read_text());return next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name==name)
def epoch(path):
    tree=ast.parse(path.read_text())
    return next(n for n in ast.walk(tree) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='epoch')
def compiled(path,names):
    name='both_frozen_source_check';mod=types.ModuleType(name);mod.torch=torch;mod.__file__=str(path);sys.modules[name]=mod
    nodes=[function(path,n) for n in names]
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(path),'exec'),mod.__dict__)
    return mod
def ledger(budget,cut):
    total,switch=budget//1024,cut//1024;seen=[0]*total;collected=0;retained=[];rows=[]
    while collected<total or retained:
        prior=collected;early=prior<switch
        fresh=min(64-len(retained),total-prior,switch-prior if early else total-prior)
        batch=retained+list(range(prior,prior+fresh));collected+=fresh
        flush=early and collected==switch;used=len(batch) if flush or collected==total else min(56 if early else 64,len(batch))
        for x in batch[:used]:seen[x]+=1
        rows.append({'prior':prior*1024,'steps':collected*1024,'used':used,'end':len(batch),'early':early})
        retained=batch[used:]
    assert all(v==1 for v in seen)
    early=sum(r['early'] for r in rows)
    return {'updates':len(rows),'early_updates':early,'first_adaptive_update':early+1,
        'fresh_and_trained_transitions':budget,'adam_calls':sum(r['used']*10 for r in rows),
        'every_sample_directly_consumed_once':True,'audit_updates':[3,early-1,early,early+1,len(rows)],
        'audit_window_shapes':[[rows[u-1]['end'],rows[u-1]['used']] for u in [3,early-1,early,early+1,len(rows)]]}
def oracle(r,v,n,t,d,rho,c,lam):
    # Match the unchanged source's float32 mask coefficients before promotion.
    delta=r+.99*(~t).float()*n-v;disc=(.99*lam*(~d).float()).double();D=torch.zeros_like(r)
    for i in range(len(r)):
        weight=torch.ones_like(r[0])
        for j in range(i,len(r)):
            D[i]+=weight*rho[j]*delta[j];weight=weight*disc[j]*c[j]
    A=delta.clone();A[:-1]+=disc[:-1]*D[1:]
    return A,v+D
def main():
    torch.set_num_threads(1)
    old=OLD/'source_i2/train_pae_baseline.py';new=ROOT/'source_i2/train_pae_baseline.py'
    for name in ['split_tail_trace','capped_tail_trace','split_td_diagnostics','finite_drift_metrics','trace_correction_diagnostics']:
        assert ast.dump(function(old,name),include_attributes=False)==ast.dump(function(new,name),include_attributes=False),name
    assert ast.dump(epoch(old),include_attributes=False)==ast.dump(epoch(new),include_attributes=False)
    assert all(p.read_bytes()==(OLD/'source_i2'/p.name).read_bytes() for p in (ROOT/'source_i2').iterdir() if p.is_file() and p.name!='train_pae_baseline.py')
    assert (ROOT/'source_i2/lambda_kl_relative.py').read_bytes()==(OLD/'source_i1/lambda_kl_relative.py').read_bytes()
    ns=compiled(new,['split_tail_trace']);raw=compiled(ROOT/'source_i2/train_noisy_warp.py',['gae'])
    x=torch.arange(64*4,dtype=torch.float64).reshape(64,4);r=x.sin();v=x.cos();n=(x+.3).cos()
    t=torch.zeros_like(x,dtype=torch.bool);d=t.clone();t[7,0]=d[7,0]=True;d[13,1]=True
    logs=torch.zeros_like(x);logs[:8]=(x[:8].remainder(7)-3)*.17;rho=logs.exp();c=logs.clamp(max=0).exp()
    before=torch.get_rng_state().clone()
    for lam in [.90,.943,.95,.99]:
        a,b=ns.split_tail_trace(r,v,n,t,d,rho,c,.99,lam);aa,bb=oracle(r,v,n,t,d,rho,c,lam)
        torch.testing.assert_close(a,aa,rtol=1e-12,atol=1e-12);torch.testing.assert_close(b,bb,rtol=1e-12,atol=1e-12)
        plain=raw.gae(r,v,n,t,d,.99,lam)
        assert torch.equal(a[8:],plain[0][8:]) and torch.equal(b[8:],plain[1][8:])
        one=torch.ones_like(r)
        for z,w in zip(ns.split_tail_trace(r,v,n,t,d,one,one,.99,lam),plain):assert torch.equal(z,w)
    a,_=ns.split_tail_trace(r,v,n,t,d,rho,c,.99,.943);_,b=ns.split_tail_trace(r,v,n,t,d,rho,c,.99,.95)
    torch.testing.assert_close(a,oracle(r,v,n,t,d,rho,c,.943)[0],rtol=1e-12,atol=1e-12)
    torch.testing.assert_close(b,oracle(r,v,n,t,d,rho,c,.95)[1],rtol=1e-12,atol=1e-12)
    assert torch.equal(before,torch.get_rng_state())
    text=new.read_text();assert text.index('feedback.step(update)')<text.index('used_lambda = lam')
    assert "if current_steps>=a.stage_switch_steps:" in text
    assert 'feedback.observe(realized_kl)' in text and "if a.combined_i1:\n                        pass" in text
    ledgers={'short':ledger(524288,262144),'formal':ledger(10027008,4980736)}
    assert ledgers['short']['updates']==9 and ledgers['formal']['updates']==164
    assert ledgers['formal']['adam_calls']==97920 and ledgers['short']['adam_calls']==5120
    out={'state':'passed','checks':['dual actor/critic traces against independent finite TD sums','all-ones GAE and fresh suffix exact equivalence','termination and time-limit masks','unchanged R4 split traces/PPO optimizer/17 support files/KLF2 controller','causal prior-transition controller step and post-update observation','direct-once sample and optimizer ledger'],
        'ledgers':ledgers,'source_hashes':{p.name:sha(p) for p in (ROOT/'source_i2').iterdir() if p.is_file()},'check_sha256':sha(Path(__file__))}
    (ROOT/'SOURCE_BOTH_CHECK.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
