"""Pin original R4 runs and every internal control before any new training."""
import hashlib
import json
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'halfcheetah_innovation12_r4_8seed_20261003'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    assert not(ROOT/'PROTECTED_INVENTORY.json').exists()
    original=read(OLD/'suite_status.json');assert original['state']=='completed' and original['completed_count']==16 and not original['active'] and original['failure'] is None
    assert sha(OLD/'ANALYSIS.json')==sha(ROOT/'ORIGINAL_R4_ANALYSIS.json')
    proof=read(OLD/'PARENT_VERIFIED_terminal16.json');assert proof['state']=='passed' and proof['analysis_recomputed_exact']
    files={};sources={}
    provenance=read(ROOT/'COPIED_CONTROL_PROVENANCE.json')
    assert provenance['state']=='exact_source_copy' and provenance['no_training'] is True
    assert len(provenance['original_artifact_hashes'])==24
    for original_file,digest in provenance['original_artifact_hashes'].items():
        original_file=Path(original_file);copy=ROOT/'copied_controls'/original_file.parent.name/original_file.name
        assert sha(copy)==digest,('copied historical control changed',str(copy))
    files[str(ROOT/'COPIED_CONTROL_PROVENANCE.json')]=sha(ROOT/'COPIED_CONTROL_PROVENANCE.json')
    for folder in ['source_i1','source_i2']:
        hashes=read(OLD/(folder+'_hashes.json'));assert len(hashes)==18;sources[folder]=hashes
        for name,digest in hashes.items():
            p=OLD/folder/name;assert sha(p)==digest;files[str(p)]=digest
        files[str(OLD/(folder+'_hashes.json'))]=sha(OLD/(folder+'_hashes.json'))
    for j in original['jobs']+original['smoke_jobs']:
        assert j['state']=='completed'
        hashes=j.get('artifact_hashes',j.get('metrics',{}).get('artifact_hashes'))
        assert hashes
        for name,digest in hashes.items():
            p=Path(j['path'])/name;assert sha(p)==digest;files[str(p)]=digest
    for name in ['ANALYSIS.json','suite_status.json','PARENT_VERIFIED_terminal16.json','LAUNCH_MANIFEST.json','BASE8_REUSE_MANIFEST.json']:
        files[str(OLD/name)]=sha(OLD/name)
    rows=read(ROOT/'INTERNAL5_REFERENCE.json')['rows'];assert len(rows)==40
    assert {(r['method'],r['seed']) for r in rows}=={(m,s) for m in ['fixed90','fixed95','fixed99','linear','critic_aware'] for s in range(21,29)}
    for r in rows:
        p=Path(r['path']);c=read(p/'config.json');s=read(p/'summary.json')
        assert c['seed']==r['seed'] and c['effective_steps']==s['steps']==10027008
        assert s['state']=='completed' and s['reload_check']=='passed' and s['final_eval']['mean']==r['final_return']
        initial=read(p/'initial_evaluation.json');ev=[json.loads(line) for line in (p/'evaluations.jsonl').read_text().splitlines() if line.strip()]
        pts=[(0,initial['mean'])]+[(e['steps'],e['mean']) for e in ev]
        area=sum((y[0]-x[0])*(x[1]+y[1])/2 for x,y in zip(pts,pts[1:]))/10027008
        assert area==r['auc'] and len(ev)==39
        if r['method']=='critic_aware':
            original_source=ROOT.parent/'dpo_external_base8_20260925/source'
            for name,digest in c['source_sha256'].items():
                path=original_source/name;assert sha(path)==digest;files[str(path)]=digest
        names=['config.json','summary.json','status.json','latest.pt','progress.csv','initial_evaluation.json','evaluations.jsonl']
        names+=['lambda_decisions.jsonl'] if r['method']=='critic_aware' else ['best.pt','stress_evaluation.json']
        for name in names:files[str(p/name)]=sha(p/name)
    refs={'formal':{},'smokes':{}}
    for j in original['jobs']+original['smoke_jobs']:
        if j['arm']!='innovation2':continue
        r={'path':j['path'],'gpu':j['gpu'],'artifact_hashes':j.get('artifact_hashes',j.get('metrics',{}).get('artifact_hashes'))}
        if j.get('smoke'):refs['smokes'][str(j['gpu'])]=r
        else:refs['formal'][str(j['seed'])]=r
    assert set(refs['formal'])=={str(s) for s in range(21,29)} and set(refs['smokes'])=={'0','1'}
    for name in ['runs','tmp']:(ROOT/name).mkdir(exist_ok=False)
    (ROOT/'.venv').symlink_to(OLD/'.venv',target_is_directory=True)
    if (OLD/'analysis_dependencies').exists():(ROOT/'analysis_dependencies').symlink_to(OLD/'analysis_dependencies',target_is_directory=True)
    shutil.copytree(OLD/'cache',ROOT/'cache')
    agents=[]
    for a in [ROOT,*ROOT.parents]:
        if (a/'AGENTS.md').is_file():agents.append({'path':str(a/'AGENTS.md'),'text':(a/'AGENTS.md').read_text()})
    inventory={'state':'verified','files':files,'old_r4_source_files':36,'old_r4_formal_runs':16,'old_r4_short_runs':4,
        'internal_controls':40,'original_i2_references':refs,'xml_sha256':'11797a5d69e8ac955e89ca6fdd3a0087f1c990094fda401ac51420de1b6c5494'}
    (ROOT/'PROTECTED_INVENTORY.json').write_text(json.dumps(inventory,indent=2)+'\n')
    out={'state':'prepared','root':str(ROOT),'origin':str(OLD),'protected_files':len(files),'inventory_sha256':sha(ROOT/'PROTECTED_INVENTORY.json'),
        'reference_sha256':sha(ROOT/'INTERNAL5_REFERENCE.json'),'applicable_agents':agents,'disk_free_bytes':shutil.disk_usage(ROOT).free,'training_started':False}
    (ROOT/'REMOTE_PREPARED.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
if __name__=='__main__':main()
