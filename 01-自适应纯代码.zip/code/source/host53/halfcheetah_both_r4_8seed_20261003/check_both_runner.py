"""Check common-seed comparison cannot conceal a stronger internal control."""
import hashlib
import json
from pathlib import Path
import run_both as r
def main():
    jobs=[{'metrics':{'seed':s,'final_return':6000.+s*3.,'auc':4000.+s*2.}} for s in r.SEEDS]
    rows=[{'method':m,'seed':s,'final_return':5700.+s*2.,'auc':3700.+s} for m in r.METHODS for s in r.SEEDS]
    r.controls=lambda:rows
    original=r.read
    r.read=lambda p:{'rows':[{'arm':a,'seed':s,'final_return':5500.+s,'auc':3500.+s} for a in ['innovation1','innovation2'] for s in r.SEEDS]} if Path(p).name=='ORIGINAL_R4_ANALYSIS.json' else original(p)
    out=r.analysis(jobs);assert out['numerical_three_seed_development_pass']
    assert len(out['full8']['comparisons'])==5 and len(out['individual_r4_comparisons'])==2
    for e in r.ENDS:
        saved=[x[e] for x in rows]
        for x in rows:
            if x['method']=='linear':x[e]=99999.
        no=r.analysis(jobs);assert not no['numerical_three_seed_development_pass']
        assert not no['same_seed_beats_all_internal_on_both']
        for x,value in zip(rows,saved):x[e]=value
    for short,budget,cut in [(True,r.SHORT,r.SHORT_SWITCH),(False,r.BUDGET,r.SWITCH)]:
        c=r.command({'seed':21,'gpu':1,'path':'/tmp/not_executed_both','smoke':short})
        assert c[c.index('--steps')+1]==str(budget) and c[c.index('--stage-switch-steps')+1]==str(cut)
        assert c[c.index('--device')+1]=='cuda:1' and '--combined-i1' in c and '--adaptive-kl' in c
    report={'state':'passed','checks':['all5 internal methods and both endpoints required','same seed group across all comparisons','both individual R4 arms compared without rerun','matched short/formal shared scientific configuration'],
        'runner_sha256':r.sha(r.ROOT/'run_both.py'),'check_sha256':r.sha(Path(__file__)),'no_environment_or_optimizer_calls':True}
    (r.ROOT/'RUNNER_BOTH_CHECK.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':main()
