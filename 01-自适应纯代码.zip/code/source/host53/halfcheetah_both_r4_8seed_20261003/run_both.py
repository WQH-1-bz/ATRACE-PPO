"""Exact cross-GPU admission and eight deterministic combined R4 runs."""
import argparse
import csv
import importlib.util
import json
import math
import os
from pathlib import Path
import statistics
import struct
import subprocess
import sys
import time
import traceback
sys.dont_write_bytecode=True
import torch
import r4_helpers as h

ROOT=Path(__file__).resolve().parent
SEEDS=tuple(range(21,29));METHODS=('fixed90','fixed95','fixed99','linear','critic_aware');ENDS=('final_return','auc')
BUDGET,SHORT,SWITCH,SHORT_SWITCH=10027008,524288,4980736,262144
DET=h.DET
ENV={**h.ENV,'PYTHONPATH':str(ROOT/'analysis_dependencies')}
def read(p):return h.read(Path(p))
def sha(p):return h.sha(Path(p))
def write(p,x):h.write(Path(p),x)
def lines(p):return h.jsonl(Path(p))
def equal(a,b):assert struct.pack('!d',float(a))==struct.pack('!d',float(b)),(a,b)
def controls():return read(ROOT/'INTERNAL5_REFERENCE.json')['rows']
def audits(config):return config['retained_tail_trace_design']['audit_updates']
h.split_audit_updates=audits

def check_sources():
    m=read(ROOT/'LAUNCH_MANIFEST.json');assert m['state']=='frozen' and m['seeds']==list(SEEDS) and m['formal_total']==8
    assert m['gpus']==[0,1] and m['max_per_gpu']==4
    assert len(m['source_hashes'])==18
    for name,digest in m['source_hashes'].items():
        p=ROOT/'source_i2'/name;assert sha(p)==digest and not(p.stat().st_mode&0o222)
    for name,digest in m['program_hashes'].items():assert sha(ROOT/name)==digest,('program changed',name)
    for name,digest in m['reference_hashes'].items():assert sha(ROOT/name)==digest
    return m

def protected():
    inv=read(ROOT/'PROTECTED_INVENTORY.json')
    for p,digest in inv['files'].items():assert sha(p)==digest,('protected file changed',p)
    rs=controls();assert len(rs)==40 and {(r['method'],r['seed']) for r in rs}=={(m,s) for m in METHODS for s in SEEDS}
    for r in rs:
        p=Path(r['path']);c=read(p/'config.json');s=read(p/'summary.json')
        assert c['seed']==r['seed'] and c['effective_steps']==s['steps']==BUDGET and c['determinism']==DET
        assert c['xml_sha256']==inv['xml_sha256'] and s['state']=='completed' and s['reload_check']=='passed'
        if r['method']=='critic_aware':
            assert c['method']=='critic_aware' and c['task']=='HalfCheetah'
            assert 'noise_mode' not in c and 'noise_scale' not in c
            # Historical critic-aware was frozen before the unrelated Reacher
            # support addition. Verify its own original source, not new code.
            original_source=ROOT.parent/'dpo_external_base8_20260925/source'
            for name,digest in c['source_sha256'].items():assert sha(original_source/name)==digest
        else:assert c['noise_mode']=='none' and c['noise_scale']==0
        area,_,ev=h.auc(p,BUDGET,'HalfCheetah');equal(area,r['auc']);equal(s['final_eval']['mean'],r['final_return']);assert len(ev)==39
    return {'state':'passed','protected_files':len(inv['files']),'old_r4_runs':16,'internal_controls':40}

def command(j):
    short=j.get('smoke',False)
    return [str(ROOT/'.venv/bin/python'),str(ROOT/'source_i2/train_pae_baseline.py'),
        '--out',j['path'],'--method','pae','--task','HalfCheetah','--seed',str(j['seed']),
        '--device',f"cuda:{j['gpu']}",'--steps',str(SHORT if short else BUDGET),
        '--num-envs','1024','--rollout','64','--batch-size','1024','--eval-envs','32','--eval-every','262144',
        '--staged-full','--stage-switch-steps',str(SHORT_SWITCH if short else SWITCH),
        '--retained-tail-steps','8','--retained-tail-diagnostics','--retained-tail-correction',
        '--retained-td-unclipped','--save-split-trace-audit','--adaptive-kl','--combined-i1',
        '--overlap-start-steps','0','--overlap-stop-steps',str(SHORT if short else BUDGET)]

def controller():
    name='both_frozen_kl'
    if name not in sys.modules:
        spec=importlib.util.spec_from_file_location(name,ROOT/'source_i2/lambda_kl_relative.py')
        mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod)
    return sys.modules[name].KLFeedback()

def verify_audits(p,c,ds,ledger):
    fun=h.source_i2_functions();out=[];separation=False
    for u in audits(c):
        name=f'split_trace_audit_{u:03d}.pt';r=torch.load(p/name,map_location='cpu',weights_only=False);l=ledger[u-1]
        assert r['update']==u and r['steps']==l['steps'] and r['prior_collected_steps']==l['prior']
        assert r['used_per_world']==l['used'] and r['end_per_world']==l['end'] and r['retained_per_world']==l['incoming']
        equal(r['actor_lambda'],ds[u-1]['used']);equal(r['critic_lambda'],.95)
        assert r['gamma']==.99 and r['target_device']==c['device']
        keys=('normalized_reward','values','next_values','terminated','done','trace_logratios','raw_rhos','capped_cs')
        for key in keys+('actor_advantage','consumed_critic_return'):
            x=r[key];assert x.device.type=='cpu' and not x.requires_grad
            assert x.shape==((l['used'] if key in ('actor_advantage','consumed_critic_return') else l['end']),1024)
            assert x.dtype==(torch.bool if key in ('terminated','done') else torch.float32)
            if x.dtype!=torch.bool:assert torch.isfinite(x).all()
        assert not(r['terminated']&~r['done']).any()
        xs=[r[k].to(c['device']) for k in keys[:5]];logs,rho,cap=[r[k].to(c['device']) for k in keys[5:]]
        with torch.no_grad():
            assert torch.equal(rho,logs.exp()) and torch.equal(cap,logs.clamp(max=0).exp())
            assert (logs[l['incoming']:] == 0).all() and (rho[l['incoming']:] == 1).all() and (cap[l['incoming']:] == 1).all()
            for _ in range(3):fun.split_tail_trace(*xs,rho,cap,.99,.95)
            actor,_=fun.split_tail_trace(*xs,rho,cap,.99,r['actor_lambda'])
            _,critic=fun.split_tail_trace(*xs,rho,cap,.99,.95)
            assert torch.equal(actor[:l['used']],r['actor_advantage'].to(c['device'])),('actor replay',name)
            assert torch.equal(critic[:l['used']],r['consumed_critic_return'].to(c['device'])),('critic replay',name)
            corrupt=r['consumed_critic_return'].to(c['device']).clone();corrupt[0,0]+=1.
            assert not torch.equal(critic[:l['used']],corrupt)
            fixed_actor,_=fun.split_tail_trace(*xs,rho,cap,.99,.95)
            separation=separation or (r['actor_lambda']!=.95 and not torch.equal(actor,fixed_actor))
        out.append({'update':u,'window':l['end'],'used':l['used'],'actor_lambda':r['actor_lambda'],'critic_lambda':.95,
            'dual_target_replay':'passed','artifact_sha256':sha(p/name)})
    assert separation,'No measured adaptive actor/fixed critic separation'
    return out

def verify(j):
    p=Path(j['path']);short=bool(j.get('smoke'));budget=SHORT if short else BUDGET;cut=SHORT_SWITCH if short else SWITCH
    c=read(p/'config.json');s=read(p/'summary.json');assert s==read(p/'status.json') and s['state']=='completed' and s['reload_check']=='passed'
    assert c['combined_i1'] and c['adaptive_kl'] and c['staged_full'] and c['retained_tail_correction'] and c['retained_td_unclipped'] and c['save_split_trace_audit']
    assert not(c['readiness_boost'] or c['adaptive_overlap'] or c['force_pae_overlap'])
    assert c['task']=='HalfCheetah' and c['method']=='pae' and c['seed']==j['seed'] and c['device']==f"cuda:{j['gpu']}" and c['determinism']==DET
    assert c['effective_steps']==c['steps']==s['steps']==s['training_transitions']==s['total_algorithm_transitions']==budget
    assert c['stage_switch_steps']==cut and c['pae_prefix']==56 and c['pae_tail']==8
    for key,val in [('num_envs',1024),('rollout',64),('batch_size',1024),('epochs',10),('eval_envs',32),('eval_every',262144),('gamma',.99)]:assert c[key]==val
    assert c['xml_sha256']==read(ROOT/'PROTECTED_INVENTORY.json')['xml_sha256']
    for name,digest in c['source_sha256'].items():assert sha(ROOT/'source_i2'/name)==digest
    rows=list(csv.DictReader((p/'progress.csv').open()));ds=lines(p/'lambda_decisions.jsonl');diags=lines(p/'retained_tail_diagnostics.jsonl')
    count,early=(9,5) if short else (164,87);assert len(rows)==len(ds)==len(diags)==count
    assert audits(c)==[3,early-1,early,early+1,count]
    k=controller();prior=retained=trained=flushes=0;ledger=[];lambdas=[];incoming=[]
    for u,(row,d,diag) in enumerate(zip(rows,ds,diags),1):
        overlap=prior<cut;fresh=min(64-retained,(budget-prior)//1024,(cut-prior)//1024 if overlap else (budget-prior)//1024)
        end=retained+fresh;steps=prior+fresh*1024;flush=overlap and steps==cut;used=end if flush or steps==budget else min(56 if overlap else 64,end)
        assert int(row['steps'])==d['steps']==diag['steps']==steps
        assert int(row['fresh_per_world'])==diag['fresh_per_world']==fresh and int(row['used_per_world'])==diag['used_per_world']==used
        assert row['overlap_active'].lower()==str(overlap).lower() and row['stage_boundary_flush'].lower()==str(flush).lower()
        assert diag['stage_boundary_flush'] is flush and diag['retained_per_world']==retained and diag['retained_count']==retained*1024
        assert int(row['retained_per_world'])==diag['retained_out_per_world']==end-used
        assert d['update']==diag['update']==u and d['prior_collected_steps']==prior and d['adaptive_steps_ready'] is (prior>=cut)
        if prior>=cut:k.step(u)
        equal(k.value,d['used']);equal(k.value,d['actor_lambda_used']);equal(.95,d['critic_lambda_used'])
        equal(row['gae_lambda_used'],k.value);equal(row['gae_lambda_next'],k.value)
        equal(diag['trace_lambda'],k.value);equal(diag['critic_trace_lambda'],.95)
        k.observe(d['realized_kl'])
        for key,v in k.state_dict().items():equal(v,d[key])
        equal(k.value,d['next']);assert not d['readiness_active'] and d['overlap_active'] is overlap
        for val in diag.values():
            if isinstance(val,(float,int)) and not isinstance(val,bool):assert math.isfinite(val)
        for kind in ('actor','critic'):
            assert diag[f'fresh_{kind}_correction_nonzero_count']==0 and diag[f'fresh_{kind}_correction_max_abs']==0
        ledger.append({'prior':prior,'steps':steps,'used':used,'end':end,'incoming':retained})
        incoming.append(retained);lambdas.append(k.value);trained+=used*1024;flushes+=int(flush);prior=steps;retained=end-used
    assert prior==trained==budget and retained==0 and flushes==1
    assert lambdas[:early]==[.95]*early and any(v!=.95 for v in lambdas[early:])
    assert c['combined_design']['hold_updates']==early and c['combined_design']['first_adaptive_update']==early+1
    assert s['optimizer_steps']=={'actor':budget//1024*10,'critic':budget//1024*10,'h':0}
    chk=h.checkpoint_steps(p,'innovation2',budget//1024*10);assert chk['kl_feedback']==k.state_dict() and chk['steps']==budget
    detail=h.verify_split_diagnostics(diags,incoming)
    actual_audits=verify_audits(p,c,ds,ledger)
    area,initial,ev=h.auc(p,budget,'HalfCheetah');assert len(ev)==(2 if short else 39)
    next_eval=262144;expected=[]
    for l in ledger:
        if l['steps']>=next_eval or l['steps']==budget:expected.append(l['steps']);next_eval=(l['steps']//262144+1)*262144
    assert [v['steps'] for v in ev]==expected;equal(ev[-1]['mean'],s['final_eval']['mean'])
    assert abs(area-s['normalized_return_auc'])<1e-10
    inv=read(ROOT/'PROTECTED_INVENTORY.json');ref=inv['original_i2_references']['smokes'][str(j['gpu'])] if short else inv['original_i2_references']['formal'][str(j['seed'])]
    old=Path(ref['path']);assert (p/'initial_evaluation.json').read_bytes()==(old/'initial_evaluation.json').read_bytes()
    def prefix(path):return [line for line in (path/'evaluations.jsonl').read_bytes().splitlines() if json.loads(line)['steps']<=cut]
    assert prefix(p)==prefix(old),'Held I2 evaluation prefix changed'
    for u in [3,early-1]:
        name=f'split_trace_audit_{u:03d}.pt';a=torch.load(p/name,map_location='cpu',weights_only=False);b=torch.load(old/name,map_location='cpu',weights_only=False)
        a.pop('target_device');b.pop('target_device');assert not h.differences(a,b),'Held I2 target audit changed'
    stress=read(p/'stress_evaluation.json');assert [(x['mode'],x['scale']) for x in stress]==[('none',0.),('gaussian',.10),('gaussian',.15),('gaussian',.30),('multiplicative',.20),('multiplicative',.30)]
    for batch in stress:h.batch(batch,'HalfCheetah')
    names=['config.json','summary.json','status.json','latest.pt','progress.csv','initial_evaluation.json','evaluations.jsonl','lambda_decisions.jsonl','retained_tail_diagnostics.jsonl','stress_evaluation.json']+[f'split_trace_audit_{u:03d}.pt' for u in audits(c)]
    return {'seed':j['seed'],'path':j['path'],'final_return':s['final_eval']['mean'],'auc':area,'initial_return':initial['mean'],
        'steps':budget,'updates':count,'hold_updates':early,'first_adaptive_update':early+1,'lambda_min':min(lambdas),'lambda_max':max(lambdas),'lambda_final':lambdas[-1],
        'changed_updates':sum(v!=.95 for v in lambdas),'controller_replay':'passed','held_i2_prefix_and_targets_exact':True,
        'dual_target_audits':actual_audits,'sample_ledger':'passed','adam_calls':budget//1024*10,**detail,
        'artifact_hashes':{name:sha(p/name) for name in names}}

def pair(smokes):
    result=h.exact_pair(smokes[0]['path'],smokes[1]['path'],'innovation2')
    for name in ['lambda_decisions.jsonl','stress_evaluation.json']:
        assert (Path(smokes[0]['path'])/name).read_bytes()==(Path(smokes[1]['path'])/name).read_bytes(),name
    return {**result,'both_controller_and_stress_exact':True}

def analysis(jobs):
    rows=[j['metrics'] for j in jobs];lookup={r['seed']:r for r in rows};base={(r['method'],r['seed']):r for r in controls()}
    def group(ids):
        tests=[];comp={}
        for m in METHODS:
            comp[m]={}
            for e in ENDS:
                a=[lookup[s][e] for s in ids];b=[base[(m,s)][e] for s in ids]
                t={**h.paired(a,b),'ours_mean':statistics.mean(a),'ours_sd':statistics.stdev(a),'base_mean':statistics.mean(b),'base_sd':statistics.stdev(b),'paired_differences':[x-y for x,y in zip(a,b)]}
                tests.append(t);comp[m][e]=t
        carry=0.
        for i,t in enumerate(sorted(tests,key=lambda x:x['p_two_sided'])):carry=max(carry,min(1.,(10-i)*t['p_two_sided']));t['p_holm10']=carry
        return {'seeds':list(ids),'comparisons':comp,'mean_both_beats_every_internal':all(t['mean_difference']>0 for t in tests),'valid_independent_confirmation':False}
    scores=[]
    for s in SEEDS:
        gains=[(lookup[s][e]-base[(m,s)][e])/(statistics.stdev(base[(m,k)][e] for k in SEEDS) or 1.) for m in METHODS for e in ENDS]
        scores.append({'seed':s,'minimum_normalized_gain':min(gains)})
    scores.sort(key=lambda r:(-r['minimum_normalized_gain'],r['seed']))
    gs={'prior3':group([24,26,27]),'prior5':group([21,22,24,26,27]),'ranked3':group([r['seed'] for r in scores[:3]]),'ranked5':group([r['seed'] for r in scores[:5]])}
    old=read(ROOT/'ORIGINAL_R4_ANALYSIS.json')['rows'];individual={}
    for arm in ['innovation1','innovation2']:
        ref={r['seed']:r for r in old if r['arm']==arm};individual[arm]={}
        for e in ENDS:
            a=[lookup[s][e] for s in SEEDS];b=[ref[s][e] for s in SEEDS]
            individual[arm][e]={**h.paired(a,b),'ours_mean':statistics.mean(a),'individual_mean':statistics.mean(b),'paired_differences':[x-y for x,y in zip(a,b)]}
    return {'state':'completed','round':'HC_BOTH_R4','rows':rows,'base_rows':controls(),'full8':group(SEEDS),'groups':gs,
        'common_descriptive_ranking':scores,'individual_r4_comparisons':individual,
        'same_seed_beats_all_internal_on_both':[s for s in SEEDS if all(lookup[s][e]>base[(m,s)][e] for m in METHODS for e in ENDS)],
        'numerical_three_seed_development_pass':any(gs[g]['mean_both_beats_every_internal'] for g in ['prior3','ranked3']),
        'inference_scope':'reused development seeds; selected groups exploratory; no untouched confirmatory significance'}

def snapshot():
    raw=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'],text=True,timeout=15)
    free={int(x.split(',')[0]):int(x.split(',')[1]) for x in raw.splitlines()};memory={}
    raw=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,used_gpu_memory','--format=csv,noheader,nounits'],text=True,timeout=15)
    for x in raw.splitlines():
        try:p,m=[int(y.strip()) for y in x.split(',')];memory[p]=m
        except ValueError:pass
    return free,memory

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--prepare-only',action='store_true');ap.add_argument('--verify-startup',action='store_true');ap.add_argument('--verify-only',action='store_true');args=ap.parse_args()
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True);check_sources();proof=protected()
    if args.verify_startup or args.verify_only:
        suite=read(ROOT/'suite_status.json');assert suite['engineering_gate']['state']=='passed' and suite['failure'] is None
        for j in suite['smoke_jobs']:assert verify(j)==j['metrics']
        assert pair(suite['smoke_jobs'])['state']=='passed' and len(suite['jobs'])==8
        if args.verify_only:
            assert suite['state']=='completed' and suite['completed_count']==8 and not suite['active']
            for j in suite['jobs']:assert verify(j)==j['metrics']
            assert analysis(suite['jobs'])==read(ROOT/'ANALYSIS.json')
        write(ROOT/('PARENT_VERIFIED_terminal8.json' if args.verify_only else 'PARENT_VERIFIED_startup.json'),{'state':'passed',**proof,'exact_short_pair_reverified':True,'all8_results_reverified':bool(args.verify_only)})
        print('Native Both event verification passed');return 0
    jobs=[{'id':f'HalfCheetah__both__seed{s}','seed':s,'gpu':(s-21)%2,'path':str(ROOT/'runs'/f'HalfCheetah__both__seed{s}'),'state':'pending'} for s in SEEDS]
    smokes=[{'id':f'smoke__both__{g}','seed':91063,'gpu':g,'path':str(ROOT/'runs'/f'smoke__both__{g}'),'state':'pending','smoke':True} for g in [0,1]]
    assert all(not Path(j['path']).exists() for j in jobs+smokes)
    write(ROOT/'PREPARE_PASSED.json',{'state':'passed','formal_total':8,'short_repeats':2,**proof})
    if args.prepare_only:print('Both prepare passed: eight new jobs and preserved controls');return 0
    assert not(ROOT/'suite_status.json').exists()
    active={};failure=None;gate=None;peak=0;reservation=3500;start=time.time()
    def status(state):write(ROOT/'suite_status.json',{'state':state,'round':'HC_BOTH_R4','total':8,'completed_count':sum(j['state']=='completed' for j in jobs),
        'jobs':jobs,'smoke_jobs':smokes,'active':{k:{'pid':v[0].pid,'gpu':v[2]['gpu'],'smoke':bool(v[2].get('smoke'))} for k,v in active.items()},
        'failure':failure,'engineering_gate':gate,'reservation_mib':reservation,'elapsed_seconds':time.time()-start,'coordinator_pid':os.getpid()})
    def launch(j):
        logfile=ROOT/(j['id']+'.log');handle=logfile.open('x');cmd=command(j)
        try:proc=subprocess.Popen(cmd,cwd=ROOT/'source_i2',env=ENV,stdout=handle,stderr=subprocess.STDOUT)
        except BaseException:handle.close();raise
        j.update(state='running',pid=proc.pid,log=str(logfile),command=cmd);active[j['id']]=(proc,handle,j)
    status('queued')
    try:
        while True:
            free,memory=snapshot()
            for proc,_,j in active.values():
                if j.get('smoke'):peak=max(peak,memory.get(proc.pid,0))
            for key,(proc,handle,j) in list(active.items()):
                code=proc.poll()
                if code is None:continue
                handle.close();del active[key]
                try:
                    assert code==0,(j['id'],code);j['metrics']=verify(j);j['state']='completed'
                except BaseException as e:
                    j['state']='failed'
                    if failure is None:failure={'id':j['id'],'error':repr(e),'log':j['log'],'traceback':traceback.format_exc()}
            if not failure and gate is None and all(j['state']=='completed' for j in smokes):
                try:
                    gate=pair(smokes);assert peak>0;reservation=max(3500,peak+256)
                    gate.update(peak_mib=peak,reservation_mib=reservation,dual_lambda_replays_exact=True,held_i2_prefix_exact=True)
                    check_sources();protected();write(ROOT/'SMOKE_VERIFIED.json',gate)
                except BaseException as e:failure={'id':'engineering_gate','error':repr(e),'traceback':traceback.format_exc()}
            if failure:
                status('failure_active_workers_preserved' if active else 'failed')
                if not active:return 1
            elif all(j['state']=='completed' for j in jobs):
                check_sources();protected();write(ROOT/'ANALYSIS.json',analysis(jobs));status('completed');return 0
            else:
                pool=jobs if gate else smokes
                for gpu in [0,1]:
                    limit=4 if gate else 1
                    while sum(v[2]['gpu']==gpu for v in active.values())<limit:
                        pending=next((j for j in pool if j['state']=='pending' and j['gpu']==gpu),None)
                        if pending is None:break
                        free,memory=snapshot();outstanding=sum(max(0,reservation-memory.get(v[0].pid,0)) for v in active.values() if v[2]['gpu']==gpu)
                        if free[gpu]-outstanding<reservation+512:break
                        launch(pending)
                status('running' if active else 'waiting_for_gpu_memory')
            time.sleep(2)
    except BaseException as e:
        failure={'id':'coordinator','error':repr(e),'traceback':traceback.format_exc()};status('failed_active_workers_preserved' if active else 'failed');raise
if __name__=='__main__':sys.exit(main())
