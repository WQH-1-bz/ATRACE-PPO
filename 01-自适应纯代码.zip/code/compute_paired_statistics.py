"""Retrospective paired statistics, preserving the original five-environment families."""
from pathlib import Path
import argparse,json,csv,itertools,math
import numpy as np
from scipy import stats

def main():
 p=argparse.ArgumentParser();p.add_argument('--weights-root',type=Path,required=True);p.add_argument('--out',type=Path);a=p.parse_args();d=json.loads((a.weights_root/'report_source/data.json').read_text());rows=[]
 labels={'fixed90':'固定λ=0.90','fixed95':'Base：固定λ=0.95','fixed99':'固定λ=0.99','linear':'线性λ调度','critic_aware':'Critic-aware自适应GAE','gradient_ppo':'Gradient PPO','reward_profiling':'PPO+Lookback Reward Profiling','pae':'PAE'}
 for e in d['environment_order']:
  for metric in ['final','auc']:
   for m in d['method_order'][:8]:
    x=np.asarray(d['environments'][e]['methods']['Full'][metric])-np.asarray(d['environments'][e]['methods'][m][metric]);mean=float(x.mean());se=float(x.std(ddof=1))/math.sqrt(8);t=mean/se if se else 0.;pv=float(stats.t.sf(abs(t),7)*2) if se else (0. if mean else 1.);ci=float(stats.t.ppf(.975,7))*se
    exact=sum(abs(float(np.mean(x*np.array(sig))))>=abs(mean)-1e-12 for sig in itertools.product([-1,1],repeat=8))/256
    rows.append({'环境':e,'指标':metric,'对比方法':labels[m],'n':8,'Full−对比均值':mean,'95%CI下界':mean-ci,'95%CI上界':mean+ci,'配对t':t,'df':7,'双侧p':pv,'Holm校正p':None,'精确符号翻转p':exact,'正差种子数':int(sum(x>0)),'比较族':'主比较10项：Full对固定0.95，五环境×两指标' if m=='fixed95' else '次比较70项：Full对其他七基线，五环境×两指标'})
 for family in {r['比较族'] for r in rows}:
  rr=sorted([r for r in rows if r['比较族']==family],key=lambda r:r['双侧p']);running=0.
  for i,r in enumerate(rr):running=max(running,min(1.,(len(rr)-i)*r['双侧p']));r['Holm校正p']=running
 out=a.out or a.weights_root/'statistics/paired_statistics.csv';out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 print('Wrote80paired comparisons, originalHolm families10and70:',out)
if __name__=='__main__':main()
