# 代码包
本包仅包含项目源代码、运行环境XML资产、依赖清单与使用说明，不含模型权重、实验日志、评估结果、论文或虚拟环境。

## 结构
- source/：当前四环境及历史Walker2d及各方法实际使用的源码快照；保留原相对目录与模块关系。
- legacy_source/：历史Hopper、Reacher和Walker2d对应源码，单独存放。
- supplementary/pointmaze_tail_sensitivity/：尾段8/16/24参数敏感性实验代码。
- analysis/：结果统计及报告制图源代码；这些原脚本保留了实验工作区路径，迁移运行时需调整数据根目录。
- inference.py：原归档推理模块，含观测归一化。
- predict.py：支持指定独立权重目录的推理入口，不自动选择种子。

## 推理
解压两个包后，使用权重包中的输入样例：
```
python predict.py --weights-root ../weights --environment PointMaze --seed 21 --method Full --input ../weights/inference_examples/PointMaze.json --device cuda:0
```
输入为原始观测，输出确定性策略均值及裁剪至[-1,1]的控制量。输入样例只用于接口验证，不等于完整环境评估。完整episode需要相应环境适配代码。

## 训练与源码定位
先安装requirements-training.txt；CUDA版Torch使用与机器匹配的PyTorch安装源，本实验实际运行时为2.8.0+cu128。物理仿真使用MuJoCo Warp，实验确定性设置为DPO_TORCH_DETERMINISTIC=1、DPO_WARP_DETERMINISTIC=run_to_run、DPO_WARP_DETERMINISTIC_MAX_RECORDS=8、CUBLAS_WORKSPACE_CONFIG=:4096:8、OMP_NUM_THREADS=1、MKL_NUM_THREADS=1。
每组权重目录的config.json记录实际参数；权重包SOURCE_BINDINGS.json将配置中的源码SHA256映射到本代码包的具体文件。源码保留每组真实实现，没有合并成一个未经验证的新训练入口。部分原调度／诊断脚本包含原服务器路径，迁移时需调整目录；主要训练模块及环境资产保留原相对结构。
标准MuJoCo环境所需的第三方模型资产随相应Python依赖安装，本包不包含第三方虚拟环境。参数敏感性实验的调度脚本原路径亦需按目标机器设置。


## 2026-10-15更新：最新Fig.2–7
当前图表环境为HalfCheetah、Swimmer、PointMaze、CartpoleSwingup。Walker2d保留在权重包legacy_models中，不进入当前四环境图。所有训练权重数值均未改变。
安装requirements-analysis.txt后，从解压后的code目录运行：
```
python analysis/sci_figures_20261015/build_figures.py --weights-root ../weights --out ./figure_outputs
```
新绘图入口不依赖原工作区绝对路径；其输入评估记录、Full实际λ轨迹、主数据与统计表均已放入权重包。直接使用实际评估步数，不平滑、不插值；保留全部8个种子。原analysis目录的旧报告脚本保留原路径，新图请使用上述入口。
如需重新计算配对统计，运行：
```
python compute_paired_statistics.py --weights-root ../weights
```
统计保留原五环境×两指标的十项Full–Base Holm比较族。原始阶段的反复开发仍属回顾性分析；四环境显示不重新缩减校正族。

方法名称对应：innovation1目录对应图中的Feedback only；innovation2目录对应Tail only；Full为组合方法。目录名保留以兼容原配置及推理接口。
