"""Run an archived policy with a separately extracted weights directory."""
import argparse,json,pathlib,sys,importlib.util

def main():
 p=argparse.ArgumentParser();p.add_argument('--weights-root',type=pathlib.Path,required=True);p.add_argument('--environment',required=True);p.add_argument('--seed',type=int,required=True);p.add_argument('--method',default='Full');p.add_argument('--input',type=pathlib.Path,required=True);p.add_argument('--device',default='cpu');a=p.parse_args()
 spec=importlib.util.spec_from_file_location('archived_inference',pathlib.Path(__file__).with_name('inference.py'));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.ROOT=a.weights_root.resolve()
 policy=module.load_policy(a.environment,a.seed,a.method,a.device);obs=json.loads(a.input.read_text());print(json.dumps({'metadata':policy.metadata,'raw_action_mean':policy(obs).cpu().tolist(),'clipped_control':policy(obs,True).cpu().tolist()},ensure_ascii=False))
if __name__=='__main__':main()
