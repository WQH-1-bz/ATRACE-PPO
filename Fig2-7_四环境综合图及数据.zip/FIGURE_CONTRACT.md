# Figure contract
Backend: saved Python preference, matplotlib only. Quantitative grids, editable PDF/SVG and600dpiPNG/TIFF.
User-requested environment subset: HalfCheetah,Swimmer,PointMaze,Cartpole Swingup; Walker2d omitted only from display, never silently from the original statistical correction family.
Fig2 internal learning; Fig3 external learning: each method's native actual evaluation steps, eight-seed arithmetic mean±sampleSD; no smoothing, no interpolation, no resampling. Different methods can have different native evaluation times.
Fig4 nine-method Final/AUC summaries plus allseed observations. Fig5 paired Full−Base means with95%two-sidedtCI df7; existingHolm10comparisonfamily retained; only requested significantAUCpanels annotated. Fig6 actual task-specific fourarm configurations, notstrict matchedfactorial. Fig7 actualactorlambda staircase traces; sharedrange within each row; stageboundary4.980736million.
All eight seeds21–28 retained. n denotes independent training seeds, not episodes. No modelselection/subsetselection of seeds. Colours: darknavyFull, darkgreyBase, muted distinctbaseline colours plus dash patterns. Lower fontfloor6.5pt, width183mm.
