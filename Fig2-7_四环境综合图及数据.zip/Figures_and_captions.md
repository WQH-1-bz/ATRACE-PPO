# Four-environment results: Figures 2–7

## Fig. 2

![](Fig2_internal_learning.png){width=17cm}

Fig. 2 | Learning curves against internal λ baselines. Panels (a–d) show HalfCheetah, Swimmer, PointMaze and Cartpole Swingup. Lines show the arithmetic mean over eight training seeds (21–28); shaded regions show one sample standard deviation (ddof=1). Each method is plotted at its actual evaluation steps. No smoothing, interpolation or resampling is applied. The horizontal axis counts fresh training transitions.

## Fig. 3

![](Fig3_external_learning.png){width=17cm}

Fig. 3 | Learning curves against external PPO methods. The four environments and eight training seeds are the same as in Fig. 2. Lines indicate means and shaded regions indicate sample standard deviations. Curves use native evaluation steps without smoothing or interpolation. Reward Profiling uses additional profiling interactions that are not included in the primary fresh-transition axis. These additional interactions are reported separately in the source-data workbook.

## Fig. 4

![](Fig4_all_methods_final_auc.png){width=17cm}

Fig. 4 | Final return and normalized return AUC for all nine methods. The first row shows final-checkpoint return and the second row shows normalized AUC; columns correspond to the four environments. Large points and horizontal intervals indicate eight-seed means and sample standard deviations. Faint points show all individual training seeds, with fixed vertical offsets for visibility. Every panel has its own horizontal scale. Normalized AUC is the trapezoidal integral of the native evaluation trajectory, including the initial evaluation, divided by 10,027,008 fresh transitions.

## Fig. 5

![](Fig5_full_base_paired_difference.png){width=17cm}

Fig. 5 | Paired Full–Base differences. The upper row shows final-return differences and the lower row shows normalized-AUC differences. Faint points represent all eight matched training seeds; dark points represent mean paired differences. Horizontal intervals are two-sided 95% t confidence intervals (df=7), not sample standard deviations. The vertical dashed line marks zero. Displayed Holm-adjusted p values retain the original family of ten Full–Base comparisons (five environments × two metrics), although Walker2d is omitted from this figure. Only PointMaze AUC (p_adj=0.0025) and Cartpole AUC (p_adj=0.0049) are annotated. Analyses are retrospective on development seeds; the confidence intervals are not multiplicity-adjusted.

## Fig. 6

![](Fig6_component_comparison.png){width=17cm}

Fig. 6 | Component comparisons in four environments. The first row shows final return and the second row shows normalized AUC. Within each panel, faint lines connect the same training seed across Base, Feedback only, Tail only and Full. Large points and intervals denote eight-seed means and sample standard deviations. The four arms represent the actual task-specific configurations rather than a strictly matched factorial ablation.

## Fig. 7

![](Fig7_actor_lambda_trajectories.png){width=17cm}

Fig. 7 | Actual actor trace-parameter trajectories. Faint step lines show all eight seeds and the dark line shows their arithmetic mean. No smoothing is applied. The dashed vertical line marks the predetermined stage boundary at 4,980,736 fresh transitions. The upper row shares a λ range of 0.930–0.955; the lower row shares 0.982–0.991. Swimmer remains at λ=0.95 and is shown without adding artificial variation. Target λ values, where preserved, are supplied separately in the source-data workbook.

