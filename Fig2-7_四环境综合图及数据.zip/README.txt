Fig.2–7：四环境综合图
环境顺序：HalfCheetah、Swimmer、PointMaze、Cartpole Swingup。已去除Walker2d。
每图提供可编辑PDF/SVG及600dpi PNG/TIFF。Fig2-7_Combined.pdf为六图预览。
Fig2-7_SourceData.xlsx前四页为均值±样本标准差的主结果表及组件表，后续为各图汇总数据、全部逐种子学习曲线、配对差／95%CI／Holm p、λ轨迹和target字段、Reward Profiling额外交互预算。所有18张表均有独立CSV。
Figure_captions.txt含可直接使用的英文图注，包含额外profiling交互说明及组件比较限定。
统计保留原五环境×两指标十项Holm比较族，主图只显示四环境；因此对应校正值保持0.0025与0.0049。
不平滑，不插值，不挑种子。build_figures.py为完整复算／绘图脚本；使用已保存的实验数据根目录，迁移时需调整R。
